/*
 * Copyright 2003-2010 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.codehaus.groovy.classgen

print """

public class ArrayUtil {
   ${genMethods()}
}

"""

def genMethods () {
    def res = ""
    for (i in 1..250)
      res += "\n\n" + genMethod (i)
    res
}

def genMethod (int paramNum) {
    def res = "public static Object [] createArray ("
    for (k in 0..<paramNum) {
        res += "Object arg" + k
        if (k != paramNum-1)
          res += ", "
    }
    res += ") {\n"
    res += "return new Object [] {\n"
        for (k in 0..<paramNum) {
            res += "arg" + k
            if (k != paramNum-1)
              res += ", "
        }
        res += "};\n"
    res += "}"
    res
}
