/*
 * Copyright (C) 2004-2012 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2010 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.polarion.alm.wiki.internal;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.Logger;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import com.polarion.alm.tracker.model.IPlan;
import com.polarion.alm.tracker.model.ITestRun;
import com.polarion.alm.tracker.model.IWikiPage;
import com.polarion.core.util.ObjectUtils;
import com.polarion.platform.context.IContextService;
import com.polarion.platform.core.PlatformContext;
import com.polarion.platform.persistence.internal.IWikiPagePersistenceListener;
import com.polarion.platform.service.repository.IExtendedFileChangesListener;
import com.polarion.platform.service.repository.IRepositoryService;
import com.polarion.subterra.base.SubterraURI;
import com.polarion.subterra.base.data.identification.ILocalId;
import com.polarion.subterra.base.data.identification.IObjectId;
import com.polarion.subterra.base.data.identification.IObjectResolver;
import com.polarion.subterra.base.location.ILocation;
import com.polarion.subterra.base.location.Location;
import com.polarion.wiki.util.Constants;
import com.xpn.xwiki.cache.api.XWikiCache;
import com.xpn.xwiki.store.XWikiCacheStore;
import com.xpn.xwiki.store.XWikiCacheStoreProvider;

/**
 * @author <a href="mailto:dev@polarion.com">Jakub Stroleny</a>, Polarion Software
 */
public class WikiPagePersistenceListener implements IWikiPagePersistenceListener, IExtendedFileChangesListener {

    @NotNull
    private static final Logger log = Logger.getLogger(WikiPagePersistenceListener.class);

    @NotNull
    private static final ThreadLocal<Set<ILocation>> changedLocations = new ThreadLocal<Set<ILocation>>();

    public WikiPagePersistenceListener(IRepositoryService repoService, IContextService contextService) {
        initWikiPagePersistenceListener(repoService);
        initWikiSpacePersistenceListener(repoService, contextService);
    }

    private void initWikiPagePersistenceListener(@NotNull IRepositoryService repoService) {
        ILocation loc = Location.getLocationWithRepository(IRepositoryService.DEFAULT, "/.polarion/user-management/users/"); //$NON-NLS-1$
        repoService.addFileChangesListener(this, Arrays.asList(loc));
    }

    private void initWikiSpacePersistenceListener(@NotNull IRepositoryService repoService, @NotNull IContextService contextService) {
        WikiSpacePersistenceListener wikiSpaceListener = new WikiSpacePersistenceListener();
        repoService.addFileChangesListener(wikiSpaceListener);
        contextService.addContextListener(wikiSpaceListener);
    }

    @Override
    public void objectsModified(@SuppressWarnings("rawtypes") Collection ids) {
        if (log.isDebugEnabled()) {
            log.debug("objectsModified: " + ids); //$NON-NLS-1$
        }
        clearWikiPagesCache(ids);
    }

    @Override
    public void objectsRemoved(@SuppressWarnings("rawtypes") Collection ids) {
        clearWikiPagesCache(ids);
    }

    @Override
    public void resourceRemoved(ILocation loc) {
        locationModified(loc);
    }

    @Override
    public void resourceModified(ILocation loc) {
        locationModified(loc);
    }

    @Override
    public void resourceMoved(ILocation oldLoc, ILocation newLoc) {
        locationModified(oldLoc, newLoc);
    }

    @Override
    public void revisionAdded(String repository, String revision) {
        try {
            XWikiCacheStore cacheStore = XWikiCacheStoreProvider.getCacheStore();
            if (cacheStore == null || changedLocations.get() == null) {
                return;
            }
            Set<ILocation> locations = new HashSet<ILocation>(changedLocations.get());
            for (ILocation location : locations) {
                String key = null;
                if (revision != null && revision.equals(location.getRevision()) && (key = getKey(location)) != null) {
                    removeKey(cacheStore, key);
                }
            }
        } finally {
            changedLocations.remove();
        }
    }

    private void locationModified(@NotNull ILocation... locs) {
        for (ILocation loc : locs) {
            if (changedLocations.get() == null) {
                changedLocations.set(new HashSet<ILocation>());
            }
            changedLocations.get().add(loc);
        }
    }

    @Override
    public void clearCaches() {
        XWikiCacheStore cacheStore = XWikiCacheStoreProvider.getCacheStore();
        if (cacheStore != null) {
            cacheStore.flushCache();
        }
    }

    @Override
    public void clearCaches(Collection<SubterraURI> uris) {
        clearWikiPagesCache(uris);
    }

    private void clearWikiPagesCache(@NotNull Collection<SubterraURI> uris) {
        XWikiCacheStore cacheStore = XWikiCacheStoreProvider.getCacheStore();
        if (cacheStore == null) {
            return;
        }
        for (SubterraURI uri : uris) {
            IObjectId oid = getObjectId(uri);
            if (isWikiPageOrPlanOrTestRun(oid)) {
                String key = getKey(oid);
                removeKey(cacheStore, key);
            }
        }
    }

    @Nullable
    private static final String getKey(@NotNull IObjectId objectId) {
        ILocalId localId = objectId.getLocalId();
        if (localId == null || objectId.getContextId() == null) {
            return null;
        }
        String objectName = localId.getObjectName();
        String containerName = getContainerName(localId);

        String contextName = objectId.getContextId().getContextName();
        if (ObjectUtils.emptyString(contextName)) {
            return String.format("page/%s/%s", containerName, objectName); //$NON-NLS-1$
        } else {
            return String.format("project/%s/page/%s/%s", contextName, containerName, objectName); //$NON-NLS-1$
        }
    }

    @NotNull
    private static String getContainerName(@NotNull ILocalId localId) {
        ILocalId containerId = localId.getContainerId();
        if (containerId != null) {
            return containerId.getObjectName();
        }
        return IPlan.PROTO.equals(localId.getPrototypeName()) ? Constants.PLANS : Constants.TEST_RUNS;
    }

    @Nullable
    private static final String getKey(@NotNull ILocation loc) {
        String user = getUserHomeFromLocation(loc);
        return user != null ? String.format("page/_users/%s", user) : null; //$NON-NLS-1$
    }

    @NotNull
    private static final IObjectId getObjectId(@NotNull SubterraURI uri) {
        IObjectResolver resolver = PlatformContext.getPlatform().lookupService(IObjectResolver.class);
        return resolver.getObjectIdForSubterraURI(uri);
    }

    @Nullable
    private static final String getUserHomeFromLocation(@NotNull ILocation loc) {
        return (loc.getComponentCount() == 5 && loc.startsWithComponentSequence("/.polarion/user-management/users/") //$NON-NLS-1$
        && "page.xml".equals(loc.getLastComponent())) ? //$NON-NLS-1$
        loc.getComponent(loc.getComponentCount() - 2)
                : null;
    }

    private static final void removeKey(@NotNull XWikiCacheStore cacheStore, @Nullable String key) {
        if (log.isDebugEnabled()) {
            log.debug("removeKey: " + key); //$NON-NLS-1$
        }
        if (key != null) {
            XWikiCache cache = cacheStore.getCache();
            if (cache != null) {
                cache.flushEntry(key);
            }
            XWikiCache pageExistCache = cacheStore.getPageExistCache();
            if (pageExistCache != null) {
                pageExistCache.flushEntry(key);
            }
        }
    }

    private static boolean isWikiPageOrPlanOrTestRun(@Nullable IObjectId oid) {
        if (oid == null) {
            return false;
        }
        String protoName = oid.getLocalId().getPrototypeName();
        return IWikiPage.PROTO.equals(protoName) || IPlan.PROTO.equals(protoName) || ITestRun.PROTO.equals(protoName);
    }

    @Override
    public void objectsCreated(@SuppressWarnings("rawtypes") Collection ids) {
        // nothing to do
    }

    @Override
    public void objectsNotAccessible(@SuppressWarnings("rawtypes") Collection ids) {
        // nothing to do
    }

    @Override
    public void resourceCreated(ILocation loc) {
        // nothing to do
    }

    @Override
    public void resourceCopied(ILocation oldLoc, ILocation newLoc) {
        // nothing to do
    }

    @Override
    public void revisionStart(@Nullable String revision) {
        // nothing to do
    }

    @Override
    public void revisionEnd(String revision) {
        // nothing to do
    }

    @Override
    public void setReindex(boolean reindexEventsWillFollow) {
        // nothing to do
    }

    @Override
    public boolean ignoresResourceChanges() {
        return false;
    }

}