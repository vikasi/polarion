/*
 * $Id$
 *
 * Copyright (C) 2004-2008 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2008 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.polarion.alm.wiki;

import java.util.Collection;
import java.util.Map;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import com.polarion.alm.wiki.model.IWikiPage;
import com.polarion.alm.wiki.model.IWikiSpace;

/**
 * 
 * @author Jiri Banszel
 * @version $Revision$ $Date$
 * @since 3.4.1
 */
public interface IWikiService {

    IWikiPolicy getWikiPolicy();

    @NotNull
    Collection<IWikiSpace> getSpaces(@Nullable String projectId);

    Collection<IWikiPage> getPages(String projectId, String spaceId);

    IWikiPage getPage(String name, String spaceId, String projectId, String revision);

    /**
     * Returns Wiki Pages from given project, searchString and optional spaceId
     *
     * @param searchString - not <code>null</code>
     * @param sort - can be null - null = no sort is applied
     * @param projectId limit result to Wiki Pages from particular project - can be null - null = result is not limited by project
     * @param spaceId limit result to Wiki Pages from particular spaceId - can be null - null = result is not limited by space
     * @return sorted list of {@link IWikiPage}, never return the <code>null</code>
     * @since 3.5.0
     */
    Collection<IWikiPage> searchPages(String searchString, String sort, String projectId, String spaceId);

    /**
     * Returns context map with values available to Wiki page during rendering.
     * 
     * @return unmodifiable map with context mapping (not <code>null</code>)
     */
    Map<String, Object> getWikiRenderingContextMap();

}
