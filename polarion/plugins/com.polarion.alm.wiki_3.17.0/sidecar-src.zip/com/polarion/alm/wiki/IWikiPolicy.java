package com.polarion.alm.wiki;

import com.polarion.platform.persistence.IPersistencePolicy;
import com.polarion.platform.persistence.model.IPObject;
import com.polarion.subterra.base.data.identification.IContextId;

/**
 * 
 * 
 * @author Stepan Roh
 * @version $Revision$ $Date$
 * @since 3.4.1
 * @deprecated Use appropriate methods on {@link IPersistencePolicy}.
 */
@Deprecated
public interface IWikiPolicy {

    boolean canReadPages(IContextId context);

    boolean canModifyPages(IContextId context);

    boolean canDeletePages(IContextId context);

    boolean canCreatePages(IContextId context);

    /**
     * <strong>WARNING:</strong> assumes default space, does not work with custom sets.<br/>
     * Use {@link IPersistencePolicy#canReadInstance(IPObject)} instead.
     */
    boolean canReadPage(String page, IContextId context);

    /**
     * <strong>WARNING:</strong> assumes default space, does not work with custom sets.<br/>
     * Use {@link IPersistencePolicy#canModifyInstance(IPObject)} instead.
     */
    boolean canModifyPage(String page, IContextId context);

    /**
     * <strong>WARNING:</strong> assumes default space, does not work with custom sets.<br/>
     * Use {@link IPersistencePolicy#canDeleteInstance(IPObject)} instead.
     */
    boolean canDeletePage(String page, IContextId context);

}
