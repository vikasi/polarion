/*
 * Copyright (C) 2004-2013 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2013 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.polarion.alm.wiki.internal;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import com.polarion.alm.projects.model.IFolder;
import com.polarion.alm.projects.model.IUser;
import com.polarion.alm.tracker.internal.FolderUtils;
import com.polarion.alm.wiki.IWikiPolicy;
import com.polarion.alm.wiki.IWikiService;
import com.polarion.alm.wiki.internal.model.WikiPage;
import com.polarion.alm.wiki.internal.model.WikiSpace;
import com.polarion.alm.wiki.model.IWikiPage;
import com.polarion.alm.wiki.model.IWikiSpace;
import com.polarion.core.util.ObjectUtils;
import com.polarion.core.util.collection.CollectionsUtil;
import com.polarion.platform.core.PlatformContext;
import com.polarion.platform.persistence.IDataService;
import com.polarion.platform.persistence.model.IPObjectList;
import com.polarion.platform.security.ISecurityService;
import com.polarion.portal.internal.server.navigation.TestManagementServiceAccessor;
import com.polarion.wiki.security.WikiPolicy;
import com.polarion.wiki.svn.ISvnProvider;
import com.polarion.wiki.svn.PolarionSvnProvider;
import com.polarion.wiki.svn.bo.SpaceSvnInfo;

/**
 * @author Jiri Banszel
 */
public class WikiService implements IWikiService {

    private static final String FIELD_PROJECT = "project.id"; //$NON-NLS-1$
    private static final String FIELD_SPACE = "space.id"; //$NON-NLS-1$
    private static final String FIELD_PAGE = "id"; //$NON-NLS-1$

    private IWikiPolicy wikiPolicy;

    public WikiService(ISecurityService securityService) {
        if (securityService == null) {
            throw new IllegalArgumentException("securityService is null"); //$NON-NLS-1$
        }
        wikiPolicy = new WikiPolicy(securityService);
    }

    @Override
    public IWikiPolicy getWikiPolicy() {
        return wikiPolicy;
    }

    @Override
    @NotNull
    public Collection<IWikiSpace> getSpaces(@Nullable String projectId) {
        String targetProjectId = projectId != null ? projectId : ISvnProvider.REPO_ROOT_AS_PROJECT_NAME;
        List<SpaceSvnInfo> spaces = new PolarionSvnProvider().getSpacesInProject(targetProjectId);
        List<IWikiSpace> result = new ArrayList<IWikiSpace>();

        for (SpaceSvnInfo space : spaces) {
            String spaceName = space.getName();
            if (spaceName != null) {
                IFolder folder = FolderUtils.getFolder(projectId, spaceName);
                result.add(new WikiSpace(space.getName(), targetProjectId, folder.getTitleOrName()));
            }
        }
        Collections.sort(result, new Comparator<IWikiSpace>() {
            @Override
            public int compare(IWikiSpace o1, IWikiSpace o2) {
                return o1.getTitleOrName().compareToIgnoreCase(o2.getTitleOrName());
            }
        });
        return result;
    }

    @Override
    public Collection<IWikiPage> getPages(String projectId, String spaceId) {
        StringBuilder query = new StringBuilder();
        query.append(FIELD_SPACE).append(":\"").append(spaceId).append("\""); //$NON-NLS-1$//$NON-NLS-2$
        addProjectQueryPart(query, projectId);
        List<IWikiPage> result = searchPages(query.toString(), null);
        Collections.sort(result, new Comparator<IWikiPage>() {
            @Override
            public int compare(IWikiPage o1, IWikiPage o2) {
                return o1.getTitleOrName().toLowerCase().compareTo(o2.getTitleOrName().toLowerCase());
            }
        });
        return result;
    }

    private void addProjectQueryPart(StringBuilder builder, String projectId) {
        if (ObjectUtils.emptyString(projectId)) {
            if (builder.length() > 0) {
                builder.append(" AND "); //$NON-NLS-1$
            } else {
                builder.append("*:* AND "); //$NON-NLS-1$
            }
            builder.append("NOT HAS_VALUE:project.id"); //$NON-NLS-1$ 
        } else {
            if (builder.length() > 0) {
                builder.append(" AND "); //$NON-NLS-1$
            }
            builder.append("project.id:\"" + projectId + "\""); //$NON-NLS-1$ //$NON-NLS-2$
        }
    }

    private WikiPage createWikiPage(String name, @Nullable String title, String spaceId, String spaceTitle, String projectId, String revision, Date created, Date updated, String updatedBy, String createdBy) {
        WikiSpace space = new WikiSpace(spaceId, projectId, spaceTitle);
        space.setWikiService(this);
        WikiPage wikiPage = new WikiPage(name, space, revision);
        wikiPage.setTitle(title);
        wikiPage.setCreated(created);
        wikiPage.setCreatedBy(createdBy);
        wikiPage.setUpdated(updated);
        wikiPage.setUpdatedBy(updatedBy);
        return wikiPage;
    }

    @Override
    public IWikiPage getPage(String name, String spaceId, String projectId, String revision) {
        StringBuilder query = new StringBuilder();
        query.append(FIELD_PAGE).append(":\"" + name + "\" AND " + FIELD_SPACE + ":\"" + WikiSpace.getSpaceName(spaceId) + "\""); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
        addProjectQueryPart(query, projectId);
        Collection<IWikiPage> pages = searchPages(query.toString(), null);
        if (!pages.isEmpty()) {
            return CollectionsUtil.getFirst(pages);
        } else {
            //template object
            return createWikiPage(name, null, spaceId, null, projectId, revision, null, null, null, null);
        }
    }

    private Map<String, Object> wikiRenderingContextMap = Collections.EMPTY_MAP;

    @Override
    public Map<String, Object> getWikiRenderingContextMap() {
        return wikiRenderingContextMap;
    }

    public void setWikiRenderingContextMap(Map<String, Object> context) {
        if (context == null) {
            throw new IllegalArgumentException("context is null"); //$NON-NLS-1$
        }
        HashMap contextMap = new HashMap(context);

        // XXX support contributions from Guice
        contextMap.put("testManagementService", new TestManagementServiceAccessor().getTestingService()); //$NON-NLS-1$

        wikiRenderingContextMap = Collections.unmodifiableMap(contextMap);
    }

    @SuppressWarnings("nls")
    @Override
    public Collection<IWikiPage> searchPages(String searchString, String sort, String projectId, String spaceId) {
        String q = null;
        if ("".equals(spaceId)) {
            spaceId = null;
        }
        if (searchString == null || "".equals(searchString)) {
            if (projectId == null) {
                q = (spaceId == null ? "" : FIELD_SPACE + ":\"" + WikiSpace.getSpaceName(spaceId) + "\"");
            } else {
                q = FIELD_PROJECT + ":\"" + projectId + "\"" + (spaceId == null ? "" : " AND " + FIELD_SPACE + ":\"" + WikiSpace.getSpaceName(spaceId) + "\"");
            }
        } else {
            if (searchString.contains(":")) {
                q = searchString + " ";
            } else {
                q = "(" + searchString + ") ";
            }
            if (projectId != null) {
                q = q + "AND " + FIELD_PROJECT + ":\"" + projectId + "\"";
            }
            q = q + (spaceId == null ? "" : " AND " + FIELD_SPACE + ":\"" + WikiSpace.getSpaceName(spaceId) + "\"");
        }
        return searchPages(q, sort);
    }

    private List<IWikiPage> searchPages(String query, String sort) {
        IDataService ds = PlatformContext.getPlatform().lookupService(IDataService.class);
        IPObjectList wikiPages = ds.searchInstances(com.polarion.alm.tracker.model.IWikiPage.PROTO, query, sort);

        List<IWikiPage> result = new ArrayList<IWikiPage>();
        for (Object element : wikiPages) {
            com.polarion.alm.tracker.model.IWikiPage wikiPage = (com.polarion.alm.tracker.model.IWikiPage) element;
            if (!wikiPage.getDataSvc().getPersistencePolicy().canReadInstance(wikiPage) || wikiPage.isUnresolvable()) {
                continue;
            }
            if (wikiPage.getPageName() != null) {
                IUser author = wikiPage.getAuthor();
                IUser updatedBy = wikiPage.getUpdatedBy();
                WikiPage wp = createWikiPage(wikiPage.getPageName(), wikiPage.getTitle(), wikiPage.getSpaceId(), wikiPage.getFolder().getTitle(), wikiPage.getProjectId(), wikiPage.getDataRevision(), wikiPage.getCreated(),
                        wikiPage.getUpdated(), (updatedBy != null) ? updatedBy.getId() : null, (author != null) ? author.getId() : null);
                result.add(wp);
            }
        }
        return result;
    }

}
