/*
* Copyright (C) 2004-2013 Polarion Software
* All rights reserved.
* Email: dev@polarion.com
*
*
* Copyright (C) 2004-2013 Polarion Software
* All Rights Reserved. No use, copying or distribution of this
* work may be made except in accordance with a valid license
* agreement from Polarion Software. This notice must be
* included on all copies, modifications and derivatives of this
* work.
*
* POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
* ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
* INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
* SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
* OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
*
*/
package com.polarion.alm.wiki.internal;

import java.util.List;

import org.jetbrains.annotations.NotNull;

import com.polarion.platform.context.IContextListener;
import com.polarion.platform.service.repository.IFileChangesListener;
import com.polarion.subterra.base.data.identification.IContextId;
import com.polarion.subterra.base.location.ILocation;
import com.polarion.wiki.svn.ISvnProvider;
import com.polarion.wiki.svn.PolarionSvnProvider;
import com.polarion.wiki.svn.WikiSpacesCache;
import com.polarion.wiki.svn.bo.SpaceSvnInfo;

/**
 * @author <a href="mailto:dev@polarion.com">Jakub Stroleny</a>, Polarion Software
 */
public class WikiSpacePersistenceListener implements IFileChangesListener, IContextListener {

    private static class Holder {
        @NotNull
        public static final PolarionSvnProvider provider = new PolarionSvnProvider();
    }

    @Override
    public void resourceCreated(ILocation loc) {
        if (isSpace(loc)) {
            SpaceSvnInfo space = getSvnProvider().getSpaceInfo(loc);
            WikiSpacesCache.getInstance().addSpace(space);
        }
    }

    @Override
    public void resourceCopied(ILocation oldLoc, ILocation newLoc) {
        if (isSpace(newLoc)) {
            WikiSpacesCache.getInstance().copySpace(oldLoc, newLoc);
        }
    }

    @Override
    public void resourceRemoved(ILocation loc) {
        if (isSpace(loc)) {
            WikiSpacesCache.getInstance().removeSpace(loc);
        }
    }

    @Override
    public void resourceModified(ILocation loc) {
        // nothing to do
    }

    @Override
    public void resourceMoved(ILocation oldLoc, ILocation newLoc) {
        if (isSpace(newLoc)) {
            WikiSpacesCache.getInstance().moveSpace(oldLoc, newLoc);
        }
    }

    @Override
    public void contextCreated(@NotNull IContextId id) {
        ILocation projectLocation = getSvnProvider().getProjectLocation(id.getContextName());
        WikiSpacesCache.getInstance().proccessSpaces(projectLocation);
    }

    @Override
    public void contextsMoved(@NotNull List contextPairs) {
        // nothing to do
    }

    @Override
    public void contextRemoved(@NotNull IContextId id) {
        // nothing to do
    }

    private boolean isSpace(@NotNull ILocation loc) {
        ILocation parentLocation = loc.getParentLocation();
        return parentLocation != null && ISvnProvider.WIKI_ROOT_FOLDER.equals(parentLocation.getLastComponent());
    }

    @NotNull
    private PolarionSvnProvider getSvnProvider() {
        return Holder.provider;
    }

}
