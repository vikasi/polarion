package com.polarion.alm.wiki.internal.model;

import java.util.Date;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import com.polarion.alm.wiki.model.IWikiPage;
import com.polarion.alm.wiki.model.IWikiSpace;
import com.polarion.wiki.integration.utils.MacroUtils;

public class WikiPage implements IWikiPage {

    private String name;
    private IWikiSpace space;
    private String revision;
    private Date created;
    private String createdBy;
    private Date updated;
    private String updatedBy;
    @Nullable
    private String title;

    public WikiPage(String name, IWikiSpace space, String revision) {
        super();
        this.name = name;
        this.space = space;
        this.revision = revision;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public void setUpdated(Date updated) {
        this.updated = updated;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public void setTitle(@Nullable String title) {
        this.title = title;
    }

    @Override
    @NotNull
    public String getName() {
        return name;
    }

    @Override
    public IWikiSpace getSpace() {
        return space;
    }

    @Override
    public String getFormattedName() {
        StringBuilder sb = new StringBuilder();
        String spaceName = space.getName();

        String pageName = name;
        if ((spaceName != null) && (!spaceName.matches("_default")) && (!spaceName.matches("_modules"))) { //$NON-NLS-1$ //$NON-NLS-2$
            pageName = spaceName + "." + name; //$NON-NLS-1$
        }

        if ((space.getProjectId() != null) && (!space.getProjectId().equals(""))) { //$NON-NLS-1$
            //project scope
            sb.append(MacroUtils.getInstance().getProjectName(space.getProjectId()));
            sb.append(" - "); //$NON-NLS-1$
            sb.append(pageName);
        } else {
            sb.append(pageName);
        }
        return sb.toString();
    }

    @Override
    public String getRevision() {
        return revision;
    }

    @Override
    public Date getCreated() {
        return created;
    }

    @Override
    public String getCreatedBy() {
        return createdBy;
    }

    @Override
    public Date getUpdated() {
        return updated;
    }

    @Override
    public String getUpdatedBy() {
        return updatedBy;
    }

    @Override
    @Nullable
    public String getTitle() {
        return title;
    }

    @Override
    public String getProject() {
        return getSpace() != null ? getSpace().getProjectId() : null;
    }

    @Override
    @NotNull
    public String getTitleOrName() {
        String pageTitle = getTitle();
        if (pageTitle == null) {
            return getName();
        }
        return pageTitle;
    }

    @Override
    public String toString() {
        return "WikiPage [name=" + name + ", space=" + space + ", title=" + title + "]"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    }

}
