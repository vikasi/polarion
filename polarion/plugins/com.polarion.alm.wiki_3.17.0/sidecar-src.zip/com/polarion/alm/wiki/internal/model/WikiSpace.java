package com.polarion.alm.wiki.internal.model;

import java.util.Collection;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import com.polarion.alm.wiki.IWikiService;
import com.polarion.alm.wiki.model.IWikiPage;
import com.polarion.alm.wiki.model.IWikiSpace;

public class WikiSpace implements IWikiSpace {

    private String id;
    private String projectId;

    private IWikiService wikiService;
    @Nullable
    private String spaceTitle;

    public WikiSpace(String id, String projectId, @Nullable String spaceTitle) {
        super();
        this.id = id;
        this.projectId = projectId;
        this.spaceTitle = spaceTitle;
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public String getName() {
        return getSpaceName(id);
    }

    public static String getSpaceName(String id) {
        if (id == null) {
            return null;
        }
        if (id.indexOf("page/") != -1) {
            return id.substring(id.lastIndexOf("page/") + 5).trim();
        } else {
            return id.substring(id.lastIndexOf("/") + 1).trim();
        }
    }

    @Override
    public String getProjectId() {
        return projectId;
    }

    public void setWikiService(IWikiService wikiService) {
        this.wikiService = wikiService;
    }

    @Override
    public Collection<IWikiPage> getPages() {
        return wikiService.getPages(projectId, id);
    }

    @Nullable
    @Override
    public String getTitle() {
        return spaceTitle;
    }

    @Override
    @NotNull
    public String getTitleOrName() {
        String title = getTitle();
        if (title == null) {
            return getName();
        }
        return title;
    }

}
