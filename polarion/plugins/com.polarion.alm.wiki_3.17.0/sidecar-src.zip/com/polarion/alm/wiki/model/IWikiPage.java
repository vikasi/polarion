package com.polarion.alm.wiki.model;

import java.util.Date;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * 
 * 
 * @author Stepan Roh
 * @version $Revision$ $Date$
 * @since 3.4.1
 */
public interface IWikiPage {
    @NotNull
    String getName();

    @Nullable
    IWikiSpace getSpace();

    String getFormattedName();

    String getRevision();

    Date getUpdated();

    Date getCreated();

    String getUpdatedBy();

    String getCreatedBy();

    /**
     * @since 3.5.0
     */
    String getProject();

    /**
     * @since 3.8.2
     */
    @Nullable
    String getTitle();

    /**
     * Returns {@link #getTitle()} or {@link #getName()} if the former returns <code>null</code>.
     * @since 3.8.2
     */
    @NotNull
    String getTitleOrName();

}
