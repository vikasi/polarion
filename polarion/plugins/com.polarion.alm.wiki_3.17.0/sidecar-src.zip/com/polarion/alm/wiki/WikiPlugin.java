package com.polarion.alm.wiki;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.security.Principal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.portlet.PortalContext;
import javax.portlet.PortletMode;
import javax.portlet.PortletPreferences;
import javax.portlet.PortletSession;
import javax.portlet.WindowState;
import javax.servlet.AsyncContext;
import javax.servlet.DispatcherType;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpUpgradeHandler;
import javax.servlet.http.Part;

import org.apache.velocity.VelocityContext;
import org.eclipse.core.runtime.Platform;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import com.polarion.alm.tracker.internal.WikiRenderingProvider;
import com.polarion.alm.tracker.internal.WikiRenderingProvider.IWikiRenderingAccessor;
import com.polarion.alm.tracker.model.IModule;
import com.polarion.alm.tracker.web.internal.server.ModuleConverter;
import com.polarion.alm.tracker.web.internal.server.PdfExportChartReport;
import com.polarion.alm.tracker.web.internal.server.pdfexport.PdfExporter;
import com.polarion.alm.ui.server.tracker.ImportExportStatusKeeper;
import com.polarion.alm.ui.server.wiki.WikiDataServiceImpl;
import com.polarion.alm.ui.server.wiki.WikiDataServiceImpl.WikiStorageAccessor;
import com.polarion.alm.wiki.model.IWikiPage;
import com.polarion.alm.wiki.model.IWikiSpace;
import com.polarion.core.util.ObjectUtils;
import com.polarion.platform.core.PlatformContext;
import com.polarion.platform.i18n.Localization;
import com.polarion.platform.persistence.IDataService;
import com.polarion.portal.internal.server.navigation.WikiTreeProvider;
import com.polarion.portal.internal.server.navigation.WikiTreeProvider.IWikiServiceAccessor;
import com.polarion.portal.internal.shared.navigation.PageDocumentInfo;
import com.polarion.subterra.base.data.identification.IContextId;
import com.polarion.wiki.util.OverviewPanel;
import com.polarion.wiki.util.SpaceParser;
import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.api.Document;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.web.XWikiEngineContext;
import com.xpn.xwiki.web.XWikiMessageTool;
import com.xpn.xwiki.web.XWikiRequest;
import com.xpn.xwiki.web.XWikiURLFactory;

public class WikiPlugin {

    private abstract class WikiRenderingAccessor {

        /**
         * 
         * @param input
         * @param document
         * @param pdfExportId is null if it is not for pdf export,, can be an empty if clients are really not interested in report
         * @param isCompare
         * @param query
         * @param language
         * @return rendered text
         */
        public String render(String input, IModule document, @Nullable String pdfExportId, boolean isCompare, String query, String language) {
            return render(document, input, document.getProject().getId(), document.getModuleFolder(), document.getModuleName(),
                    pdfExportId, isCompare, document.getRevision(), document.getDataRevision(), query, language);
        }

        private String render(IModule document, String input, String projectId, String moduleSpace,
                String moduleName, @Nullable String pdfExportId, boolean isCompare, String revision, String dataRevision, String query, String language) {
            URL url = getURL(moduleName, query, projectId, document.getRevision());

            XWikiContext<String, Object> context = new XWikiContext<String, Object>();
            context.setURL(url);
            context.setEngineContext(getFakeRenderingAccessor());
            XWiki wiki = getXWiki(context);
            if (wiki == null) {
                return null;
            }
            context.setWiki(wiki);
            context.setRequest(getRequest(url));
            wiki.setLastNotServiceRequest(url.toString());
            XWikiURLFactory urlf = context.getWiki().getURLFactoryService()
                    .createURLFactory(XWikiContext.MODE_SERVLET, context);
            context.setURLFactory(urlf);
            XWikiDocument doc = new XWikiDocument();
            doc.setName(moduleName);
            doc.setSpace("project/" + projectId + "/page/" + moduleSpace); //$NON-NLS-1$ //$NON-NLS-2$
            doc.setContent(input);
            context.setDoc(doc);
            context.setAction("view"); //$NON-NLS-1$
            prepareResources(context, pdfExportId, isCompare, revision, dataRevision, document, language);
            wiki.prepareResources(context);
            input = prepareContent(context, input);
            String renderText = wiki.getRenderingEngine().renderText(input, doc, context);

            VelocityContext vcontext = (VelocityContext) context.get("vcontext"); //$NON-NLS-1$
            if (pdfExportId != null) {
                PdfExporter.threadLocalVelocityContext.set(vcontext);
                ((PdfExportChartReport) vcontext.get(PdfExportChartReport.KEY_PDF_EXPORT_REPORT)).persist(false);
            }
            return renderText;
        }

        protected abstract String prepareContent(
                XWikiContext<String, Object> context, String content);

        private void prepareResources(XWikiContext<String, Object> context,
                @Nullable String pdfExportId, boolean isCompare, String revision, String dataRevision, IModule document, String language) {
            XWikiDocument doc = context.getDoc();
            context.put(TARGET, "1"); //$NON-NLS-1$
            if (pdfExportId != null) {
                context.put("pdf_generate", "1"); //$NON-NLS-1$ //$NON-NLS-2$
            }
            if (isCompare) {
                context.put("compareMode", "1"); //$NON-NLS-1$ //$NON-NLS-2$
                context.put("compareModeDLE", "1"); //$NON-NLS-1$ //$NON-NLS-2$
            }
            if (dataRevision != null) {
                doc.setVersion(dataRevision);
                doc.setRevision(dataRevision);
            }
            if (revision != null) {
                context.put("revision", revision); //$NON-NLS-1$
            }
            VelocityContext vcontext = new VelocityContext();
            vcontext.put("tdoc", new Document(doc, context)); //$NON-NLS-1$
            if (document != null) {
                vcontext.put("document", document); //$NON-NLS-1$
            }
            if (language != null) {
                vcontext.put("language", language); //$NON-NLS-1$
            }
            if (pdfExportId != null) {
                if (pdfExportId.trim().isEmpty()) {
                    pdfExportId = ImportExportStatusKeeper.getInstance().generateNewId();
                }
                vcontext.put(PdfExportChartReport.KEY_PDF_EXPORT_REPORT, new PdfExportChartReport(pdfExportId));
            }
            context.put("vcontext", vcontext); //$NON-NLS-1$
        }

        private URL getURL(@NotNull String moduleName, @Nullable String query, @NotNull String projectId, @Nullable String revision) {
            try {
                return new URL(getServerUrl()
                        + "/polarion/wiki" //$NON-NLS-1$
                        + (revision != null ? "/baseline/" + revision : "") //$NON-NLS-1$//$NON-NLS-2$ 
                        + "/bin/view/project/" + projectId //$NON-NLS-1$
                        + "/page/_modules/" + moduleName + "?" //$NON-NLS-1$ //$NON-NLS-2$
                        + getDocumentParameters(query));
            } catch (MalformedURLException e) {
                throw new RuntimeException(e);
            }
        }

        private String getServerUrl() {
            String baseUrl = System.getProperty("base.url", ""); //$NON-NLS-1$ //$NON-NLS-2$
            return baseUrl.endsWith("/") ? baseUrl.substring(0, //$NON-NLS-1$
                    baseUrl.length() - 1) : baseUrl;
        }

        private String getDocumentParameters(String query) {
            StringBuilder params = new StringBuilder();
            params.append("pdf_generate=1"); //$NON-NLS-1$
            if (!ObjectUtils.emptyString(query)) {
                query = escapeURL(query);
                params.append("&query=").append(query); //$NON-NLS-1$
            }
            return params.toString();
        }

        private String escapeURL(String query) {
            query = query.replaceAll("#", "%23"); //$NON-NLS-1$ //$NON-NLS-2$
            query = query.replaceAll("&", "%26"); //$NON-NLS-1$ //$NON-NLS-2$
            return query;
        }

        private XWikiRequest getRequest(final URL url) {
            return new XWikiRequest() {

                @Override
                public String get(String name) {
                    return null;
                }

                @Override
                public Cookie getCookie(String cookieName) {
                    return null;
                }

                @Override
                public HttpServletRequest getHttpServletRequest() {
                    return null;
                }

                @Override
                public String getAuthType() {
                    return null;
                }

                @Override
                public String getContextPath() {
                    return null;
                }

                @Override
                public Cookie[] getCookies() {
                    return null;
                }

                @Override
                public long getDateHeader(String arg0) {
                    return 0;
                }

                @Override
                public String getHeader(String arg0) {
                    return ""; //$NON-NLS-1$
                }

                @Override
                @SuppressWarnings("unchecked")
                public Enumeration getHeaderNames() {
                    return null;
                }

                @Override
                @SuppressWarnings("unchecked")
                public Enumeration getHeaders(String arg0) {
                    return null;
                }

                @Override
                public int getIntHeader(String arg0) {
                    return 0;
                }

                @Override
                public String getMethod() {
                    return null;
                }

                @Override
                public String getPathInfo() {
                    return url.getPath();
                }

                @Override
                public String getPathTranslated() {
                    return null;
                }

                @Override
                public String getQueryString() {
                    return url.getQuery();
                }

                @Override
                public String getRemoteUser() {
                    return null;
                }

                @Override
                public String getRequestURI() {
                    try {
                        return url.toURI().toString();
                    } catch (URISyntaxException ex) {
                        return ""; //$NON-NLS-1$
                    }
                }

                @Override
                public StringBuffer getRequestURL() {
                    return new StringBuffer(url.toExternalForm());
                }

                @Override
                public String getRequestedSessionId() {
                    return null;
                }

                @Override
                public String getServletPath() {
                    return url.toString();
                }

                @Override
                public HttpSession getSession() {
                    return null;
                }

                @Override
                public HttpSession getSession(boolean arg0) {
                    return null;
                }

                @Override
                public Principal getUserPrincipal() {
                    return null;
                }

                @Override
                public boolean isRequestedSessionIdFromCookie() {
                    return false;
                }

                @Override
                public boolean isRequestedSessionIdFromURL() {
                    return false;
                }

                @Override
                public boolean isRequestedSessionIdFromUrl() {
                    return false;
                }

                @Override
                public boolean isRequestedSessionIdValid() {
                    return false;
                }

                @Override
                public boolean isUserInRole(String arg0) {
                    return false;
                }

                @Override
                public Object getAttribute(String arg0) {
                    return null;
                }

                @Override
                @SuppressWarnings("unchecked")
                public Enumeration getAttributeNames() {
                    return null;
                }

                @Override
                public String getCharacterEncoding() {
                    return null;
                }

                @Override
                public int getContentLength() {
                    return 0;
                }

                @Override
                public String getContentType() {
                    return null;
                }

                @Override
                public ServletInputStream getInputStream() throws IOException {
                    return null;
                }

                @Override
                public String getLocalAddr() {
                    return null;
                }

                @Override
                public String getLocalName() {
                    return null;
                }

                @Override
                public int getLocalPort() {
                    return 0;
                }

                @Override
                public Locale getLocale() {
                    return null;
                }

                @Override
                @SuppressWarnings("unchecked")
                public Enumeration getLocales() {
                    return null;
                }

                @Override
                public String getParameter(String arg0) {
                    return null;
                }

                @Override
                @SuppressWarnings("unchecked")
                public Map getParameterMap() {
                    return null;
                }

                @Override
                @SuppressWarnings("unchecked")
                public Enumeration getParameterNames() {
                    return null;
                }

                @Override
                public String[] getParameterValues(String arg0) {
                    return null;
                }

                @Override
                public String getProtocol() {
                    return null;
                }

                @Override
                public BufferedReader getReader() throws IOException {
                    return null;
                }

                @Override
                public String getRealPath(String arg0) {
                    return null;
                }

                @Override
                public String getRemoteAddr() {
                    return null;
                }

                @Override
                public String getRemoteHost() {
                    return null;
                }

                @Override
                public int getRemotePort() {
                    return 0;
                }

                @Override
                public RequestDispatcher getRequestDispatcher(String arg0) {
                    return null;
                }

                @Override
                public String getScheme() {
                    return null;
                }

                @Override
                public String getServerName() {
                    return null;
                }

                @Override
                public int getServerPort() {
                    return 0;
                }

                @Override
                public boolean isSecure() {
                    return false;
                }

                @Override
                public void removeAttribute(String arg0) {
                    // nothing to do
                }

                @Override
                public void setAttribute(String arg0, Object arg1) {
                    // nothing to do
                }

                @Override
                public void setCharacterEncoding(String arg0)
                        throws UnsupportedEncodingException {
                    // nothing to do
                }

                @Override
                public PortalContext getPortalContext() {
                    return null;
                }

                @Override
                public PortletMode getPortletMode() {
                    return null;
                }

                @Override
                public PortletSession getPortletSession() {
                    return null;
                }

                @Override
                public PortletSession getPortletSession(boolean create) {
                    return null;
                }

                @Override
                public PortletPreferences getPreferences() {
                    return null;
                }

                @Override
                @SuppressWarnings("unchecked")
                public Enumeration getProperties(String name) {
                    return null;
                }

                @Override
                public String getProperty(String name) {
                    return null;
                }

                @Override
                @SuppressWarnings("unchecked")
                public Enumeration getPropertyNames() {
                    return null;
                }

                @Override
                public String getResponseContentType() {
                    return null;
                }

                @Override
                @SuppressWarnings("unchecked")
                public Enumeration getResponseContentTypes() {
                    return null;
                }

                @Override
                public WindowState getWindowState() {
                    return null;
                }

                @Override
                public boolean isPortletModeAllowed(PortletMode mode) {
                    return false;
                }

                @Override
                public boolean isWindowStateAllowed(WindowState state) {
                    return false;
                }

                @Override
                public InputStream getPortletInputStream() throws IOException {
                    return null;
                }

                @Override
                public String changeSessionId() {
                    throw new UnsupportedOperationException();
                }

                @Override
                public boolean authenticate(HttpServletResponse response) throws IOException, ServletException {
                    throw new UnsupportedOperationException();
                }

                @Override
                public void login(String username, String password) throws ServletException {
                    throw new UnsupportedOperationException();
                }

                @Override
                public void logout() throws ServletException {
                    throw new UnsupportedOperationException();
                }

                @Override
                public Collection<Part> getParts() throws IOException, ServletException {
                    throw new UnsupportedOperationException();
                }

                @Override
                public Part getPart(String name) throws IOException, ServletException {
                    throw new UnsupportedOperationException();
                }

                @Override
                public <T extends HttpUpgradeHandler> T upgrade(Class<T> httpUpgradeHandlerClass) throws IOException, ServletException {
                    throw new UnsupportedOperationException();
                }

                @Override
                public long getContentLengthLong() {
                    throw new UnsupportedOperationException();
                }

                @Override
                public ServletContext getServletContext() {
                    throw new UnsupportedOperationException();
                }

                @Override
                public AsyncContext startAsync() throws IllegalStateException {
                    throw new UnsupportedOperationException();
                }

                @Override
                public AsyncContext startAsync(ServletRequest servletRequest, ServletResponse servletResponse) throws IllegalStateException {
                    throw new UnsupportedOperationException();
                }

                @Override
                public boolean isAsyncStarted() {
                    throw new UnsupportedOperationException();
                }

                @Override
                public boolean isAsyncSupported() {
                    throw new UnsupportedOperationException();
                }

                @Override
                public AsyncContext getAsyncContext() {
                    throw new UnsupportedOperationException();
                }

                @Override
                public DispatcherType getDispatcherType() {
                    throw new UnsupportedOperationException();
                }
            };
        }

    }

    private class TrackerWikiRenderingAccessor extends WikiRenderingAccessor
            implements IWikiRenderingAccessor {

        @Override
        protected String prepareContent(XWikiContext<String, Object> context,
                String content) {
            XWikiMessageTool msg = (XWikiMessageTool) context.get("msg"); //$NON-NLS-1$
            return content != null ? content.replaceAll("\\{toc\\}", //$NON-NLS-1$
                    "<span style=\"color:red;font-weight:bold;\">" //$NON-NLS-1$
                            + msg.get("tocMacroIsNotSupportedInDLE") //$NON-NLS-1$
                            + "</span>") : ""; //$NON-NLS-1$ //$NON-NLS-2$
        }

        @Override
        public String render(IModule document, String input, @Nullable String pdfExportId,
                boolean isCompare, String query, String language) {
            return super.render(input, document, pdfExportId, isCompare, query, language);
        }

    }

    private class UIWikiRenderingAccessor extends WikiRenderingAccessor
            implements
            com.polarion.alm.tracker.web.internal.server.ModuleConverter.IWikiRenderingAccessor {

        @Override
        protected String prepareContent(XWikiContext<String, Object> context,
                String content) {
            return content;
        }

        @Override
        public String render(IModule module, String input, String projectId, String moduleName) {
            return super.render(input, module, "", false, null, null); //$NON-NLS-1$
        }

    }

    public static final String TARGET = "documentLikeEditor"; //$NON-NLS-1$

    public static final String PLUGIN_ID = "com.polarion.alm.wiki"; //$NON-NLS-1$

    private static IWikiService wikiService = PlatformContext
            .getPlatform().lookupService(IWikiService.class);

    /*
     * Use dynamic initializing block - Startup Service will invoke this block,
     * prevents NPE when extending from Plugin class, because class depends on platform
     * which must be initialized before this class is statically initialized
     */
    {
        WikiTreeProvider.set(new IWikiServiceAccessor() {
            @Override
            public Collection<PageDocumentInfo> getPages(String projectId, String spaceId) {
                Collection<IWikiPage> pages = wikiService.getPages(projectId,
                        spaceId);
                Collection<PageDocumentInfo> result = new ArrayList<>();
                for (IWikiPage page : pages) {
                    result.add(new PageDocumentInfo(page.getName(), page.getTitle()));
                }
                return result;
            }

            @Override
            @NotNull
            public Collection<String> getSpaces(@Nullable String projectId) {
                Collection<IWikiSpace> spaces = wikiService
                        .getSpaces(projectId);
                Collection<String> result = new ArrayList<String>();
                for (IWikiSpace space : spaces) {
                    result.add(space.getId());
                }
                return result;
            }

            @Override
            public Map<String, Object> getPage(String projectId,
                    String spaceId, String pageName) {
                IWikiPage page = wikiService.getPage(pageName, spaceId,
                        projectId, null);

                Map<String, Object> parameters = new HashMap<String, Object>();
                parameters.put("name", page.getName()); //$NON-NLS-1$
                parameters.put("author", page.getCreatedBy()); //$NON-NLS-1$
                parameters.put("updatedBy", page.getUpdatedBy()); //$NON-NLS-1$
                parameters.put("created", page.getCreated()); //$NON-NLS-1$
                parameters.put("updated", page.getUpdated()); //$NON-NLS-1$
                parameters.put("revision", page.getRevision()); //$NON-NLS-1$
                parameters.put("title", page.getTitle()); //$NON-NLS-1$
                parameters.put(IWikiServiceAccessor.KEY_TITLE_OR_NAME, page.getTitleOrName());
                IWikiSpace space = page.getSpace();
                parameters.put(KEY_SPACE_TITLE_OR_NAME, space != null ? space.getTitleOrName() : null);
                parameters.put(KEY_SPACE_TITLE, space != null ? space.getTitle() : null);
                return parameters;
            }

            @Override
            public List<Map<String, Object>> searchPages(String projectId,
                    String spaceId, String query, String sort, int limit) {
                Collection<IWikiPage> searchPages = wikiService.searchPages(
                        query, sort, projectId, spaceId);
                ArrayList<Map<String, Object>> result = new ArrayList<Map<String, Object>>();
                int start = 0;
                for (Object element : searchPages) {
                    if (start < limit) {
                        IWikiPage page = (IWikiPage) element;
                        Map<String, Object> parameters = new HashMap<String, Object>();
                        parameters.put("name", page.getName()); //$NON-NLS-1$
                        parameters.put("author", page.getCreatedBy()); //$NON-NLS-1$
                        parameters.put("updatedBy", page.getUpdatedBy()); //$NON-NLS-1$
                        parameters.put("created", page.getCreated()); //$NON-NLS-1$
                        parameters.put("updated", page.getUpdated()); //$NON-NLS-1$
                        parameters.put("revision", page.getRevision()); //$NON-NLS-1$
                        parameters.put("project", page.getProject()); //$NON-NLS-1$
                        IWikiSpace space = page.getSpace();
                        parameters.put("space", space != null ? space.getName() : null); //$NON-NLS-1$
                        parameters.put(KEY_SPACE_TITLE_OR_NAME, space != null ? space.getTitleOrName() : null);
                        parameters.put(KEY_SPACE_TITLE, space != null ? space.getTitle() : null);
                        parameters.put(KEY_TITLE_OR_NAME, page.getTitleOrName());
                        result.add(parameters);
                        start++;
                    } else {
                        return result;
                    }
                }
                return result;
            }

            @Override
            public void updateWikiPageTitle(@Nullable String projectId, @Nullable String spaceId, @NotNull String pageName, @Nullable String pageTitle) {
                WikiDataServiceImpl.wikiStorageAccessor.updateWikiPageTitle(projectId, spaceId, pageName, pageTitle);
            }
        });
        WikiRenderingProvider.wikiRenderingAccessor = new TrackerWikiRenderingAccessor();

        WikiDataServiceImpl.wikiStorageAccessor = new WikiStorageAccessor() {

            @Override
            public void savePageContent(String project, String space,
                    String page, @Nullable String title, String content) {
                XWikiDocument document = new XWikiDocument(
                        SpaceParser.getMixedSpace(project, space), page);
                document.setContent(content);
                document.setPageTitle(title);
                XWikiContext<String, Object> context = getXWikiContext();
                try {
                    context.getWiki().saveDocument(document, context);
                } catch (XWikiException e) {
                    throw new RuntimeException(e);
                }

            }

            @Override
            public String loadPageContent(String project, String space,
                    String page) {
                XWikiContext<String, Object> context = getXWikiContext();
                try {
                    XWikiDocument document = context.getWiki().getDocument(SpaceParser.getMixedSpace(project, space), page, context);
                    if (document.isNew()) {
                        String name = document.getName();
                        String group = document.getGroup();
                        String scope = OverviewPanel.getScope(group, project, space);
                        if (OverviewPanel.hasPage(space, name, scope)) {
                            XWikiDocument panelDoc = OverviewPanel.getPage(context, space, name, scope);
                            if (panelDoc != null) {
                                return panelDoc.getContent();
                            }
                        }
                    }
                    return document.getContent();
                } catch (XWikiException e) {
                    throw new RuntimeException(e);
                }
            }

            private XWikiContext<String, Object> getXWikiContext() {

                XWikiContext<String, Object> context = new XWikiContext<String, Object>();
                try {
                    context.setURL(new URL("http://absolutelyirellevanthere")); //$NON-NLS-1$
                } catch (MalformedURLException e) {
                    throw new RuntimeException("Code errror.", e); //$NON-NLS-1$
                }

                context.setEngineContext(getFakeRenderingAccessor());

                getXWiki(context);

                return context;

            }

            @Override
            public void updateWikiPageTitle(@Nullable String projectId, @Nullable String spaceId, @NotNull String pageName, @Nullable String pageTitle) {
                XWikiContext<String, Object> context = getXWikiContext();
                try {
                    XWikiDocument document = context.getWiki().getDocument(
                            SpaceParser.getMixedSpace(projectId, spaceId), pageName,
                            context);
                    document.setIsTemplate(false);
                    document.setPageTitle(pageTitle);
                    context.getWiki().saveDocument(document, context);
                } catch (XWikiException e) {
                    throw new RuntimeException(e);
                }
            }
        };

        ModuleConverter.wikiRenderingAccessor = new UIWikiRenderingAccessor();

        initWiki();

    }

    private void initWiki() {
        // workaround for wiki initialization on startup
        XWikiContext<String, Object> context = new XWikiContext<String, Object>();
        try {
            context.setURL(new URL("http://absolutelyirellevanthere")); //$NON-NLS-1$
        } catch (MalformedURLException e) {
            throw new RuntimeException("Code errror.", e); //$NON-NLS-1$
        }

        context.setEngineContext(getFakeRenderingAccessor());

        getXWiki(context);
    }

    private XWiki getXWiki(XWikiContext<String, Object> context) {
        try {
            return XWiki.getMainXWiki(context);
        } catch (XWikiException ex) {
            throw new RuntimeException(ex);
        }
    }

    private final URL getResourceInternal(String name) {
        try {
            URL url = Platform.getBundle(PLUGIN_ID).getEntry("src/main/webapp" + name); //$NON-NLS-1$
            if (url == null) {
                return null;
            }
            return Platform.asLocalURL(url);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private XWikiEngineContext getFakeRenderingAccessor() {
        return new XWikiEngineContext() {

            @Override
            public Object getAttribute(String name) {
                return null;
            }

            @Override
            public String getMimeType(String filename) {
                return null;
            }

            @Override
            public String getRealPath(String path) {
                return ""; //$NON-NLS-1$
            }

            @Override
            public URL getResource(String name)
                    throws MalformedURLException {
                return getResourceInternal(name);
            }

            @Override
            public InputStream getResourceAsStream(String name) {
                URL url = getResourceInternal(name);
                if (url != null) {
                    try {
                        return url.openStream();
                    } catch (IOException ex) {
                        throw new RuntimeException(ex);
                    }
                }
                return null;
            }

            @Override
            public void setAttribute(String name, Object value) {
                // nothing to do
            }
        };
    }

    public static final String getDeprecatedMethodMessage(String method) {
        return Localization.getString("wiki.deprecated.method", method); //$NON-NLS-1$
    }
}
