package com.polarion.wiki.security;

import com.polarion.alm.wiki.IWikiPolicy;
import com.polarion.platform.internal.FeatureEnum;
import com.polarion.platform.internal.LicenseSecurityManager;
import com.polarion.platform.security.IPermission;
import com.polarion.platform.security.ISecurityService;
import com.polarion.subterra.base.data.identification.IContextId;
import com.polarion.wiki.util.Constants;

public class WikiPolicy implements IWikiPolicy {

    private final ISecurityService securityService;

    public WikiPolicy(ISecurityService securityService) {
        if (securityService == null) {
            throw new IllegalArgumentException("securityService is null"); //$NON-NLS-1$
        }
        this.securityService = securityService;
    }

    /*
     * Checks whether current user has read right for given project context.
     * For non-project context it always returns true.
     */
    private boolean canReadProject(IContextId contextId) {
        if (contextId.getContextName() != null) {
            IPermission readProjectPermission = securityService.constructPermission("com.polarion.persistence.object.Project.read"); //$NON-NLS-1$
            return securityService.hasPermission(readProjectPermission, contextId);
        }
        return true;
    }

    private boolean hasPermission(IPermission permission, IContextId contextId) {
        // test for project read permission is there to support the setup when root permission
        // configuration must ensure that general user does not see any project and yet he can
        // see root wiki pages
        return canReadProject(contextId) && securityService.hasPermission(permission, contextId);
    }

    @Override
    public boolean canModifyPages(IContextId contextId) {
        return licenseAllowsWriteAccess() && hasPermission(new WikiPagePermission(null, null, WikiPagePermission.ACTION_MODIFY), contextId);
    }

    @Override
    public boolean canDeletePages(IContextId contextId) {
        return licenseAllowsWriteAccess() && hasPermission(new WikiPagePermission(null, null, WikiPagePermission.ACTION_DELETE), contextId);
    }

    @Override
    public boolean canReadPages(IContextId contextId) {
        return hasPermission(new WikiPagePermission(null, null, WikiPagePermission.ACTION_READ), contextId);
    }

    @Override
    public boolean canCreatePages(IContextId contextId) {
        return licenseAllowsWriteAccess() && hasPermission(new WikiPagePermission(null, null, WikiPagePermission.ACTION_CREATE), contextId);
    }

    @Override
    public boolean canModifyPage(String page, IContextId contextId) {
        return licenseAllowsWriteAccess() && hasPermission(new WikiPagePermission(Constants.DEFAULT_SPACE, page, WikiPagePermission.ACTION_MODIFY), contextId);
    }

    @Override
    public boolean canDeletePage(String page, IContextId contextId) {
        return licenseAllowsWriteAccess() && hasPermission(new WikiPagePermission(Constants.DEFAULT_SPACE, page, WikiPagePermission.ACTION_DELETE), contextId);
    }

    @Override
    public boolean canReadPage(String page, IContextId contextId) {
        return hasPermission(new WikiPagePermission(Constants.DEFAULT_SPACE, page, WikiPagePermission.ACTION_READ), contextId);
    }

    private boolean licenseAllowsWriteAccess() {
        return LicenseSecurityManager.getLicenseManager().isFeatureAvailableForCurrentUser(FeatureEnum.WriteAccess);
    }

}
