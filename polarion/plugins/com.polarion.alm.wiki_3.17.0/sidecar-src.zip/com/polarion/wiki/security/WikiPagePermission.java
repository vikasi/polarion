/*
 * Copyright (C) 2004-2014 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2014 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.polarion.wiki.security;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import com.polarion.platform.core.PlatformContext;
import com.polarion.platform.security.IPermission;
import com.polarion.platform.security.ISecurityService;
import com.polarion.platform.security.Permission;

/**
 * @deprecated Kept here only because the deprecated implementation ({@link WikiPolicy}) uses it.
 */
@Deprecated
public class WikiPagePermission extends Permission {
    @NotNull
    private static final String PERM_WIKI_PREFIX = "com.polarion.persistence.object.WikiPage."; //$NON-NLS-1$
    @NotNull
    private static final String SPACE_VALUE_NAME = "space"; //$NON-NLS-1$
    @NotNull
    private static final String PAGE_VALUE_NAME = "page"; //$NON-NLS-1$

    @NotNull
    public static final String ACTION_READ = "read"; //$NON-NLS-1$
    @NotNull
    public static final String ACTION_MODIFY = "modify"; //$NON-NLS-1$
    @NotNull
    public static final String ACTION_DELETE = "delete"; //$NON-NLS-1$
    @NotNull
    public static final String ACTION_CREATE = "create"; //$NON-NLS-1$

    @Nullable
    private String space;
    @Nullable
    private String page;
    //@Nullable
    private String action;

    public WikiPagePermission(@NotNull String name) {
        super(name);
        deconstructPermissionName(name);
    }

    public WikiPagePermission(@Nullable String space, @Nullable String page, @NotNull String action) {
        super(constructPermissionName(space, page, action));
        this.space = space;
        this.page = page;
        this.action = action;
    }

    @NotNull
    private static String constructPermissionName(@Nullable String space, @Nullable String page, @NotNull String action) {
        StringBuffer buff = new StringBuffer(PERM_WIKI_PREFIX);
        if (space != null) {
            buff.append(SPACE_VALUE_NAME).append(".").append(space).append("."); //$NON-NLS-1$ //$NON-NLS-2$
        }
        if (page != null) {
            buff.append(PAGE_VALUE_NAME).append(".").append(page).append("."); //$NON-NLS-1$ //$NON-NLS-2$
        }
        buff.append(action);
        return buff.toString();
    }

    private void deconstructPermissionName(@NotNull String name) {
        if (!name.startsWith(PERM_WIKI_PREFIX)) {
            throw new IllegalArgumentException("Unknow permission: " + name); //$NON-NLS-1$
        }
        space = null;
        page = null;
        action = null;

        StringBuffer buff = new StringBuffer(name);
        buff.delete(0, PERM_WIKI_PREFIX.length());
        int lastDotIdx = buff.lastIndexOf("."); //$NON-NLS-1$
        if (lastDotIdx < 0) {
            action = buff.toString();
            return;
        }
        action = buff.substring(lastDotIdx + 1);
        buff.delete(lastDotIdx, buff.length());

        space = readValue(SPACE_VALUE_NAME, buff);
        page = readValue(PAGE_VALUE_NAME, buff);
    }

    /**
     * If buffer starts with name=".", string after this prefix up to next "."
     * or end of the string is returned (= value), and the name+"."+value[+"."]
     * is removed from the buffer. Otherwise null is returned and buffer is unchanged.
     */
    @Nullable
    private static String readValue(@NotNull String name, @NotNull StringBuffer buff) {
        String namePrefix = name + "."; //$NON-NLS-1$
        String value = null;
        if (buff.indexOf(namePrefix) == 0) {
            buff.delete(0, namePrefix.length());
            String suffix = buff.toString();
            int dotIdx = buff.indexOf("."); //$NON-NLS-1$
            if (dotIdx < 0) {
                value = suffix;
                buff.delete(0, value.length());
            } else {
                value = suffix.substring(0, dotIdx);
                buff.delete(0, value.length() + 1);
            }
        }
        return value;
    }

    @NotNull
    public String getAction() {
        return action;
    }

    // used in tests
    @Nullable
    public String getSpace() {
        return space;
    }

    // used in tests
    @Nullable
    public String getPage() {
        return page;
    }

    //@Nullable
    private IPermission[] parentPermissions = null;

    @NotNull
    private static IPermission[] deriveParentPermissions(@Nullable String space, @Nullable String page, @NotNull String action) {
        if (space == null) {
            ISecurityService ss = PlatformContext.getPlatform().lookupService(ISecurityService.class);
            return new IPermission[] { ss.constructPermission("com.polarion.persistence.object." + action) }; //$NON-NLS-1$
        }
        if (page == null) {
            return new IPermission[] { new WikiPagePermission(null, null, action) };
        }
        return new IPermission[] { new WikiPagePermission(space, null, action) };
    }

    @Override
    @NotNull
    public IPermission[] getParentPermissions() {
        if (parentPermissions == null) {
            parentPermissions = deriveParentPermissions(space, page, action);
        }
        return parentPermissions;
    }

}
