/*
 * Copyright (C) 2004-2014 POLARION SOFTWARE
 * All rights reserved.
 * Email: info@polarion.com
 *
 *
 * Copyright (C) 2004-2010 POLARION SOFTWARE
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from POLARION SOFTWARE. This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.polarion.wiki.auth;

import java.security.PrivilegedAction;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.inject.Inject;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.jetbrains.annotations.NotNull;

import com.polarion.alm.projects.IProjectService;
import com.polarion.alm.projects.model.IUniqueObject;
import com.polarion.alm.tracker.ITestManagementService;
import com.polarion.alm.tracker.ITrackerService;
import com.polarion.alm.tracker.model.IModule;
import com.polarion.alm.tracker.model.IPlan;
import com.polarion.alm.tracker.model.IRichPage;
import com.polarion.alm.tracker.model.ITestRun;
import com.polarion.alm.tracker.model.ITrackerUser;
import com.polarion.alm.tracker.model.IWikiPage;
import com.polarion.platform.core.PlatformContext;
import com.polarion.platform.guice.internal.GuicePlatform;
import com.polarion.platform.persistence.IPersistencePolicy;
import com.polarion.platform.persistence.internal.PersistencePermission;
import com.polarion.platform.security.PermissionDeniedException;
import com.polarion.subterra.base.data.identification.ContextId;
import com.polarion.subterra.base.data.identification.IContextId;
import com.polarion.subterra.base.data.identification.ILocalId;
import com.polarion.subterra.base.data.identification.IObjectId;
import com.polarion.subterra.base.data.identification.LocalId;
import com.polarion.subterra.base.data.identification.ObjectId;
import com.polarion.subterra.base.location.Location;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.objects.BaseObject;
import com.xpn.xwiki.user.api.XWikiGroupService;
import com.xpn.xwiki.user.api.XWikiRightNotFoundException;
import com.xpn.xwiki.user.api.XWikiRightService;
import com.xpn.xwiki.util.Util;

public class SidecarRightServiceImpl implements XWikiRightService {
    public static final String PROJECT_LEVEL_PERMISSION = "com.polarion.persistence.object.Project"; //$NON-NLS-1$

    private static final Logger log = Logger.getLogger(SidecarRightServiceImpl.class);
    private static Map<String, String> actionMap;
    private static List<String> list;
    private static Map permissionsMap;

    private final IProjectService projectService;
    private final ITrackerService trackerService;
    private ITestManagementService testService;

    @SuppressWarnings("deprecation")
    public SidecarRightServiceImpl() {
        projectService = PlatformContext.getPlatform().lookupService(IProjectService.class);
        trackerService = PlatformContext.getPlatform().lookupService(ITrackerService.class);

        GuicePlatform.getGlobalInjector().injectMembers(this);
    }

    @Inject
    public void setTestService(ITestManagementService testService) {
        this.testService = testService;
    }

    protected void logAllow(String username, String page, String action, String info) {
        if (log.isDebugEnabled()) {
            log.debug("Access has been granted for (" + username + "," + page + "," + action + "): " + info); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
        }
    }

    protected void logDeny(String username, String page, String action, String info) {
        if (log.isInfoEnabled()) {
            log.info("Access has been denied for (" + username + "," + page + "," + action + "): " + info); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
        }
    }

    protected void logDeny(String name, String resourceKey, String accessLevel, String info, Exception e) {
        if (log.isDebugEnabled()) {
            log.debug("Access has been denied for (" + name + "," + resourceKey + "," + accessLevel + ") at " + info, e); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
        }
    }

    @Override
    public List listAllLevels(XWikiContext context) throws XWikiException {
        if (list == null) {
            list = new ArrayList<String>();
            String levels = "admin,view,edit,comment,delete,register,programming"; //$NON-NLS-1$
            String[] level = levels.split(","); //$NON-NLS-1$
            for (String element : level) {
                list.add(element);
            }
        }
        return list;
    }

    public String getRight(String action) {
        if (actionMap == null) {
            actionMap = new HashMap<String, String>();
            actionMap.put("login", "login"); //$NON-NLS-1$ //$NON-NLS-2$
            actionMap.put("logout", "login"); //$NON-NLS-1$ //$NON-NLS-2$
            actionMap.put("loginerror", "login"); //$NON-NLS-1$ //$NON-NLS-2$
            actionMap.put("view", "view"); //$NON-NLS-1$ //$NON-NLS-2$
            actionMap.put("viewrev", "view"); //$NON-NLS-1$ //$NON-NLS-2$
            actionMap.put("downloadrev", "download"); //$NON-NLS-1$ //$NON-NLS-2$
            actionMap.put("plain", "view"); //$NON-NLS-1$ //$NON-NLS-2$
            actionMap.put("raw", "view"); //$NON-NLS-1$ //$NON-NLS-2$
            actionMap.put("attach", "view"); //$NON-NLS-1$ //$NON-NLS-2$
            actionMap.put("skin", "view"); //$NON-NLS-1$ //$NON-NLS-2$
            actionMap.put("download", "view"); //$NON-NLS-1$ //$NON-NLS-2$
            actionMap.put("dot", "view"); //$NON-NLS-1$ //$NON-NLS-2$
            actionMap.put("svg", "view"); //$NON-NLS-1$ //$NON-NLS-2$
            actionMap.put("pdf", "view"); //$NON-NLS-1$ //$NON-NLS-2$
            actionMap.put("pdfdialogaction", "view"); //$NON-NLS-1$ //$NON-NLS-2$
            actionMap.put("delete", "delete"); //$NON-NLS-1$ //$NON-NLS-2$
            actionMap.put("reset", "delete"); //$NON-NLS-1$ //$NON-NLS-2$
            actionMap.put("commentadd", "comment"); //$NON-NLS-1$ //$NON-NLS-2$
            actionMap.put("register", "register"); //$NON-NLS-1$ //$NON-NLS-2$
            actionMap.put("redirect", "view"); //$NON-NLS-1$ //$NON-NLS-2$
            actionMap.put("admin", "admin"); //$NON-NLS-1$ //$NON-NLS-2$
            actionMap.put("export", "admin"); //$NON-NLS-1$ //$NON-NLS-2$
            actionMap.put("import", "admin"); //$NON-NLS-1$ //$NON-NLS-2$
        }

        String right = actionMap.get(action);
        if (right == null) {
            return "edit"; //$NON-NLS-1$
        } else {
            return right;
        }
    }

    @Override
    public boolean checkAccess(String action, XWikiDocument doc, XWikiContext context) throws XWikiException {
        //log.error("Check access: " + action + ", " + doc.getFullName());
        return true;
    }

    @Override
    public boolean hasAccessLevel(String right, String username, String docname, XWikiContext context) throws XWikiException {
        try {
            return hasAccessLevel(right, username, docname, true, context);
        } catch (XWikiException e) {
            return false;
        }
    }

    public boolean checkRight(String name, XWikiDocument doc, String accessLevel, boolean user, boolean allow, boolean global, XWikiContext context) throws XWikiRightNotFoundException, XWikiException {
        //log.error("Check right: " + name + ", " + doc.getFullName() + ", " + accessLevel);
        String className = global ? "XWiki.XWikiGlobalRights" : "XWiki.XWikiRights"; //$NON-NLS-1$ //$NON-NLS-2$
        String fieldName = user ? "users" : "groups"; //$NON-NLS-1$ //$NON-NLS-2$
        boolean found = false;

        // Get the userdb and the shortname
        String userdatabase = null;
        String shortname = name;
        int i0 = name.indexOf(":"); //$NON-NLS-1$
        if (i0 != -1) {
            userdatabase = name.substring(0, i0);
            shortname = name.substring(i0 + 1);
        }

        if (log.isDebugEnabled()) {
            log.debug("Checking right: " + name + "," + doc.getFullName() + "," + accessLevel + "," + user + "," + allow + "," + global); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
        }

        Vector vobj = doc.getObjects(className);
        if (vobj != null) {
            if (log.isDebugEnabled()) {
                log.debug("Checking objects " + vobj.size()); //$NON-NLS-1$
            }
            for (int i = 0; i < vobj.size(); i++) {
                if (log.isDebugEnabled()) {
                    log.debug("Checking object " + i); //$NON-NLS-1$
                }

                BaseObject bobj = (BaseObject) vobj.get(i);

                if (bobj == null) {
                    if (log.isDebugEnabled()) {
                        log.debug("Bypass object " + i); //$NON-NLS-1$
                    }
                    continue;
                }
                String users = bobj.getStringValue(fieldName);
                String levels = bobj.getStringValue("levels"); //$NON-NLS-1$
                boolean allowdeny = (bobj.getIntValue("allow") == 1); //$NON-NLS-1$

                if (allowdeny == allow) {
                    if (log.isDebugEnabled()) {
                        log.debug("Checking match: " + accessLevel + " in " + levels); //$NON-NLS-1$ //$NON-NLS-2$
                    }

                    String[] levelsarray = StringUtils.split(levels, " ,|"); //$NON-NLS-1$
                    if (ArrayUtils.contains(levelsarray, accessLevel)) {
                        if (log.isDebugEnabled()) {
                            log.debug("Found a right for " + allow); //$NON-NLS-1$
                        }
                        found = true;

                        if (log.isDebugEnabled()) {
                            log.debug("Checking match: " + name + " in " + users); //$NON-NLS-1$ //$NON-NLS-2$
                        }

                        String[] userarray = StringUtils.split(users, " ,|"); //$NON-NLS-1$

                        for (int ii = 0; ii < userarray.length; ii++) {
                            String value = userarray[ii];
                            if (value.indexOf(".") == -1) { //$NON-NLS-1$
                                userarray[ii] = "XWiki." + value; //$NON-NLS-1$
                            }
                        }

                        if (log.isDebugEnabled()) {
                            log.debug("Checking match: " + name + " in " + StringUtils.join(userarray, ",")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
                        }

                        // In the case where the document database and the user
                        // database is the same
                        // then we allow the usage of the short name, otherwise
                        // the fully qualified name is requested
                        if (context.getDatabase().equals(userdatabase)) {
                            if (ArrayUtils.contains(userarray, shortname)) {
                                if (log.isDebugEnabled()) {
                                    log.debug("Found matching right in " + users + " for " + shortname); //$NON-NLS-1$ //$NON-NLS-2$
                                }
                                return true;
                            }
                            // We should also allow to skip "XWiki." from the
                            // usernames and group lists
                            String veryshortname = shortname.substring(shortname.indexOf(".") + 1); //$NON-NLS-1$
                            if (ArrayUtils.contains(userarray, veryshortname)) {
                                if (log.isDebugEnabled()) {
                                    log.debug("Found matching right in " + users + " for " + shortname); //$NON-NLS-1$ //$NON-NLS-2$
                                }
                                return true;
                            }
                        }

                        if ((context.getDatabase() != null) && (ArrayUtils.contains(userarray, name))) {
                            if (log.isDebugEnabled()) {
                                log.debug("Found matching right in " + users + " for " + name); //$NON-NLS-1$ //$NON-NLS-2$
                            }
                            return true;
                        }

                        if (log.isDebugEnabled()) {
                            log.debug("Failed match: " + name + " in " + users); //$NON-NLS-1$ //$NON-NLS-2$
                        }
                    }
                } else {
                    if (log.isDebugEnabled()) {
                        log.debug("Bypass object because wrong allow/deny" + i); //$NON-NLS-1$
                    }
                }
            }
        }

        if (log.isDebugEnabled()) {
            log.debug("Searching for matching rights at group level"); //$NON-NLS-1$
        }

        // Didn't found right at this level.. Let's go to group level
        Map grouplistcache = (Map) context.get("grouplist"); //$NON-NLS-1$
        if (grouplistcache == null) {
            grouplistcache = new HashMap();
            context.put("grouplist", grouplistcache); //$NON-NLS-1$
        }

        Collection grouplist = new ArrayList();
        XWikiGroupService groupService = context.getWiki().getGroupService(context);
        String key = context.getDatabase() + ":" + name; //$NON-NLS-1$
        Collection grouplist1 = (Collection) grouplistcache.get(key);

        if (grouplist1 == null) {
            grouplist1 = new ArrayList();
            try {
                Collection glist = groupService.listGroupsForUser(name, context);
                Iterator it = glist.iterator();

                while (it.hasNext()) {
                    grouplist1.add(context.getDatabase() + ":" + it.next()); //$NON-NLS-1$
                }
            } catch (Exception e) {
                //
            }

            grouplistcache.put(key, grouplist1);
        }

        grouplist.addAll(grouplist1);

        if (context.isVirtual()) {
            String database = context.getDatabase();
            try {
                shortname = Util.getName(name, context);

                if (!database.equals(context.getDatabase())) {
                    String key2 = context.getDatabase() + ":" + name; //$NON-NLS-1$
                    Collection grouplist2 = (Collection) grouplistcache.get(key2);

                    if (grouplist2 == null) {
//                        Collection glist = groupService.listGroupsForUser(shortname, context);
//                        Iterator it = glist.iterator();
//                        while (it.hasNext())
//                        {
//                            grouplist2.add(context.getDatabase() + ":" + it.next());
//                        }
                        grouplistcache.put(key2, new ArrayList());

                    }

                    if (grouplist2 != null) {
                        grouplist.addAll(grouplist2);
                    }
                }
            } catch (Exception e) {
                //
            } finally {
                context.setDatabase(database);
            }
        }

        if (log.isDebugEnabled()) {
            log.debug("Searching for matching rights for " + grouplist.size() + " groups: " + grouplist); //$NON-NLS-1$ //$NON-NLS-2$
        }

        Iterator groupit = grouplist.iterator();
        while (groupit.hasNext()) {
            String group = (String) groupit.next();
            try {
                // We need to construct the full group name to make sure the
                // groups are
                // handled separately
                boolean result = checkRight(group, doc, accessLevel, false, allow, global, context);
                if (result) {
                    return true;
                }
            } catch (XWikiRightNotFoundException e) {//
            } catch (Exception e) {
                // This should not happen
                e.printStackTrace();
            }
        }

        if (log.isDebugEnabled()) {
            log.debug("Finished searching for rights for " + name + ": " + found); //$NON-NLS-1$ //$NON-NLS-2$
        }

        if (found) {
            return false;
        } else {
            throw new XWikiRightNotFoundException();
        }
    }

    public Map /*String : String*/ getPermissionsMap() {
        if (permissionsMap == null) {
            permissionsMap = new HashMap();
            permissionsMap.put("view", "read"); //$NON-NLS-1$ //$NON-NLS-2$
            permissionsMap.put("edit", "modify"); //$NON-NLS-1$ //$NON-NLS-2$
        }
        return permissionsMap;
    }

    /*private boolean hasPermission(IPermission permission, IContextId contextId){
    	boolean hasPermission = false;
    	try{
    		ISecurityService ss = (ISecurityService) PlatformContext.getPlatform().lookupService(ISecurityService.class);
    		ss.checkPermission(permission, contextId);
    		hasPermission = ss.hasPermission(permission, contextId);
    	} catch (PermissionDeniedException pde){
    		IPermission[] parentPermissions = permission.getParentPermissions();
    		for (int i = 0; i < parentPermissions.length; i++){
    			hasPermission = hasPermission || hasPermission(parentPermissions[i], contextId);
    		}
    	} catch (Exception e){
    		log.error(e);
    	}

    	//log.error("Has current user " + permission.getName() + " permission on " + contextId.getContextName() + "?: " + (new Boolean(hasPermission)).toString());
    	return hasPermission;
    }*/

    @Override
    public boolean hasPermission(String space, String name, String level, String projectName) {
        boolean hasPermission = false;
        try {
            IPersistencePolicy policy = trackerService.getDataService().getPersistencePolicy();
            ILocalId pageLid = LocalId.getLocalIdWithContainer(IWikiPage.PROTO, LocalId.getLocalId(IModule.KEY_MODULEFOLDER, space), name);
            IObjectId pageId = ObjectId.getCrossContextObjectId(getContextId(projectName), pageLid);
            IWikiPage page = (IWikiPage) trackerService.getDataService().getInstance(pageId);
            if (page.isUnresolvable()) {
                page = createTestPage(page);
            }
            if (PersistencePermission.ACTION_READ.equals(level)) {
                hasPermission = page.can().read();
            } else if (PersistencePermission.ACTION_MODIFY.equals(level)) {
                hasPermission = page.can().modify();
            } else if (PersistencePermission.ACTION_DELETE.equals(level)) {
                hasPermission = page.can().delete();
            } else if (PersistencePermission.ACTION_CREATE.equals(level)) {
                if (projectName != null && !projectName.isEmpty()) {
                    hasPermission = trackerService.getTrackerProject(projectName).can().createWikiPage(space);
                } else {
                    hasPermission = policy.canCreateInstance(page);
                }
            } else if ("createRichPage".equals(level)) { //$NON-NLS-1$
                if (projectName != null && !projectName.isEmpty()) {
                    hasPermission = trackerService.getTrackerProject(projectName).can().createRichPage(space);
                } else {
                    hasPermission = policy.canCreateInstance(getGlobalRichPage(space, name));
                }
            }
        } catch (PermissionDeniedException pde) {//
        } catch (Exception e) {
            log.error(e);
        }
        //log.error("Has user " + context.getUser() + " " + permission.getName() + " permission on " + projectName + "?: " + (new Boolean(hasPermission)).toString());
        return hasPermission;
    }

    @NotNull
    private IRichPage getGlobalRichPage(@NotNull String space, @NotNull String name) {
        ILocalId pageLid = LocalId.getLocalIdWithContainer(IRichPage.PROTO, LocalId.getLocalId(IModule.KEY_MODULEFOLDER, space), name);
        IObjectId pageId = ObjectId.getCrossContextObjectId(getContextId(null), pageLid);
        IRichPage page = (IRichPage) trackerService.getDataService().getInstance(pageId);
        if (page.isUnresolvable()) {
            page = createTestPage(page);
        }
        return page;
    }

    @NotNull
    private IWikiPage createTestPage(final @NotNull IWikiPage obj) {
        return (IWikiPage) obj.getDataSvc().getSecurityService().doAsSystemUser(new PrivilegedAction<IWikiPage>() {
            @Override
            public IWikiPage run() {
                IWikiPage page = (IWikiPage) obj.getDataSvc().createInstance(IWikiPage.PROTO);
                page.setValue(IWikiPage.KEY_PAGENAME, obj.getPageName());
                page.setValue(IWikiPage.KEY_SPACEID, obj.getSpaceId());
                page.setValue(IWikiPage.KEY_LOCATION, Location.getLocation(obj.getSpaceId()));
                page.setValue(IUniqueObject.KEY_PROJECT, obj.getProject());
                return page;
            }
        });
    }

    @NotNull
    private IRichPage createTestPage(final @NotNull IRichPage obj) {
        return (IRichPage) obj.getDataSvc().getSecurityService().doAsSystemUser(new PrivilegedAction<IRichPage>() {
            @Override
            public IRichPage run() {
                IRichPage page = (IRichPage) obj.getDataSvc().createInstance(IRichPage.PROTO);
                page.setValue(IRichPage.KEY_PAGENAME, obj.getPageName());
                page.setValue(IRichPage.KEY_SPACEID, obj.getSpaceId());
                page.setValue(IRichPage.KEY_LOCATION, Location.getLocation(obj.getSpaceId()));
                page.setValue(IUniqueObject.KEY_PROJECT, obj.getProject());
                return page;
            }
        });
    }

    @Override
    public boolean hasPermission(String level, XWikiContext context) {
        XWikiDocument doc = context.getDoc();
        return hasPermission(doc.getSpaceName(), doc.getName(), level, doc.getProject());
    }

    public boolean hasAccessLevel(String accessLevel, String name, String resourceKey, boolean user, XWikiContext context) throws XWikiException {
        // native XWiki rights implementation is not needed now
        return true;
    }

    @Override
    public boolean hasProgrammingRights(XWikiContext context) {
        XWikiDocument sdoc = (XWikiDocument) context.get("sdoc"); //$NON-NLS-1$
        if (sdoc == null) {
            sdoc = context.getDoc();
        }
        return hasProgrammingRights(sdoc, context);
    }

    @Override
    public boolean hasProgrammingRights(XWikiDocument doc, XWikiContext context) {
        try {
            if (doc == null) {
                return false;
            }

            String username = doc.getAuthor();

            if (username == null) {
                return false;
            }

            String docname;
            if (doc.getDatabase() != null) {
                docname = doc.getDatabase() + ":" + doc.getFullName(); //$NON-NLS-1$
                if (username.indexOf(":") == -1) { //$NON-NLS-1$
                    username = doc.getDatabase() + ":" + username; //$NON-NLS-1$
                }
            } else {
                docname = doc.getFullName();
            }

            // programming rights can only been given for user of the main wiki
            if (context.getWiki().isVirtual()) {
                String maindb = context.getWiki().getDatabase();
                if ((maindb == null) || (!username.startsWith(maindb))) {
                    return false;
                }
            }

            return hasAccessLevel("programming", username, docname, context); //$NON-NLS-1$
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }

    }

    @Override
    public boolean hasAdminRights(XWikiContext context) {
        boolean hasAdmin = false;
        try {
            hasAdmin = hasAccessLevel("admin", context.getUser(), "XWiki.XWikiPreferences", context); //$NON-NLS-1$ //$NON-NLS-2$
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (!hasAdmin) {
            try {
                hasAdmin = hasAccessLevel("admin", context.getUser(), context.getDoc().getSpace() + ".WebPreferences", context); //$NON-NLS-1$ //$NON-NLS-2$
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return hasAdmin;
    }

    @Override
    public boolean hasUserDashboardPermission(String name, String permissionName, String currentProject) {
        boolean hasPermission = false;
        try {
            if (name != null) {
                ITrackerUser trackerUser = trackerService.getTrackerUser(name);
                if (trackerUser != null && !trackerUser.isUnresolvable()) {
                    IPersistencePolicy persistencePolicy = trackerService.getDataService().getPersistencePolicy();
                    if (PersistencePermission.ACTION_READ.equals(permissionName)) {
                        hasPermission = persistencePolicy.canReadInstance(trackerUser);
                    } else if (PersistencePermission.ACTION_MODIFY.equals(permissionName)) {
                        hasPermission = persistencePolicy.canModifyInstance(trackerUser);
                    } else if (PersistencePermission.ACTION_DELETE.equals(permissionName)) {
                        hasPermission = persistencePolicy.canModifyInstance(trackerUser);
                    } else if (PersistencePermission.ACTION_CREATE.equals(permissionName)) {
                        hasPermission = persistencePolicy.canModifyInstance(trackerUser);
                    }
                }
            }
        } catch (Exception e) {
            log.error(e);
        }
        return hasPermission;
    }

    @Override
    public boolean hasTestRunPermission(String name, String permissionName, String currentProject) {
        boolean hasPermission = false;
        try {
            if (name != null) {
                IContextId contextId = trackerService.getProjectsService().getProject(currentProject).getContextId();
                IObjectId objectId = ObjectId.getCrossContextObjectId(contextId, LocalId.getLocalId(ITestRun.PROTO, name));
                ITestRun testRun = (ITestRun) trackerService.getDataService().getInstance(objectId);

                if (testRun != null && !testRun.isUnresolvable()) {
                    IPersistencePolicy persistencePolicy = trackerService.getDataService().getPersistencePolicy();
                    if (PersistencePermission.ACTION_READ.equals(permissionName)) {
                        hasPermission = persistencePolicy.canReadInstance(testRun);
                    } else if (PersistencePermission.ACTION_DELETE.equals(permissionName)) {
                        // delete of a test run overview is delete of the test run
                        hasPermission = persistencePolicy.canDeleteInstance(testRun);
                    } else if (PersistencePermission.ACTION_MODIFY.equals(permissionName) || PersistencePermission.ACTION_CREATE.equals(permissionName)) {
                        // just a modification of a test run, "create" means saving modified default page of the test run
                        hasPermission = persistencePolicy.canModifyInstance(testRun);
                    } else if ("createTestRun".equals(permissionName)) { //$NON-NLS-1$
                        // see note above about "create"
                        hasPermission = (trackerService.getDataService().getCurrentBaselineRevision() == null) && persistencePolicy.canCreateInstance(testRun);
                    } else if ("modifyTestRuns".equals(permissionName)) { //$NON-NLS-1$
                        hasPermission = testService.getPolicy().canModifyTestRuns();
                    }
                }
            }
        } catch (Exception e) {
            log.error(e);
        }
        return hasPermission;
    }

    @Override
    public boolean hasPlanPermission(String name, String permissionName, String currentProject) {
        boolean hasPermission = false;
        try {
            if (name != null) {
                IContextId contextId = trackerService.getProjectsService().getProject(currentProject).getContextId();
                IObjectId objectId = ObjectId.getCrossContextObjectId(contextId, LocalId.getLocalId(IPlan.PROTO, name));
                IPlan plan = (IPlan) trackerService.getDataService().getInstance(objectId);

                if (plan != null) {
                    IPersistencePolicy persistencePolicy = trackerService.getDataService().getPersistencePolicy();
                    if (PersistencePermission.ACTION_READ.equals(permissionName)) {
                        hasPermission = persistencePolicy.canReadInstance(plan);
                    } else if (PersistencePermission.ACTION_CREATE.equals(permissionName)) {
                        hasPermission = persistencePolicy.canCreateInstance(plan);
                    } else if (PersistencePermission.ACTION_DELETE.equals(permissionName)) {
                        hasPermission = persistencePolicy.canDeleteInstance(plan);
                    } else if (PersistencePermission.ACTION_MODIFY.equals(permissionName)) {
                        hasPermission = persistencePolicy.canModifyInstance(plan);
                    }
                }
            }
        } catch (Exception e) {
            log.error(e);
        }

        return hasPermission;
    }

    private IContextId getContextId(String project) {
        if ((project == null) || project.equals("")) { //$NON-NLS-1$
            return ContextId.getGlobalContextId();
        }
        return projectService.getProject(project).getContextId();
    }

}
