package com.polarion.wiki.auth;

import java.security.Principal;

import javax.security.auth.Subject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.polarion.platform.core.PlatformContext;
import com.polarion.platform.hivemind.EclipseHiveMindPlatform;
import com.polarion.platform.security.AuthenticationFailedException;
import com.polarion.platform.security.ISecurityService;
import com.polarion.portal.tomcat.realm.PrincipalX;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.user.api.XWikiAuthService;
import com.xpn.xwiki.user.api.XWikiUser;

public class SidecarAuthServiceImpl implements XWikiAuthService
{

    private static final Log log = LogFactory.getLog(SidecarAuthServiceImpl.class);

    @Override
    public XWikiUser checkAuth(XWikiContext context) throws XWikiException
    {
        //log.error("Check Auth");
        HttpServletRequest request = null;
        HttpServletResponse response = null;

        if (context.getRequest() != null) {
            request = context.getRequest().getHttpServletRequest();
        }

        if (context.getResponse() != null) {
            response = context.getResponse().getHttpServletResponse();
        }

        if (request == null) {
            return null;
        }

        //polarion user is already authentified?
        Principal user = request.getUserPrincipal();
        if ((user instanceof PrincipalX) && user != null) {
            log.debug("Polarion User " + user.getName() + " is already authentified");
            return new XWikiUser(user.getName());
        }

        try
        {
            if (user == null) {
                return null;
            } else {
                return new XWikiUser(user.getName());
            }
        } catch (Exception e)
        {
            log.error(e);
            return null;
        }
    }

    @Override
    public void showLogin(XWikiContext context) throws XWikiException
    {
    }

    @Override
    public Principal authenticate(String username, String password, XWikiContext context) throws XWikiException
    {
        log.debug("(TRY REG) Authenticate: " + username + ", pass: " + password);

        if ((username == null) || (username.trim().equals("")))
        {
            context.put("message", "nousername");
            return null;
        }

        if ((password == null) || (password.trim().equals("")))
        {
            context.put("message", "nopassword");
            return null;
        }

        // If we have the context then we are using direct mode
        // then we should specify the database
        // This is needed for virtual mode to work
        if (context != null)
        {
            String susername = username;
            int i = username.indexOf(".");
            if (i != -1) {
                susername = username.substring(i + 1);
            }

            // First we check in the local database
            try
            {
                String user = findUser(susername, context);
                if (user != null)
                {
                    if (checkPassword(user, password, context))
                    {

                        Subject subj = (Subject) context.getRequest().getSession().getAttribute("SVN_SUBJECT");

                        if (null == subj)
                        {
                            try
                            {

                                // Verify Platform 
                                //TODO: please exmplain!!! This should not bee needed at all
                                if (!PlatformContext.isInitialized())
                                {
                                    EclipseHiveMindPlatform platform = new EclipseHiveMindPlatform();
                                    PlatformContext.initPlatform(platform);
                                }

                                ISecurityService securityService = (ISecurityService) PlatformContext.getPlatform().lookupService(ISecurityService.class);

                                if (susername.equals("superadmin")) {
                                    subj = securityService.getSystemUserSubject();
                                } else {
                                    String addr = context.getRequest().getRemoteAddr();
                                    if (addr == null) {
                                        addr = "UNKNOWN";
                                    }
                                    String source = "wiki/" + addr;
                                    subj = securityService.login(susername, password, source);
                                }

                                context.getRequest().getSession().setAttribute("SVN_SUBJECT", subj);

                            } catch (AuthenticationFailedException e)
                            {
                                context.getRequest().getSession().setAttribute("SVN_SUBJECT", null);
                                context.put("message", "loginfailed");
                                return null;
                            }
                        }

                        return null;
                    }
                    else
                    {
                        context.put("message", "wrongpassword");
                    }
                }
                else
                {
                    context.put("message", "wronguser");
                }
            } catch (Exception e)
            {
                // continue
            }

            if (context.isVirtual())
            {
                // Then we check in the main database
                String db = context.getDatabase();
                try
                {
                    context.setDatabase(context.getWiki().getDatabase());
                    try
                    {
                        String user = findUser(susername, context);
                        if (user != null)
                        {
                            if (checkPassword(user, password, context))
                            {
                                return null;
                            }
                            else
                            {
                                context.put("message", "wrongpassword");
                                return null;
                            }
                        }
                        else
                        {
                            context.put("message", "wronguser");
                            return null;
                        }
                    } catch (Exception e)
                    {
                        context.put("message", "loginfailed");
                        return null;
                    }
                } finally
                {
                    context.setDatabase(db);
                }
            }
            else
            {
                // error message was already set
                return null;
            }
        }
        else
        {
            //context.put("message", "loginfailed");
            return null;
        }
    }

    protected String findUser(String susername2, XWikiContext context) throws XWikiException
    {
        String susername = susername2.replaceAll(" ", "");

        susername = susername.replaceAll(" ", "");

        log.debug("Find user: " + susername);
        // First lets look in the cache
        /*if (context.getWiki().exists("XWiki." + susername, context))
        {
        	log.error("Found in cache");
        	return "XWiki." + susername;
        }*/

        boolean find = false;

        try
        {
            XWikiDocument doc = new XWikiDocument("XWiki", susername);
            find = context.getDoc().getStore().exists(doc, context);
            log.debug("User exists is: " + find);
        } catch (Exception e)
        {
            log.error("Exception while try find user: " + susername);
        }

        if (find) {
            return "XWiki." + susername;
        }

        /*String sql = "select distinct doc.web, doc.name from XWikiDocument as doc where doc.web='XWiki' and doc.name like '" + Utils.SQLFilter(susername) + "'";
        List list = context.getWiki().search(sql, context);
        if (list.size() == 0)
        	return null;
        if (list.size() > 1)
        {
        	for (int i = 0; i < list.size(); i++)
        	{
        		Object[] result = (Object[]) list.get(0);
        		if (result[1].equals(susername))
        			return result[0] + "." + result[1];
        	}
        }
        Object[] result = (Object[]) list.get(0);*/
        //return result[0] + "." + result[1];

        return ".";
    }

    protected boolean checkPassword(String username, String password, XWikiContext context) throws XWikiException
    {
        try
        {

            log.debug("Check password: " + username + ", pass: " + password);
            boolean result = false;
            XWikiDocument doc = context.getWiki().getDocument(username, context);
            // We only allow empty password from users having a XWikiUsers
            // object.
            try
            {
                if (log.isDebugEnabled()) {
                    log.debug("Found: " + doc);
                }
            } catch (Exception e)
            {
                log.error("Doc not found");
            }

            if (doc.getObject("XWiki.XWikiUsers") != null)
            {
                String passwd = doc.getStringValue("XWiki.XWikiUsers", "password");
                result = (password.equals(passwd));
            }

            if (log.isDebugEnabled())
            {
                if (result) {
                    log.debug("(debug) Password check for user " + username + " successfull");
                } else {
                    log.debug("(debug) Password check for user " + username + " failed");
                }
            }

            return result;
        } catch (Throwable e)
        {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public XWikiUser checkAuth(String username, String password, String rememberme, XWikiContext context) throws XWikiException
    {
        return null;
    }

}
