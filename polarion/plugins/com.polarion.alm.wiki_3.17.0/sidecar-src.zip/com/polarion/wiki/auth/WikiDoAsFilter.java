package com.polarion.wiki.auth;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import com.polarion.portal.tomcat.servlets.DoAsFilter;

public class WikiDoAsFilter extends DoAsFilter {

    @Override
    public void doFilter(final ServletRequest request, final ServletResponse response, final FilterChain chain) throws IOException, ServletException {
        if (!isStandalone()) {
            super.doFilter(request, response, chain);
        } else {
            chain.doFilter(request, response);
        }
    }

    //XXX: to wiki team, reimplement as you wish, but must be default 
    public static boolean isStandalone() {
        return Boolean.getBoolean("wiki.standalone");
    }

}
