package com.polarion.wiki.web;

import java.util.Calendar;

import org.apache.velocity.VelocityContext;

import com.polarion.wiki.integration.IntegrationPlugin;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.api.WorkItem;
import com.xpn.xwiki.web.XWikiAction;

public class WorkItemAction extends XWikiAction
{

    @Override
    public boolean action(XWikiContext context) throws XWikiException
    {

        Calendar cl = Calendar.getInstance();
        long id = cl.getTimeInMillis() + IntegrationPlugin.getUniqID();
        VelocityContext vcontext = (VelocityContext) context.get("vcontext");
        WorkItem item = new WorkItem(context, id);
        item.setId(id);
        context.put("workitem", item);
        vcontext.put("workitem", item.newItem(context, id));
        return true;
    }

    @Override
    public String render(XWikiContext context) throws XWikiException
    {

        return "loadwi";
    }
}
