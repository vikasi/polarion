/*
 * Copyright (C) 2004-2009 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2009 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.polarion.wiki.web;

import java.util.Map;

import org.apache.velocity.VelocityContext;

import com.polarion.alm.reports.server.ReportsPolicy;
import com.polarion.alm.reports.server.ReportsProvider;
import com.polarion.alm.reports.shared.ReportData;
import com.polarion.alm.reports.shared.ReportPolicyData;
import com.polarion.alm.tracker.web.internal.server.liveplan.LivePlanDataProvider;
import com.polarion.core.util.logging.Logger;
import com.polarion.portal.internal.shared.navigation.ProjectGroupScope;
import com.polarion.portal.internal.shared.navigation.ProjectScope;
import com.polarion.portal.shared.navigation.IScope;
import com.polarion.portal.shared.navigation.Perspective;
import com.polarion.portal.shared.navigation.PortalService;
import com.polarion.portal.shared.navigation.PortalSiteContext;
import com.polarion.reina.web.shared.localization.Localization;
import com.polarion.reina.web.shared.rpc.DefaultJSRPCCallback;
import com.polarion.reina.web.shared.rpc.IJSRPCCallback;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.util.RequestParser;
import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.web.XWikiAction;

/**
 * @author <a href="mailto:dev@polarion.com">Jakub Stroleny</a>, Polarion Software
 */
public class UpdateChartFooterAction extends XWikiAction {

    private static final Logger log = Logger.getLogger(UpdateChartFooterAction.class);

    private ReportData reportData = null;
    private XWikiContext<String, Object> xcontext = null;
    private String data;
    private String calculation;
    private IScope scope;
    private ReportPolicyData policyData;
    private String elementId;

    private static final String PARAM_DATA = "data"; //$NON-NLS-1$
    private static final String PARAM_CALCULATION = "calculation"; //$NON-NLS-1$
    private static final String PARAM_ACTION = "myaction"; //$NON-NLS-1$
    private static final String PARAM_PROJECTGROUP = "projectGroup"; //$NON-NLS-1$
    private static final String PARAM_PROJECT = "project"; //$NON-NLS-1$
    private static final String PARAM_VCONTEXT = "vcontext"; //$NON-NLS-1$
    private static final String PARAM_ID = "id"; //$NON-NLS-1$

    private static final String ACTION_INIT = "init"; //$NON-NLS-1$
    private static final String ACTION_REFRESH = "refresh"; //$NON-NLS-1$
    private static final String ACTION_UPDATE = "update"; //$NON-NLS-1$

    private static final String UNKNOWN_ERROR = "Unknown error";

    private static final String LIVE_PLAN_DATA = "xml/live-plan.xml"; //$NON-NLS-1$
    private static final String LIVE_PLAN_QUERY = "HAS_VALUE:plannedStart"; //$NON-NLS-1$

    private static final ReportsPolicy policy = ReportsPolicy.getPolicy();

    @Override
    @SuppressWarnings("unchecked")
    public boolean action(XWikiContext context) throws XWikiException {
        return actionInternal(context);
    }

    private String getCalculation() {
        if ("null".equals(calculation)) { //$NON-NLS-1$
            return null;
        }
        return calculation;
    }

    private String[] getFactBases() {
        return null;
    }

    private String getLivePlanQuery() {
        if (scope != null && scope.getProjectId() != null) {
            return LIVE_PLAN_QUERY + " AND project.id:" + scope.getProjectId(); //$NON-NLS-1$
        } else {
            return LIVE_PLAN_QUERY;
        }
    }

    private boolean actionInternal(XWikiContext<String, Object> context) {
        xcontext = context;
        try {
            VelocityContext vcontext = (VelocityContext) context.get(PARAM_VCONTEXT);
            Map requestParams = RequestParser.parseQuery(XWiki.getRequestURL(context.getRequest()).toString(), context);
            String currentProject = (String) requestParams.get(PARAM_PROJECT);
            String currentProjectGroup = (String) requestParams.get(PARAM_PROJECTGROUP);
            String action = context.getRequest().getParameter(PARAM_ACTION);
            data = context.getRequest().getParameter(PARAM_DATA);
            calculation = context.getRequest().getParameter(PARAM_CALCULATION);
            scope = getScope(currentProject, currentProjectGroup);
            elementId = context.getRequest().getParameter(PARAM_ID);
            ReportsProvider.checkPolicy(scope, new DefaultJSRPCCallback() {
                @Override
                public void callback(Object data) {
                    policyData = (ReportPolicyData) data;
                }
            });
            String response = null;
            if (action != null) {
                action = action.trim();
            }
            if (action.equalsIgnoreCase(ACTION_UPDATE)) { //update data report, return refresh button
                response = parseUpdateAction();
            } else if (action.trim().equalsIgnoreCase(ACTION_REFRESH)) { //refresh button was pressed, if report is not updating, then refresh of frame will be called as well
                response = parseRefreshAction();
            } else if (action.trim().equalsIgnoreCase(ACTION_INIT)) { //when no button was pressed, just print the footer
                response = parseInitAction();
            } else {
                response = UNKNOWN_ERROR;
            }
            if (response == null) {
                return false;
            }
            context.put("result", response); //$NON-NLS-1$
            vcontext.put("result", response); //$NON-NLS-1$
        } catch (Exception ex) {
            log.warn("Could not update chart, report-path: " + data, ex); //$NON-NLS-1$
            return false;
        }
        return true;
    }

    private String parseUpdateAction() {
        try {
            IJSRPCCallback<ReportData> callback = new DefaultJSRPCCallback<ReportData>() {
                @Override
                public void callback(ReportData data) {
                    reportData = data;
                }
            };
            if (data.equals(LIVE_PLAN_DATA)) {
                LivePlanDataProvider.updateLivePlan(callback);
                String monitorLink = getMonitorLink();

                return getRefreshButton() + " | " + Localization.getString("report.updatingReportNoData") + Localization.getString("definition.commaSpace") + monitorLink; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

            } else {
                ReportsProvider.updateReport(scope, getCalculation(), callback);
                return getFooter();
            }
        } catch (Exception ex) {
            log.warn("Could not parse update action", ex); //$NON-NLS-1$
            return null;
        }
    }

    private String parseInitAction() {
        try {
            IJSRPCCallback<ReportData> callback = new DefaultJSRPCCallback<ReportData>() {
                @Override
                public void callback(ReportData data) {
                    reportData = data;
                }
            };
            if (data.equals(LIVE_PLAN_DATA)) {
                LivePlanDataProvider.getLivePlanFlashData(scope, getLivePlanQuery(), true, callback);
            } else {
                ReportsProvider.getReportData(scope, data, getCalculation(), getFactBases(), callback);
            }
            return getFooter();
        } catch (Exception ex) {
            log.warn("Could not parse init action", ex); //$NON-NLS-1$
            return null;
        }
    }

    private String parseRefreshAction() {
        try {
            IJSRPCCallback<ReportData> callback = new DefaultJSRPCCallback<ReportData>() {
                @Override
                public void callback(ReportData data) {
                    reportData = data;
                }
            };
            if (data.equals(LIVE_PLAN_DATA)) {
                LivePlanDataProvider.getLivePlanFlashData(scope, getLivePlanQuery(), true, callback);
                return "refresh";
            } else {
                ReportsProvider.getReportData(scope, data, getCalculation(), getFactBases(), callback);
                return reportData.isUpdating ? getFooter() : "refresh";
            }
        } catch (Exception ex) {
            log.warn("Could not parse refresh action", ex); //$NON-NLS-1$
            return null;
        }
    }

    private String getFooter() {
        if (reportData == null) {
            return "No report data";
        }
        String response;

        String monitorLink = getMonitorLink();
        if (reportData.isUpdating) {
            response = getRefreshButton() + " | " + Localization.getString("report.updatingReportNoData") + Localization.getString("definition.commaSpace") + monitorLink; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
        } else {
            if (reportData.lastUpdatedLabel != null) {
                response = Localization.getString("definition.updated") + Localization.getString("definition.colon") + ' ' + reportData.lastUpdatedLabel; //$NON-NLS-1$ //$NON-NLS-2$
            } else {
                response = Localization.getString("definition.updated") + Localization.getString("definition.colon") + ' ' + MacroUtils.NOT_AVAILABLE; //$NON-NLS-1$ //$NON-NLS-2$
            }
            response = getUpdateButton() + " | " + response; //$NON-NLS-1$
        }
        return response;
    }

    private String getMonitorLink() {
        PortalSiteContext context = new PortalSiteContext(false, null, Perspective.PERSP_PROJECTS_ID, null, scope, null);
        String urlHash;
        if (context != null) {
            urlHash = PortalService.getPortal().createUrlHash(context, "monitor", null); //$NON-NLS-1$
        } else {
            urlHash = "/monitor"; //$NON-NLS-1$
        }
        return Localization.getString("report.seeMonitorLink", "<a style=\"color:gray\" href='/polarion/#" + urlHash + "' target='_top'>", "</a>"); //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    }

    private String getRefreshButton() {
        StringBuilder sb = new StringBuilder();
        String url = xcontext.getURL().getPath();
        url = url.substring(0, url.indexOf("bin/") + 4) + "updatechart" + url.substring(url.indexOf("/", url.indexOf("bin/") + 4), url.length()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
        url += "?myaction=refresh"; //$NON-NLS-1$
        url += "&data=" + data; //$NON-NLS-1$
        url += "&calculation=" + calculation; //$NON-NLS-1$
        url += "&id=" + elementId; //$NON-NLS-1$
        sb.append("<span class=\"footerButtons\" "); //$NON-NLS-1$
        boolean canUse = policy.canUseDashboardMacros() && policy.canUpdateOrCreateReports();
        if (canUse && policyData.canRead) {
            sb.append("onclick=\"try { executeCommand('"); //$NON-NLS-1$
            sb.append(url);
            sb.append("', updatechart_" + elementId + ");return false;} catch(e) {}\""); //$NON-NLS-1$ //$NON-NLS-2$
        } else {
            sb.append("title=\"" + Localization.getString("report.haveNoRightsOrLicense") + "\""); //$NON-NLS-1$ //$NON-NLS-3$
        }
        sb.append(">" + Localization.getString("definition.refresh") + "</span>"); //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$
        return sb.toString();
    }

    private String getUpdateButton() {
        StringBuilder sb = new StringBuilder();
        String url = xcontext.getURL().getPath();
        url = url.substring(0, url.indexOf("bin/") + 4) + "updatechart" + url.substring(url.indexOf("/", url.indexOf("bin/") + 4), url.length()); //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
        url += "?myaction=update"; //$NON-NLS-1$
        url += "&data=" + data; //$NON-NLS-1$
        url += "&calculation=" + calculation; //$NON-NLS-1$
        url += "&id=" + elementId; //$NON-NLS-1$
        boolean canUse = policy.canUseDashboardMacros() && policy.canUpdateOrCreateReports();
        sb.append("<span class=\"footerButtons\" "); //$NON-NLS-1$
        if (canUse && policyData.canUpdate) {
            sb.append("onclick=\"try { executeCommand('"); //$NON-NLS-1$
            sb.append(url);
            sb.append("', updatechart_" + elementId + ");return false;} catch (e) {}\""); //$NON-NLS-1$ //$NON-NLS-2$
        } else {
            sb.append("title=\"" + Localization.getString("report.haveNoRightsOrLicense") + "\""); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
        }
        sb.append(">" + Localization.getString("definition.update") + "</span>"); //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$
        return sb.toString();
    }

    @Override
    public String render(XWikiContext<String, Object> context)
            throws XWikiException {
        return "updatechart"; //$NON-NLS-1$
    }

    private IScope getScope(String project, String prgroup) {
        IScope scope = null;
        if ((project != null) && !project.trim().equals("")) { //$NON-NLS-1$
            scope = new ProjectScope(project);
        } else if ((prgroup != null) && !prgroup.trim().equals("")) { //$NON-NLS-1$
            scope = new ProjectGroupScope(prgroup);
        } else {
            scope = new ProjectGroupScope(""); //repository scope //$NON-NLS-1$
        }
        return scope;
    }

}
