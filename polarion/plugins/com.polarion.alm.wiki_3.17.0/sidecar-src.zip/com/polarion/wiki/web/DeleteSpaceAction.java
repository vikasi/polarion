package com.polarion.wiki.web;

import java.util.StringTokenizer;

import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.web.Utils;
import com.xpn.xwiki.web.XWikiAction;
import com.xpn.xwiki.web.XWikiRequest;
import com.xpn.xwiki.web.XWikiResponse;

public class DeleteSpaceAction extends XWikiAction
{
    @Override
    public boolean action(XWikiContext context) throws XWikiException
    {
        XWikiRequest request = context.getRequest();
        XWikiResponse response = context.getResponse();
        String space_name = request.getParameter("space");
        String pagesRemove = request.getParameter("pagesForDelete");
        String isPagesDelete = request.getParameter("pagesDel");

        XWiki xwiki = context.getWiki();

        String confirm = request.getParameter("confirm");
        if ((confirm != null) && (confirm.equals("1")))
        {
            xwiki.deleteSpace(space_name, null, context);
            return true;
        }
        else if (isPagesDelete != null && isPagesDelete.equalsIgnoreCase("1"))
        {

            if (pagesRemove != null && !pagesRemove.trim().equalsIgnoreCase(""))
            {
                StringTokenizer strToken = new StringTokenizer(pagesRemove, ";");
                while (strToken.hasMoreTokens())
                {
                    String path = strToken.nextToken();
                    int sep = path.lastIndexOf("/");
                    if (sep != -1) {
                        xwiki.deleteSpace(path.substring(0, sep), path.substring(sep + 1), context);
                    }
                }
            }
            return true;
        }
        else
        {
            String redirect = Utils.getRedirect(request, null);
            if (redirect == null) {
                return true;
            } else {
                sendRedirect(response, redirect);
                return false;
            }
        }
    }

    @Override
    public String render(XWikiContext context) throws XWikiException
    {

        XWikiRequest request = context.getRequest();
        String confirm = request.getParameter("confirm");
        String isPagesDelete = request.getParameter("pagesDel");
        if ((confirm != null) && (confirm.equals("1"))) {
            return "deletedspace";
        }
        else if (isPagesDelete != null && isPagesDelete.equalsIgnoreCase("1"))
        {
            return "deletespace";
        }
        else
        {
            return "deletespace";
        }
    }

}
