package com.polarion.wiki.web;

import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.integration.utils.UsersMacroParser;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.web.XWikiAction;

public class UsersMacroAction extends XWikiAction {

    @Override
    @SuppressWarnings("unchecked")
    public boolean action(XWikiContext context) throws XWikiException {

        UsersMacroParser parser = new UsersMacroParser(context);

        return MacroUtils.getInstance().performAjaxAction(parser, "users"); //$NON-NLS-1$
    }

    @Override
    public String render(XWikiContext context) throws XWikiException
    {
        return "usersmacroaction"; //$NON-NLS-1$
    }
}
