package com.polarion.wiki.web;

import java.util.Calendar;

import org.apache.velocity.VelocityContext;

import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.api.PUser;
import com.xpn.xwiki.web.XWikiAction;

public class UserAction extends XWikiAction
{

    @Override
    public boolean action(XWikiContext context) throws XWikiException
    {

        Calendar cl = Calendar.getInstance();
        long id = cl.getTimeInMillis();
        VelocityContext vcontext = (VelocityContext) context.get("vcontext"); //$NON-NLS-1$
        PUser item = new PUser(context, id);
        context.put("puser", item); //$NON-NLS-1$
        vcontext.put("puser", new PUser(context, id)); //$NON-NLS-1$
        return true;
    }

    @Override
    public String render(XWikiContext context) throws XWikiException
    {
        return "loaduser"; //$NON-NLS-1$
    }

}
