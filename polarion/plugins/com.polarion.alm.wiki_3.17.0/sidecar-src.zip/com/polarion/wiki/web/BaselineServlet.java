/*
 * Copyright (C) 2004-2012 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2012 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.polarion.wiki.web;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.polarion.core.util.RunnableWEx;
import com.polarion.platform.core.PlatformContext;
import com.polarion.platform.persistence.IDataService;
import com.polarion.portal.internal.shared.navigation.BaselineHelper;

public class BaselineServlet extends HttpServlet {

    private static final long serialVersionUID = 522378811469042593L;

    private static final IDataService dataService = (IDataService) PlatformContext.getPlatform().lookupService(IDataService.class);

    public static String getCurrentBaselineRevision() {
        return dataService.getCurrentBaselineRevision();
    }

    public BaselineServlet() {
        super();
    }

    @Override
    protected void service(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
        String uri = request.getRequestURI();
        final ServletContext sc = getServletContext();
        String bas = BaselineHelper.getBaselineFromURI(uri);
        uri = BaselineHelper.removeBaselineFromURI(uri);
        String webapp = sc.getServletContextName();
        int ix = uri.indexOf(webapp);
        final String path = uri.substring(ix + webapp.length());
        dataService.doInBaseline(bas, new RunnableWEx<Void>() {
            @Override
            public Void runWEx() throws Exception {
                sc.getRequestDispatcher(path).forward(request, response);
                return null;
            }
        });
    }

}
