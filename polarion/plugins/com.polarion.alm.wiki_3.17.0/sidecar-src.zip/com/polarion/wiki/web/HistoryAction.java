package com.polarion.wiki.web;

import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.web.XWikiAction;

public class HistoryAction extends XWikiAction
{

    @Override
    public boolean action(XWikiContext context) throws XWikiException
    {
        return true;
    }

    @Override
    public String render(XWikiContext context) throws XWikiException
    {

        return "historyinline";
    }

}
