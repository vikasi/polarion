package com.polarion.wiki.web;

import com.polarion.alm.wiki.WikiPlugin;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.integration.utils.ModuleWorkItemsMacroParser;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.web.XWikiAction;
import com.xpn.xwiki.web.XWikiRequest;

public class ModuleWorkitemsMacroAction extends XWikiAction {
    @Override
    @SuppressWarnings("unchecked")
    public boolean action(XWikiContext context) throws XWikiException {
        XWikiRequest request = context.getRequest();
        String query = request.getQueryString();
        boolean isDLE = query != null && query.contains("&" + WikiPlugin.TARGET + "=1");
        if (isDLE) {
            context.put(WikiPlugin.TARGET, "1");
        }
        ModuleWorkItemsMacroParser parser = new ModuleWorkItemsMacroParser(context);

        return MacroUtils.getInstance().performAjaxAction(parser, "module-workitems");
    }

    @Override
    public String render(XWikiContext context) throws XWikiException
    {
        return "moduleworkitemsmacroaction";
    }
}
