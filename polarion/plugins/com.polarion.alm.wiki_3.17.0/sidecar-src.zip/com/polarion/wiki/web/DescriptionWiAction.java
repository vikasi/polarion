package com.polarion.wiki.web;

import org.apache.velocity.VelocityContext;

import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.api.WorkItem;
import com.xpn.xwiki.web.XWikiAction;

public class DescriptionWiAction extends XWikiAction
{
    @Override
    public boolean action(XWikiContext context) throws XWikiException
    {
        VelocityContext vcontext = (VelocityContext) context.get("vcontext");
        WorkItem item = new WorkItem(context, 0);
        context.put("workitem", item);
        vcontext.put("workitem", item.newItem(context, 0));
        return true;
    }

    @Override
    public String render(XWikiContext context) throws XWikiException
    {
        return "xdescrpwi";
    }
}
