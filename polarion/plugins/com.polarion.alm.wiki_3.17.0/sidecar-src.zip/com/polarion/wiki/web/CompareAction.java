package com.polarion.wiki.web;

import org.apache.velocity.VelocityContext;

import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.web.XWikiAction;
import com.xpn.xwiki.web.XWikiRequest;

public class CompareAction extends XWikiAction
{

    @Override
    public boolean action(XWikiContext context) throws XWikiException
    {
        return true;
    }

    @Override
    public String render(XWikiContext context) throws XWikiException
    {
        XWikiRequest request = context.getRequest();
        String rev1 = request.getParameter("rev1");
        String rev2 = request.getParameter("rev2");

        String leftName = request.getParameter("leftName");
        String rightName = request.getParameter("rightName");

        String leftSpace = request.getParameter("leftSpace");
        String rightSpace = request.getParameter("rightSpace");

        XWikiDocument tdoc = (XWikiDocument) context.get("tdoc");

        com.xpn.xwiki.api.Document origdoc = context.getWiki().getDocument(tdoc, rev1, leftName, leftSpace, context);
        com.xpn.xwiki.api.Document newdoc = context.getWiki().getDocument(tdoc, rev2, rightName, rightSpace, context);

        VelocityContext vcontext = (VelocityContext) context.get("vcontext");

        context.put("origdoc", origdoc);
        context.put("newdoc", newdoc);
        vcontext.put("newdoc", newdoc);
        vcontext.put("origdoc", origdoc);

        context.put("compareMode", "1");
        vcontext.put("compareMode", "1");

        return "compare";
    }

}
