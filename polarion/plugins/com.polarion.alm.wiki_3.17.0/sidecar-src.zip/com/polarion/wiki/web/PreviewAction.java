package com.polarion.wiki.web;

import org.apache.velocity.VelocityContext;

import com.polarion.reina.web.shared.DynURL;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.web.XWikiAction;
import com.xpn.xwiki.web.XWikiRequest;

/**
 * XWiki Preview action, creates duplicate content of the current page
 * to be used for preview. 
 * Used by xpage.vm
 * @author Igor Makarenko
 */

public class PreviewAction extends XWikiAction
{
    private static final String PREVIEW_ACTION = "preview";
    private static final String PREVIEW_DOC = "pdoc";

    @Override
    public boolean action(XWikiContext context) throws XWikiException {
        XWikiRequest request = context.getRequest();
        //get page content from te request
        String content = request.getParameter("xcontent");
        content = DynURL.decodeQueryValue(content);
        content = content.replaceAll("%2b", "+");
        VelocityContext vcontext = (VelocityContext) context.get("vcontext");

        XWikiDocument doc = context.getDoc();
        XWikiDocument pdoc = (XWikiDocument) doc.clone();
        if (pdoc != null) {
            context.put(PREVIEW_DOC, pdoc);
            vcontext.put(PREVIEW_DOC, pdoc.newDocument(context));
            //replace page content with current 
            pdoc.setContent(content);
            return true;
        }
        return false;
    }

    @Override
    public String render(XWikiContext context) throws XWikiException {
        return PREVIEW_ACTION;
    }
}
