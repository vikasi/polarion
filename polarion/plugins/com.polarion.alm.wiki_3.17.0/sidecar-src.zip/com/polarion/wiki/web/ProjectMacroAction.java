package com.polarion.wiki.web;

import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.integration.utils.ProjectMacroParser;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.web.XWikiAction;

public class ProjectMacroAction extends XWikiAction {

    @Override
    @SuppressWarnings("unchecked")
    public boolean action(XWikiContext context) throws XWikiException {

        ProjectMacroParser parser = new ProjectMacroParser(context);

        return MacroUtils.getInstance().performAjaxAction(parser, "project");
    }

    @Override
    public String render(XWikiContext context) throws XWikiException
    {
        return "projectmacroaction";
    }
}
