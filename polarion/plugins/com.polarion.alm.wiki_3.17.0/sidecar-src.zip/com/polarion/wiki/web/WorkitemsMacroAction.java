package com.polarion.wiki.web;

import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.integration.utils.WorkItemsMacroParser;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.web.XWikiAction;

public class WorkitemsMacroAction extends XWikiAction {

    @Override
    @SuppressWarnings("unchecked")
    public boolean action(XWikiContext context) throws XWikiException {

        WorkItemsMacroParser parser = new WorkItemsMacroParser(context);

        return MacroUtils.getInstance().performAjaxAction(parser, "workitems");
    }

    @Override
    public String render(XWikiContext context) throws XWikiException
    {
        return "workitemsmacroaction";
    }
}
