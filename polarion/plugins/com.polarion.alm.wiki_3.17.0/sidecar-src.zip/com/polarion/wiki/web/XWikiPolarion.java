package com.polarion.wiki.web;

public class XWikiPolarion
{
    public static final String POLARION = "polarion";
    public static final String _WIKI = "_wiki";
    public static final String WIKI = "wiki";
    public static final String BIN = "bin";
    public static final String VIEW = "view";
    public static final String EDIT = "edit";
    public static final String POLARION_BASE_URL = "/" + POLARION + "/" + WIKI + "/" + BIN + "/" + VIEW + "/";
    public static final String POLARION_BASE_EDIT_URL = "/" + POLARION + "/" + WIKI + "/" + BIN + "/" + EDIT + "/";
}
