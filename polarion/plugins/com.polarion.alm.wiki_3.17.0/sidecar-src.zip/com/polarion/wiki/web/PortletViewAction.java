package com.polarion.wiki.web;

import org.apache.velocity.VelocityContext;

import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.web.XWikiAction;

public class PortletViewAction extends XWikiAction
{
    private static final String PORTLETVIEW_ACTION = "preview";
    private static final String PORTLETVIEW_DOC = "pdoc";
    private static final String LINK = "link";

    @Override
    public boolean action(XWikiContext context) throws XWikiException {
        //get page content from te request
        String link = context.getRequest().getParameter("wlink");
        VelocityContext vcontext = (VelocityContext) context.get("vcontext");

        XWikiDocument pdoc = context.getDoc();
        context.put(PORTLETVIEW_DOC, pdoc);
        vcontext.put(PORTLETVIEW_DOC, pdoc.newDocument(context));
        if (pdoc.isNew()) {
            context.put(LINK, "[" + link + "]");
            vcontext.put(LINK, "[" + link + "]");
        }
        return true;
    }

    @Override
    public String render(XWikiContext context) throws XWikiException {
        return PORTLETVIEW_ACTION;
    }

}
