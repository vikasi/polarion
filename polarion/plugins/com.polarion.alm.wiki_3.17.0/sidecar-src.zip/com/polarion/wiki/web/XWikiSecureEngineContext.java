/*
 * Copyright (C) 2004-2013 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2013 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.polarion.wiki.web;

import java.io.File;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import org.jetbrains.annotations.NotNull;

import com.polarion.alm.wiki.WikiPlugin;
import com.polarion.core.util.eclipse.BundleHelper;
import com.xpn.xwiki.web.XWikiEngineContext;

/**
 * Decorator for engine contexts that performs validating
 * of path against com.polarion.alm.wiki plugin.
 */
public class XWikiSecureEngineContext implements XWikiEngineContext {

    @NotNull
    private static final String BASE_PATH = "src/main/webapp"; //$NON-NLS-1$

    @NotNull
    private final XWikiEngineContext context;

    public XWikiSecureEngineContext(@NotNull XWikiEngineContext context) {
        this.context = context;
    }

    @Override
    public Object getAttribute(String name) {
        return context.getAttribute(name);
    }

    @Override
    public void setAttribute(String name, Object value) {
        context.setAttribute(name, value);
    }

    @Override
    public String getRealPath(String path) {
        if (!path.startsWith("/")) { //$NON-NLS-1$
            path = "/" + path; //$NON-NLS-1$
        }
        /*
         * Do not use realPath from engine context directly,
         * because we need to be sure that path comes from
         * wiki plugin.
         */
        if (!BundleHelper.exists(WikiPlugin.PLUGIN_ID, BASE_PATH + path)) {
            return ""; //$NON-NLS-1$
        }
        return BundleHelper.getPath(WikiPlugin.PLUGIN_ID, BASE_PATH + path);
    }

    @Override
    public URL getResource(String name) throws MalformedURLException {
        return context.getResource(name);
    }

    @Override
    public InputStream getResourceAsStream(String name) {
        String basePath = BundleHelper.getPath(WikiPlugin.PLUGIN_ID, BASE_PATH);
        if (name.startsWith(basePath)) {
            name = name.substring(basePath.length() + 1);
        }
        /*
         * Return the resource only if path does not overflow from
         * src/main/webapp directory. 
         */
        if (isValidURL(name)) {
            return context.getResourceAsStream(name);
        }
        return null;
    }

    @Override
    public String getMimeType(String filename) {
        return context.getMimeType(filename);
    }

    private static boolean isValidURL(@NotNull String url) {
        try {
            return isChildDir(new File(url));
        } catch (Exception e) {
            // nothing to do
        }
        return false;
    }

    private static boolean isChildDir(@NotNull File child) {
        List<String> components = new LinkedList<String>();
        for (File parentFile = child; parentFile != null; parentFile = parentFile.getParentFile()) {
            components.add(parentFile.getName());
        }
        Collections.reverse(components);
        int count = 0;
        for (String component : components) {
            if (component.equals("..")) { //$NON-NLS-1$
                count--;
            } else if (!component.equals(".")) { //$NON-NLS-1$
                count++;
            }
        }
        return count >= 0;
    }

}
