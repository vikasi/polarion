package com.polarion.wiki.web;

import com.polarion.wiki.util.PlainTextExtractor;
import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.doc.XWikiLock;
import com.xpn.xwiki.web.XWikiAction;
import com.xpn.xwiki.web.XWikiRequest;
import com.xpn.xwiki.web.XWikiResponse;

public class CreateWorkItemAction extends XWikiAction
{
    private int lastPos = 0;

    @Override
    public boolean action(XWikiContext context) throws XWikiException
    {
        XWikiRequest request = context.getRequest();
        XWikiResponse response = context.getResponse();

        String title = request.getParameter("selection");

        String WI = "{workitem: " + request.getParameter("project") + "/" + request.getParameter("id") + "}";

        XWikiDocument doc = context.getDoc();
        XWikiDocument edoc = (XWikiDocument) doc.clone();

        String result = "<b>Text to search: </b></br>" + title + "</br></br>";
        XWiki xwiki = context.getWiki();
        String cnt = context.getDoc().getContent();
        String param = "";

        int i = findPos(context, title);
        // \r\n1a - \r\nc - i - \r\nb
        int a, b, c = 0;

        if (i > -1)
        {
            c = cnt.lastIndexOf("\r\n", i - 1);
            a = cnt.lastIndexOf("\r\n1", i - 1);
            b = cnt.indexOf("\r\n", i + 1);

            if (b == -1) {
                b = cnt.length();
            }
            if (a != -1 && c <= a)
            {
                String s1 = cnt.substring(0, b);
                String s2 = cnt.substring(b, cnt.length());
                edoc.setContent(s1 + WI + s2);
            }
            else
            {
                String s1 = cnt.substring(0, i);
                String s2 = cnt.substring(i, cnt.length());
                edoc.setContent(s1 + WI + s2);
                lastPos = i + 10;
                if (lastPos > cnt.length()) {
                    lastPos = cnt.length();
                }
            }
            if (lastPos == 0) {
                lastPos = i + title.length();
            }
            result = result + "<b>Found at: " + new Integer(i).toString() + "</b></br>" + cnt.substring(i, lastPos) + ".";
        }
        else
        {
            edoc.setContent(cnt + WI);
            param = "&extwarn=1";
        }

        xwiki.saveDocument(edoc, doc, edoc.getComment(), context);
        XWikiLock lock = edoc.getLock(context);
        if (lock != null) {
            edoc.removeLock(context);
        }

        context.put("cdoc", edoc);
        String url = context.getDoc().getURL("view", request.getQueryString().concat(param), context);
        sendRedirect(response, url);

        return true;
    }

    public int findPos(XWikiContext context, String searchText)
    {
        XWikiDocument currentdoc = context.getDoc();
        PlainTextExtractor plainTextExtractor = new PlainTextExtractor();
        //plainTextExtractor.test();
        int pos = -1;
        try {
            pos = plainTextExtractor.findTextPos(currentdoc.getContent(), searchText);
        } catch (Exception e) {
            return -1;
        }
        if (pos > -1) {
            lastPos = plainTextExtractor.getLastPos();
        }
        return pos;

    }

    @Override
    public String render(XWikiContext context) throws XWikiException
    {
        return "view";
    }

}
