package com.polarion.wiki.web;

import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.integration.utils.UserMacroParser;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.web.XWikiAction;

public class UserMacroAction extends XWikiAction {

    @Override
    @SuppressWarnings("unchecked")
    public boolean action(XWikiContext context) throws XWikiException {

        UserMacroParser parser = new UserMacroParser(context);

        return MacroUtils.getInstance().performAjaxAction(parser, "user"); //$NON-NLS-1$
    }

    @Override
    public String render(XWikiContext context) throws XWikiException
    {
        return "usermacroaction"; //$NON-NLS-1$
    }
}
