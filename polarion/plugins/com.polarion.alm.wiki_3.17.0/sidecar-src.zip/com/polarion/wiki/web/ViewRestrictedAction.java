package com.polarion.wiki.web;

import org.apache.velocity.VelocityContext;

import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.web.XWikiAction;

public class ViewRestrictedAction extends XWikiAction
{
    @Override
    public boolean action(XWikiContext context) throws XWikiException
    {
        VelocityContext vcontext = (VelocityContext) context.get("vcontext");
        String backURL = context.getDoc().getURL("view", context);
        context.put("backURL", backURL);
        vcontext.put("backURL", backURL);
        return true;
    }

    @Override
    public String render(XWikiContext context) throws XWikiException
    {
        return "linkrestricted";
    }
}
