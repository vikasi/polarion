package com.polarion.wiki.web;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import org.apache.velocity.VelocityContext;
import org.w3c.dom.Document;

import com.polarion.alm.projects.model.IProject;
import com.polarion.core.util.logging.Logger;
import com.polarion.subterra.base.location.ILocation;
import com.polarion.wiki.svn.PolarionSvnProvider;
import com.polarion.wiki.svn.bo.DocumentSvnInfo;
import com.polarion.wiki.svn.bo.SpaceSvnInfo;
import com.polarion.wiki.util.RequestParser;
import com.polarion.wiki.util.XHTMLValidator;
import com.polarion.wiki.util.XmlParser;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.web.XWikiAction;

public class TestXHTMLAction extends XWikiAction
{
    static Logger log = Logger.getLogger(TestXHTMLAction.class);
    private static final String TEST_XHTML_RESULT = "testxhtmlresult";
    private XWikiContext context = null;
    private PolarionSvnProvider svn = new PolarionSvnProvider();

    private Collection<Error> errors = new ArrayList<Error>();

    @Override
    public boolean action(XWikiContext context) throws XWikiException {
        this.context = context;
        VelocityContext vcontext = (VelocityContext) context.get("vcontext");

        try {
            processProjects();
        } catch (Exception e) {
            log.error("Failed with exception: " + e.getMessage());
        }

        context.put("errors", errors);
        vcontext.put("errors", errors);

        return true;
    }

    @Override
    public String render(XWikiContext context) throws XWikiException {
        return TEST_XHTML_RESULT;
    }

    private boolean processProjects() {
        boolean valid = true;
        valid = processSpaces(svn.getRootLocation()) && valid;
        Collection projects = svn.getAllProjects();
        for (Iterator iter = projects.iterator(); iter.hasNext();)
        {
            IProject project = (IProject) iter.next();
            valid = processSpaces(project.getLocation()) && valid;
        }

        return true;
    }

    private boolean processSpaces(ILocation prLocation)
    {
        boolean valid = true;
        Collection spaces = svn.getSpacesInProject(prLocation);
        for (Iterator iter = spaces.iterator(); iter.hasNext();)
        {
            SpaceSvnInfo space = (SpaceSvnInfo) iter.next();
            if (RequestParser.isDocumentPage(space.getName()) == false) {
                continue;
            }
            valid = processDocuments(space.getLocation()) && valid;
        }
        return valid;
    }

    private boolean processDocuments(ILocation spaceLocation)
    {
        boolean valid = true;
        Collection docs = svn.getDocumentsInSpace(spaceLocation);
        for (Iterator iter = docs.iterator(); iter.hasNext();)
        {
            DocumentSvnInfo doc = (DocumentSvnInfo) iter.next();
            ILocation loc = doc.getDocumentFileLocation();
            InputStream is = svn.readFile(loc);
            Document xml = XmlParser.getXmlFromInputStream(is);

            String content = null;
            try {
                content = XmlParser.getNodeString(XmlParser.getNodeBy(xml, "content", 0));
            } catch (NullPointerException e) {
                log.error("Content of " + doc.getLocation() + " is null.");
            } catch (Exception e) {
                log.error(e);
            }

            String renderedContent = "";
            try {
                renderedContent = context.getWiki().getRenderingEngine().renderText(content, new XWikiDocument(), context);
            } catch (Exception e) {
                log.error("Error " + doc.getLocation().getLocationPath() + " content rendering: " + e);
                continue;
            }

            XHTMLValidator validator = new XHTMLValidator();
            try {
                validator.validateDocumentContent(renderedContent, context, XHTMLValidator.VALIDATOR_TRANSITIONAL);
            } catch (XWikiException xwe) {
                errors.add(new Error(xwe.getMessage(), doc.getLocation(), xwe.getSaxLine()));
                valid = false;
            } catch (Exception e) {
                log.error(e);
            }

        }
        return valid;
    }

    public class Error {
        private String desc;
        private ILocation loc;
        private String line;

        public Error(String desc, ILocation loc, String line) {
            this.desc = desc;
            this.loc = loc;
            this.line = line;
        }

        public String getDesc() {
            return desc;
        }

        public ILocation getLoc() {
            return loc;
        }

        public String getLine() {
            return line;
        }
    }
}
