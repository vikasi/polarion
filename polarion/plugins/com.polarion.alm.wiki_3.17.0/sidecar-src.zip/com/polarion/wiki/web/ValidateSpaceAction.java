package com.polarion.wiki.web;

//import org.apache.velocity.VelocityContext;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.velocity.VelocityContext;

import com.polarion.subterra.base.location.ILocation;
import com.polarion.wiki.svn.ISvnProvider;
import com.polarion.wiki.svn.PolarionSvnProvider;
import com.polarion.wiki.svn.WikiSvnStore;
import com.polarion.wiki.svn.bo.SpaceSvnInfo;
import com.polarion.wiki.util.Constants;
import com.polarion.wiki.util.SpaceParser;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.store.XWikiCacheStore;
import com.xpn.xwiki.web.XWikiAction;
import com.xpn.xwiki.web.XWikiRequest;

public class ValidateSpaceAction extends XWikiAction
{
    @Override
    public boolean action(XWikiContext context) throws XWikiException
    {
        return true;
    }

    @Override
    public String render(XWikiContext context) throws XWikiException
    {
        VelocityContext vcontext = (VelocityContext) context.get("vcontext");

        XWikiRequest request = context.getRequest();
        String space = (request.getParameter("space") != null) ? request.getParameter("space").trim() : null;
        space = SpaceParser.getSpace(space);
        String mixedspace = (request.getParameter("project") != null) ? request.getParameter("project").trim() : null;
        String page = (request.getParameter("page") != null) ? request.getParameter("page").trim() : null;
        String project = SpaceParser.getProject(mixedspace);

        if (project == null) {
            project = ISvnProvider.REPO_ROOT_AS_PROJECT_NAME;
        }

        WikiSvnStore store = (WikiSvnStore) ((XWikiCacheStore) context.getWiki().getStore()).getStore();
        PolarionSvnProvider svn = (PolarionSvnProvider) store.getSvnProvider();

        boolean res = false;
        if (space != null && (space.equalsIgnoreCase(Constants.MODULES) || space.equalsIgnoreCase(Constants.USERS)
                || space.equalsIgnoreCase(Constants.TEST_RUNS) || space.equalsIgnoreCase(Constants.PLANS)))
        {
            res = true;
        }
        else if (page.equals(""))
        {
            ILocation projectLocation = svn.getProjectLocation(project);
            List spaces = new ArrayList();
            spaces = svn.getSpacesInProject(projectLocation);

            for (Iterator spaceIterator = spaces.iterator(); spaceIterator.hasNext();) {
                SpaceSvnInfo spaceInfo = (SpaceSvnInfo) spaceIterator.next();
                res = spaceInfo.getName().equals(space);
                if (res) {
                    break;
                }
            }
        }
        else
        {
            ILocation pageLocation = svn.getPageWikiLocation(project, space, page);
            res = svn.exist(pageLocation);
        }
        context.put("isspacevalid", res);
        vcontext.put("isspacevalid", res);

        return "xvalidspace";
    }
}
