package com.polarion.wiki.svn;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.polarion.alm.projects.model.IProject;
import com.polarion.subterra.base.location.ILocation;
import com.polarion.wiki.svn.bo.SpaceSvnInfo;
import com.polarion.wiki.util.LocationMapping;
import com.polarion.wiki.web.XWikiPolarion;

/**
 * 
 * Class <code>WikiSpacesCache</code> 
 * Caches a list of spaces for all Polarion projects 
 *
 */
public class WikiSpacesCache
{
    private static WikiSpacesCache instance;

    private static final Log log = LogFactory.getLog(WikiSpacesCache.class);
    private static final Object CACHE_SPACE_LOCK = new Object();
    private static PolarionSvnProvider svn;
    private static Map<String, List<SpaceSvnInfo>> cache;
    private static boolean isSorted;

    private WikiSpacesCache()
    {
        cache = new HashMap<String, List<SpaceSvnInfo>>();
        svn = new PolarionSvnProvider();
        isSorted = false;
    }

    private WikiSpacesCache(PolarionSvnProvider svn)
    {
        cache = new HashMap<String, List<SpaceSvnInfo>>();
        WikiSpacesCache.svn = svn;
        isSorted = false;
    }

    public static WikiSpacesCache getInstance()
    {
        synchronized (CACHE_SPACE_LOCK)
        {
            if (instance == null)
            {
                try
                {
                    instance = new WikiSpacesCache();
                } catch (Exception e)
                {
                    log.error("Unable to create WikiSpacesCache: " + e.getMessage());
                }
            }
            return instance;
        }
    }

    public static WikiSpacesCache getInstance(PolarionSvnProvider svn)
    {
        synchronized (CACHE_SPACE_LOCK)
        {
            if (instance == null)
            {
                try
                {
                    instance = new WikiSpacesCache(svn);
                } catch (Exception e)
                {
                    log.error("Unable to create WikiSpacesCache: " + e.getMessage());
                }
            }
            return instance;
        }
    }

    private static String getProjectComponent(ILocation loc)
    {
        String res = null;
        try
        {
            String str = loc.getLocationPath();
            res = str.substring(0, str.indexOf("/" + XWikiPolarion._WIKI));
            if (res.equals("")) {
                res = "/";
            }
        } catch (IndexOutOfBoundsException iobe) {
            log.error(iobe);
        }
        return res;
    }

    private static String getSpaceComponent(ILocation loc)
    {
        String res = null;
        try
        {
            String str = loc.getLocationPath();
            res = str.substring(str.indexOf(XWikiPolarion._WIKI + "/") + (XWikiPolarion._WIKI + "/").length());
        } catch (IndexOutOfBoundsException iobe) {
            log.error(iobe);
        }
        return res;
    }

    private String listToString(List value)
    {
        String str = "";
        Iterator innerIt = value.iterator();
        while (innerIt.hasNext()) {
            SpaceSvnInfo space = (SpaceSvnInfo) innerIt.next();
            str += space + (innerIt.hasNext() ? ", " : "");
        }
        return str;
    }

    private int findInList(List<SpaceSvnInfo> list, ILocation loc) {
        //omly location is sensail for comparision
        SpaceSvnInfo spcaeInfo = new SpaceSvnInfo(loc, "", "", "", null);
        if (isSorted) {
//			 if entries are sorted use fast binary search:
            return Collections.binarySearch(list, spcaeInfo);
        } else {
//			else use slower indexOf list's method
            return list.indexOf(spcaeInfo);
        }

    }

    private void sort() {
        try {
            Collection<List<SpaceSvnInfo>> projects = cache.values();
            List<SpaceSvnInfo> currSpaces;
            Iterator<List<SpaceSvnInfo>> it = projects.iterator();
            while (it.hasNext()) {
                currSpaces = it.next();
                Collections.sort(currSpaces);
            }
            isSorted = true;
        } catch (Exception e) {
            log.error(e);
        }
        return;
    }

    public void proccessSpaces(ILocation projectLocation)
    {
        List spaces = svn.getSpacesInProjectNonCached(projectLocation);
        if (spaces == null) {
            return;
        }
        Iterator spaceIterator = spaces.iterator();
        while (spaceIterator.hasNext()) {
            SpaceSvnInfo space = (SpaceSvnInfo) spaceIterator.next();
            addSpace(space);
        }
    }

    private static boolean initialized = false;

    /**
     * 
     * @param space
     * @return Initializs the cache 
     * 		
     */
    public void init(String reindexInitState) {
        synchronized (CACHE_SPACE_LOCK)
        {
            if (!initialized) {
                try {
                    // projects
                    List projects = svn.getAllProjects();
                    Iterator projectIterator = projects.iterator();
                    while (projectIterator.hasNext()) {
                        IProject iproject = (IProject) projectIterator.next();
                        proccessSpaces(iproject.getLocation().setRevision(reindexInitState));
                    }
                    // root
                    proccessSpaces(svn.getRootLocation().setRevision(reindexInitState));
                    sort();
                } catch (Exception e) {
                    log.error("ERROR in WikiSpacesCache.init(): ", e);
                } finally {
                    initialized = true;
                }
            }
        }
    }

    /**
     * 
     * @param loc
     * 		location of space to find
     * @return
     * 		Returns SpaceInfo if it was found or <code>null</code> 
     */
    public SpaceSvnInfo getSpace(ILocation loc) {
        SpaceSvnInfo space = null;
        String sLoc = getProjectComponent(loc);
        if (cache.containsKey(sLoc)) {
            List<SpaceSvnInfo> locSpaces = cache.get(sLoc);
            int i = findInList(locSpaces, loc);
            if (i >= 0) {
                space = locSpaces.get(i);
            }
        }
        return space;
    }

    /**
     * 
     * @param space
     * @return Adds the space to the cache 
     * 		
     */
    public void addSpace(SpaceSvnInfo space) {
        synchronized (CACHE_SPACE_LOCK)
        {
            if (LocationMapping.isModule(space.getLocation()) || LocationMapping.isUser(space.getLocation())
                    || LocationMapping.isTestRun(space.getLocation()) || LocationMapping.isPlan(space.getLocation())) {
                return;
            }
            String sLoc = getProjectComponent(space.getLocation());
            boolean contains = cache.containsKey(sLoc);
            List<SpaceSvnInfo> locSpaces;
            if (contains) {
                locSpaces = cache.get(sLoc);
                if (isSorted) {
                    int i = findInList(locSpaces, space.getLocation());
                    if (i < 0) {
                        locSpaces.add(space);
                    }
                    sort();
                }
                else
                {
                    locSpaces.add(space);
                }
            }
            else
            {
                locSpaces = new ArrayList<SpaceSvnInfo>();
                locSpaces.add(space);
                cache.put(sLoc, locSpaces);
            }
        }
    }

    /**
     * 
     * @param loc
     * 			location of space to delete
     * @return
     *          Removes the space to the cache and return true if operetion successful
     */
    public boolean removeSpace(ILocation loc) {
        boolean contains = false;
        synchronized (CACHE_SPACE_LOCK)
        {
            try {
                String sLoc = getProjectComponent(loc);
                contains = cache.containsKey(sLoc);
                if (contains) {
                    List<SpaceSvnInfo> locSpaces = cache.get(sLoc);
                    int i = findInList(locSpaces, loc);
                    if (i >= 0) {
                        locSpaces.remove(i);
                    }

                    if (locSpaces.isEmpty()) {
                        // if some entry in cache hash is empty then delete it
                        cache.remove(sLoc);
                    }
                }
            } catch (Exception e) {
                log.error("ERROR on delete space", e);
            }
            return contains;
        }
    }

    public boolean removeProjectSpaces(ILocation loc) {
        boolean contains = false;
        synchronized (CACHE_SPACE_LOCK)
        {
            try {
                String sLoc = loc.getLocationPath();
                contains = cache.containsKey(sLoc);
                if (contains) {
                    List<SpaceSvnInfo> locSpaces = cache.get(sLoc);
                    if (locSpaces != null) {
                        // if some entry in cache hash is empty then delete it
                        cache.remove(sLoc);
                    }
                }
            } catch (Exception e) {
                log.error("ERROR on delete space", e);
            }
            return contains;
        }
    }

    /**
     * 
     * @param source
     * @param target
     * @return Copies space from one loaction to another
     * 
     */
    public boolean copySpace(ILocation source, ILocation target) {
        try {
            SpaceSvnInfo oldSpace = getSpace(source);
            if (oldSpace == null) {
                oldSpace = svn.getSpaceInfo(source);
            }
            if (oldSpace == null) {
                return false;
            }
            SpaceSvnInfo space = (SpaceSvnInfo) oldSpace.clone();
            space.setLocation(target);
            space.setName(getSpaceComponent(target));
            addSpace(space);
            return true;
        } catch (Exception e) {
            log.error(e);
            return false;
        }
    }

    /**
     * 
     * @param source
     * @param target
     * @returnMove Space from one loaction to another
     * 
     */
    public boolean moveSpace(ILocation source, ILocation target) {
        if (!copySpace(source, target)) {
            return false;
        }
        removeSpace(source);
        return true;
    }

    /**
     * 
     * @param source
     * @param target
     * @return Returns the list of spaces in the project
     * 
     */
    public List<SpaceSvnInfo> getSpacesInProject(ILocation project) {
        Object obj = cache.get(project.getLocationPath());
        List<SpaceSvnInfo> obj2 = new ArrayList<SpaceSvnInfo>();
        if (obj == null) {
            return new ArrayList<SpaceSvnInfo>();
        }
        Iterator it = ((List) obj).iterator();

        while (it.hasNext()) {
            SpaceSvnInfo space = (SpaceSvnInfo) it.next();
            ILocation location = space.getLocation();
            if (!LocationMapping.isModule(location) && !LocationMapping.isUser(location)
                    && !LocationMapping.isTestRun(location) && !LocationMapping.isPlan(location))
            {
                obj2.add(space);
            }
        }
        return obj2;
    }

    @Override
    public String toString() {
        String str = "";
        str += "WikiSpacesCache object: \n";
        Set entrySet = cache.entrySet();
        Iterator it = entrySet.iterator();
        while (it.hasNext()) {
            Map.Entry entry = (Map.Entry) it.next();
            String key = (String) entry.getKey();
            List value = (List) entry.getValue();
            str += key + ":: [" + listToString(value) + "] \n";
        }
        return str;
    }
}
