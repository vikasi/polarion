package com.polarion.wiki.svn;

public class SvnUtil
{
    public static final String REPOSITORY_SPACE = "Main";
    public static final String PANELS_SPACE = "Panels";
    public static final String INTERNAL_SPACE = "XWiki";
    public static final String SPACE_PARAM = "?space=";
    public static final String SERVICE_PARAM = "?service=";
    public static final String SERVICE_SPACEINDEX = SERVICE_PARAM + "SpaceIndex";
    public static final String SERVICE_SEARCH = SERVICE_PARAM + "Search";
    public static final String INNER_SPACE_INDEX_URL = "/polarion/wiki/bin/view/Main/SpaceIndex" + SPACE_PARAM;

    public static String getPrimarySpace(String web)
    {
        int firstDot = getFirstSingleDotIdx(web);
        return (firstDot < 0) ? web : web.substring(0, firstDot);
    }

    public static String removePrimarySpace(String web)
    {
        int firstDot = getFirstSingleDotIdx(web);
        return (firstDot < 0) ? "" : web.substring(firstDot + 1, web.length());
    }

    private static int getFirstSingleDotIdx(String s)
    {
        return s.replaceAll("\\.\\.", "__").indexOf('.');
    }

    public static String translatePrimarySpace(String space)
    {
        //if (!space.equals(REPOSITORY_SPACE) && !space.equals(INTERNAL_SPACE))
        //{
        return space.replaceAll("\\.\\.", ".");
        //}
        //return null;
    }

    /**
     * 
     * @param referencedRevision
     * @param testingRevision
     * @return true when testingRevision is greather then referencedRevision, false otherwise
     */
    public static boolean isNewerRevision(String referencedRevision, String testingRevision) {
        try {
            int referenced = Integer.parseInt(referencedRevision);
            int test = Integer.parseInt(testingRevision);
            return (test > referenced);
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
