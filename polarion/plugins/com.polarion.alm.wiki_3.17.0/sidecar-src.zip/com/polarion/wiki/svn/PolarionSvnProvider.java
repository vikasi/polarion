package com.polarion.wiki.svn;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.nio.ByteBuffer;
import java.security.PrivilegedAction;
import java.security.PrivilegedExceptionAction;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.security.auth.Subject;

import com.polarion.alm.projects.IProjectService;
import com.polarion.alm.projects.model.IProject;
import com.polarion.alm.tracker.ITrackerService;
import com.polarion.core.util.RunnableWEx;
import com.polarion.core.util.StringUtils;
import com.polarion.core.util.logging.Logger;
import com.polarion.platform.ITransactionService;
import com.polarion.platform.TransactionExecuter;
import com.polarion.platform.context.IContextListener;
import com.polarion.platform.context.IContextService;
import com.polarion.platform.core.PlatformContext;
import com.polarion.platform.persistence.IDataService;
import com.polarion.platform.security.ISecurityService;
import com.polarion.platform.service.repository.IFileChangesListener;
import com.polarion.platform.service.repository.IRepositoryConnection;
import com.polarion.platform.service.repository.IRepositoryInfo;
import com.polarion.platform.service.repository.IRepositoryReadOnlyConnection;
import com.polarion.platform.service.repository.IRepositoryService;
import com.polarion.platform.service.repository.IResourceProperties;
import com.polarion.subterra.base.location.ILocation;
import com.polarion.subterra.base.location.Location;
import com.polarion.wiki.svn.bo.AttachmentSvnInfo;
import com.polarion.wiki.svn.bo.DocumentSvnInfo;
import com.polarion.wiki.svn.bo.SpaceSvnInfo;
import com.polarion.wiki.util.Constants;
import com.polarion.wiki.util.ConvertUtil;
import com.polarion.wiki.util.SpaceParser;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.doc.XWikiAttachment;
import com.xpn.xwiki.doc.XWikiDocument;

public class PolarionSvnProvider implements ISvnProvider {

    private static final Logger log = Logger.getLogger(PolarionSvnProvider.class);

    private static String getBaselineRevision() {
        IDataService ds = PlatformContext.getPlatform().lookupService(IDataService.class);
        return ds.getCurrentBaselineRevision();
    }

    private static boolean isInBaseline() {
        return getBaselineRevision() != null;
    }

    private static ILocation makeBaselineLocation(ILocation loc) {
        String baseline;
        return !loc.hasRevision() && ((baseline = getBaselineRevision()) != null) ? loc.setRevision(baseline) : loc;
    }

    private static String getAttachmentTitle(IRepositoryReadOnlyConnection conn, ILocation loc) {
        String title = null;
        try {
            title = conn.getProperty(loc, ISvnProvider.PROPERTY_TITLE_NAME_POLARION);
            if (title == null) {
                title = conn.getProperty(loc, ISvnProvider.PROPERTY_TITLE_NAME);
            }
        } catch (Exception e) {
            log.warn("Exception while getting attachment title property", e);
        }
        return StringUtils.getEmptyIfNull(title);
    }

    private WikiSpacesCache spacesCache = WikiSpacesCache.getInstance(this);

    private IRepositoryService rs;
    private ISecurityService ss;
    private ITransactionService tt;
    private IProjectService projectSrv;
    private IContextService cs;

    public PolarionSvnProvider() {
        initRepository();
    }

    public void setIFileChangesListener(IFileChangesListener ifl, IContextListener ev2) {
        rs.addFileChangesListener(ifl);
        cs.addContextListener(ev2);
    }

    @Override
    public boolean canRead(final ILocation loaction) {
        return testAccessAction(new PrivilegedAction() {
            @Override
            public Object run() {
                ILocation location = makeBaselineLocation(loaction);
                IRepositoryReadOnlyConnection readOnlyConnection = rs.getReadOnlyConnection(location);
                readOnlyConnection.exists(location);
                return null;
            }
        });
    }

    public String getProjectPath(String project) {
        if (project == null || project.length() == 0) {
            return "";
        }
        try {
            ILocation loc = projectSrv.getProject(project).getLocation();
            return loc.getLocationPath();
        } catch (Exception e) {
            log.error("Unable to get project location: " + project, e);
        }
        return "";
    }

    /**
     * @param project
     * @return project loction
     *  if project equals REPO_ROOT_AS_PROJECT_NAME then root location is returned e.g.: /
     *  else valid project location with grups is returned e.g.: /someGrop/SomeProject/
     */
    public ILocation getProjectLocation(String project) {
        if (project == null) {
            return null;
        }
        try {
            return REPO_ROOT_AS_PROJECT_NAME.equals(project) ? getRootLocation() : projectSrv.getProject(project).getLocation();
        } catch (Exception e) {
            log.error("Unable to get project location: " + project);
        }
        return null;
    }

    private IProject getProjectFromLocation(ILocation projLoc) {
        String path = projLoc.getLocationPath();

        // checking if repository level
        if (path.startsWith(ISvnProvider.WIKI_ROOT_FOLDER)) {
            return null;
        }

        path = path.substring(0, path.indexOf(ISvnProvider.WIKI_ROOT_FOLDER) - 1);

        int ind = 0;

        if (path.indexOf('/') != -1) {
            // path contains groups
            ind = path.lastIndexOf('/') + 1;
        }

        return projectSrv.getProject(path.substring(ind));
    }

    public List getAllProjects() {
        return (List) executeNonTransactionActionAsSystemUser(new PrivilegedExceptionAction() {
            @Override
            public Object run() throws Exception {
                return projectSrv.getRootProjectGroup().getDeepContainedProjects();
            }
        });
    }

    public IProject getProject(String projectName)
    {
        return projectSrv.getProject(projectName);
    }

    public boolean initRepository() {
        boolean done = false;

        try {
            rs = PlatformContext.getPlatform().lookupService(IRepositoryService.class);
            ss = PlatformContext.getPlatform().lookupService(ISecurityService.class);
            tt = PlatformContext.getPlatform().lookupService(ITransactionService.class);
            projectSrv = PlatformContext.getPlatform().lookupService(IProjectService.class);
            cs = PlatformContext.getPlatform().lookupService(IContextService.class);

            done = true;
        } catch (Exception e) {
            log.error("Exception while init repository: " + e.getMessage());
        }
        return done;
    }

    @Override
    public void createFile(ILocation locFile, Subject user, boolean system) {
        createFile(locFile, user, system, null);
    }

    @Override
    public void createFile(ILocation locFile, Subject user, boolean system, String propertyTitleValue) {
        createFile(locFile, new ByteArrayInputStream(new byte[0]), user, system, propertyTitleValue);
    }

    public void createFile(final ILocation loc, final InputStream is, Subject user, boolean system, final String propertyTitleValue) {
        //assert is != null;
        boolean failed = true;
        Throwable t = null;
        try {
            tt.beginTx();
            if (!system) {
                ss.doAsUser(user, // arg1)
                        // ss.doAsSystemUser(
                        new PrivilegedExceptionAction() {

                            @Override
                            public Object run() throws Exception {
                                IRepositoryConnection conn = rs.getConnection(IRepositoryService.DEFAULT);
                                conn.create(loc, is);

                                if (propertyTitleValue != null) {
                                    conn.setProperty(loc, PROPERTY_TITLE_NAME_POLARION, propertyTitleValue);
                                }

                                return null;
                            }

                        });
            } else {
                ss.doAsSystemUser(new PrivilegedExceptionAction() {

                    @Override
                    public Object run() throws Exception {
                        IRepositoryConnection conn = rs.getConnection(IRepositoryService.DEFAULT);
                        conn.create(loc, is);

                        return null;
                    }

                });

            }

            failed = false;
        } catch (Exception e) {
            log.error("Can't create file(" + loc.getLocationPath() + "): ", e);
            t = e;
        } finally {
            try {
                tt.endTx(failed);
                is.close();
            }

            catch (IOException e) {
                log.error("Can't close input stream: " + e.getMessage());
            } catch (Exception e) {
                throw new RuntimeException("Can't end transaction: " + e.getMessage(), e);
            }
            if (t != null) {
                throw new RuntimeException(t);
            }
        }
    }

    @Override
    public List getFileVersions(final ILocation loc) {
        return (List) executeNonTransactionActionAsSystemUser(new PrivilegedExceptionAction() {
            @Override
            public Object run() throws Exception {
                ILocation location = loc.removeRevision();
                IRepositoryReadOnlyConnection conn = rs.getReadOnlyConnection(location);
                if (!conn.exists(location)) {
                    return conn.getRevisionsMetaData(location.setRevision("0"), getBaselineRevision(), false); //$NON-NLS-1$
                }
                return conn.getRevisionsMetaData(location, false);
            }
        });
    }

    @Override
    public boolean isFileExists(final ILocation loc) {
        boolean exists = exist(loc);
        log.debug("Is exists file: " + loc.toString() + " = " + exists);
        return exists;
    }

    /**
     * @deprecated
     * @param loc
     * @return
     */
    @Deprecated
    public Boolean existsFile(ILocation loc) {
        return new Boolean(exist(loc));
    }

    /**
     * will delete file at location, or folder
     * folder is deleted only if its empty
     */
    @Override
    public void deleteFile(final ILocation loc) throws XWikiException
    {
        executeTransactionAction(new PrivilegedExceptionAction() {
            @Override
            public Object run() throws Exception {
                IRepositoryConnection conn = rs.getConnection(loc);
                if (conn.isFolder(loc)) {
                    if (conn.getSubLocations(loc, false).size() == 0) {
                        conn.delete(loc);
                    }
                } else if (conn.exists(loc)) {
                    conn.delete(loc);
                }
                return null;
            }
        });
    }

    @Override
    public void deleteFile(final XWikiDocument doc) throws XWikiException
    {
        executeTransactionAction(new PrivilegedExceptionAction() {
            @Override
            public Object run() throws Exception {

                String project = SpaceParser.getProject(doc.getSpace());
                if (project == null) {
                    project = ISvnProvider.REPO_ROOT_AS_PROJECT_NAME;
                }
                String space = SpaceParser.getSpace(doc.getSpace());

                ILocation pageLocation = getDocumentWikiLocation(project, space, doc.getName());
                DocumentSvnInfo documentInfo = new DocumentSvnInfo();
                documentInfo.setLocation(pageLocation);

                log.debug("Delete: " + pageLocation.toString());

                //remove page.xml
                deleteFileNonTransaction(documentInfo.getDocumentFileLocation());

                //remove comments.xml
                deleteFileNonTransaction(documentInfo.getDocumentCommentsFileLocation());

                //remove attachments
                doc.getAttachmentList();
                for (Object element : doc.getAttachmentList()) {
                    XWikiAttachment attachment = (XWikiAttachment) element;
                    ILocation attachmentLocation = documentInfo.getAttachmentLocation(attachment.getFilename());
                    deleteFileNonTransaction(attachmentLocation);
                }
                //ILocation attachmentLocation

                // remove Attachments directory
                deleteFileNonTransaction(documentInfo.getAttachmentLocation(""));
                //remove page directory
                deleteFileNonTransaction(documentInfo.getLocation());

                //try remove space direcotry (if its empty)
                deleteFileNonTransaction(documentInfo.getLocation().getParentLocation());
                //try remove _wiki directory (if its empty)
                deleteFileNonTransaction(documentInfo.getLocation().getParentLocation().getParentLocation());

                return null;
            }
        });
    }

    @Override
    public void deleteFileNonTransaction(final ILocation loc)
    {
        IRepositoryConnection conn = rs.getConnection(loc);
        if (conn.isFolder(loc)) {
            if (conn.getSubLocations(loc, false).size() == 0) {
                conn.delete(loc);
            }
        } else if (conn.exists(loc)) {
            conn.delete(loc);
        }

    }

    /**
     * will delete file at location, or folder
     * folder is deleted only if its empty
     */
    @Override
    public void deleteFolder(final ILocation loc) throws XWikiException
    {
        executeTransactionAction(new PrivilegedExceptionAction() {
            @Override
            public Object run() throws Exception {
                IRepositoryConnection conn = rs.getConnection(loc);
                if (conn.isFolder(loc))
                {
                    List locs = conn.getSubLocations(loc, true);
                    Iterator it = locs.iterator();

                    while (it.hasNext()) {

                        ILocation loc = (ILocation) it.next();
                        conn.delete(loc);
                    }
                    conn.delete(loc);
                } else if (conn.exists(loc)) {
                    conn.delete(loc);
                }
                return null;
            }
        });
    }

    @Override
    public ByteBuffer readFile(ILocation locFile, Subject user, boolean system) {
        return readFile(locFile, "", user, system);
    }

    @Override
    public ByteBuffer readFile(ILocation locFile, String version, Subject user, boolean system) {
        ByteBuffer bb = null;
        try {
            ILocation fileLocation = locFile;
            if (version != null && ("".equals(version) == false)) {
                fileLocation = fileLocation.setRevision(version);
            }
            bb = ConvertUtil.inputStreamToByteBuffer(readFile(fileLocation));
        } catch (Exception e) {
            log.error("Exception while read file: ", e);
        }
        return bb;
    }

    @Override
    public boolean exist(final ILocation location) {
        return ((Boolean) executeNonTransactionActionAsSystemUser(new PrivilegedExceptionAction() {
            @Override
            public Object run() throws Exception {
                if (location == null) {
                    return Boolean.FALSE;
                }
                ILocation loc = makeBaselineLocation(location);
                IRepositoryReadOnlyConnection conn = rs.getReadOnlyConnection(loc);
                try {
                    return Boolean.valueOf(conn.exists(loc));
                } catch (Exception e)
                {
                    return Boolean.FALSE;
                }
            }
        })).booleanValue();
    }

    public InputStream readFileWithUser(final ILocation loc) throws XWikiException
    {
        return (InputStream) executeTransactionAction(new PrivilegedExceptionAction() {
            @Override
            public Object run() throws Exception {
                if (loc == null) {
                    return null;
                }
                ILocation location = makeBaselineLocation(loc);
                IRepositoryReadOnlyConnection conn = rs.getReadOnlyConnection(location);
                if (conn.isFile(location)) {
                    InputStream content = conn.getContent(location);
                    return content;
                }
                return null;
            }
        });
    }

    public InputStream readFileWithUser(final String url) throws XWikiException
    {
        return (InputStream) executeTransactionAction(new PrivilegedExceptionAction() {
            @Override
            public Object run() throws Exception {
                if (url == null) {
                    return null;
                }

                IRepositoryReadOnlyConnection conn = rs.getReadOnlyConnection(IRepositoryService.DEFAULT);
                IRepositoryInfo ri = conn.getRepositoryInfo();
                URI uri = ri.getRepositoryUri();
                String repoName = uri.toString();
                String location = url.replaceAll(repoName, "");
                ILocation loc = Location.getLocation(location);
                loc = makeBaselineLocation(loc);
                conn = rs.getReadOnlyConnection(loc);
                if (conn.isFile(loc)) {
                    InputStream content = conn.getContent(loc);
                    return content;
                }
                return null;
            }
        });
    }

    @Override
    public InputStream readFile(final ILocation loc) {
        return (InputStream) executeNonTransactionActionAsSystemUser(new PrivilegedExceptionAction() {
            @Override
            public Object run() throws Exception {
                if (loc == null) {
                    return null;
                }
                ILocation location = makeBaselineLocation(loc);
                IRepositoryReadOnlyConnection conn = rs.getReadOnlyConnection(location);
                if (conn.isFile(location)) {
                    InputStream content = conn.getContent(location);
                    return content;
                }
                return null;
            }
        });
    }

    @Override
    public void writeFileNonTransaction(ILocation fileLocation, byte[] what, Subject user, boolean system) throws Exception
    {
        newWriteFileNonTransaction(fileLocation, new ByteArrayInputStream(what), user, system, null);
    }

    @Override
    public void writeFile(ILocation fileLocation, byte[] what, Subject user, boolean system) throws Exception
    {
        newWriteFile(fileLocation, new ByteArrayInputStream(what), user, system, null);
    }

    @Override
    public void writeFile(ILocation fileLocation, byte[] what, Subject user, boolean system, String propertyTitleValue) throws Exception
    {
        newWriteFile(fileLocation, new ByteArrayInputStream(what), user, system, propertyTitleValue);
    }

    public void writeFileNonTransaction(ILocation fileLocation, byte[] what, Subject user, boolean system, String propertyTitleValue) throws Exception
    {
        newWriteFileNonTransaction(fileLocation, new ByteArrayInputStream(what), user, system, propertyTitleValue);
    }

    @Override
    public boolean copyLocations(final ILocation from, final ILocation to, Subject user) {
        boolean failed = true;
        if (tt == null) {
            log.error("Transaction service failed!!!");
        }

        tt.beginTx();

        try {
            ss.doAsUser(user, new PrivilegedExceptionAction() {

                @Override
                public Object run() throws Exception {
                    IRepositoryConnection conn = rs.getConnection(IRepositoryService.DEFAULT);
                    conn.copy(from, to, conn.exists(to));
                    return null;
                }
            });

            failed = false;
        } catch (Exception e) {
            log.error("Exception while copy locations: " + e.getMessage(), e);
        } finally {
            try {
                tt.endTx(failed);
            } catch (Exception e) {
                log.error("Can't end transaction: " + e.getMessage(), e);
                failed = true;
            }
        }

        return !failed;
    }

    public boolean checkEditRights(ILocation loc, Subject user) {
        try {
            Collection colUserRoles = Collections.EMPTY_LIST;
            IProject proj = getProjectFromLocation(loc);
            if (proj != null) {
                colUserRoles = ss.getRolesForUser(ss.getSubjectUser(user), proj.getContextId());
            } else {
                colUserRoles = ss.getRolesForUser(ss.getSubjectUser(user));
            }

            return hasEditRights(colUserRoles);
        } catch (Throwable e) {
            log.error("Exception when checking edit rights " + e.getMessage());
            return true;
        }
    }

    public boolean checkEditRights(String projectId) {
        try {
            Collection colUserRoles = Collections.EMPTY_LIST;
            IProject proj = null;

            if ((projectId != null) && (projectId.length() > 0)) {
                proj = projectSrv.getProject(projectId);
            }

            if (proj != null) {
                colUserRoles = ss.getRolesForUser(ss.getCurrentUser(), proj.getContextId());
            } else {
                colUserRoles = ss.getRolesForUser(ss.getCurrentUser());
            }

            return hasEditRights(colUserRoles);
        } catch (Throwable e) {
            log.error("Exception when checking edit rights " + e.getMessage());
            return true;
        }
    }

    public void newWriteFile(final ILocation loc, final ByteArrayInputStream content, Subject user, boolean system,
            final String propertyTitleValue) throws Exception {
        try {
            Subject useSubj;
            if (system) {
                useSubj = ss.getSystemUserSubject();
            } else {
                useSubj = user;
            }

            ss.doAsUser(useSubj, new PrivilegedExceptionAction() {

                @Override
                public Object run() throws Exception {
                    TransactionExecuter.executeSafely(new RunnableWEx<Void>() {

                        @Override
                        public Void runWEx() throws Exception {
                            IRepositoryConnection conn = rs.getConnection(IRepositoryService.DEFAULT);
                            conn.setContent(loc, content);
                            conn.setProperty(loc, ISvnProvider.PROPERTY_TITLE_NAME_POLARION, propertyTitleValue);
                            return null;
                        }
                    });

                    return null;
                }
            });

        } catch (Exception e) {
            log.error("Can't write file: " + e.getMessage(), e);
            Object[] args = { "" };
            throw new XWikiException(XWikiException.MODULE_XWIKI_STORE,
                    XWikiException.ERROR_XWIKI_STORE_RCS_SAVING_FILE, "Exception while saving document {0}", e, args);
        }
    }

    public void newWriteFileNonTransaction(final ILocation loc, final ByteArrayInputStream content, Subject user, boolean system,
            final String propertyTitleValue) throws Exception {
        try
        {
            IRepositoryConnection conn = rs.getConnection(IRepositoryService.DEFAULT);
            conn.setContent(loc, content);
            conn.setProperty(loc, ISvnProvider.PROPERTY_TITLE_NAME_POLARION, propertyTitleValue);

        } catch (Exception e) {
            log.error("Can't write file: " + e.getMessage(), e);
            Object[] args = { "" };
            throw new XWikiException(XWikiException.MODULE_XWIKI_STORE,
                    XWikiException.ERROR_XWIKI_STORE_RCS_SAVING_FILE, "Exception while saving document {0}", e, args);
        }
    }

    /**
     * @deprecated
     */
    @Override
    @Deprecated
    public String[] getSpaces(final String rt) {
        final List<String> sub = new ArrayList<String>();
        String[] ret = null;
        boolean failed = true;
        Subject subj = null;
        try {
            try {
                // subj = (Subject)context.getRequest().getSession().getAttribute("SVN_SUBJECT");
                subj = ss.getCurrentSubject();
            } catch (Exception e) {
                log.error("Can't get subject while getting spaces: " + e.getMessage(), e);
            }
            tt.beginTx();
            if (subj != null) {
                ss.doAsUser(subj, new PrivilegedExceptionAction() {

                    @Override
                    public Object run() throws Exception {
                        IRepositoryConnection conn = rs.getConnection(IRepositoryService.DEFAULT);
                        IRepositoryInfo ri = conn.getRepositoryInfo();
                        ILocation root = ri.getRootLocation();

                        // searching for spaces in root of SVN
                        ILocation rootSpaces = root.append(ISvnProvider.WIKI_ROOT_FOLDER);
                        if (conn.exists(rootSpaces)) {
                            try {
                                List locs = conn.getSubLocations(rootSpaces, false);
                                Iterator it = locs.iterator();

                                while (it.hasNext()) {
                                    ILocation loc = (ILocation) it.next();
                                    sub.add("/" + loc.getLastComponent());
                                }
                            } catch (Exception e) {
                                log.error("Root spaces were not located: " + e.getMessage(), e);
                            }
                        }

                        // searching for spaces in projects
                        List projects = projectSrv.getRootProjectGroup().getDeepContainedProjects();
                        for (int i = 0; i < projects.size(); i++) {
                            try {
                                IProject pr = (IProject) projects.get(i);

                                String ProjName = pr.getLocalId().getObjectName();
                                ILocation ProjLoc = getProjectLocation(ProjName);
                                ProjLoc = ProjLoc.append(ISvnProvider.WIKI_ROOT_FOLDER);

                                List locs = conn.getSubLocations(ProjLoc, false);
                                Iterator it = locs.iterator();

                                while (it.hasNext()) {
                                    ILocation loc = (ILocation) it.next();
                                    sub.add(ProjName + "/" + loc.getLastComponent());
                                }
                            } catch (Exception e) {
                                log.error("Project spaces were not located: " + e.getMessage(), e);
                            }
                        }

                        return null;
                    }
                });
            } else {
                ss.doAsSystemUser(new PrivilegedExceptionAction() {

                    @Override
                    public Object run() throws Exception {
                        IRepositoryConnection conn = rs.getConnection(IRepositoryService.DEFAULT);
                        IRepositoryInfo ri = conn.getRepositoryInfo();
                        ILocation root = ri.getRootLocation();

                        List projects = getAllProjects();
                        for (int i = 0; i < projects.size(); i++) {
                            try {
                                IProject pr = (IProject) projects.get(i);

                                String ProjName = pr.getLocalId().getObjectName();
                                ILocation ProjLoc = getProjectLocation(ProjName);
                                ProjLoc = ProjLoc.append(ISvnProvider.WIKI_ROOT_FOLDER);

                                List locs = conn.getSubLocations(ProjLoc, false);
                                Iterator it = locs.iterator();

                                while (it.hasNext()) {
                                    ILocation loc = (ILocation) it.next();
                                    sub.add(ProjName + "/" + loc.getLastComponent());
                                }
                            } catch (Exception e) {
                                log.error("Project spaces were not located: " + e.getMessage(), e);
                            }
                        }

                        // searching for spaces in root of SVN
                        ILocation rootSpaces = root.append(ISvnProvider.WIKI_ROOT_FOLDER);
                        if (conn.exists(rootSpaces)) {
                            try {
                                List locs = conn.getSubLocations(rootSpaces, false);
                                Iterator it = locs.iterator();

                                while (it.hasNext()) {
                                    ILocation loc = (ILocation) it.next();
                                    sub.add("/" + loc.getLastComponent());
                                }
                            } catch (Exception e) {
                                log.error("Root spaces were not located: " + e.getMessage(), e);
                            }
                        }

                        return null;
                    }
                });
            }

            failed = false;
        } catch (Exception e) {
            log.error("Can't get spaces: " + e.getMessage(), e);
        } finally {

            try {
                tt.endTx(failed);
            } catch (Exception e) {
                log.error("Can't end transaction: " + e.getMessage(), e);
            }
        }

        if (!failed) {
            try {

                ret = new String[sub.size()];
                for (int i = 0; i < sub.size(); i++) {
                    ret[i] = String.valueOf(sub.get(i));
                }

            } catch (Exception e) {
                log.error("Exception while copy ret array", e);
            }
        }
        return ret;
    }

    private boolean hasEditRights(Collection colUserRoles) {
        Iterator it = colUserRoles.iterator();

        while (it.hasNext()) {
            String role = (String) it.next();
            if (role.equals("project_admin") || role.equals("project_developer") || role.equals("admin")
                    || role.equals("developer")) {
                return true;
            }
        }

        return false;
    }

    /**
     * Returns list of spaces is some particular project
     * if project is REPO_ROOT_AS_PROJECT_NAME will return spaces in root repo wiki
     */
    @Override
    public List getCurrentSpaces(String project)
    {
        List<String> mixedSpaces = new ArrayList<String>();

        List spaceInfos = getSpacesInProject(project);
        if (spaceInfos == null) {
            return mixedSpaces;
        }

        for (Iterator iter = spaceInfos.iterator(); iter.hasNext();) {
            SpaceSvnInfo space = (SpaceSvnInfo) iter.next();
            mixedSpaces.add(SpaceParser.getMixedSpace(project, space.getName()));
        }

        return mixedSpaces;
    }

    /**
     * space is some mixed project/projectName/page/SpaceName
     * 
     * @see ISvnProvider#getDocumentAttachments(String, String)
     */
    @Override
    public List/* AttachmentSvnInfo */getDocumentAttachments(String mixedSpace, String page) {
        String project = SpaceParser.getProject(mixedSpace);
        String space = SpaceParser.getSpace(mixedSpace);
        boolean isRoot = SpaceParser.isRoot(mixedSpace);

        if (isRoot) {
            project = REPO_ROOT_AS_PROJECT_NAME;
        }

        return getAttachmentsInDocument(project, space, page);
    }

    @Override
    public List/* AttachmentSvnInfo */getDocumentAttachments(String mixedSpace, String page, String rev) {
        String project = SpaceParser.getProject(mixedSpace);
        String space = SpaceParser.getSpace(mixedSpace);
        boolean isRoot = SpaceParser.isRoot(mixedSpace);

        if (isRoot) {
            project = REPO_ROOT_AS_PROJECT_NAME;
        }
        return getAttachmentsInDocument(project, space, page, rev);
    }

    /**
     * @see ISvnProvider#getSpacesInProject(String)
     */
    @Override
    public List/* SpaceSvnInfo */getSpacesInProject(final String projectName) {
        return getSpacesInProject(getProjectLocation(projectName));
    }

    @SuppressWarnings("unchecked")
    public List<SpaceSvnInfo> getSpacesInProjectNonCached(final ILocation projectLoc) {
        return (List<SpaceSvnInfo>) executeNonTransactionActionAsSystemUser(new PrivilegedExceptionAction() {
            @Override
            public Object run() throws Exception {
                ILocation projectLocation = makeBaselineLocation(projectLoc);
                IRepositoryReadOnlyConnection conn = rs.getReadOnlyConnection(projectLocation);
                List locs = conn.getSubLocations(projectLocation.append(WIKI_ROOT_FOLDER), false);
                List<SpaceSvnInfo> list = new ArrayList<SpaceSvnInfo>();
                Iterator it = locs.iterator();
                while (it.hasNext()) {
                    ILocation loc = (ILocation) it.next();
                    String name = loc.getLastComponent();

                    // if its not space continue (space is folder, which doesn't contains '.' )
                    //if (name.indexOf('.') != -1)
                    //   continue;
                    IResourceProperties properties = conn.getResourceProperties(loc);
                    loc = loc.setRevision(properties.getLastChangedRevision());

                    //FIXME: wrong last changed revision returned on move
                    if (!conn.exists(loc) && projectLocation.hasRevision()) {
                        loc = loc.setRevision(projectLocation.getRevision());
                    }

                    SpaceSvnInfo space = new SpaceSvnInfo(loc, name, loc.getRevision(), properties.getLastChangedAuthor(), properties.getLastChangedDate());
                    list.add(space);
                }
                Collections.sort(list);
                return list;
            }
        });
    }

    public/*List<SpaceSvnInfo>*/SpaceSvnInfo getSpacesInProjectModules(final ILocation projectLoc) {
        return /*(List<SpaceSvnInfo>)*/(SpaceSvnInfo) executeNonTransactionActionAsSystemUser(new PrivilegedExceptionAction() {
            @Override
            public Object run() throws Exception {
                ILocation projectLocation = makeBaselineLocation(projectLoc);
                IRepositoryReadOnlyConnection conn = rs.getReadOnlyConnection(projectLocation);
                ILocation loc = projectLocation.append(Constants.MODULES_FOLDER);
                if (conn.exists(loc)) {
                    IResourceProperties properties = conn.getResourceProperties(loc);
                    loc = loc.setRevision(properties.getLastChangedRevision());
                    //FIXME: wrong last changed revision returned on move
                    if (!conn.exists(loc) && projectLocation.getRevision() != null) {
                        loc = loc.setRevision(projectLocation.getRevision());
                    }
                    SpaceSvnInfo space = new SpaceSvnInfo(loc, Constants.MODULES, loc.getRevision(), properties.getLastChangedAuthor(), properties.getLastChangedDate());
                    return space;
                }
                return null;
            }
        });
    }

    /**
     * 
     */
    @Override
    public List<SpaceSvnInfo>/* SpaceSvnInfo */getSpacesInProject(final ILocation projectLocation) {
        return isInBaseline() ? getSpacesInProjectNonCached(projectLocation) : spacesCache.getSpacesInProject(projectLocation);
    }

    public int getDocumentsCountInSpace(String projectName, String spaceName) {
        return getDocumentsCountInSpace(getSpaceWikiLocation(projectName, spaceName));
    }

    public int getDocumentsCountInSpace(final ILocation spaceLocation) {
        return (Integer) executeNonTransactionActionAsSystemUser(new PrivilegedExceptionAction() {
            @Override
            public Object run() throws Exception {
                ILocation loc = makeBaselineLocation(spaceLocation);
                IRepositoryReadOnlyConnection conn = rs.getReadOnlyConnection(loc);
                List locs = conn.getSubLocations(loc, false);
                return locs.size();
            }
        });
    }

    /**
     * @author VKO
     *
     * @param location
     * @return  <code>SpaceSvnInfo</code> object with full space description
     * 	only usefull info it gives is last revision number
     
    public SpaceSvnInfo getSpaceByLocation(ILocation location){
    	IRepositoryReadOnlyConnection conn = rs.getReadOnlyConnection(location);
    	IResourceProperties properties = conn.getResourceProperties(location);
    	if (!properties.getResourceKind().equals(IResourceProperties.KIND_FOLDER)) return null;
    	location = location.setRevision(properties.getLastChangedRevision());
    	return new SpaceSvnInfo(location, location.getLastComponent());
    }
    */

    /**
     * @see ISvnProvider#getDocumentsInSpace(String, String)
     */
    @Override
    public List<DocumentSvnInfo> getDocumentsInSpace(String projectName, String spaceName) {
        return getDocumentsInSpace(getSpaceWikiLocation(projectName, spaceName));
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<DocumentSvnInfo> getDocumentsInSpace(final ILocation location) {
        return (List) executeNonTransactionActionAsSystemUser(new PrivilegedExceptionAction() {
            @Override
            public Object run() throws Exception {
                ILocation spaceLocation = makeBaselineLocation(location);
                IRepositoryReadOnlyConnection conn = rs.getReadOnlyConnection(spaceLocation);
                List locs = conn.getSubLocations(spaceLocation, false);
                List documents = new ArrayList();
                for (Iterator iter = locs.iterator(); iter.hasNext();) {
                    ILocation location = (ILocation) iter.next();
                    String name = location.getLastComponent();

                    // if its not page continue (page is directori so not contains . )
                    if (name.indexOf('.') != -1)
                    {
                        // continue;
                        //name = name.replaceAll("\\.", "&sdot;");
                        name = name.replaceAll("\\.", "&#46;");

                    }

                    DocumentSvnInfo document = new DocumentSvnInfo();
                    IResourceProperties properties = conn.getResourceProperties(location);
                    location = location.setRevision(properties.getLastChangedRevision());
                    //FIXME: wrong last changed revision returned on move
                    if (!conn.exists(location) && spaceLocation.getRevision() != null) {
                        location = location.setRevision(spaceLocation.getRevision());
                    }

                    document.setLocation(location);
                    document.setAutor(properties.getLastChangedAuthor());
                    document.setDate(properties.getLastChangedDate());
                    document.setName(name);
                    documents.add(document);
                }
                return documents;
            }
        });
    }

    /**
     * @see ISvnProvider#getAttachmentsInDocument(String, String, String)
     */
    @Override
    public List getAttachmentsInDocument(String projectName, String spaceName, String pageName) {
        return getAttachmentsInDocument(projectName, spaceName, pageName, null);
    }

    @Override
    public List getAttachmentsInDocument(String projectName, String spaceName, String pageName, String revision) {
        ILocation documentLocation = getDocumentWikiLocation(projectName, spaceName, pageName);

        if (revision != null) {
            documentLocation = documentLocation.setRevision(revision);
        }

        return getAttachmentsInDocument(documentLocation);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List getAttachmentsInDocument(final ILocation location)
    {
        return (List) executeNonTransactionActionAsSystemUser(new PrivilegedExceptionAction() {
            @Override
            public Object run() throws Exception {
                ILocation documentLocation = makeBaselineLocation(location);
                IRepositoryReadOnlyConnection conn = rs.getReadOnlyConnection(documentLocation.append(DocumentSvnInfo.ATTACHMENT_FILE_FOLDER));
                List locs = conn.getSubLocations(documentLocation.append(DocumentSvnInfo.ATTACHMENT_FILE_FOLDER), false);
                Iterator it = locs.iterator();
                List list = new ArrayList();
                while (it.hasNext()) {

                    ILocation loc = (ILocation) it.next();
                    String name = loc.getLastComponent();

                    // if its not attachmnet continue
                    if (name.indexOf(DocumentSvnInfo.COMMENTS_XML) != -1) {
                        continue;
                    }

                    IResourceProperties properties = conn.getResourceProperties(loc);
                    AttachmentSvnInfo info = new AttachmentSvnInfo();
                    //loc = loc.setRevision(properties.getLastChangedRevision());
                    info.setLocation(loc);
                    info.setName(name);
                    info.setAutor(properties.getLastChangedAuthor());
                    info.setDate(properties.getLastChangedDate());
                    info.setSize((int) properties.getFileSize());
                    info.setTitle(getAttachmentTitle(conn, loc));

                    list.add(info);
                }

                return list;
            }
        });

    }

    /**
     * add this function for history list
     *  show only revisions with page.xml file
     * valid documentLocation example: ../_wiki/SpaceName/DocumentName
     * @param documentLocation
     * @return
     */
    @Override
    public DocumentSvnInfo getDocumentForHistory(final ILocation location) {
        return (DocumentSvnInfo) executeNonTransactionActionAsSystemUser(new PrivilegedExceptionAction() {
            @Override
            public Object run() throws Exception {
                ILocation documentLocation = makeBaselineLocation(location);
                if (documentLocation.getLastComponent().equalsIgnoreCase(DocumentSvnInfo.PAGE_XML)) {
                    log.error(documentLocation + " is not valid document location (valid: ../_wiki/space/document)");
                }
                IRepositoryReadOnlyConnection conn = rs.getReadOnlyConnection(documentLocation);
                DocumentSvnInfo document = new DocumentSvnInfo();
                IResourceProperties properties = null;
                try
                {
                    properties = conn.getResourceProperties(documentLocation);
                } catch (Exception e)
                {
                    return null;
                }
                ILocation doc = properties.getLocation();
                document.setLocation(doc);
                document.setRevision(doc.getRevision());
                document.setAutor(properties.getLastChangedAuthor());
                document.setDate(properties.getLastChangedDate());
                document.setName(doc.getLastComponent());
                return document;
            }
        });
    }

    /**
     * valid documentLocation example: ../_wiki/SpaceName/DocumentName
     * @param documentLocation
     * @return
     */
    @Override
    public DocumentSvnInfo getDocument(final ILocation documentLocation) {
        return (DocumentSvnInfo) executeNonTransactionActionAsSystemUser(new PrivilegedExceptionAction() {
            @Override
            public Object run() throws Exception {
                if (documentLocation.getLastComponent().equalsIgnoreCase(DocumentSvnInfo.PAGE_XML)) {
                    log.error(documentLocation + " is not valid document location (valid: ../_wiki/space/document)");
                }
                IRepositoryReadOnlyConnection conn = rs.getReadOnlyConnection(documentLocation);
                ILocation doc = documentLocation.setRevision(getLocationLastRevisionImpl(documentLocation));
                doc = makeBaselineLocation(doc);
                DocumentSvnInfo document = new DocumentSvnInfo();
                IResourceProperties properties = conn.getResourceProperties(doc);
                document.setLocation(doc);
                document.setAutor(properties.getLastChangedAuthor());
                document.setDate(properties.getLastChangedDate());
                document.setName(documentLocation.getLastComponent());
                document.setRevision(documentLocation.getRevision());
                return document;
            }
        });
    }

    /**
     * valid attachments location example: ../_wiki/spaceName/pageName/attachment-someFiel.doc
     * @param attachmentLocation
     * @return
     */
    public AttachmentSvnInfo getAttachment(final ILocation location) {
        return (AttachmentSvnInfo) executeNonTransactionActionAsSystemUser(new PrivilegedExceptionAction() {
            @Override
            public Object run() throws Exception {
                ILocation attachmentLocation = makeBaselineLocation(location);
                IRepositoryReadOnlyConnection conn = rs.getReadOnlyConnection(attachmentLocation);
                IResourceProperties properties = conn.getResourceProperties(attachmentLocation);
                AttachmentSvnInfo info = new AttachmentSvnInfo();
                //ILocation att = attachmentLocation.setRevision(properties.getLastChangedRevision());
                info.setLocation(attachmentLocation);
                info.setName(attachmentLocation.getLastComponent());
                info.setAutor(properties.getLastChangedAuthor());
                info.setDate(properties.getLastChangedDate());
                info.setSize((int) properties.getFileSize());
                info.setTitle(getAttachmentTitle(conn, attachmentLocation));
                return info;
            }
        });
    }

    @Override
    public String getLocationLastRevision(final ILocation location) {
        return (String) executeNonTransactionActionAsSystemUser(new PrivilegedExceptionAction() {
            @Override
            public Object run() throws Exception {
                return getLocationLastRevisionImpl(location);
            }
        });
    }

    private String getLocationLastRevisionImpl(ILocation loc) {
        loc = makeBaselineLocation(loc);
        IRepositoryReadOnlyConnection conn = rs.getReadOnlyConnection(loc);
        String rev = conn.getLastRevision(loc);
        // we have to check if the location in given revision exists
        // because we can be in a moved project and not touched after the move
        // then 'lastRevision' is revision of last modify before the move
        while ((loc != null) && !conn.exists(loc.setRevision(rev))) {
            loc = loc.getParentLocation();
            rev = conn.getLastRevision(loc);
        }
        return rev;
    }

    @Override
    public String[] getDocuments(final String mixedSpace) {

        boolean rolback = false;
        Subject subj = null;
        final String project = SpaceParser.getProject(mixedSpace);
        final String space = SpaceParser.getSpace(mixedSpace);
        final boolean isRoot = SpaceParser.isRoot(mixedSpace);
        try {
            subj = ss.getCurrentSubject();
            tt.beginTx();
            PrivilegedExceptionAction action = new PrivilegedExceptionAction() {

                @Override
                public Object run() throws Exception {
                    IRepositoryConnection conn = rs.getConnection(IRepositoryService.DEFAULT);
                    IRepositoryInfo ri = conn.getRepositoryInfo();

                    ILocation root = ri.getRootLocation();
                    ILocation rootLoc = root;

                    if (isRoot) {
                        // documents are located in some space in root of SVN
                        String spaceLoc = ISvnProvider.WIKI_ROOT_FOLDER + "/" + space;
                        rootLoc = rootLoc.append(spaceLoc);
                    } else {
                        rootLoc = projectSrv.getProject(project).getLocation();
                        rootLoc = rootLoc.append(ISvnProvider.WIKI_ROOT_FOLDER).append(space);
                    }

                    List locs = conn.getSubLocations(rootLoc, false);
                    String[] data = new String[locs.size()];
                    for (int i = 0; i < locs.size(); i++) {
                        data[i] = ((ILocation) locs.get(i)).getLastComponent();
                    }
                    return data;
                }
            };

            if (subj != null) {
                return (String[]) ss.doAsUser(subj, action);
            } else {
                return (String[]) ss.doAsSystemUser(action);
            }

        } catch (Exception e) {
            log.error("Can't get documents: " + e.getMessage(), e);
            rolback = true;
        } finally {
            try {
                tt.endTx(rolback);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
        return null;
    }

    @Override
    public String getHeaderTitle(String name) {
        if (name.trim().equalsIgnoreCase("")) {
            return "";
        }

        String group = "";
        String project = projectSrv.getProject(name).getName();

        ILocation loc = projectSrv.getProject(name).getLocation();
        String projectPath = loc.getLocationPath();
        int projectIndex = projectPath.indexOf(name);
        if (projectIndex > 1) {
            group = projectPath.substring(1, projectIndex - 1) + " > ";
        }

        return group + project + (project != "" ? " > " : "");
    }

    @Override
    public void removeAttachments(final String mixedSpace, final String page) throws XWikiException {
        final String project = SpaceParser.getProject(mixedSpace);
        final String space = SpaceParser.getSpace(mixedSpace);
        final boolean isRoot = SpaceParser.isRoot(mixedSpace);
        PrivilegedExceptionAction action = new PrivilegedExceptionAction() {

            @Override
            public Object run() throws Exception {
                IRepositoryConnection conn = rs.getConnection(IRepositoryService.DEFAULT);
                IRepositoryInfo ri = conn.getRepositoryInfo();

                ILocation root = ri.getRootLocation();
                ILocation rootLoc = root;

                if (isRoot) {
                    // documents are located in some space in root of SVN
                    String spaceLoc = ISvnProvider.WIKI_ROOT_FOLDER + "/" + space;
                    rootLoc = rootLoc.append(spaceLoc);
                } else {
                    rootLoc = projectSrv.getProject(project).getLocation();
                    rootLoc = rootLoc.append(ISvnProvider.WIKI_ROOT_FOLDER).append(space);

                }
                rootLoc = rootLoc.append(page);

                List locs = conn.getSubLocations(rootLoc, false);
                Iterator it = locs.iterator();

                while (it.hasNext()) {

                    ILocation loc = (ILocation) it.next();
                    String name = loc.getLastComponent();

                    // if its not attachmnet continue
                    if (name.indexOf(DocumentSvnInfo.COMMENTS_XML) != -1 || name.indexOf(DocumentSvnInfo.PAGE_XML) != -1) {
                        continue;
                    }
                    conn.delete(loc);
                }

                return null;
            }

        };
        executeTransactionAction(action);
    }

    public void removeAttachmentsNonTransaction(final String mixedSpace, final String page) {
        final String project = SpaceParser.getProject(mixedSpace);
        final String space = SpaceParser.getSpace(mixedSpace);
        final boolean isRoot = SpaceParser.isRoot(mixedSpace);
        IRepositoryConnection conn = rs.getConnection(IRepositoryService.DEFAULT);
        IRepositoryInfo ri = conn.getRepositoryInfo();

        ILocation root = ri.getRootLocation();
        ILocation rootLoc = root;

        if (isRoot) {
            // documents are located in some space in root of SVN
            String spaceLoc = ISvnProvider.WIKI_ROOT_FOLDER + "/" + space;
            rootLoc = rootLoc.append(spaceLoc);
        } else {
            rootLoc = projectSrv.getProject(project).getLocation();
            rootLoc = rootLoc.append(ISvnProvider.WIKI_ROOT_FOLDER).append(space);

        }
        rootLoc = rootLoc.append(page);

        List locs = conn.getSubLocations(rootLoc, false);
        Iterator it = locs.iterator();

        while (it.hasNext()) {

            ILocation loc = (ILocation) it.next();
            String name = loc.getLastComponent();

            // if its not attachmnet continue
            if (name.indexOf(DocumentSvnInfo.COMMENTS_XML) != -1 || name.indexOf(DocumentSvnInfo.PAGE_XML) != -1) {
                continue;
            }
            conn.delete(loc);
        }

    }

    // <<--

    private Object executeTransactionAction(PrivilegedExceptionAction action) throws XWikiException {
        boolean rollback = false;
        Throwable t = null;
        try {
            Subject subject = ss.getCurrentSubject();
            tt.beginTx();

            if (subject != null) {
                return ss.doAsUser(subject, action);
            }
            return ss.doAsSystemUser(action);
        } catch (Exception e) {
            rollback = true;
            t = e;
            log.warn("executing action:", e);
        } finally {
            try {
                tt.endTx(rollback);
            } catch (Exception e) {
                log.error("Exception in executeTransactionAction. Transaction failed", e);
                Object[] args = { "" };
                throw new XWikiException(XWikiException.MODULE_XWIKI_STORE,
                        XWikiException.ERROR_XWIKI_STORE_RCS_SAVING_FILE, "Exception while saving document {0}", e, args);
            }
            if (t != null) {
                if (t.getCause() instanceof XWikiException)
                {
                    XWikiException xex = (XWikiException) t.getCause();
                    if (xex.getCode() == XWikiException.ERROR_XWIKI_STORE_RCS_SAVING_FILE)
                    {
                        throw new XWikiException(XWikiException.MODULE_XWIKI_DOC,
                                XWikiException.ERROR_DOC_XML_PARSING, "Error parsing xml", t.getCause(), null);

                    }
                }
                Object[] args = { "" };
                throw new XWikiException(XWikiException.MODULE_XWIKI_STORE,
                        XWikiException.ERROR_XWIKI_UNKNOWN, "Exception while saving document {0}", new RuntimeException(t), args);
            }
        }
        return null;
    }

    private Object executeNonTransactionActionAsSystemUser(PrivilegedExceptionAction action) {
        try {
            return ss.doAsSystemUser(action);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private boolean testAccessAction(PrivilegedAction action) {
        try {
            Subject subject = ss.getCurrentSubject();

            if (subject != null) {
                ss.doAsUser(subject, action);
            }
            ss.doAsSystemUser(action);

        } catch (Exception e) {
            return false;
        }
        return true;
    }

    /**
     * 
     * @return /_wiki (where _wiki is WIKI_ROOT_DIRECTORY_NAME)
     */
    @Override
    public ILocation getRootWikiLocation() {
        return Location.getLocationWithRepository(IRepositoryService.DEFAULT, "/" + WIKI_ROOT_FOLDER);
    }

    /**
     * Repository root
     * 
     * @return /
     */
    @Override
    public ILocation getRootLocation() {
        return Location.getLocationWithRepository(IRepositoryService.DEFAULT, "/");
    }

    /**
     * 
     * @param projectName
     * @return location project location with _wiki (/_wiki or /project/_wiki
     */
    @Override
    public ILocation getProjectWikiLocation(String projectName) {
        ILocation projectLocation = getRootWikiLocation();

        if (!REPO_ROOT_AS_PROJECT_NAME.equals(projectName) && !"".equals(projectName)) {
            projectLocation = projectSrv.getProject(projectName).getLocation().append(WIKI_ROOT_FOLDER);
        }
        return projectLocation;
    }

    /**
     * 
     * @param projectName
     * @param spaceName
     * @return /_wiki/spaceName or ...../projectName/_wiki/spaceName
     */
    @Override
    public ILocation getSpaceWikiLocation(String projectName, String spaceName) {
        ILocation loc = null;
        if (Constants.MODULES.equals(spaceName)) {
            if (!REPO_ROOT_AS_PROJECT_NAME.equals(projectName)) {
                loc = projectSrv.getProject(projectName).getLocation().append(Constants.MODULES_FOLDER);
            } else {
                loc = Location.getLocation(Constants.MODULES_FOLDER);
            }
        } else if (Constants.USERS.equals(spaceName)) {
            loc = Location.getLocationWithRepository(IRepositoryService.DEFAULT, "/.polarion/" + Constants.USERS_FOLDER + "/users"); //$NON-NLS-1$ //$NON-NLS-2$

        } else if (Constants.TEST_RUNS.equals(spaceName)) {
            if (!REPO_ROOT_AS_PROJECT_NAME.equals(projectName)) {
                loc = projectSrv.getProject(projectName).getLocation().append(Constants.TEST_RUNS_REAL_FOLDER);
            } else {
                loc = Location.getLocation(Constants.TEST_RUNS_REAL_FOLDER);
            }
        } else if (Constants.PLANS.equals(spaceName)) {
            if (!REPO_ROOT_AS_PROJECT_NAME.equals(projectName)) {
                loc = projectSrv.getProject(projectName).getLocation().append(Constants.PLANS_REAL_FOLDER);
            } else {
                loc = Location.getLocation(Constants.PLANS_REAL_FOLDER);
            }
        } else {
            loc = getProjectWikiLocation(projectName).append(spaceName);
        }
        return loc;
    }

    /**
     * 
     * @param projectName
     * @param spaceName
     * @param pageName
     * @return /_wiki/spaceName/pageName or ...../projectName/_wiki/spaceName/pageName
     */
    @Override
    public ILocation getDocumentWikiLocation(String projectName, String spaceName, String pageName) {
        return getSpaceWikiLocation(projectName, spaceName).append(pageName);
    }

    @Override
    public ILocation getDocumentWikiLocation(XWikiDocument doc) {
        return getDocumentWikiLocation(doc.getProject(), SpaceParser.getSpace(doc.getSpace()), doc.getName());
    }

    @Override
    public ILocation getPageWikiLocation(String projectName, String spaceName, String pageName) {
        return getDocumentWikiLocation(projectName, spaceName, pageName).append(DocumentSvnInfo.PAGE_XML);
    }

    @Override
    public ILocation getPageWikiLocation(XWikiDocument doc) {
        return getPageWikiLocation(doc.getProject(), SpaceParser.getSpace(doc.getSpace()), doc.getName());
    }

    @Override
    public String getUserNamePolarion(String user)
    {
        try
        {
            return projectSrv.getUser(user).getName();
        } catch (Exception e)
        {
            return user;
        }
    }

    @Override
    public void saveAttachmentContent(final ILocation loc, final byte[] content, final String title) throws Exception
    {
        PrivilegedExceptionAction action = new PrivilegedExceptionAction() {

            @Override
            public Object run() throws Exception {
                IRepositoryConnection conn = rs.getConnection(IRepositoryService.DEFAULT);

                createFile(conn, loc, title, content);

                return null;
            }

        };
        executeTransactionAction(action);

    }

    public void saveAttachmentContentNonTransaction(final ILocation loc, final byte[] content, final String title) throws Exception
    {
        IRepositoryConnection conn = rs.getConnection(IRepositoryService.DEFAULT);
        createFile(conn, loc, title, content);
    }

    private void createFile(IRepositoryConnection conn, ILocation loc, String title, byte[] content) throws Exception
    {
        try
        {
            InputStream is = new ByteArrayInputStream(content);

            conn.create(loc, is);

            if (title != null) {
                conn.setProperty(loc, PROPERTY_TITLE_NAME_POLARION, title);
            }

        } catch (java.lang.OutOfMemoryError e2) {
            try
            {
                conn.delete(loc);
            } catch (Exception e3) {
            }
            throw e2;

        } catch (Exception e) {

            log.error("Can't create file: " + e.getMessage(), e);
            Object[] args = { "" };
            throw new XWikiException(XWikiException.MODULE_XWIKI_STORE,
                    XWikiException.ERROR_XWIKI_STORE_RCS_SAVING_FILE, "Exception while saving document {0}", e, args);
        }

    }

    // BPO get space info
    @Override
    public SpaceSvnInfo getSpaceInfo(final ILocation loc)
    {
        return (SpaceSvnInfo) executeNonTransactionActionAsSystemUser(new PrivilegedExceptionAction() {
            @Override
            public Object run() throws Exception {
                ILocation location = makeBaselineLocation(loc);
                IRepositoryReadOnlyConnection conn = rs.getReadOnlyConnection(location);

                String name = location.getLastComponent();
                IResourceProperties properties = conn.getResourceProperties(location);
                return new SpaceSvnInfo(location, name, properties.getLastChangedRevision(), properties.getLastChangedAuthor(), properties.getLastChangedDate());
            }
        });
    }

    protected ITrackerService trackerService = PlatformContext.getPlatform().lookupService(ITrackerService.class);

    public String convertDocImgUrls(String html) throws Exception {
        return null;
    }

    @Override
    public void rollbackDocument(final XWikiDocument doc, final XWikiContext context, final WikiSvnStore store) throws XWikiException
    {
        executeTransactionAction(new PrivilegedExceptionAction() {
            @Override
            public Object run() throws Exception {
                removeAttachmentsNonTransaction(doc.getSpace(), doc.getName());

                List list = doc.getAttachmentList();
                Iterator itr = list.iterator();
                while (itr.hasNext())
                {
                    XWikiAttachment attachment = (XWikiAttachment) itr.next();
                    ILocation attLocation = getDocumentWikiLocation(attachment.getDoc()).append(DocumentSvnInfo.ATTACHMENT_FILE_FOLDER).append(attachment.getFilename());
                    attachment.setDoc(doc);
                    if (attachment.isContentDirty() || attachment.isMetaDataDirty())
                    {
                        attachment.setDate(new Date());
                    }

                    //newdoc.saveOnlyAttachmentContentRollback(att, context);
                    saveAttachmentContentNonTransaction(attLocation, attachment.getContent(context), attachment.getTitle());
                }

                store.saveXWikiDocNonTransaction(doc, context);
                return null;
            }
        });
    }

    @Override
    public void updateDocument(final XWikiDocument doc, final List saveList, final List deleteList, final XWikiContext context, final WikiSvnStore store, final boolean updateDoc) throws XWikiException
    {
        executeTransactionAction(new PrivilegedExceptionAction() {
            @Override
            public Object run() throws Exception {

                for (int j = 0; j < deleteList.size(); j++)
                {
                    XWikiAttachment attachment = (XWikiAttachment) deleteList.get(j);
                    if (attachment == null) {
                        continue;
                    }
                    //store.deleteXWikiAttachment(attachment, context, false);

                    ILocation attLocation = getDocumentWikiLocation(attachment.getDoc()).append(DocumentSvnInfo.ATTACHMENT_FILE_FOLDER).append(attachment.getFilename());
                    if (isFileExists(attLocation))
                    {
                        deleteFileNonTransaction(attLocation);
                    }
                    //if (bTransaction)
                    //	saveXWikiDocPart(attachment.getDoc(), context, true);

                    List list = attachment.getDoc().getAttachmentList();
                    for (int i = 0; i < list.size(); i++)
                    {
                        XWikiAttachment attach = (XWikiAttachment) list.get(i);
                        if (attachment.getFilename().equals(attach.getFilename()))
                        {
                            list.remove(i);
                            break;
                        }
                    }

                }// for
                 // save part
                for (int e = 0; e < saveList.size(); e++)
                {
                    XWikiAttachment attachment = (XWikiAttachment) saveList.get(e);
                    //store.saveAttachmentContent(attachment, false, context, true, false);

                    ILocation attLocation = getDocumentWikiLocation(attachment.getDoc()).append(DocumentSvnInfo.ATTACHMENT_FILE_FOLDER).append(attachment.getFilename());
                    if (attachment.isContentDirty() || attachment.isMetaDataDirty())
                    {
                        attachment.incrementVersion();
                        attachment.setDate(new Date());
                    }
                    saveAttachmentContentNonTransaction(attLocation, attachment.getContent(context), attachment.getTitle());
                    doc.getAttachmentList().add(attachment);
                }
                // document part
                if (updateDoc) {
                    store.saveXWikiDocNonTransaction(doc, context);
                }

                return null;
            }
        });
    }

    @Override
    public void deleteAttachmentNew(final XWikiDocument doc, final XWikiAttachment attachment, final XWikiContext context, final WikiSvnStore store) throws XWikiException
    {
        executeTransactionAction(new PrivilegedExceptionAction() {
            @Override
            public Object run() throws Exception {

                ILocation attLocation = getDocumentWikiLocation(attachment.getDoc()).append(DocumentSvnInfo.ATTACHMENT_FILE_FOLDER).append(attachment.getFilename());
                deleteFileNonTransaction(attLocation);

                List list = attachment.getDoc().getAttachmentList();
                for (int i = 0; i < list.size(); i++)
                {
                    XWikiAttachment attach = (XWikiAttachment) list.get(i);
                    if (attachment.getFilename().equals(attach.getFilename()))
                    {
                        list.remove(i);
                        break;
                    }
                }

                store.saveXWikiDocNonTransaction(doc, context);

                return null;
            }
        });
    }

    public ISecurityService getSecureService()
    {
        return ss;
    }

    @Override
    public void createSpace(final XWikiDocument doc) throws XWikiException
    {
        executeTransactionAction(new PrivilegedExceptionAction() {
            @Override
            public Object run() throws Exception {
                IRepositoryConnection conn = rs.getConnection(IRepositoryService.DEFAULT);
                conn.makeFolders(getSpaceWikiLocation(doc.getProject(), doc.getSpaceName()));

                return null;
            }
        });

    }
}
