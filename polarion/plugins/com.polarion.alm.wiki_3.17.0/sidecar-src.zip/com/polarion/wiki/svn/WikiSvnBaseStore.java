package com.polarion.wiki.svn;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.security.auth.Subject;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.polarion.alm.wiki.WikiPlugin;
import com.polarion.platform.core.PlatformContext;
import com.polarion.platform.security.ISecurityService;
import com.polarion.subterra.base.location.ILocation;
import com.polarion.subterra.base.location.Location;
import com.polarion.wiki.svn.bo.DocumentSvnInfo;
import com.polarion.wiki.util.Constants;
import com.polarion.wiki.util.RequestParser;
import com.polarion.wiki.util.SpaceParser;
import com.polarion.wiki.util.XmlParser;
import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.doc.XWikiAttachment;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.render.XWikiRenderer;

public class WikiSvnBaseStore
{
    private static final Log log = LogFactory.getLog(WikiSvnBaseStore.class);

    private ISvnProvider svn;

    //Dmitry
    private static final String WIKI_ROOT_S = "";

    //private static final IPath WIKI_ROOT = new Path(WIKI_ROOT_S);
    private static final ILocation WIKI_ROOT = Location.getLocation(WIKI_ROOT_S);
    // TODO (polarion/wiki) change to polarion/wiki

    public static final String WIKI_MAINSPACE = "XWiki";

    //private static IPath USERS_FILE = WIKI_ROOT.append(WIKI_MAINSPACE).append("users").addFileExtension("lst");
    private static ILocation USERS_FILE = WIKI_ROOT.append(WIKI_MAINSPACE).append("users.lst");

    public static final String WIKI_DEFAULT_PAGE = Constants.DEFAULT_PAGE;

    public static final ILocation WIKI_PROJECT_ROOT_LOCATION = Location.getLocation(ISvnProvider.WIKI_ROOT_FOLDER);

    // TODO (polarion/wiki)(!!SUSF!!)
    // !!!! SVN USER SPECIFIC FUNCS
    // dir for read from templates
    public static final String WIKI_TEMPLITES_ROOT_XML_S = "/templates/XWikiTemplates";
    public static final ILocation WIKI_TEMPLITES_ROOT_XML = Location.getLocation(WIKI_TEMPLITES_ROOT_XML_S);

    public boolean addUser(String fullName)
    {
        log.debug("Try to add user: " + fullName);
        boolean done = false;
        try
        {

            StringBuffer content = getFile(USERS_FILE);

            while (checkUser(fullName, content))
            {
                log.debug("User already in list");
                removeUser(fullName, content);
            }

            content.append(fullName + "\n");

            svn.writeFile(USERS_FILE, content.toString().getBytes("UTF-8"), null, true);

            done = true;
        } catch (Exception e)
        {
            log.error("Exception while add user: " + e.getMessage(), e);
        }

        return done;
    }

    public StringBuffer getFile(ILocation loc)
    {
        StringBuffer sb = null;
        try
        {
            if (!svn.isFileExists(loc))
            {
                log.debug("File not found, creating new: " + loc.toString());
                svn.createFile(loc, null, true);
                return new StringBuffer();
            }

            return new StringBuffer(new String(svn.readFile(loc, null, true).array()));
        } catch (Exception e)
        {
            log.error("Exception while file" + loc.toString() + ": " + e.getMessage(), e);
        }

        return sb;
    }

    public boolean removeUser(String fullName, StringBuffer content)
    {
        boolean removed = false;
        try
        {
            int pos = content.indexOf(fullName);
            if (pos != -1)
            {
                content.delete(pos, pos + fullName.length() + 1);
                return true;
            }
        } catch (Exception e)
        {
            log.error("Exception while remove user: " + e.getMessage(), e);
        }

        return removed;
    }

    public boolean checkUser(String fullName, StringBuffer content)
    {
        return (content.indexOf(fullName) != -1 ? true : false);
    }

    public boolean checkUser(String fullName)
    {
        return checkUser(fullName, getFile(USERS_FILE));
    }

    public String getUserName(String fullName)
    {
        return fullName.substring(fullName.indexOf(".") + 1, fullName.length());
    }

    public List<String> getUsersList()
    {
        ILocation userFile = WIKI_ROOT.append(WIKI_MAINSPACE);
        List<String> users = new ArrayList<String>();
        StringBuffer content = getFile(USERS_FILE);
        String userName = "";
        int currPos = content.indexOf("\n");
        int lastPos;

        if (currPos != -1)
        {
            if ((currPos + 1) == content.toString().length())
            {
                users.add(content.substring(0, currPos));
            }
            else
            {
                userName = content.substring(0, currPos);
                //log.error("First user: " + getUserName(userName));
                if (svn.isFileExists(userFile.append(getUserName(userName) + ".xml")))
                {
                    users.add(userName);
                }

                while ((currPos + 1) != content.toString().length())
                {
                    lastPos = currPos;
                    currPos = content.indexOf("\n", currPos + 1);
                    userName = content.substring(lastPos + 1, currPos);

                    //log.error("Check user: " + getUserName(userName));
                    if (svn.isFileExists(userFile.append(getUserName(userName) + ".xml")))
                    {
                        users.add(userName);
                    }
                }

            }
        }
        return users;
    }

    @Deprecated
    public List<String> getDocuments(String space, XWikiContext context)
    {
//        try {
//            if (RequestParser.isDocumentPage(space)) {
//                String realSpace = space.substring(space.lastIndexOf('/') + 1);
//                List<XWikiDocument> documents = ReIndexPluginApi.getInstance().searchDocument(Index.FIELD_SPACE + ":\"" + realSpace + "\"");
//                List<String> mixedSpaces = new ArrayList<String>();
//                for (Object element : documents) {
//                    XWikiDocument doc = (XWikiDocument) element;
//                    mixedSpaces.add(space + "." + doc.getName());
//                }
//                return mixedSpaces;
//            }
//        } catch (Exception e) {
//            log.error("Error while getDocuments:" + space, e);
//        }
//        return Collections.emptyList();
        throw new RuntimeException(WikiPlugin.getDeprecatedMethodMessage("getDocuments")); //$NON-NLS-1$
    }

    public List getCurrentSpaces(XWikiContext context, String project) {
        return svn.getCurrentSpaces(project);
    }

    public List<String> getSpaces(XWikiContext context)
    {
        List<String> spaces = new ArrayList<String>();
        try
        {
            String[] allSpaces = svn.getSpaces(getSvnRoot());

            for (int idx = 0; idx <= allSpaces.length - 1; idx++)
            {
                if (RequestParser.isDocumentPage(allSpaces[idx]))
                {
                    spaces.add(allSpaces[idx]);
                }
            }
        } catch (Exception e)
        {
            log.error("Exception while get spaces: " + e.getMessage(), e);
        }
        return spaces;
    }

    /**
     * PBO add for attachments
     * @param space
     * @param context
     * @return
     */
    public List<String> getDocumentsAttachments(String space, XWikiContext context)
    {
        List<String> docs = new ArrayList<String>();
        try
        {
            //PBO 
            String[] allDocs = svn.getDocuments(space);
            for (int idx = 0; idx <= allDocs.length - 1; idx++)
            {
                int fpos = allDocs[idx].indexOf(".");
                if (fpos != -1)
                {
                    String doc = allDocs[idx];
                    docs.add(space + "." + doc);
                }
            }
        } catch (Exception e)
        {
            log.error("Exception while get documents in space: " + e.getMessage(), e);
        }
        return docs;
    }

    public void copySpace(String from, String to, XWikiContext context)
    {

        Subject subj = null;

        try
        {
            subj = PlatformContext.getPlatform().lookupService(ISecurityService.class).getCurrentSubject();
        } catch (Exception e)
        {
        }

        List<String> docsFrom = getDocuments(from, context);
        Iterator<String> it = docsFrom.iterator();

        while (it.hasNext())
        {
            try
            {
                String web = it.next();
                String page = web.substring(web.lastIndexOf(".") + 1);

                web = web.substring(0, web.lastIndexOf("."));
                String projectFrom = SpaceParser.getProject(web);
                if (projectFrom == null) {
                    projectFrom = ISvnProvider.REPO_ROOT_AS_PROJECT_NAME;
                }

                String spaceFrom = SpaceParser.getSpace(web);

                String projectTo = SpaceParser.getProject(to);
                if (projectTo == null) {
                    projectTo = ISvnProvider.REPO_ROOT_AS_PROJECT_NAME;
                }

                String spaceTo = SpaceParser.getSpace(to);

                ILocation pageLocationFrom = svn.getDocumentWikiLocation(projectFrom, spaceFrom, page);
                ILocation pageLocationTo = svn.getDocumentWikiLocation(projectTo, spaceTo, page);

                svn.copyLocations(pageLocationFrom, pageLocationTo, subj);
            } catch (Exception e)
            {
                log.error("Can't get subject while copy space: " + e.getMessage(), e);
            }

        }

    }

    public boolean isContentChange(XWikiDocument doc, XWikiContext context)
    {
        boolean change = false;
        try
        {
            ILocation docLocation = svn.getDocumentWikiLocation(doc).append(DocumentSvnInfo.PAGE_XML);
            ByteBuffer content = svn.readFile(docLocation, null, true);
            if (content == null) {
                // just bail-out instead of logging error
                return false;
            }
            XWikiDocument old = new XWikiDocument();
            old.fromXML(new String(content.array()));

            if (!doc.getContent().equals(old.getContent()))
            {
                change = true;
            }
        } catch (Exception e)
        {
            log.error("Exception while check content change", e);
        }
        return change;
    }

    public boolean isDocumentPage(XWikiDocument doc)
    {
        return RequestParser.isDocumentPage(doc.getSpace());
    }

    public ILocation getFileLocation(XWikiDocument doc, XWikiContext context) throws XWikiException {

        if (RequestParser.isDocumentPage(doc.getSpace())) {
            // loading wiki page
            //return convertXWikiDocToILocation(doc, context).append(doc.getName()).append(DocumentSvnInfo.PAGE_XML);
            return svn.getPageWikiLocation(doc);
        } else {
            // loading preferences or views from templates
            return convertXWikiDocToILocation(doc, context).append(doc.getName() + "." + DocumentSvnInfo.XML);
        }
    }

    /**
     * loc: /_wiki/_default/Home/page.xml -> /_wiki/_default/Home/comments.xml 
     * @param path
     * @return /_wiki/_default/Home/comments.xml
     */
    public ILocation getCommentsLocation(ILocation loc) {
        return loc.setComponent(loc.getComponentCount() - 1, DocumentSvnInfo.COMMENTS_XML);
    }

    public ILocation getAttachmentLocation(XWikiAttachment attachment, XWikiContext context) throws XWikiException
    {
        return svn.getDocumentWikiLocation(attachment.getDoc()).append(DocumentSvnInfo.ATTACHMENT_FILE_FOLDER).append(attachment.getFilename());
    }

    public String addCommentsToPage(String from, String to)
    {
        if (from.length() == 0 && to.length() == 0)
        {
            //we do not support comments on page, there are such call but not needed to be fixed
            //log.error("XMLs is empty ?! from: " + from.length() + ", to: " + to.length());
            return "";
        }

        String xmlString = "";

        try
        {
            Document fromXml = XmlParser.getXmlFromString(from);
            Document toXml = XmlParser.getXmlFromString(to);

            NodeList nl = fromXml.getElementsByTagName("object");

            if (nl.getLength() > 0)
            {
                for (int i = 0; i <= nl.getLength() - 1; i++)
                {

                    Element elem = (Element) nl.item(i);
                    Node dup = toXml.importNode(elem, true);
                    toXml.getDocumentElement().appendChild(dup);
                }

                xmlString = XmlParser.getStringXmlFromDocument(toXml);
            }
        } catch (Exception e)
        {
            log.error("Exception while joinXml: " + e.getMessage(), e);
        }
        return xmlString;
    }

    public Document getXmlFromXWikDocument(XWikiDocument doc, XWikiContext context) throws XWikiException
    {
        return XmlParser.getXmlFromString(getFullContent(doc, context));
    }

    /*
     * public Document getXmlFromString(String doc) { Document xmlDoc = null;
     * try { DocumentBuilderFactory factory =
     * DocumentBuilderFactory.newInstance(); ByteArrayInputStream xmlStream =
     * new ByteArrayInputStream(doc.getBytes()); DocumentBuilder db =
     * factory.newDocumentBuilder(); xmlDoc = db.parse(xmlStream); }
     * catch(Exception e) { log.error("Exception while get xml from string: " +
     * e.getMessage()); } return xmlDoc; }
     */

    public List getLinks(XWikiDocument doc, XWikiContext context)
    {
        context.remove("links");

        try
        {
            XWikiRenderer renderer = context.getWiki().getRenderingEngine().getRenderer("wiki");
            renderer.render(doc.getContent(), doc, doc, context);
        } catch (Exception e)
        {
            log.error("Exception while render links: " + e.getMessage());
            // If the rendering fails lets forget backlinks without errors
        }

        //List links =

        return (List) context.get("links");
    }

    public String getPageContent(String doc) // TODO to XML !!!
    {
        String xmlString = "";
        try
        {
            Document xmlDoc = XmlParser.getXmlFromString(doc);
            NodeList nl = xmlDoc.getElementsByTagName("object");

            if (nl.getLength() > 0)
            {
                log.debug("Found: " + nl.getLength());
                while (nl.getLength() > 0)
                {
                    Node elem = nl.item(0);
                    elem.getParentNode().removeChild(elem);
                }
            }

            xmlString = XmlParser.getStringXmlFromDocument(xmlDoc);

        } catch (Exception e)
        {
            log.error("Can't get page content: " + e.getMessage(), e);
        }
        return xmlString;
    }

    public String getPageContent(XWikiDocument doc, XWikiContext context) throws XWikiException
    {
        // TODO to XML !!!
        String content = getPageContent(XmlParser.getStringXmlFromDocument(getXmlFromXWikDocument(doc, context)));
        checkContent(content);
        return content;
    }

    private void checkContent(String content) {
        if (content == null) {
            throw new RuntimeException("page.xml content is null.");
        }
        if (content.trim().length() == 0) {
            throw new RuntimeException("page.xml content is empty string.");
        }
    }

    /*
     * public String getStringXmlFromDocument(Document doc) { StreamResult
     * result = new StreamResult(new StringWriter()); try { Transformer
     * transformer = TransformerFactory.newInstance().newTransformer();
     * //transformer.setOutputProperty(OutputKeys.INDENT, "yes"); DOMSource
     * source = new DOMSource(doc); transformer.transform(source, result); }
     * catch(Exception e) { log.error("Exception while get xml from document: " +
     * e.getMessage()); } return result.getWriter().toString(); }
     */
    public boolean isUserXml(String doc)
    {
        boolean done = false;
        try
        {

            log.debug("Testing if user");
            Document xmlDoc = XmlParser.getXmlFromString(doc);
            NodeList nl = xmlDoc.getElementsByTagName("parent");

            if (nl.getLength() > 0)
            {
                if (XmlParser.getNodeString(nl.item(0)).equalsIgnoreCase("XWiki.XWikiUsers"))
                {
                    done = true;
                }
            }
        } catch (Exception e)
        {
            log.error("Exception while check is the document user", e);
        }
        return done;
    }

    public String getPageComments(XWikiDocument doc, XWikiContext context)
    {
        boolean done = false;
        String xmlString = "";
        String xmlComments = "<?xml version='1.0' encoding='utf-8'?><xwikicomments></xwikicomments>";
        try
        {
            Document xmlDoc = getXmlFromXWikDocument(doc, context);
            Document xmlNew = XmlParser.getXmlFromString(xmlComments);

            NodeList nl = xmlDoc.getElementsByTagName("object");

            // log.error("Working on: " + doc.getSpace() + "/" + doc.getName());

            if (nl.getLength() > 0)
            {
                // log.error("Found: " + nl.getLength() + " objects");
                for (int i = 0; i <= nl.getLength() - 1; i++)
                {
                    Element elem = (Element) nl.item(i);
                    NodeList subNl = elem.getElementsByTagName("name");
                    String objName = XmlParser.getNodeString(subNl.item(0));// .getTextContent();
                    // log.error("Obj name: " + objName);
                    if (objName.equalsIgnoreCase("XWiki.XWikiComments"))
                    {
                        Node dup = xmlNew.importNode(elem, true);
                        xmlNew.getDocumentElement().appendChild(dup);
                        // log.error("Yes, it's comment");
                        done = true;
                    }
                }

                if (done) {
                    xmlString = XmlParser.getStringXmlFromDocument(xmlNew);
                }
            }
            else
            {
                log.debug("Page has no comments");
            }
        } catch (Exception e)
        {
            log.error("Can't get page comments: " + e.getMessage(), e);
        }

        return (done == true ? xmlString : "");
    }

    public String getFullContent(XWikiDocument doc, XWikiContext context)
    {
        String tmp = "";
        try
        {
            tmp = doc.toXML(context);
        } catch (Exception e)
        {
            log.error("getFullContent: " + e.getMessage(), e);
        }
        checkContent(tmp);
        return tmp;
    }

    //TODO: REIMPLEMENT USING ISvnProvider.getDocumentWikiLocation!!!
    public ILocation convertXWikiDocToILocation(XWikiDocument doc, XWikiContext context) throws XWikiException
    {
        ILocation rootLocation = null;
        ILocation pageLocation = null;

        try
        {
            String docWeb = doc.getSpace();
            String projectGroup = "", project = "", space = "";
            HashMap qr = new HashMap();

            if (docWeb.equalsIgnoreCase("Sidecar"))
            {
                docWeb = "XWiki";
            }

            String path = RequestParser.getPathInfo(context);

            if (path.indexOf(docWeb) == -1)
            {
                // file needed not from URL
                path = path.substring(0, path.indexOf("/", 1) + 1) + docWeb + "/" + doc.getName();
            }

            qr = RequestParser.parseQuery(path, context);
            projectGroup = (String) qr.get("projectGroup");
            project = (String) qr.get("project");
            space = (String) qr.get("space");

            try
            {
                if (RequestParser.isDocumentPage(docWeb))
                {
                    //strore to location _wiki/_default
                    pageLocation = Location.getLocation(projectGroup).append(project).append(WIKI_PROJECT_ROOT_LOCATION).append(space);
                }
                else
                {
                    // now read from files
                    rootLocation = WIKI_TEMPLITES_ROOT_XML;
                    pageLocation = rootLocation.append(docWeb);
                }
            } catch (Exception e)
            {
                log.error("Exception while testing new path: " + e.getMessage(), e);
            }

        } catch (Exception e)
        {
            log.error("Exception while convert paths: " + e.getMessage(), e);
        }
        if (log.isDebugEnabled()) {
            log.debug("Page path: " + pageLocation);
        }
        return pageLocation;
    }

    public ISvnProvider getSvnProvider()
    {
        return svn;
    }

    public String getSvnRoot()
    {
        return WIKI_ROOT_S;
    }

    public WikiSvnBaseStore(XWiki xwiki)
    {
        try
        {
            // svn = new JavaSvnProvider(xwiki);
            svn = new PolarionSvnProvider();
        } catch (Exception e)
        {
            log.error("Can't init Svn provider: " + e.getMessage());
        }
    }

///

    public ILocation getAttachmentILocation(XWikiAttachment attachment) {
        String mixedSpace = attachment.getDoc().getSpace();
        String page = attachment.getDoc().getName();
        String space = SpaceParser.getSpace(mixedSpace);
        String project = SpaceParser.getProject(mixedSpace);

        if (SpaceParser.isRoot(mixedSpace)) {
            project = ISvnProvider.REPO_ROOT_AS_PROJECT_NAME;
        }
        ILocation attachmentLocation = svn.getDocumentWikiLocation(project, space, page).append(DocumentSvnInfo.ATTACHMENT_FILE_FOLDER).append(attachment.getFilename()).setRevision(attachment.getVersion());
        return attachmentLocation;
    }

    public String getUserNamePolarion(String user)
    {
        return svn.getUserNamePolarion(user);
    }

}
