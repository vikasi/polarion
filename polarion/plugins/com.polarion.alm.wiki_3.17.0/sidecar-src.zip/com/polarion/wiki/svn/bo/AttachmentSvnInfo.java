package com.polarion.wiki.svn.bo;

import java.util.Date;

import com.polarion.subterra.base.location.ILocation;

public class AttachmentSvnInfo {

    private ILocation location;
    private String autor = "";
    private Date date;
    private String title = "";
    private String name = "";
    private int size;

    //public static final String ATTACHMENT_FILE_PREFIX = "attachment-";
    //public static final String ATTACHMENT_FILE_FOLDER = "Attachments";

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getRevision() {
        return location.getRevision();
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    /**
     * will replace attachmnet- prefix
     * 
     * @return
     */
    public String getRealName() {
        return getRealName(name);
    }

    public static String getRealName(String attachmentName) {
        if (attachmentName != null)
        {
            return attachmentName;
        }
        return null;
    }

    /**
     * @return the location
     */
    public ILocation getLocation() {
        return location;
    }

    /**
     * @param location
     *            the location to set
     */
    public void setLocation(ILocation location) {
        this.location = location;
    }
}
