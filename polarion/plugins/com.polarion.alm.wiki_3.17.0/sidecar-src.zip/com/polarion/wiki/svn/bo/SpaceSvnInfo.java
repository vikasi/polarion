package com.polarion.wiki.svn.bo;

import java.util.Date;

import com.polarion.subterra.base.location.ILocation;
import com.polarion.subterra.base.location.Location;

/**
 * 
 * Class <code>SpaceSvnInfo</code> 
 * Keeps general information about space 
 *
 */

public class SpaceSvnInfo implements Comparable<SpaceSvnInfo>, Cloneable {

    private ILocation location;
    private String name = "";
    private String author = "";
    private String revision = "";
    private Date updated = new Date();

    public SpaceSvnInfo(ILocation location, String name, String revision, String author, Date created) {
        this.location = location;
        this.name = name;
        this.revision = revision;
        this.author = author;
        updated = created;
    }

    /**
     * @return the location
     */
    public ILocation getLocation() {
        return location;
    }

    /**
     * @param location
     *            the location to set
     */
    public void setLocation(ILocation location) {
        this.location = location;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    public String getAuthor() {
        return author;
    }

    public String getRevision() {
        return revision;
    }

    public Date getUpdated() {
        return updated;
    }

    /**
     * @param name
     *            the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setRevision(String revision) {
        this.revision = revision;
    }

    public void setUpdated(Date created) {
        updated = created;
    }

    /**
     * @param obj
     * 				object to compare with 
     * 	method overrides <code>equals(Object )</code> from <code>Object</code> class
     */
    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj instanceof SpaceSvnInfo) {
            SpaceSvnInfo objSpace = (SpaceSvnInfo) obj;
            if (location.getLocationPath().equals(objSpace.getLocation().getLocationPath())) {
                return true;
            }
        }
        return false;
    }

    /**
     * 
     * implements <code>compareTo()</code> method of <code>Comparable</code> interface
     */
    @Override
    public int compareTo(SpaceSvnInfo obj)
    {
        SpaceSvnInfo objSpace = obj;
        int res = location.getLocationPath().toLowerCase().compareTo(objSpace.getLocation().getLocationPath().toLowerCase());
        return res;
    }

    /**
     * 
     * overrides <code>hashCode()</code> method of <code>Object</code> class
     */
    @Override
    public int hashCode() {
        return location.getLocationPath().hashCode();
    }

    /**
     * 
     */
    @Override
    public Object clone() {
        if (author == null) {
            author = "";
        }
        SpaceSvnInfo space = new SpaceSvnInfo(Location.getCanonicalLocation(location), new String(name), new String(revision), new String(author), updated);
        return space;
    }

    @Override
    public String toString() {
        return "(" + location.getLocationPath() + ": " + revision + ", " + author + ", " + updated + ")";
    }

}
