package com.polarion.wiki.svn;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.swing.text.MutableAttributeSet;
import javax.swing.text.html.HTML;
import javax.swing.text.html.HTMLEditorKit;

import org.polarion.svnwebclient.data.model.DataFile;
import org.polarion.svnwebclient.web.model.data.file.FileCompareResult;
import org.polarion.svnwebclient.web.support.DifferenceModel;

import com.xpn.xwiki.XWikiContext;

import de.regnis.q.sequence.line.diff.QDiffGenerator;
import de.regnis.q.sequence.line.diff.QDiffManager;
import de.regnis.q.sequence.line.diff.QDiffUniGenerator;

public class SvnCompareVersions
{
    /**
     * HTML parsing proceeds by calling a callback for
     * each and every piece of the HTML do*****ent.  This
     * simple callback class handle HTML data
     * and listing them in specail way for compartor.
     */

    public class HTMLParseComments extends HTMLEditorKit.ParserCallback
    {
        private LinkedList<String> comentsInText = new LinkedList<String>();

        @Override
        public void handleComment(char[] data, int pos) {
            String s = "";
            for (char element : data) {
                s += element;
            }

            if (!s.startsWith("function ") || !s.startsWith("executeCommand")) {
                comentsInText.add(s);
            }
        }

        public LinkedList getComments()
        {
            return comentsInText;
        }

    }

    public class HTMLParseTable extends HTMLEditorKit.ParserCallback
    {
        private static final String WIKI_TD_WIDTH = "WIKI_TD_SPEC_WIDTH";
        private String outHTML = "";
        private int indentSize = 0;
        private int indentTable = 0;
        private int indentRow = 0;
        private int countCells = 0;
        private boolean lastTagClosed = false;
        private String lastText = "";
        private boolean firstRow = false;
        private boolean paraClosed = false;
        private String content;
        private HTML.Tag lastTag = HTML.Tag.HTML;
        private HTML.Tag curTag = HTML.Tag.HTML;

        public boolean isHeaderStart = false;

        public HTMLParseTable(String content)
        {
            this.content = content;
        }

        public String getHTML()
        {
            return outHTML;
        }

        private void add(String HTML)
        {
            outHTML += HTML;
            println(HTML);
            lastText = "";
        }

        private void addTag(HTML.Tag t, MutableAttributeSet a)
        {
            if (!(t.toString()).equalsIgnoreCase("html") && !(t.toString()).equalsIgnoreCase("head") && !(t.toString()).equalsIgnoreCase("body")) {
                add("<" + t.toString() + getAttributes(a) + ">");
            }
        }

        private void addTag(HTML.Tag t)
        {
            if (!(t.toString()).equalsIgnoreCase("html") && !(t.toString()).equalsIgnoreCase("head") && !(t.toString()).equalsIgnoreCase("body")) {
                add("</" + t.toString() + ">");
            }
        }

        //move to the next line    
        private void addNewLine()
        {
            add("\r\n");
        }

        private void indentTable()
        {
            indentTable++;
        }

        private void outdentTable()
        {
            indentTable--;
        }

        private void indentRow()
        {
            indentRow++;
        }

        private void outdentRow()
        {
            indentRow--;
        }

        protected void indent() {
            indentSize += 3;
        }

        protected void unIndent() {
            indentSize -= 3;
            if (indentSize < 0) {
                indentSize = 0;
            }
        }

        protected void pIndent() {
            for (int i = 0; i < indentSize; i++) {
                print(" ");
            }
        }

        private boolean isTable(HTML.Tag t)
        {
            return t.toString().equalsIgnoreCase("table");
        }

        private boolean isRow(HTML.Tag t)
        {
            return t.toString().equalsIgnoreCase("tr");
        }

        private boolean isCell(HTML.Tag t)
        {
            return t.toString().equalsIgnoreCase("td") || t.toString().equalsIgnoreCase("th");
        }

        private boolean isHeading(HTML.Tag t)
        {
            String tag = t.toString();
            return tag.equalsIgnoreCase("h2") || tag.toString().equalsIgnoreCase("h3") || tag.equalsIgnoreCase("h4") || tag.equalsIgnoreCase("h5") || tag.equalsIgnoreCase("h6");
        }

        private boolean isPara(HTML.Tag t)
        {
            return t.toString().equalsIgnoreCase("p");
        }

        private boolean isList(HTML.Tag t)
        {
            return t.toString().equalsIgnoreCase("li");
        }

        private boolean topTable()
        {
            return (indentTable == 1);
        }

        private void HandleStartTable(HTML.Tag t, MutableAttributeSet a, int pos)
        {
            indentTable();
            if (topTable()) {
                firstRow = true;//remove first level table tag from the stream at all
            } else {
                addTag(t, a);
            }
        }

        private void HandleEndTable(HTML.Tag t, int pos)
        {
            if (topTable())
            {
                //remove first level table tag from the stream at all
                //setup valid col width
                int witdh = Math.round(100 / countCells);
                String colWidth = new Integer(witdh).toString() + "%";
                outHTML = outHTML.replaceAll(WIKI_TD_WIDTH, colWidth);
            } else {
                addTag(t);
            }
            outdentTable();
        }

        //Put each row in the table
        private void HandleStartRow(HTML.Tag t, MutableAttributeSet a, int pos)
        {
            indentRow();
            if (topTable())
            {
                countCells = 0;
                if (firstRow)
                {
                    addNewLine();
                    firstRow = false;
                }
                //the row must have look and feel like in wiki table
                add("<table cellspacing=\"0\" cellpadding=\"0\" border=\"0\" class=\"wiki-table\">");
            }
            addTag(t, a);
        }

        private void HandleEndRow(HTML.Tag t, int pos)
        {
            addTag(t);
            if (topTable())
            {
                //close table
                add("</table>");
                addNewLine();
            }
            outdentRow();
        }

        private void handleStartPara(HTML.Tag t, MutableAttributeSet a, int pos)
        {
            paraClosed = lastTagClosed;
            String attr = getAttributes(a);
            //type excatly like in radeox_markup_xwiki.properties
            if (attr.indexOf("class=\"paragraph\"") > -1)
            {
                //instead of paragraph for table comapre use \r\n
                //addTag(t, a);
                addNewLine();
            } else {
                addTag(t, a);
            }
        }

        private void handleStartCell(HTML.Tag t, MutableAttributeSet a, int pos)
        {
            if (topTable())
            {
                countCells++;
                a.addAttribute("width", WIKI_TD_WIDTH);
            }
            addTag(t, a);
        }

        private void handleEndPara(HTML.Tag t, int pos)
        {
            if (!lastText.equals("")) {
                addNewLine();
            }
            if (!paraClosed) {
                addTag(t);
            }
        }

        @Override
        public void handleComment(char[] data, int pos) {
            pIndent();
            setCurrentTag(HTML.Tag.COMMENT);
            String s = "";
            for (char element : data) {
                s += element;
            }
            //add("<!--" + s + "-->");
            add(s);
        }

        public String getAttributes(MutableAttributeSet a)
        {
            String res = "";
            if (a.getAttributeCount() > 0)
            {
                java.util.Enumeration e = a.getAttributeNames();
                while (e.hasMoreElements())
                {
                    Object key = e.nextElement();
                    if ("_implied_".equals(key)) {
                        continue;
                    }
                    Object attr = a.getAttribute(key);
                    res += " " + key.toString() + "=\"" + attr.toString() + "\"";
                }
            }
            return res;
        }

        private void setCurrentTag(HTML.Tag t)
        {
            lastTag = curTag;
            curTag = t;
        }

        @Override
        public void handleStartTag(HTML.Tag t, MutableAttributeSet a, int pos)
        {
            pIndent();
            setCurrentTag(t);
            validateTag(pos);

            if (isTable(t))
            {
                HandleStartTable(t, a, pos);
            }
            else if (isRow(t))
            {
                HandleStartRow(t, a, pos);
            }
            else if (isPara(t))
            {
                handleStartPara(t, a, pos);
            }
            else if (isCell(t))
            {
                handleStartCell(t, a, pos);
            }
            else if (isList(t))
            {
                addNewLine();
                addTag(t, a);
            }
            else if (isHeading(t))
            {
                //if it was a text or someting between paragraps
                if (!isPara(lastTag)) {
                    addNewLine();
                }
                addTag(t, a);
            } else {
                addTag(t, a);
            }
            indent();
        }

        @Override
        public void handleEndTag(HTML.Tag t, int pos) {
            unIndent();
            pIndent();
            setCurrentTag(t);
            if (isTable(t))
            {
                HandleEndTable(t, pos);
            }
            else if (isRow(t))
            {
                HandleEndRow(t, pos);
            }
            else if (isPara(t))
            {
                handleEndPara(t, pos);
            } else {
                addTag(t);
            }
        }

        @Override
        public void handleText(char[] data, int pos) {
            pIndent();
            String text = "";

            setCurrentTag(HTML.Tag.CODE);

            for (char element : data) {
                text += element;
            }
            int iPos = text.indexOf(">");
            if (iPos > -1 && lastTagClosed) {
                //not add > second time because of />
                text = text.substring(iPos + 1, text.length());
            }
            lastText = text;
            add(text);
            lastTagClosed = false;
        }

        @Override
        public void handleEndOfLineString(String str)
        {
            println("---------------------------------------------");
        }

        private String extractTag(int pos)
        {
            String tag = "";
            try
            {
                int lastIndex = content.indexOf(">", pos);
                if (lastIndex > -1)
                {
                    tag = content.substring(pos, lastIndex + 1);
                }
            } catch (Exception e)
            {
                println("Buffer read error at: " + pos);
            }
            return tag;
        }

        private boolean isTagClosed(String tag)
        {
            boolean closed = false;
            for (int i = tag.length() - 1; i >= 0; i--)
            {
                char c = tag.charAt(i);
                if (c == '/')
                {
                    closed = true;
                    break;
                }
                if ((c == '\"') || (c == '\'')) {
                    break;
                }
            }
            //store status
            lastTagClosed = closed;
            return closed;
        }

        private void validateTag(int pos)
        {
            String tag = extractTag(pos);
            isTagClosed(tag);
        }

        @Override
        public void handleSimpleTag(HTML.Tag t, MutableAttributeSet a, int pos)
        {
            pIndent();
            validateTag(pos);
            addTag(t, a);
        }

        private void println(String text) {
            //System.out.println(text);
        }

        private void print(String text) {
            //System.out.print(text);
        }

        @Override
        public void handleError(String errorMsg, int pos)
        {
            println("Parsing error: " + errorMsg + " at " + pos);
        }
    }

    private com.xpn.xwiki.XWiki xwiki = null;
    private List leftList = null;
    private List rightList = null;

    public SvnCompareVersions(com.xpn.xwiki.XWiki xwiki)
    {
        this.xwiki = xwiki;
    }

    public boolean diffContent(String startContent, String endContent) {
        return diffContent(startContent, endContent, "html");
    }

    public boolean diffContent(String startContent, String endContent, String type)
    {
        try
        {
            String sContent = "";
            String eContent = "";
            sContent = startContent;
            eContent = endContent;

/*
    		if ("html".equals(type)){
    			sContent = prepareHTMLContent(startContent).trim();
    			eContent = prepareHTMLContent(endContent).trim();
    			if (!sContent.endsWith("\r\n"))
    				sContent = sContent+"\r\n";
    			if (!eContent.endsWith("\r\n"))
    				eContent = eContent+"\r\n";
    		}
  */

            if ("html".equals(type)) {

                sContent = sContent.replaceAll("<div class=\"code\"><pre>", "<div class=\"codeCompare\"></div>");
                eContent = eContent.replaceAll("<div class=\"code\"><pre>", "<div class=\"codeCompare\"></div>");
                sContent = sContent.replaceAll("</pre></div>", "<div class=\"codeCompare\"></div>");
                eContent = eContent.replaceAll("</pre></div>", "<div class=\"codeCompare\"></div>");
            }

            if (!sContent.endsWith("\r\n")) {
                sContent = sContent + "\r\n";
            }
            if (!eContent.endsWith("\r\n")) {
                eContent = eContent + "\r\n";
            }

            eContent = eContent.replaceAll("<p class=\"paragraph\"></p>", "\r\n");
            sContent = sContent.replaceAll("<p class=\"paragraph\"></p>", "\r\n");

            eContent = eContent.replaceAll("\r\n", "\n");
            sContent = sContent.replaceAll("\r\n", "\n");

            byte[] startContentByte = sContent.getBytes(xwiki.getEncoding());
            byte[] endContentByte = eContent.getBytes(xwiki.getEncoding());

            DataFile startRevisionData = new DataFile();
            DataFile endRevisionData = new DataFile();

            startRevisionData.setContent(startContentByte);
            startRevisionData.setBinary(false);

            endRevisionData.setContent(endContentByte);
            endRevisionData.setBinary(false);

            InputStream is1 = new ByteArrayInputStream(startContentByte);
            InputStream is2 = new ByteArrayInputStream(endContentByte);

            ByteArrayOutputStream bos = new ByteArrayOutputStream();

            QDiffUniGenerator.setup();
            QDiffGenerator generator = QDiffManager.getDiffGenerator(QDiffUniGenerator.TYPE, null);
            Writer writer = new OutputStreamWriter(bos, xwiki.getEncoding());
            QDiffManager.generateTextDiff(is1, is2, xwiki.getEncoding(), writer, generator);
            writer.flush();
            writer.close();

            //ISVNDiffGenerator diffGenerator = new DefaultSVNDiffGenerator();

            String difference = bos.toString(xwiki.getEncoding());
            DifferenceModel model = new DifferenceModel(difference);

            String startRevisionContent = new String(startRevisionData.getContent(), "UTF-8");
            String endRevisionContent = new String(endRevisionData.getContent(), "UTF-8");

            leftList = model.getLeftLines(startRevisionContent);
            rightList = model.getRightLines(endRevisionContent);

        } catch (Exception e)
        {
            return false;
        }
        return true;
    }

    public List getLeftDiff()
    {
        return leftList;
    }

    public List getRightDiff()
    {
        return rightList;
    }

    public List getCompareLeftResult()
    {
        List res = null;
        if (leftList != null)
        {
            FileCompareResult left = new FileCompareResult(leftList, null);
            res = left.getLines();
        }
        return res;
    }

    public List getCompareRightResult()
    {
        List res = null;
        if (rightList != null)
        {
            FileCompareResult right = new FileCompareResult(rightList, null);
            res = right.getLines();
        }
        return res;
    }

    public List<List<FileCompareResult.Line>> getCompareTable(XWikiContext context)
    {
        List<List<FileCompareResult.Line>> full = new ArrayList<List<FileCompareResult.Line>>();
        try
        {
            FileCompareResult left = new FileCompareResult(leftList, null);
            List resLeft = left.getLines();

            FileCompareResult right = new FileCompareResult(rightList, null);
            List resRight = right.getLines();

            if (resRight.size() == resLeft.size())
            {
                for (int i = 0; i < resRight.size(); i++)
                {
                    //Map line = new HashMap(2);
                    FileCompareResult.Line lineL = (FileCompareResult.Line) resLeft.get(i);
                    FileCompareResult.Line lineR = (FileCompareResult.Line) resRight.get(i);

                    List<FileCompareResult.Line> temp = new ArrayList<FileCompareResult.Line>();
                    temp.add(lineL);
                    temp.add(lineR);

                    full.add(temp);
                }
            }
        } catch (Exception e)
        {
        }

        return full;
    }
}
