package com.polarion.wiki.svn;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.security.auth.Subject;

import org.suigeneris.jrcs.rcs.Version;

import com.polarion.alm.tracker.model.IModule;
import com.polarion.alm.tracker.model.IWikiPage;
import com.polarion.alm.wiki.WikiPlugin;
import com.polarion.core.util.logging.Logger;
import com.polarion.core.util.xml.DOMHelper;
import com.polarion.platform.context.IContextListener;
import com.polarion.platform.core.PlatformContext;
import com.polarion.platform.persistence.IDataService;
import com.polarion.platform.persistence.model.IPObjectList;
import com.polarion.platform.security.ISecurityService;
import com.polarion.platform.service.repository.IFileChangesListener;
import com.polarion.platform.service.repository.IRevisionMetaData;
import com.polarion.subterra.base.data.identification.ContextId;
import com.polarion.subterra.base.data.identification.IContextId;
import com.polarion.subterra.base.data.identification.ILocalId;
import com.polarion.subterra.base.data.identification.IObjectId;
import com.polarion.subterra.base.data.identification.LocalId;
import com.polarion.subterra.base.data.identification.ObjectId;
import com.polarion.subterra.base.location.ILocation;
import com.polarion.subterra.persistence.document.DocumentStorage;
import com.polarion.wiki.svn.bo.AttachmentSvnInfo;
import com.polarion.wiki.svn.bo.DocumentSvnInfo;
import com.polarion.wiki.svn.bo.SpaceSvnInfo;
import com.polarion.wiki.util.Constants;
import com.polarion.wiki.util.ConvertUtil;
import com.polarion.wiki.util.RequestParser;
import com.polarion.wiki.util.SpaceParser;
import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.doc.XWikiAttachment;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.doc.XWikiDocumentArchive;
import com.xpn.xwiki.doc.XWikiLock;
import com.xpn.xwiki.objects.classes.BaseClass;
import com.xpn.xwiki.store.XWikiAttachmentStoreInterface;
import com.xpn.xwiki.store.XWikiStoreInterface;
import com.xpn.xwiki.store.XWikiVersioningStoreInterface;
import com.xpn.xwiki.util.Util;

public class WikiSvnStore extends WikiSvnBaseStore implements XWikiStoreInterface, XWikiAttachmentStoreInterface, XWikiVersioningStoreInterface
{

    private static Logger log = Logger.getLogger(WikiSvnStore.class);

    private final ISvnProvider svn;
    private final IDataService dataService = PlatformContext.getPlatform().lookupService(IDataService.class);

    public WikiSvnStore(XWiki xwiki, XWikiContext context)
    {
        super(xwiki);
        svn = getSvnProvider();
    }

    public void addFileListener(IFileChangesListener ifl, IContextListener ev2)
    {
        ((PolarionSvnProvider) svn).setIFileChangesListener(ifl, ev2);
    }

    @Override
    public List getTranslationList(XWikiDocument doc, XWikiContext context) throws XWikiException
    {
        return Collections.EMPTY_LIST;
    }

    @Override
    public void cleanUp(XWikiContext context)
    {
        log.debug("cleanUp");
    }

    @Override
    public void createWiki(String wikiName, XWikiContext context) throws XWikiException
    {
        log.debug("createWiki");
    }

    @Override
    @Deprecated
    public void deleteLinks(long docId, XWikiContext context, boolean bTransaction) throws XWikiException
    {
//        log.debug("deleteLinks");
//        try
//        {
//            IndexInterface index = context.getWiki().getIndex(context);
//            if (index != null) {
//                index.removeLink(docId);
//            }
//        } catch (Exception e)
//        {
//            throw new XWikiException(XWikiException.MODULE_XWIKI_STORE, XWikiException.ERROR_XWIKI_STORE_HIBERNATE_DELETING_LINKS,
//                    "Exception while deleting links", e);
//        }
        throw new RuntimeException(WikiPlugin.getDeprecatedMethodMessage("deleteLinks")); //$NON-NLS-1$
    }

    @Override
    public void deleteLock(XWikiLock lock, XWikiContext context, boolean bTransaction) throws XWikiException
    {
        log.debug("deleteLock");
        // TODO LOCK
    }

    @Override
    public void deleteXWikiDoc(XWikiDocument doc, XWikiContext context) throws XWikiException {

        svn.deleteFile(doc);
    }

    public boolean exists(ILocation loc) throws XWikiException
    {
        boolean done = false;
        try
        {
            done = svn.isFileExists(loc);
        } catch (Exception e)
        {
            log.error("Exception while check file: " + loc.toString() + ", " + e.getMessage(), e);
        }
        log.debug("Is Exists: " + loc.toString() + ", is: " + done);
        return done;
    }

    @Override
    public boolean exists(XWikiDocument doc, XWikiContext context) throws XWikiException
    {
        boolean done = false;

        ILocation loc = null;

        try
        {
            loc = getFileLocation(doc, context);
            done = exists(loc);
        } catch (Exception e)
        {
            log.error("Exception while check file: " + (loc != null ? loc.toString() : "") + ", " + e.getMessage(), e);
        }
        return done;
    }

    public boolean existsFile(ILocation loc, XWikiContext context) throws IOException
    {
        InputStream ris = null;
        if (context.getEngineContext() != null)
        {
            try
            {
                ris = context.getEngineContext().getResourceAsStream(loc.getLocationPath());
                if (ris != null) {
                    return true;
                }
            } catch (Exception e)
            {
            }
        }
        File file = new File(loc.getLocationPath());
        return file.exists();
    }

    public List<String> getAllDocuments(XWikiContext context)
    {
        List<String> docs = new ArrayList<String>();
        List spaces;
        String spcName = "";
        try
        {
            spaces = getSpaces(context);
            Iterator it = spaces.iterator();
            while (it.hasNext())
            {
                spcName = (String) it.next();
                docs.addAll(getDocuments(spcName, context));
            }
        } catch (Exception e)
        {
            log.error("Exception while get all documents: " + e.getMessage(), e);
        }
        return docs;
    }

    @Override
    public List getClassList(XWikiContext context) throws XWikiException
    {
        log.warn("getClassList");
        return Collections.EMPTY_LIST;
    }

    @Override
    public List getCustomMappingPropertyList(BaseClass bclass)
    {
        log.warn("getCustomMappingPropertyList");
        return Collections.EMPTY_LIST;
    }

    @Override
    public Version[] getXWikiDocVersions(XWikiDocument doc, XWikiContext context) throws XWikiException
    {
        ILocation docLocation = svn.getPageWikiLocation(doc);
        log.debug("Get versions for: " + docLocation.toString());

        try
        {
            if (!exists(docLocation))
            {
                return new Version[0];
            }

            List revs = svn.getFileVersions(docLocation);

            Version[] versions = new Version[revs.size()];
            IRevisionMetaData rev;
            int idx = 0;

            Iterator it = revs.iterator();
            while (it.hasNext()) {
                rev = (IRevisionMetaData) it.next();
                versions[idx++] = new Version(rev.getName());
            }
            return versions;

        } catch (Exception e)
        {
            log.error("Exception while getXWikiDocVersions, for: " + docLocation.toString() + ", message: " + e.getMessage(), e);
            return new Version[0];
        }
    }

    @Override
    public boolean injectCustomMapping(BaseClass doc1class, XWikiContext xWikiContext) throws XWikiException
    {
        log.error("injectCustomMapping", new Exception());
        return false;
    }

    @Override
    public boolean injectCustomMappings(XWikiDocument doc, XWikiContext context) throws XWikiException
    {
        log.error("injectCustomMappings", new Exception());
        return false;
    }

    @Override
    public void injectCustomMappings(XWikiContext context) throws XWikiException
    {
        log.error("injectCustomMappings", new Exception());
    }

    @Override
    public void injectUpdatedCustomMappings(XWikiContext context) throws XWikiException
    {
        log.error("injectUpdatedCustomMappings", new Exception());
    }

    @Override
    public boolean isCustomMappingValid(BaseClass bclass, String custommapping1, XWikiContext context) throws XWikiException
    {
        log.error("isCustomMappingValid", new Exception());
        return false;
    }

    @Override
    public List loadBacklinks(String fullName, XWikiContext context, boolean bTransaction) throws XWikiException {
        List links = null;
        try {
            String project = SpaceParser.getProject(fullName);
            String space = SpaceParser.getSpace(fullName);
            String pageName;
            int ix = space.indexOf('/');
            if (ix > 0) {
                pageName = space.substring(ix + 1);
                space = space.substring(0, ix);
            } else {
                throw new IllegalArgumentException("No space/page found in fullName: " + fullName); //$NON-NLS-1$
            }
            if (project == null) {
                project = ISvnProvider.REPO_ROOT_AS_PROJECT_NAME;
            }
            links = getBacklinks(project, space, pageName);
        } catch (Exception e) {
            log.error("Exception while get backlinks: " + e.getMessage(), e); //$NON-NLS-1$
        }
        if ((links != null) && log.isDebugEnabled()) {
            log.debug("Found: " + links.size() + " backlinks, for " + fullName); //$NON-NLS-1$//$NON-NLS-2$
        }
        return (links != null) ? links : Collections.EMPTY_LIST;
    }

    private IWikiPage getWikiPage(String projectId, String space, String pageName) {
        String cluster = "default"; //$NON-NLS-1$
        IContextId ctxId = ISvnProvider.REPO_ROOT_AS_PROJECT_NAME.equals(projectId) ? ContextId.getGlobalContextId(cluster) : ContextId.getContextIdFromClusterAndContext(cluster, projectId);
        ILocalId spaceId = LocalId.getLocalId(IModule.KEY_MODULEFOLDER, space);
        ILocalId pageId = LocalId.getLocalIdWithContainer(IWikiPage.PROTO, spaceId, pageName);
        IObjectId p = ObjectId.getCrossContextObjectId(ctxId, pageId);
        return (IWikiPage) dataService.getInstance(p);
    }

    private List getBacklinks(String projectId, String space, String pageName) {
        List<String> result = new ArrayList<String>();
        IWikiPage page = getWikiPage(projectId, space, pageName);
        if (!page.isUnresolvable()) {
            IPObjectList backlinkedPages = page.getBacklinkedPages();
            for (Iterator i = backlinkedPages.iterator(); i.hasNext();) {
                IWikiPage backlinked = (IWikiPage) i.next();
                String bp = backlinked.getProjectId();
                String fullName = (bp != null) ? "project/" + bp + "/" : ""; //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
                fullName += "page/" + backlinked.getSpaceId() + "/" + backlinked.getPageName(); //$NON-NLS-1$//$NON-NLS-2$
                int ix = Collections.binarySearch(result, fullName);
                if (ix < 0) {
                    result.add(-ix - 1, fullName);
                }
            }
        }
        return result;
    }

    @Override
    @Deprecated
    public List loadLinks(long docId, XWikiContext context, boolean bTransaction) throws XWikiException
    {
//        log.debug("loadLinks");
//        List list = new ArrayList();
//        try
//        {
//            IndexInterface index = context.getWiki().getIndex(context);
//            if (index != null) {
//                index.loadLink(docId);
//            }
//        } catch (Exception e) {
//            throw new XWikiException(XWikiException.MODULE_XWIKI_STORE, XWikiException.ERROR_XWIKI_STORE_HIBERNATE_LOADING_LINKS,
//                    "Exception while loading links", e);
//        }
//        return list;
        throw new RuntimeException(WikiPlugin.getDeprecatedMethodMessage("loadLinks")); //$NON-NLS-1$
    }

    @Override
    public XWikiLock loadLock(long docId, XWikiContext context, boolean bTransaction) throws XWikiException
    {
        log.debug("loadLock");
        return null;
    }

    @Override
    public XWikiDocument loadXWikiDoc(XWikiDocument basedoc, XWikiContext<String, java.lang.Object> context) throws XWikiException
    {
        return loadXWikiDoc(basedoc, "", context);
    }

    public String loadXWikiDocTemplate(ILocation loc, XWikiContext context) {
        try {
            if (context.getEngineContext() != null) {
                InputStream is = context.getEngineContext().getResourceAsStream(loc.getLocationPath());
                if (is != null) {
                    return Util.getFileContent(new InputStreamReader(is, DOMHelper.ENCODING_UTF8));
                }
            }
        } catch (IOException e) {
            log.error(e.getLocalizedMessage(), e);
        }
        try {
            return Util.getFileContent(new File(loc.getLocationPath()));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        //return null;
    }

    @Override
    public XWikiDocument loadXWikiDoc(XWikiDocument basedoc, String version, XWikiContext<String, java.lang.Object> context) throws XWikiException {
        log.debug("Trying to load document");
        boolean isPage = RequestParser.isDocumentPage(basedoc.getSpace());

        if (isPage == false && !basedoc.getName().equalsIgnoreCase(Constants.DEFAULT_PAGE)) {
            //is template
            String content = loadXWikiDocTemplate(getFileLocation(basedoc, context), context);
            XWikiDocument xwikiTemplate = new XWikiDocument(basedoc.getSpace(), basedoc.getName());
            xwikiTemplate.setStore(this);
            if (content != null) {
                xwikiTemplate.fromXML(content);
            }
            xwikiTemplate.setNew(false);
            return xwikiTemplate;
        }

        //is page
        String project = SpaceParser.getProject(basedoc.getSpace());
        String space = SpaceParser.getSpace(basedoc.getSpace());

        if (project == null && !isPage)
        {
            space = Constants.DEFAULT_SPACE;
            basedoc.setSpace("page/" + Constants.DEFAULT_SPACE);
        }

        String page = basedoc.getName();
        if (SpaceParser.isRoot(basedoc.getSpace())) {
            project = ISvnProvider.REPO_ROOT_AS_PROJECT_NAME;
        }

        String baseSpace = basedoc.getSpace();
        String baseName = basedoc.getName();

        log.debug("before getting doc location, project: " + project + ", space: " + space + ", page: " + page); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
        //is svn page
        ILocation pageLocation = null;
        try
        {
            pageLocation = svn.getDocumentWikiLocation(project, space, page);
        } catch (Exception re) {
        }

        ILocation pageLocationBefore = pageLocation;
        if (version != null && (version.length() > 0)) {
            pageLocation = pageLocation.setRevision(version);
            pageLocation = DocumentStorage.getCurrentLocation(pageLocation).setRevision(version);
        }

        ILocation locationToCheck = pageLocation;
        if (Constants.USERS.equals(basedoc.getSpaceName()) || Constants.TEST_RUNS.equals(basedoc.getSpaceName())
                || Constants.PLANS.equals(basedoc.getSpaceName())) {
            locationToCheck = locationToCheck.append(DocumentSvnInfo.PAGE_XML);
        }

        if (!svn.exist(locationToCheck)) {
            //page didnt exist
            if (locationToCheck != null) {
                log.info("Page did not exist:" + locationToCheck + " beforeLocation:" + pageLocationBefore);
            }
            XWikiDocument doc = new XWikiDocument(baseSpace, baseName);
            doc.setStore(this);
            doc.setStore(this);
            doc.setNew(true);
            return doc;
        }

        log.debug("Trying to get document location");
        pageLocation = pageLocation.append(DocumentSvnInfo.PAGE_XML);
        XWikiDocument xwikiDocument = new XWikiDocument(basedoc.getSpace(), basedoc.getName());

        byte[] documentData = ConvertUtil.intputStreamToByteArray(svn.readFile(pageLocation));
        if (documentData == null) {
            log.error("Error while loading document content [" + basedoc.getSpace() + " - " + basedoc.getName() + "]");
            XWikiDocument doc = new XWikiDocument(basedoc.getSpace(), basedoc.getName());
            doc.setStore(this);
            doc.setNew(true);
            return doc;
        }

        String docXml;
        try {
            docXml = new String(documentData, "UTF-8");
        } catch (UnsupportedEncodingException e1) {
            docXml = new String(documentData);
        }

//        log.debug("Get doc comments");
//        String commentsXml = getDocumentCommentsXml(xwikiDocument, version);
//        
//        if (commentsXml != null) {
//            docXml = addCommentsToPage(commentsXml, docXml);
//        }

        xwikiDocument.setStore(this);

        //do not remove!
        if (version != null && ("".equals(version) == false)) {
            xwikiDocument.setVersion(version);
            context.put("revision", version);
        }

        DocumentSvnInfo info = null;
        try
        {
            xwikiDocument.fromXML(docXml);
            xwikiDocument.setNew(false);
            //load author/updated from SVN version it more correct then in XML file because just after import this property is not updated
            info = getDocumentSvnInfo(project, space, page, version);
        } catch (Throwable e)
        {
            log.error("Doc corrupted", e);
            xwikiDocument.setDocCorrupted(true);
            xwikiDocument.setNew(true);
        }
        if (info != null)
        {
            xwikiDocument.setAuthor(info.getAutor());
            xwikiDocument.setDate(info.getDate());
            xwikiDocument.setRevision(info.getRevision());
        }
        xwikiDocument.setAttachmentList(getDocumentAttachments(xwikiDocument, version));

        xwikiDocument.setContentDirty(false);
        xwikiDocument.setMetaDataDirty(false);
        return xwikiDocument;
    }

    @Override
    public boolean canRead(XWikiDocument doc) throws XWikiException {
        if (RequestParser.isDocumentPage(doc.getSpace()) == false) {
            return true;
        }

        String project = SpaceParser.getProject(doc.getSpace());
        String space = SpaceParser.getSpace(doc.getSpace());
        String page = doc.getName();
        if (SpaceParser.isRoot(doc.getSpace())) {
            project = ISvnProvider.REPO_ROOT_AS_PROJECT_NAME;
        }
        ILocation pageLocation = null;
        try
        {
            pageLocation = svn.getDocumentWikiLocation(project, space, page);
        } catch (Exception e)
        {
            throw new XWikiException(XWikiException.MODULE_XWIKI_ACCESS,
                    XWikiException.ERROR_XWIKI_APP_PROJECT_DOES_NOT_EXIST,
                    "Access to document {0} has been denied to user {1}",
                    e);
        }

        return svn.canRead(pageLocation);
    }

    /**
     * @return list of XWikiDocument without content loaded from DocumentSvnInfo
     */
    @Override
    public List<XWikiDocument> getDocumentHistoryList(String mixedSpace, String page) {
        String project = SpaceParser.getProject(mixedSpace);
        String space = SpaceParser.getSpace(mixedSpace);
        if (SpaceParser.isRoot(mixedSpace)) {
            project = ISvnProvider.REPO_ROOT_AS_PROJECT_NAME;
        }

        List<XWikiDocument> history = new ArrayList<XWikiDocument>();

        ILocation documentLocation = svn.getDocumentWikiLocation(project, space, page);
        boolean justPageXML = false;
        if (Constants.USERS.equals(space)) {
            documentLocation = documentLocation.append("page.xml");
            justPageXML = true;
        }
        List revisions = svn.getFileVersions(documentLocation);

        Iterator itr = revisions.iterator();
        while (itr.hasNext())
        {
            try {
                IRevisionMetaData md = (IRevisionMetaData) itr.next();
                //  DPP-13681 - Select "History" in Home Wiki takes very long
                // do not use 'svn.getDocumentForHistory()' here, it is way too slow and we have all informations already collected
                DocumentSvnInfo info = new DocumentSvnInfo();
                ILocation doc = documentLocation.setRevision(md.getName());
                info.setLocation(doc);
                info.setRevision(doc.getRevision());
                info.setAutor(md.getAuthor());
                info.setDate(md.getDate());
                if (justPageXML) {
                    info.setName(doc.getComponent(doc.getComponentCount() - 2));
                } else {
                    info.setName(doc.getLastComponent());
                }

                if (info != null) {
                    history.add(createXWikiDocument(info));
                }
            } catch (Throwable t) {
                //let it fly (mostly thorws resource doesont exist)
                log.error("Revision does not exist: " + "\n Details: " + t.getMessage(), t);
                return new ArrayList<XWikiDocument>();
            }

        }
        Collections.reverse(history);
        return history;
    }

    @Override
    public DocumentSvnInfo getDocumentSvnInfo(String project, String space, String page, String rev)
    {
        DocumentSvnInfo info = null;
        try {
            if (project.equals("")) {
                project = ISvnProvider.REPO_ROOT_AS_PROJECT_NAME;
            }
            ILocation documentLocation = svn.getDocumentWikiLocation(project, space, page);
            if ((rev == null) || rev.equals("")) {
                documentLocation = documentLocation.setRevision(svn.getLocationLastRevision(documentLocation));
            } else {
                documentLocation = documentLocation.setRevision(rev);
            }

            info = svn.getDocument(documentLocation);
        } catch (Exception e) {
            log.error("Unable to get SVN info for revision: " + rev + "for page: " + project + "/" + space + "/" + page + "\n Details: " + e.getMessage(), e);
        }
        return info;
    }

    public List<XWikiAttachment> getDocumentAttachments(XWikiDocument doc, String rev) {
        String project = SpaceParser.getProject(doc.getSpace());
        String space = SpaceParser.getSpace(doc.getSpace());

        if (SpaceParser.isRoot(doc.getSpace())) {
            project = ISvnProvider.REPO_ROOT_AS_PROJECT_NAME;
        }

        List<XWikiAttachment> attachments = new ArrayList<XWikiAttachment>();

        if (rev != null && ("".equals(rev) == false)) {
            //we need to load attahcment from svn based on revision
            List attachmentsInfo = svn.getAttachmentsInDocument(project, space, doc.getName(), rev);
            for (Iterator iter = attachmentsInfo.iterator(); iter.hasNext();) {
                AttachmentSvnInfo info = (AttachmentSvnInfo) iter.next();
                attachments.add(createXWikiAttachment(info));
            }
            return attachments;
        }

        if ("".equals(rev)) {
            // XXX for module copy - attachments must be indexed and registered
            // check if attachments are registered to the document
            ILocation loc = svn.getDocumentWikiLocation(doc);
            String revision = svn.getLocationLastRevision(loc);
            List attachmentsInfo = svn.getAttachmentsInDocument(project, space, doc.getName(), revision);
            if (attachmentsInfo != null && attachmentsInfo.size() != 0) {
                for (Iterator iter = attachmentsInfo.iterator(); iter.hasNext();) {
                    AttachmentSvnInfo info = (AttachmentSvnInfo) iter.next();
                    loc = loc.append(DocumentSvnInfo.ATTACHMENT_FILE_FOLDER).append(info.getRealName());
                    XWikiAttachment attachment = createXWikiAttachment(info);
                    attachment.setDoc(doc);
                    ILocation location = getAttachmentILocation(attachment);
                    byte[] content = ConvertUtil.intputStreamToByteArray(svn.readFile(location));
                    attachment.setContent(content);
                    attachments.add(attachment);
                }
            }
        }
        return attachments;
    }

    public String getDocumentCommentsXml(XWikiDocument doc, String rev) {
        String project = SpaceParser.getProject(doc.getSpace());
        String space = SpaceParser.getSpace(doc.getSpace());

        if (SpaceParser.isRoot(doc.getSpace())) {
            project = ISvnProvider.REPO_ROOT_AS_PROJECT_NAME;
        }

        ILocation pageLocation = ((PolarionSvnProvider) svn).getDocumentWikiLocation(project, space, doc.getName());
        ILocation commentsLocation = pageLocation.append(DocumentSvnInfo.COMMENTS_XML);

        if (rev != null && ("".equals(rev) == false)) {
            commentsLocation = commentsLocation.setRevision(rev);
        }
        byte[] data = ConvertUtil.intputStreamToByteArray(svn.readFile(commentsLocation));
        if (data == null) {
            return null;
        }

        if (data.length > 0) {
            return new String(data);
        }

        return null;

    }

    @Override
    @Deprecated
    public void saveLinks(XWikiDocument doc, XWikiContext context, boolean bTransaction) throws XWikiException
    {
        // old index was here
    }

    @Override
    public void saveLock(XWikiLock lock, XWikiContext context, boolean bTransaction) throws XWikiException
    {
        log.debug("saveLock");
    }

    public String saveDraft(String content, XWikiContext context, String filename) throws Exception
    {
        File file = new File("/src/main/webapp/drafts/", filename);
        OutputStream os = new FileOutputStream(file);

        os.write(content.getBytes());

        return "";
    }

    @Override
    public void saveXWikiDoc(XWikiDocument doc, XWikiContext context) throws XWikiException
    {
        if (RequestParser.isDocumentPage(doc.getSpace()) == false)
        {
            return; //do we need to save templates?
        }

        try
        {
            try
            {
                saveLinks(doc, context, true);
            } catch (Exception e)
            {
                log.error("Exception while save links: " + e.getMessage(), e);
            }

            doc.setStore(this);

            //ILocation docLocation = svn.getPageWikiLocation(doc);	
            ILocation docLocation = getFileLocation(doc, context);

            log.debug("Save XWikiDocument: " + docLocation.toString());

            Subject subj = null;

            try
            {
                subj = PlatformContext.getPlatform().lookupService(ISecurityService.class).getCurrentSubject();
                log.debug("Subject: " + subj.toString());
            } catch (Exception e)
            {
                log.error("Can't get subject while saving: " + e.getMessage(), e);
            }

            setDocumentCreatorAndLastUpdateBy(doc);

            if (isDocumentPage(doc))
            {

                doc.setDate(new java.util.Date());
                doc.incrementVersion();

                String comments = getPageComments(doc, context);
                String content = getPageContent(doc, context);
                log.debug("Saving pages: " + content.length() + ", coments: " + comments.length());

                String filename = "";
                String realPath = "";
                File file = new File("");
                try
                {
                    filename = doc.getSpace().replace('/', '+') + "+" + doc.getName() + ".xml";
                    realPath = context.getEngineContext().getRealPath("/templates/drafts/" + filename);
                    file = new File(realPath);
                } catch (Exception e)
                {
                    log.error("Engine Context was not initalized" + e.getMessage(), e);
                }

                if (context.getURL().toString().indexOf("autosave=1") == -1)
                {

                    ILocation commLocation = getCommentsLocation(docLocation);

                    if (comments.length() > 0)
                    {
                        svn.writeFile(commLocation, comments.getBytes("UTF-8"), subj, false);
                    }
                    if (comments.length() == 0 && exists(commLocation))
                    {
                        svn.deleteFile(commLocation);
                    }

                    if (file.exists())
                    {
                        file.delete();
                    }

                    svn.writeFile(docLocation, content.getBytes("UTF-8"), subj, (subj != null) ? false : true);
                    doc.setRevision("-1");
                }
                else
                {
                    XWikiDocument docu = new XWikiDocument(doc.getSpace(), doc.getName());
                    docu.fromXML(content);
                    if (isContentChange(docu, context))
                    {
                        file.createNewFile();
                        OutputStream os = new FileOutputStream(file);

                        os.write(content.getBytes());
                        os.close();
                    }
                    else
                    {
                        RequestParser.deleteAutosavedDoc(docu, context);
                    }

                }

            }
            else
            {
                if (doc.isContentDirty() || doc.isMetaDataDirty())
                {
                    doc.setDate(new java.util.Date());
                    doc.incrementVersion();
                }

                boolean isTempliteXML = false;
                isTempliteXML = existsFile(docLocation, context);

                if (!isTempliteXML)
                {
                    log.debug("Saving xwiki docs");
                    String content = getFullContent(doc, context);

                    log.debug("Saving xwiki docs: " + content.length());
                    svn.writeFile(docLocation, content.getBytes("UTF-8"), subj, true);
                }

            }

            doc.setMostRecent(true);
            doc.setNew(false);
        } catch (Exception e)
        {
            log.error("Exception while saving document", e);
            Object[] args = { doc.getFullName() };
            throw new XWikiException(XWikiException.MODULE_XWIKI_STORE, XWikiException.ERROR_XWIKI_STORE_RCS_SAVING_FILE, "Exception while saving document {0}", e, args);
        }

    }

    //<<--PBO 
    // save only comments or content
    // contOrComm = false for comments
    // contOrComm = true for content
    @Override
    public void saveXWikiDocPart(XWikiDocument doc, XWikiContext context, boolean contOrComm) throws XWikiException
    {
        log.debug("Start to save doc");
        try
        {
            try
            {
                saveLinks(doc, context, true);
            } catch (Exception e)
            {
                log.error("Exception while save links: " + e.getMessage(), e);
            }

            doc.setStore(this);

            //ILocation docLocation = svn.getPageWikiLocation(doc);
            ILocation docLocation = getFileLocation(doc, context);

            Subject subj = null;

            try
            {
                subj = PlatformContext.getPlatform().lookupService(ISecurityService.class).getCurrentSubject();
                log.debug("Subject: " + subj.toString());
            } catch (Exception e)
            {
                log.error("Can't get subject while saving: " + e.getMessage(), e);
            }

            setDocumentCreatorAndLastUpdateBy(doc);

            if (isDocumentPage(doc))
            {

                if (isContentChange(doc, context))
                {
                    //<<-- PBO
                    if (!doc.getComment().equalsIgnoreCase("core.comment.rollback"))
                    {
                        doc.setDate(new java.util.Date());
                    }
                    doc.setComment("");
                    //-->>
                    doc.incrementVersion();
                }

                log.debug("Get page content, comments");
                String comments = getPageComments(doc, context);
                String content = getPageContent(doc, context);
                log.debug("Saving pages: " + content.length() + ", coments : " + comments.length());

                String filename = "";
                String realPath = "";
                File file = new File("");
                try
                {
                    filename = doc.getSpace().replace('/', '+') + "+" + doc.getName() + ".xml";
                    realPath = context.getEngineContext().getRealPath("/templates/drafts/" + filename);
                    file = new File(realPath);
                } catch (Exception e)
                {
                    log.error("Engine Context was not initalized" + e.getMessage(), e);
                }

                if (context.getURL().toString().indexOf("autosave=1") == -1)
                {
                    if (/*contOrComm ||*/(/*!contOrComm &&*/!(doc.getContent().trim()).equalsIgnoreCase("")))
                    {
                        if (file.exists())
                        {
                            file.delete();
                        }
                        log.debug("Before writing to svn");
                        svn.writeFile(docLocation, comments.getBytes("UTF-8"), subj, false);
                    }

                    if (comments.length() > 0)
                    {
                        ILocation loc = getCommentsLocation(docLocation);
                        try
                        {
                            log.debug("Before writing to svn comments");
                            svn.writeFile(loc, comments.getBytes("UTF-8"), subj, false);
                        } catch (Exception e)
                        {
                            log.error("Exception when writing comments to svn" + e.getMessage(), e);
                            throw new XWikiException(XWikiException.MODULE_XWIKI_STORE, XWikiException.ERROR_XWIKI_STORE_RCS_SAVING_COMMENT, "Exception while saving document", e);
                        }
                    }

                    if (comments.length() == 0 && exists(getCommentsLocation(docLocation)))
                    {
                        log.debug("Before deleting comment file");
                        svn.deleteFile(getCommentsLocation(docLocation));
                    }

                }
                else
                {
                    XWikiDocument docu = new XWikiDocument(doc.getSpace(), doc.getName());
                    docu.fromXML(content);
                    if (isContentChange(docu, context))
                    {
                        file.createNewFile();
                        OutputStream os = new FileOutputStream(file);

                        os.write(content.getBytes());
                        os.close();
                    }
                    else
                    {
                        RequestParser.deleteAutosavedDoc(docu, context);
                    }

                }

            }
            else
            {
                if (doc.isContentDirty() || doc.isMetaDataDirty())
                {
                    doc.setDate(new java.util.Date());
                    doc.incrementVersion();
                }

                boolean isTempliteXML = false;
                isTempliteXML = existsFile(docLocation, context);

                if (!isTempliteXML)
                {
                    log.debug("Saving xwiki docs");
                    String content = getFullContent(doc, context);
                    log.debug("Saving xwiki docs: " + content.length());
                    svn.writeFile(docLocation, content.getBytes("UTF-8"), subj, true);
                }
            }

            doc.setMostRecent(true);
            doc.setNew(false);
        } catch (Exception e)
        {
            log.error("Exception while saving document", e);
            if (e instanceof XWikiException)
            {
                XWikiException xe = (XWikiException) e;
                if (xe.getCode() == XWikiException.ERROR_XWIKI_STORE_RCS_SAVING_COMMENT) {
                    throw new XWikiException(XWikiException.MODULE_XWIKI_STORE, XWikiException.ERROR_XWIKI_STORE_RCS_SAVING_COMMENT, "Exception while saving comment", e);
                }
            }
            Object[] args = { doc.getFullName() };
            throw new XWikiException(XWikiException.MODULE_XWIKI_STORE, XWikiException.ERROR_XWIKI_STORE_RCS_SAVING_FILE, "Exception while saving document {0}", e, args);
        }
    }

    private void setDocumentCreatorAndLastUpdateBy(XWikiDocument document) {
        //set document autor and lastUpdatedBy
        ISecurityService security = PlatformContext.getPlatform().lookupService(ISecurityService.class);
        String currentUserId = security.getCurrentUser();
        if (document.isNew()) {
            document.setCreator(currentUserId);//polarion autor
        }
        document.setAuthor(currentUserId);//polarion lastUpdatedBy
    }

    @Override
    public void saveXWikiDoc(XWikiDocument doc, XWikiContext context, boolean bTransaction) throws XWikiException
    {
        saveXWikiDoc(doc, context);
    }

    @Override
    public List search(String sql, int nb, int start, XWikiContext context) throws XWikiException
    {
        log.error("searchDocumentsNames: " + sql, new Exception());
        return Collections.EMPTY_LIST;
    }

    @Override
    public List search(String sql, int nb, int start, Object[][] whereParams, XWikiContext context) throws XWikiException
    {
        log.error("searchDocumentsNames: " + sql, new Exception());
        return Collections.EMPTY_LIST;
    }

    @Override
    public List searchDocuments(String wheresql, boolean distinctbyname, XWikiContext context) throws XWikiException
    {
        log.error("searchDocuments: " + wheresql, new Exception());
        return Collections.EMPTY_LIST;
    }

    @Override
    public List searchDocuments(String wheresql, boolean distinctbyname, boolean customMapping, XWikiContext context) throws XWikiException
    {
        log.error("searchDocuments: " + wheresql, new Exception());
        return Collections.EMPTY_LIST;
    }

    @Override
    public List searchDocuments(String wheresql, boolean distinctbyname, int nb, int start, XWikiContext context) throws XWikiException
    {
        log.error("searchDocuments: " + wheresql, new Exception());
        return Collections.EMPTY_LIST;
    }

    @Override
    public List searchDocuments(String wheresql, boolean distinctbyname, boolean customMapping, int nb, int start, XWikiContext context) throws XWikiException
    {
        log.error("searchDocuments: " + wheresql, new Exception());
        return Collections.EMPTY_LIST;
    }

    @Override
    public List searchDocuments(String wheresql, XWikiContext context) throws XWikiException
    {
        log.error("searchDocuments: " + wheresql, new Exception());
        return Collections.EMPTY_LIST;
    }

    @Override
    @Deprecated
    public List<String> searchDocumentsModified(String days, int count, String wheresql, boolean isInSpace, XWikiContext context) throws XWikiException
    {
//        Date dt = new Date();
//        String currentDate = ConvertUtil.dateToStringLucene(dt);
//        String space = "";
//        if (isInSpace) {
//            space = SpaceParser.getSpace(wheresql);
//        }
//
//        String whereSpace = SpaceParser.getSpace(wheresql);
//        wheresql = SpaceParser.getProject(wheresql);
//
//        if (wheresql == null || wheresql.equals("")) {
//            wheresql = ISvnProvider.REPO_ROOT_AS_PROJECT_NAME;
//        }
//        String lastDate = ConvertUtil.dateToStringLucene(new Date(dt.getTime() - (Integer.parseInt(days) * 24 * 60 * 60 * 1000)));
//        ;
//        //wheresql = "where project:\""+wheresql+"\"";
//
//        wheresql = "where (date:[" + lastDate + " TO " + currentDate + "]) AND (project:\"" + wheresql + "\")";
//        if (!space.equals("") && !space.equals(Constants.MODULES)) {
//            wheresql = wheresql + " AND (space: \"" + space + "\")";
//        } else if (whereSpace.equals(Constants.MODULES)) {
//            wheresql = wheresql + " AND (space: \"" + Constants.MODULES + "\")";
//        } else {
//            wheresql = wheresql + " AND NOT (space: \"" + Constants.MODULES + "\")";
//        }
//
//        List list = Collections.EMPTY_LIST;
//        List<String> resultList = new ArrayList<String>();
//        IndexInterface index = context.getWiki().getIndex(context);
//        if (index != null)
//        {
//            list = index.searchDocumentModified(wheresql);
//            for (Iterator iter = list.iterator(); iter.hasNext();)
//            {
//                XWikiDocument doc = (XWikiDocument) iter.next();
//                resultList.add(doc.getSpace() + "/" + doc.getName());
//            }
//
//        }
//
//        List<String> resultListSort = new ArrayList<String>();
//
//        for (int i = resultList.size() - 1; i >= 0; i--)
//        {
//            resultListSort.add(resultList.get(i));
//        }
//        return resultListSort;
        throw new RuntimeException(WikiPlugin.getDeprecatedMethodMessage("searchDocumentsModified")); //$NON-NLS-1$
    }

    @Override
    public List searchDocuments(String wheresql, int nb, int start, XWikiContext context) throws XWikiException
    {
        log.error("searchDocuments: " + wheresql, new Exception());
        return Collections.EMPTY_LIST;
    }

    @Override
    public List searchDocuments(String wheresql, boolean distinctbyname, boolean customMapping, boolean checkRight, int nb, int start, XWikiContext context) throws XWikiException
    {
        log.error("searchDocuments: " + wheresql, new Exception());
        return Collections.EMPTY_LIST;
    }

    @Override
    @Deprecated
    public List<String> searchDocumentsNames(String wheresql, String projectweb, int nb, int start, XWikiContext context) throws XWikiException
    {
//        List list = Collections.EMPTY_LIST;
//        List<String> resultList = new ArrayList<String>();
//        int fpos;
//        String cntSrch = "like '%";
//        if ((fpos = wheresql.indexOf(cntSrch)) >= 0)
//        {
//            fpos += cntSrch.length();
//            int lpos = wheresql.indexOf("%'", fpos);
//            String query = wheresql.substring(fpos, lpos);
//
//            String luceneQuery = "(" + query + ")";
//            if (!projectweb.equalsIgnoreCase(""))
//            {
//                luceneQuery += " AND " + "space:\"" + projectweb.substring(projectweb.indexOf("/") + 1) + "\"";
//                if (projectweb.indexOf("/") > 0) {
//                    luceneQuery += " AND project:\"" + projectweb.substring(0, projectweb.indexOf("/")) + "\"";
//                }
//            }
//            IndexInterface index = context.getWiki().getIndex(context);
//            if (index != null)
//            {
//                list = index.searchDocument(luceneQuery);
//                for (Iterator iter = list.iterator(); iter.hasNext();)
//                {
//                    XWikiDocument doc = (XWikiDocument) iter.next();
//                    resultList.add(doc.getSpace() + "." + doc.getName());
//                }
//
//            }
//        }
//        else
//        {
//            log.error("!!!UNKNOWN SEARCH QUERY!!!", new Exception());
//        }
//        return resultList;
        throw new RuntimeException(WikiPlugin.getDeprecatedMethodMessage("searchDocumentsNames")); //$NON-NLS-1$
    }

    @Override
    public List searchDocumentsNames(String wheresql, XWikiContext context) throws XWikiException
    {
        //log.error("searchDocumentsNames Context: " + wheresql); // + "\n" +
        String usersQuery = ", BaseObject as obj where obj.name=doc.fullName and obj.className='XWiki.XWikiUsers'";

        if (wheresql.equalsIgnoreCase(usersQuery))
        {
            log.debug("Get users list");
            return getUsersList();
        }
        return Collections.EMPTY_LIST;
    }

    @Override
    @Deprecated
    public List<String> searchCommentsNames(String wheresql, String projectweb, int nb, int start, XWikiContext context) throws XWikiException
    {
//        List list = Collections.EMPTY_LIST;
//        List<String> resultList = new ArrayList<String>();
//        int fpos;
//        String cntSrch = "like '%";
//
//        if ((fpos = wheresql.indexOf(cntSrch)) >= 0)
//        {
//            fpos += cntSrch.length();
//            int lpos = wheresql.indexOf("%'", fpos);
//            String query = wheresql.substring(fpos, lpos);
//
//            String luceneQuery = "(" + query + ")";
//            if (!projectweb.equalsIgnoreCase(""))
//            {
//                luceneQuery += " AND " + "space:\"" + projectweb.substring(projectweb.indexOf("/") + 1) + "\"";
//                if (projectweb.indexOf("/") > 0) {
//                    luceneQuery += " AND project:\"" + projectweb.substring(0, projectweb.indexOf("/")) + "\"";
//                }
//            }
//
//            IndexInterface index = context.getWiki().getIndex(context);
//
//            if (index != null)
//            {
//                list = index.searchComments(luceneQuery);
//                for (Iterator iter = list.iterator(); iter.hasNext();)
//                {
//                    Document doc = (Document) iter.next();
//                    String project = doc.get(Index.FIELD_PROJECT);
//                    if (ISvnProvider.REPO_ROOT_AS_PROJECT_NAME.equals(project)) {
//                        project = "";
//                    }
//                    resultList.add(project + "/" + doc.get(Index.FIELD_SPACE) + "." + doc.get(Index.FIELD_PAGE));
//                }
//            }
//        }
//        else
//        {
//            log.error("!!!UNKNOWN SEARCH QUERY!!!", new Exception());
//        }
//        return resultList;
        throw new RuntimeException(WikiPlugin.getDeprecatedMethodMessage("searchCommentsNames")); //$NON-NLS-1$
    }

    @Override
    @Deprecated
    public List<String> searchAttachmentsNames(String wheresql, String projectweb, int nb, int start, XWikiContext context) throws XWikiException
    {
//        List list = Collections.EMPTY_LIST;
//        List<String> resultList = new ArrayList<String>();
//        int fpos;
//        String cntSrch = "like '%";
//
//        if ((fpos = wheresql.indexOf(cntSrch)) >= 0)
//        {
//            fpos += cntSrch.length();
//            int lpos = wheresql.indexOf("%'", fpos);
//            String query = wheresql.substring(fpos, lpos);
//
//            String luceneQuery = "(" + query + ")";
//            if (!projectweb.equalsIgnoreCase(""))
//            {
//                luceneQuery += " AND " + "space:\"" + projectweb.substring(projectweb.indexOf("/") + 1) + "\"";
//                if (projectweb.indexOf("/") > 0) {
//                    luceneQuery += " AND project:\"" + projectweb.substring(0, projectweb.indexOf("/")) + "\"";
//                }
//            }
//
//            IndexInterface index = context.getWiki().getIndex(context);
//            if (index != null)
//            {
//                //list = index.searchAttachmentsDocument(query, projectweb);
//                list = index.searchAttachment(luceneQuery);
//                for (Iterator iter = list.iterator(); iter.hasNext();)
//                {
//                    Document doc = (Document) iter.next();
//                    String project = doc.get(Index.FIELD_PROJECT);
//                    if (ISvnProvider.REPO_ROOT_AS_PROJECT_NAME.equals(project)) {
//                        project = "";
//                    }
//                    resultList.add(project + "/" + doc.get(Index.FIELD_SPACE) + "." + doc.get(Index.FIELD_PAGE) + "/" + doc.get(Index.FIELD_ATTACHMENT_FILENAME));
//                }
//            }
//        }
//        else
//        {
//            log.error("!!!UNKNOWN SEARCH QUERY!!!", new Exception());
//        }
//        return resultList;
        throw new RuntimeException(WikiPlugin.getDeprecatedMethodMessage("searchAttachmentsNames")); //$NON-NLS-1$
    }

    @Override
    public List<String> searchDocumentsNames(String wheresql, int nb, int start, XWikiContext context) throws XWikiException
    {
        List<String> list = Collections.emptyList();
        List<String> resultList = new ArrayList<String>();
        int fpos;
        String cntSrch = "doc.web like '%";
        String cntSrch2 = "doc.name like '%";

        String spaceIdx = "where doc.web='";

        if ((fpos = wheresql.indexOf(cntSrch)) >= 0)
        {
            fpos += cntSrch.length();
            int lpos = wheresql.indexOf("%'", fpos);
            String query = wheresql.substring(fpos, lpos);

            if (query.length() > 0) {
                list = getDocuments(query, context);
            }

            if ((fpos = wheresql.indexOf(cntSrch2)) >= 0)
            {
                int pos1 = wheresql.indexOf(cntSrch2);
                pos1 += cntSrch2.length();
                int pos2 = wheresql.indexOf("%'", pos1);

                String docName = wheresql.substring(pos1, pos2);
                for (int i = 0; i < list.size(); i++)
                {
                    if (list.get(i).indexOf("." + docName) >= 0)
                    {
                        String find = list.get(i);
                        resultList.add(find);
                    }
                }

                return resultList;
            }

        }
        else if ((fpos = wheresql.indexOf(spaceIdx)) == 0)
        {
            fpos += spaceIdx.length();
            int lpos = wheresql.indexOf("' order", fpos);
            //log.error("First pos: " + fpos);
            //log.error("Last pos: " + lpos);
            String query = wheresql.substring(fpos, lpos);

            //log.error("Query: " + query);
            if (query.length() > 0) {
                list = getDocuments(query, context);
            }
        }
        else
        {
            log.error("!!!UNKNOWN SEARCH QUERY!!!", new Exception());
        }
        return list;
    }

    @Override
    public List searchDocumentsNames(String wheresql, int nb, int start, String selectColumns, XWikiContext context) throws XWikiException
    {
        log.error("searchDocumentsNames columns: " + wheresql, new Exception());
        return Collections.EMPTY_LIST;
    }

    //
    // ATTACHMENT STORE
    //

    @Override
    public void deleteAllAtatachments(XWikiDocument doc, XWikiContext context)
    {
        try
        {
            svn.removeAttachments(doc.getSpace(), doc.getName());
        } catch (Exception e) {
        }
    }

    @Override
    public void deleteXWikiAttachment(XWikiAttachment attachment, XWikiContext context, boolean bTransaction) throws XWikiException
    {
        deleteXWikiAttachment(attachment, true, context, bTransaction);

    }

    @Override
    public void deleteXWikiAttachment(XWikiAttachment attachment, boolean parentUpdate, XWikiContext context, boolean bTransaction) throws XWikiException
    {
        try
        {
            ILocation attLocation = getAttachmentLocation(attachment, context);

            if (exists(attLocation))
            {
                svn.deleteFile(attLocation);
            }

            if (bTransaction) {
                saveXWikiDocPart(attachment.getDoc(), context, true);
            }

            List list = attachment.getDoc().getAttachmentList();
            for (int i = 0; i < list.size(); i++)
            {
                XWikiAttachment attach = (XWikiAttachment) list.get(i);
                if (attachment.getFilename().equals(attach.getFilename()))
                {
                    list.remove(i);
                    break;
                }
            }

        } catch (Exception e)
        {
            log.error("Error while deleting attachment " + e.getMessage(), e);
            Object[] args = { attachment.getFilename(), attachment };
            throw new XWikiException(XWikiException.MODULE_XWIKI_STORE, XWikiException.ERROR_XWIKI_STORE_RCS_SAVING_ATTACHMENT, "Exception while saving attachment {0} from document {1}", e, args);
        }
    }

    @Override
    public void loadAttachmentArchive(XWikiAttachment attachment, XWikiContext context, boolean bTransaction) throws XWikiException
    {
        log.error("loadAttachmentArchive", new Exception());
    }

    @Override
    public void loadAttachmentContent(XWikiAttachment attachment, XWikiContext context, boolean bTransaction) throws XWikiException {
        ILocation location = getAttachmentILocation(attachment);
        log.debug("Load attachment at: " + location.toString());

        byte[] content = ConvertUtil.intputStreamToByteArray(svn.readFile(location));
        attachment.setContent(content);
    }

    @Override
    public void saveAttachmentContent(XWikiAttachment attachment, XWikiContext context, boolean bTransaction) throws XWikiException
    {
        saveAttachmentContent(attachment, true, context, bTransaction, false);
    }

    @Override
    public void saveAttachmentContent(XWikiAttachment attachment, boolean bParentUpdate, XWikiContext context, boolean bTransaction, boolean rollback) throws XWikiException
    {
        ILocation attLocation = getAttachmentLocation(attachment, context);

        log.debug("Save attachment to: " + attLocation.toString());

        try
        {

            Subject subj = null;
            try
            {
                subj = PlatformContext.getPlatform().lookupService(ISecurityService.class).getCurrentSubject();
                log.debug("Subject: " + subj.toString());
            } catch (Exception e)
            {
                log.error("Can't get subject while saving: " + e.getMessage(), e);
            }
            // PBO for update exist attachment (sample: change title)
            //if (!exists(path))
            {
                //svn.createFile(path, subj, true, attachment.getTitle());
                if (attachment.isContentDirty() || attachment.isMetaDataDirty())
                {
                    // attachment.updateContentArchive(context);
                    if (!rollback) {
                        attachment.incrementVersion();
                    }
                    attachment.setDate(new Date());
                }

                svn.saveAttachmentContent(attLocation, attachment.getContent(context), attachment.getTitle());
            }

            if (bParentUpdate)
            {
                log.debug("Update parent");
                context.getWiki().getStore().saveXWikiDocPart(attachment.getDoc(), context, true);
            }

        } catch (Exception e)
        {
            log.error("Error while saving attachment " + e.getMessage(), e);
            Object[] args = { attachment.getFilename(), attachment };
            throw new XWikiException(XWikiException.MODULE_XWIKI_STORE, XWikiException.ERROR_XWIKI_STORE_RCS_SAVING_ATTACHMENT, "Exception while saving attachment {0} from document {1}", e, args);
        }

    }

    @Override
    public void saveAttachmentsContent(java.util.List attachments, XWikiDocument doc, boolean bParentUpdate, XWikiContext context, boolean bTransaction) throws XWikiException
    {
        try
        {
            if (attachments == null) {
                return;
            }

            Iterator it = attachments.iterator();
            while (it.hasNext())
            {
                XWikiAttachment att = (XWikiAttachment) it.next();
                log.debug("Before writing to svn attachment");
                saveAttachmentContent(att, false, context, false, false);
            }

            if (bParentUpdate)
            {
                context.getWiki().getStore().saveXWikiDoc(doc, context, false);
            }

        } catch (Exception e)
        {
            log.error("Error while saving attachment content " + e.getMessage(), e);
            throw new XWikiException(XWikiException.MODULE_XWIKI_STORE, XWikiException.ERROR_XWIKI_STORE_HIBERNATE_SAVING_ATTACHMENT, "Exception while saving attachments", e);
        }
    }

    @Override
    public void loadXWikiDocArchive(XWikiDocumentArchive archivedoc, boolean bTransaction, XWikiContext context) throws XWikiException
    {
        log.error("updateXWikiDocArchive: " + archivedoc.getArchive(), new Exception());
    }

    @Override
    public void saveXWikiDocArchive(XWikiDocumentArchive archivedoc, boolean bTransaction, XWikiContext context) throws XWikiException
    {
        log.error("updateXWikiDocArchive: " + archivedoc.getArchive(), new Exception());
    }

    @Override
    public void updateXWikiDocArchive(XWikiDocument doc, String text, boolean bTransaction, XWikiContext context) throws XWikiException
    {
        log.error("updateXWikiDocArchive: " + doc.getFullName() + ", text: " + text, new Exception());
    }

    @Override
    public void resetRCSArchive(XWikiDocument doc, boolean bTransaction, XWikiContext context) throws XWikiException
    {
        log.error("resetRCSArchive: " + doc.getFullName(), new Exception());
    }

    @Override
    public XWikiDocumentArchive getXWikiDocumentArchive(XWikiDocument doc, XWikiContext context) throws XWikiException
    {
        log.error("getXWikiDocumentArchive: " + doc.getFullName(), new Exception());
        return null;
    }

    private XWikiAttachment createXWikiAttachment(AttachmentSvnInfo attachmentInfo) {
        XWikiAttachment attachment = new XWikiAttachment();
        attachment.setFilename(attachmentInfo.getRealName());
        attachment.setAuthor(attachmentInfo.getAutor());
        attachment.setTitle(attachmentInfo.getTitle());
        attachment.setDate(attachmentInfo.getDate());
        attachment.setVersion(attachmentInfo.getRevision());
        attachment.setFilesize(attachmentInfo.getSize());
        return attachment;
    }

    private XWikiDocument createXWikiDocument(DocumentSvnInfo documentInfo) {
        String mixedSpace = SpaceParser.getMixedSpace(documentInfo.getLocation());
        XWikiDocument document = new XWikiDocument(mixedSpace, documentInfo.getName());
        document.setAuthor(documentInfo.getAutor());
        document.setVersion(documentInfo.getLocation().getRevision());
        document.setDate(documentInfo.getDate());
        document.setNew(false);
        document.setRevision(documentInfo.getRevision());
        return document;
    }

    @Override
    public void deleteXWikiSpace(String space, String page, XWikiContext context) throws XWikiException
    {
        String delSpace = SpaceParser.getSpace(space);
        String delProgect = SpaceParser.getProject(space);

        String delPage = page;
        if (delPage == null) {
            delPage = "";
        }

        if (delProgect == null) {
            delProgect = ISvnProvider.REPO_ROOT_AS_PROJECT_NAME;
        }
        ILocation pageLocation = svn.getDocumentWikiLocation(delProgect, delSpace, delPage);

        svn.deleteFolder(pageLocation);
    }

    // PBO get space info from SVN
    @Override
    public SpaceSvnInfo getSpaceInfo(String mixedSpace)
    {
        ILocation spaceLocation = null;
        try
        {
            String Space = SpaceParser.getSpace(mixedSpace);
            String Progect = SpaceParser.getProject(mixedSpace);
            if (Progect == null) {
                Progect = ISvnProvider.REPO_ROOT_AS_PROJECT_NAME;
            }
            spaceLocation = svn.getDocumentWikiLocation(Progect, Space, "");
            return svn.getSpaceInfo(spaceLocation);
        } catch (Exception e)
        {
            return new SpaceSvnInfo(spaceLocation, "", "", "", new Date());
        }
    }

    // Read file from SVN for PDF
    @Override
    public InputStream getFileContent(String url, String file) throws XWikiException
    {
        ILocation fileLocation = null;

        if ((url.indexOf("/download/") != -1) && (url.indexOf("/page/") != -1))
        {
            String filename = url.substring(url.lastIndexOf("/") + 1);
            String mixedSpace = url.substring(url.lastIndexOf("/download/") + 10, url.lastIndexOf("/"));
            mixedSpace = mixedSpace.substring(0, mixedSpace.lastIndexOf("/")) + "/" + mixedSpace.substring(mixedSpace.lastIndexOf("/") + 1);

            String page = SpaceParser.getPage(mixedSpace);
            mixedSpace = mixedSpace.substring(0, mixedSpace.lastIndexOf("/"));
            String space = SpaceParser.getSpace(mixedSpace);
            String project = SpaceParser.getProject(mixedSpace);

            if (SpaceParser.isRoot(mixedSpace)) {
                project = ISvnProvider.REPO_ROOT_AS_PROJECT_NAME;
            }
            fileLocation = ((PolarionSvnProvider) svn).getDocumentWikiLocation(project, space, page).append(DocumentSvnInfo.ATTACHMENT_FILE_FOLDER).append(filename);
            return ((PolarionSvnProvider) svn).readFileWithUser(fileLocation);
        } else
        {
            url = url.replaceAll("%20", " ");
            return ((PolarionSvnProvider) svn).readFileWithUser(url);
        }
    }

    @Override
    public String convertDocImgUrls(String url) throws Exception
    {
        return ((PolarionSvnProvider) svn).convertDocImgUrls(url);
    }

    @Override
    public void updateXWikiDoc(XWikiDocument doc, List saveList, List deleteList, XWikiContext context, boolean updateDoc) throws XWikiException
    {
        svn.updateDocument(doc, saveList, deleteList, context, this, updateDoc);
    }

    @Override
    public void rollbackXWikiDoc(XWikiDocument doc, XWikiContext context) throws XWikiException
    {
        svn.rollbackDocument(doc, context, this);
    }

    @Override
    public void deleteAttachmentNew(XWikiDocument doc, XWikiAttachment attachment, XWikiContext context) throws XWikiException
    {
        svn.deleteAttachmentNew(doc, attachment, context, this);
    }

    public void saveXWikiDocNonTransaction(XWikiDocument doc, XWikiContext context) throws XWikiException
    {
        if (RequestParser.isDocumentPage(doc.getSpace()) == false)
        {
            return; //do we need to save templates?
        }

        try
        {
            try
            {
                saveLinks(doc, context, true);
            } catch (Exception e)
            {
                log.error("Exception while save links: " + e.getMessage(), e);
            }

            doc.setStore(this);

            //ILocation docLocation = svn.getPageWikiLocation(doc);	
            ILocation docLocation = getFileLocation(doc, context);

            log.debug("Save XWikiDocument: " + docLocation.toString());

            Subject subj = null;

            try
            {
                subj = PlatformContext.getPlatform().lookupService(ISecurityService.class).getCurrentSubject();
                log.debug("Subject: " + subj.toString());
            } catch (Exception e)
            {
                log.error("Can't get subject while saving: " + e.getMessage(), e);
            }

            setDocumentCreatorAndLastUpdateBy(doc);

            if (isDocumentPage(doc))
            {

                doc.setDate(new java.util.Date());
                doc.incrementVersion();

                String comments = "";//getPageComments(doc, context);
                String content = getPageContent(doc, context);
                log.debug("Saving pages: " + content.length() + ", coments: " + comments.length());

                String filename = "";
                String realPath = "";
                File file = new File("");
                try
                {
                    filename = doc.getSpace().replace('/', '+') + "+" + doc.getName() + ".xml";
                    realPath = context.getEngineContext().getRealPath("/templates/drafts/" + filename);
                    file = new File(realPath);
                } catch (Exception e)
                {
                    log.error("Engine Context was not initalized" + e.getMessage(), e);
                }

                if (context.getURL().toString().indexOf("autosave=1") == -1)
                {

                    ILocation commLocation = getCommentsLocation(docLocation);

                    if (comments.length() > 0)
                    {
                        svn.writeFileNonTransaction(commLocation, comments.getBytes("UTF-8"), subj, false);
                    }
                    if (comments.length() == 0 && exists(commLocation))
                    {
                        svn.deleteFileNonTransaction(commLocation);
                    }

                    if (file.exists())
                    {
                        file.delete();
                    }

                    svn.writeFileNonTransaction(docLocation, content.getBytes("UTF-8"), subj, (subj != null) ? false : true);
                    doc.setRevision("-1");
                }
                else
                {
                    XWikiDocument docu = new XWikiDocument(doc.getSpace(), doc.getName());
                    docu.fromXML(content);
                    if (isContentChange(docu, context))
                    {
                        file.createNewFile();
                        OutputStream os = new FileOutputStream(file);

                        os.write(content.getBytes());
                        os.close();
                    }
                    else
                    {
                        RequestParser.deleteAutosavedDoc(docu, context);
                    }

                }

            }
            else
            {
                if (doc.isContentDirty() || doc.isMetaDataDirty())
                {
                    doc.setDate(new java.util.Date());
                    doc.incrementVersion();
                }

                boolean isTempliteXML = false;
                isTempliteXML = existsFile(docLocation, context);

                if (!isTempliteXML)
                {
                    log.debug("Saving xwiki docs");
                    String content = getFullContent(doc, context);

                    log.debug("Saving xwiki docs: " + content.length());
                    svn.writeFileNonTransaction(docLocation, content.getBytes("UTF-8"), subj, true);
                }

            }

            doc.setMostRecent(true);
            doc.setNew(false);
        } catch (Exception e)
        {
            log.error("Exception while saving document", e);
            Object[] args = { doc.getFullName() };
            throw new XWikiException(XWikiException.MODULE_XWIKI_STORE, XWikiException.ERROR_XWIKI_STORE_RCS_SAVING_FILE, "Exception while saving document {0}", e, args);
        }

    }

    public String getLastDocumentRevision(XWikiDocument doc) {
        ILocation documentLocation = svn.getDocumentWikiLocation(doc);
        return svn.getLocationLastRevision(documentLocation);
    }

    @Override
    public XWikiDocument loadXWikiDocByRevision(XWikiDocument doc, String revision, XWikiContext<String, Object> context) throws XWikiException {
        return loadXWikiDoc(doc, revision, context);
    }

}
