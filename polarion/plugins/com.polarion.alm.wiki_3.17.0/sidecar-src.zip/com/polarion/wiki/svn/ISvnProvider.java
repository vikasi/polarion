package com.polarion.wiki.svn;

import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.List;

import javax.security.auth.Subject;

import com.polarion.subterra.base.location.ILocation;
import com.polarion.wiki.svn.bo.DocumentSvnInfo;
import com.polarion.wiki.svn.bo.SpaceSvnInfo;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.doc.XWikiAttachment;
import com.xpn.xwiki.doc.XWikiDocument;

public interface ISvnProvider {

    public static final String PROPERTY_TITLE_NAME = "polarion.attachment.title";
    public static final String PROPERTY_TITLE_NAME_POLARION = "svn.dp.attachment.title";

    /**
     * used in projectName for identify if project mean root in repository
     */
    public static final String REPO_ROOT_AS_PROJECT_NAME = "repo_root_as_project_name";
    public static final String WIKI_ROOT_FOLDER = "_wiki";

    public boolean isFileExists(ILocation loc);

    public void createFile(ILocation locFile, Subject user, boolean system);

    public void createFile(ILocation locFile, Subject user, boolean system, String propertyTitleValue);

    public void writeFile(ILocation fileLocation, byte[] what, Subject user, boolean system) throws Exception;

    public void writeFile(ILocation location, byte[] content, Subject subj, boolean b, String propertyTitleValue) throws Exception;

    public void writeFileNonTransaction(ILocation fileLocation, byte[] what, Subject user, boolean system) throws Exception;

    public void deleteFileNonTransaction(final ILocation loc);

    public void updateDocument(XWikiDocument doc, List saveList, List deleteList, XWikiContext context, WikiSvnStore store, boolean updateDoc) throws XWikiException;

    public void rollbackDocument(XWikiDocument doc, XWikiContext context, WikiSvnStore store) throws XWikiException;

    public void deleteAttachmentNew(XWikiDocument doc, XWikiAttachment att, XWikiContext context, WikiSvnStore store) throws XWikiException;

    public void saveAttachmentContent(ILocation loc, byte[] content, String title) throws Exception;

    public void deleteFile(final XWikiDocument doc) throws XWikiException;

    public void deleteFile(final ILocation loc) throws XWikiException;

    public void deleteFolder(final ILocation pageLocation) throws XWikiException;

    public SpaceSvnInfo getSpaceInfo(final ILocation paceLocation);

    public ByteBuffer readFile(ILocation locFile, Subject user, boolean system);

    public ByteBuffer readFile(ILocation locFile, String version, Subject user, boolean system);

    public boolean canRead(ILocation loaction);

    public List getFileVersions(ILocation loc);

    public String[] getSpaces(String root);

    public List getCurrentSpaces(String project);

    public String[] getDocuments(String space);

    public boolean exist(ILocation location);

    public InputStream readFile(ILocation location);

    /**
     * 
     * @param mixedSpace, the mixed space e.g.: project/projectName/page/SpaceName
     * @param page
     * @return
     */
    public List/*AttachmentSvnInfo*/getDocumentAttachments(String mixedSpace, String page);

    public List/*AttachmentSvnInfo*/getDocumentAttachments(String space, String page, String rev);

    /**
     * 
     * @param projectName, the real project name e.g.: maven-test2
     *        if you want root spaces in repositiry use projectName: /
     * @return all spaces with latest revision
     */
    public List/*SpaceSvnInfo*/getSpacesInProject(String projectName);

    /**
     * 
     * @param projectLocation
     * @return
     */
    public List/*SpaceSvnInfo*/getSpacesInProject(ILocation projectLocation);

    /**
     * 
     * @param spaceName, the real space name e.g.: _default
     * @return all documents
     */
    public List<DocumentSvnInfo> getDocumentsInSpace(String projectName, String spaceName);

    public List<DocumentSvnInfo> getDocumentsInSpace(ILocation spaceLocation);

    /**
     * 
     * @param projectName, the real project name
     * @param spaceName, the real spaceName
     * @param pageName, the real pageName
     * @return all attachments
     */
    public List/*AttachmentSvnInfo*/getAttachmentsInDocument(String projectName, String spaceName, String pageName);

    public List/*AttachmentSvnInfo*/getAttachmentsInDocument(String projectName, String spaceName, String pageName, String rev);

    public List/*AttachmentSvnInfo*/getAttachmentsInDocument(ILocation attachmentLocation);

    public DocumentSvnInfo getDocument(ILocation documentLocation);

    public DocumentSvnInfo getDocumentForHistory(ILocation documentLocation);

    public ILocation getRootWikiLocation();

    public ILocation getRootLocation();

    public ILocation getProjectWikiLocation(String projectName);

    public ILocation getSpaceWikiLocation(String projectName, String spaceName);

    public ILocation getDocumentWikiLocation(String projectName, String spaceName, String pageName);

    public ILocation getDocumentWikiLocation(XWikiDocument doc);

    public ILocation getPageWikiLocation(String projectName, String spaceName, String pageName);

    public ILocation getPageWikiLocation(XWikiDocument doc);

    public String getLocationLastRevision(ILocation location);

    public void removeAttachments(final String space, final String page) throws XWikiException;

    public boolean copyLocations(ILocation from, ILocation to, Subject user);

    public String getHeaderTitle(String name);

    public String getUserNamePolarion(String name);

    public void createSpace(XWikiDocument doc) throws XWikiException;

}
