package com.polarion.wiki.svn.bo;

public class CommentsSvnInfo {

}
