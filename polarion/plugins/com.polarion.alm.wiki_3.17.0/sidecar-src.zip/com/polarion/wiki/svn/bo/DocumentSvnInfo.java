package com.polarion.wiki.svn.bo;

import java.util.Date;

import com.polarion.subterra.base.location.ILocation;

public class DocumentSvnInfo {

    public static final String XML = "xml";
    public static final String PAGE_XML = "page.xml";
    public static final String COMMENTS_XML = "comments.xml";
    public static final String USER_XML = "user.xml";
    public static final String ATTACHMENT_FILE_FOLDER = "attachments";
    public static final String USERS_ = "users/";
    private ILocation location;
    private String autor = "";
    private Date date;
    private String creator = "";
    private Date creationDate;
    private String name = "";
    private String revision;

    public String getRevision() {
        return revision;
    }

    public void setRevision(String revision) {
        this.revision = revision;
    }

    /**
     * @return the autor
     */
    public String getAutor() {
        return autor;
    }

    /**
     * @param autor
     *            the autor to set
     */
    public void setAutor(String autor) {
        this.autor = autor;
    }

    /**
     * @return the creator
     */
    public String getCreator() {
        return creator;
    }

    /**
     * @param creator
     * the creator to set
     */
    public void setCreator(String creator) {
        this.creator = creator;
    }

    /**
     * @return the date
     */
    public Date getDate() {
        return date;
    }

    /**
     * @param date
     *            the date to set
     */
    public void setDate(Date date) {
        this.date = date;
    }

    /**
     * @return the creationDate
     */
    public Date getCreationDate() {
        return creationDate;
    }

    /**
     * @param creationDate
     * the creationDate to set
     */
    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    /**
     * @return the location
     */
    public ILocation getLocation() {
        return location;
    }

    public ILocation getAttachmentLocation(String attachmentFileName)
    {
        if (!attachmentFileName.equalsIgnoreCase("")) {
            return location.append(ATTACHMENT_FILE_FOLDER).append(attachmentFileName);
        } else {
            return location.append(ATTACHMENT_FILE_FOLDER);
        }
    }

    /**
     * @param location
     *            the location to set
     */
    public void setLocation(ILocation location) {
        this.location = location;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name.replaceAll("&#46;", ".");
    }

    /**
     * @param name
     *            the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    public ILocation getDocumentFileLocation() {
        return location.append(PAGE_XML);
    }

    public ILocation getDocumentCommentsFileLocation() {
        return location.append(COMMENTS_XML);
    }
}
