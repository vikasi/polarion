package com.polarion.wiki.portlet;

import java.io.IOException;

import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import com.polarion.portal.jetspeed.portlet.JSPPortlet;
import com.polarion.wiki.util.SpaceParser;
import com.xpn.xwiki.XWikiConstant;

public class WikiPortlet extends JSPPortlet {
    private static final String PROJECT = "/project/";

    @Override
    public void doView(RenderRequest request, RenderResponse res)
            throws IOException, PortletException {
        // get current project from action URL
        String currentProject = getProject(res.createActionURL().toString());
        String link = request.getPreferences().getValue("pageLocation", "");
        String pageLocation = SpaceParser.getFullNameFromWikiLink(link);

        if (!pageLocation.startsWith("/") && SpaceParser.getProject(pageLocation) == null) {
            if (currentProject != null) {
                pageLocation = currentProject + "/" + pageLocation;
            }
        }
        if (pageLocation.startsWith("/")) {
            pageLocation = pageLocation.substring(1);
        }
        //set attribute that is used as iframe src
        request.setAttribute("url", XWikiConstant.URL_WIKI_PORTLETVIEW + "/" + pageLocation + "?wlink=" + link + "&xpage=xportalwiki");

        super.doView(request, res);
    }

    /*
     *  util method to get project part from url
     */
    private String getProject(String url) {
        int index = url.indexOf(PROJECT);
        if (index >= 0) {
            String project = url.substring(index, url.indexOf("/", index + PROJECT.length()));
            return project;
        }
        return null;
    }

}
