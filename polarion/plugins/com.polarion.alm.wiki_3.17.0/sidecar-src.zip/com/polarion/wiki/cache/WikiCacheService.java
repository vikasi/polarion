/*
 * Copyright (C) 2004-2013 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2013 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.polarion.wiki.cache;

import java.util.Properties;

import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.cache.api.XWikiCache;
import com.xpn.xwiki.cache.api.XWikiCacheService;

public class WikiCacheService implements XWikiCacheService {

    @Override
    public void init(XWiki context) {
        // empty
    }

    /**
     * Selects type of cache based on well-known cache names.
     * Capacity argument is a hint that is ignored for some caches.
     */
    @Override
    public XWikiCache newCache(String cacheName, int capacity) throws XWikiException {
        if ("xwiki.store.pagecache".equals(cacheName)) { //$NON-NLS-1$
            // WARNING: this cache has to be in-memory as XWikiDocument is not serializable
            return new EHCacheForWiki("wiki-page"); //$NON-NLS-1$
        }
        if ("xwiki.store.pageexistcache".equals(cacheName)) { //$NON-NLS-1$
            return new EHCacheForWiki("wiki-page-exists"); //$NON-NLS-1$
        }
        return new SimpleCacheForWiki(cacheName, capacity);
    }

    @Override
    public XWikiCache newLocalCache() throws XWikiException {
        throw new UnsupportedOperationException();
    }

    @Override
    public XWikiCache newLocalCache(int capacity) throws XWikiException {
        throw new UnsupportedOperationException();
    }

    @Override
    public XWikiCache newCache(String cacheName) throws XWikiException {
        throw new UnsupportedOperationException();
    }

    @Override
    public XWikiCache newCache(String cacheName, Properties props) throws XWikiException {
        throw new UnsupportedOperationException();
    }

    @Override
    public XWikiCache newLocalCache(Properties props) throws XWikiException {
        throw new UnsupportedOperationException();
    }

    @Override
    public XWikiCache newCache(String cacheName, Properties props, int capacity) throws XWikiException {
        throw new UnsupportedOperationException();
    }

    @Override
    public synchronized XWikiCache newLocalCache(Properties props, int capacity) throws XWikiException {
        throw new UnsupportedOperationException();
    }

}
