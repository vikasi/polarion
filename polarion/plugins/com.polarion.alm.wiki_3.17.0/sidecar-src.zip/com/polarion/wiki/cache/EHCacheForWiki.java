/*
 * Copyright (C) 2004-2013 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2013 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.polarion.wiki.cache;

import net.sf.ehcache.Cache;

import com.polarion.platform.internal.cache.CacheHelper;
import com.xpn.xwiki.cache.api.XWikiCache;
import com.xpn.xwiki.cache.api.XWikiCacheNeedsRefreshException;

public class EHCacheForWiki implements XWikiCache {

    private Cache cache;

    public EHCacheForWiki(String cacheName) {
        this.cache = CacheHelper.getOrCreateCache(cacheName);
    }

    @Override
    public void setCapacity(int capacity) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void flushEntry(String key) {
        CacheHelper.remove(cache, key);
    }

    @Override
    public void putInCache(String key, Object value) {
        CacheHelper.put(cache, key, value);
    }

    @Override
    public Object getFromCache(String key) throws XWikiCacheNeedsRefreshException {
        Object value = CacheHelper.get(cache, key);
        if (value == null) {
            throw new XWikiCacheNeedsRefreshException();
        }
        return value;
    }

    @Override
    public Object getFromCache(String key, int refeshPeriod) throws XWikiCacheNeedsRefreshException {
        throw new UnsupportedOperationException();
    }

    @Override
    public int getNumberEntries() {
        throw new UnsupportedOperationException();
    }

    @Override
    public void cancelUpdate(String key) {
        // empty
    }

    @Override
    public void flushAll() {
        CacheHelper.removeAll(cache);
    }

}
