package com.polarion.wiki.util;

import java.util.ArrayList;

@SuppressWarnings("nls")
public class Constants {

    public static final String UNKNOWN_USER = "Unknown";

    public static final String DEFAULT_PAGE = "Home";

    public static final String USER_DASHBOARD = "User Dashboard";

    public static final String PAGE_USER_DASHBOARD = "mypolarion";

    public static final String DEFAULT_SPACE = "_default";

    public static final String OVERVIEW_PAGE = "Home";

    public static final String DASHBOARD_PAGE = "Dashboard";

    public static final String MODULES = "_modules";

    public static final String MODULES_FOLDER = "modules";

    public static final String TEST_RUNS_FOLDER = "testruns";

    public static final String TEST_RUNS_REAL_FOLDER = ".polarion/testing/testruns";

    public static final String PLANS_FOLDER = "plans";

    public static final String PLANS_REAL_FOLDER = ".polarion/planning/plans";

    public static final String PAGE_TEST_RUN = "testrun";

    public static final String USERS = "_users";

    public static final String TEST_RUNS = "_testruns";

    public static final String PLANS = "_plans";

    public static final String USERS_FOLDER = "user-management";

    public static final String WIKI_FOLDER = "wiki";

    public static final String SVN_WIKI_FOLDER = "_wiki";

    public static final String HOME_PAGE_AUTHOR = "Polarion";

    public static final String PAGE_IN_URL = "page";

    public static final String PROJECT_IN_URL = "project";

    public static final String SPACE_IN_URL = "space";

    public static final String ROOT_REPO_LEVEL = "Repository";

    public static final String TEMP_FOLDER_PANELS = "Panels";
    public static final String TEMP_FOLDER_MAIN = "Main";
    public static final String TEMP_FOLDER_DOC = "Doc";
    public static final String TEMP_FOLDER_XWIKI = "XWiki";

    public static ArrayList<String> defineNames = new ArrayList<String>();
    public static String defineNamesString = "";
    public static String defineNamesLowerCaseString = "";
    public static ArrayList<String> defineNamesLowerCase = new ArrayList<String>();

    static
    {
        defineNames.add(TEMP_FOLDER_PANELS);
        defineNames.add(TEMP_FOLDER_MAIN);
        defineNames.add(TEMP_FOLDER_DOC);
        defineNames.add(TEMP_FOLDER_XWIKI);

        for (int i = 0; i < defineNames.size(); i++)
        {
            String name = defineNames.get(i);
            defineNamesString += "\"" + name + ((i + 1) != defineNames.size() ? "\", " : "\"");
            defineNamesLowerCaseString += "\"" + name.toLowerCase() + ((i + 1) != defineNames.size() ? "\", " : "\"");
            defineNamesLowerCase.add(name.toLowerCase());
        }
    }

    public static final String SPACE_DOC = "Doc";
    public static final String PAGE_SYNTAX_HELP = "SyntaxHelp";
    public static final String PAGE_HIGHCHARTS_HELP = "HighchartsHelp";

}
