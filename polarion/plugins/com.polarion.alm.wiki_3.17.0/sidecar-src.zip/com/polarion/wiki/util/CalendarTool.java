package com.polarion.wiki.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.polarion.core.util.types.DateOnly;

/**
 * 
 * 
 * @author Stepan Roh
 * @version $Revision$ $Date$
 * @since 3.4.1
 */
public class CalendarTool {

    public synchronized Calendar getCalendarInstance() {
        return Calendar.getInstance();
    }

    public synchronized Calendar getCalendar(Date date) {
        Calendar c = Calendar.getInstance();
        if (date != null) {
            c.setTime(date);
        }
        return c;
    }

    public synchronized Calendar getCalendar(DateOnly date) {
        return getCalendar(date.getDate());
    }

    public synchronized Calendar getCalendarAndDaysBefore(DateOnly date, int days) {
        Calendar c = getCalendar(date.getDate());
        c.add(Calendar.DATE, -days);
        return c;
    }

    public String formatDate(Date date, String format)
    {
        if (date == null) {
            return "";
        }

        String xformat = format;
        String defaultFormat = "yyyy/MM/dd HH:mm";

        if (format == null) {
            xformat = defaultFormat;
        }
        try {

            return (new SimpleDateFormat(xformat)).format(date);

        } catch (Exception e) {

            if (format == null) {
                if (xformat.equals(defaultFormat)) {
                    return date.toString();
                } else {
                    return formatDate(date, defaultFormat);
                }
            } else {
                return formatDate(date, null);
            }
        }
    }

    /**
     * Returns date string in format: Date.UTC(yyyy, MM, dd, hh, mm, ss, SSS)
     * It can be useful for generating java script code from velocity. 
     * @param date date for encoding.
     * @return date string
     * @since 3.7.3
     */
    public String formatUtcDateTime(Date date) {
        if (date == null) {
            return ""; //$NON-NLS-1$
        }
        return formatDate(date, "Date.UTC(yyyy, MM, dd, hh, mm, ss, SSS)"); //$NON-NLS-1$
    }

    /**
     * Returns date string in format: Date.UTC(yyyy, MM, dd)
     * It can be useful for generating java script code from velocity. 
     * @param date date for encoding.
     * @return date string
     * @since 3.7.3
     */
    public String formatUtcDate(Date date) {
        if (date == null) {
            return ""; //$NON-NLS-1$
        }
        return formatDate(date, "Date.UTC(yyyy, MM, dd)"); //$NON-NLS-1$
    }

}
