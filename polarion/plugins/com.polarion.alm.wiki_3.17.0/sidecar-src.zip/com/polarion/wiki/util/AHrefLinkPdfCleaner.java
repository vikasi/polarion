package com.polarion.wiki.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AHrefLinkPdfCleaner {
    /**
     * Remove target and title from <a href="" ..../>
     * @param content
     * @return
     */
    public static String replaceInvalidXhtmlPdfHreafLinks(final String content) {
        Matcher links = Pattern.compile("<a(.*?)>").matcher(content);
        StringBuffer newContent = new StringBuffer();
        int lastLinkStart = 0;
        while (links.find()) {
            String betweenLinks = content.substring(lastLinkStart, links.start(1));
            newContent.append(betweenLinks);

            String ahref = links.group(1);
            String fixedAhref = ahref.replaceAll("target=\".+?\"", "").replaceAll("title=\".+?\"", "");
            newContent.append(fixedAhref);

            lastLinkStart = links.end(1);
        }
        newContent.append(content.substring(lastLinkStart));
        return newContent.toString();
    }
}
