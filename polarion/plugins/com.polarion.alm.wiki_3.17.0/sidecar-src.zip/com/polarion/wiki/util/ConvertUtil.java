package com.polarion.wiki.util;

import java.io.InputStream;
import java.nio.ByteBuffer;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.polarion.core.util.ObjectUtils;
import com.polarion.core.util.logging.Logger;

public class ConvertUtil {

    private static Logger log = Logger.getLogger(ConvertUtil.class);
    private static SimpleDateFormat formater = new SimpleDateFormat("yyyyMMddHHmmss");
    private static SimpleDateFormat formaterLucene = new SimpleDateFormat("yyyyMMdd");

    private static SimpleDateFormat compatFormater = new SimpleDateFormat("yyyy-MM-dd HH:mm");

    public static byte[] intputStreamToByteArray(InputStream is) {
        try {
            byte[] bytes = new byte[is.available()];
            is.read(bytes);
            return bytes;
        } catch (NullPointerException e) {
            return null;
        } catch (Exception e) {
            log.error("Exception while converting input stream to byte array:", e);
        }
        return null;
    }

    public static ByteBuffer inputStreamToByteBuffer(InputStream is) {
        byte[] bytes = ConvertUtil.intputStreamToByteArray(is);
        if (bytes == null) {
            return null;
        }
        ByteBuffer buffer = ByteBuffer.allocate(bytes.length);
        buffer.put(bytes);
        return buffer;
    }

    /**
     * parseable format: yyyyMMddHHmmss
     * @param date
     * @return
     */
    public static String dateToString(Date date) {
        return formater.format(date);
    }

    public static String dateToStringLucene(Date date) {
        return formaterLucene.format(date);
    }

    /**
     * parseable format: yyyyMMddHHmmss
     * @param date
     * @return
     */
    public static Date stringToDate(String date) {
        try {
            if (!ObjectUtils.emptyString(date)) {
                date = date.trim();
                if (date.contains(" ")) {
                    return compatFormater.parse(date);
                }
            }
            return formater.parse(date);
        } catch (ParseException e) {
            // nothing to do
        }
        return null;
    }

}
