package com.polarion.wiki.util;

/**
 * 
 * 
 * @author Stepan Roh
 * @version $Revision$ $Date$
 * @since 3.4.1
 *
 */
public class EscapingTool {

    public String escape(String input) {
        if (input == null) {
            return null;
        }
        input = input.replaceAll("&", "&amp;");
        input = input.replaceAll("<", "&lt;");
        input = input.replaceAll(">", "&gt;");
        return input;
    }
}
