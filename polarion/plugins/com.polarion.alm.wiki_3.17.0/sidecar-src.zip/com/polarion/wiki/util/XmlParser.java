package com.polarion.wiki.util;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXParseException;

import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.doc.XWikiDocument;

public class XmlParser
{
    private static final Log log = LogFactory.getLog(XmlParser.class);

    public static Document getXmlFromXWikDocument(XWikiDocument doc, XWikiContext context) throws XWikiException
    {
        String dc = "";
        try
        {
            dc = doc.toXML(context);
        } catch (Exception e)
        {
            log.error("");
        }
        return XmlParser.getXmlFromString(dc);
    }

    public static Document getXmlFromString(String doc) throws XWikiException
    {
        Document xmlDoc = null;
        try
        {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            ByteArrayInputStream xmlStream = new ByteArrayInputStream(doc.getBytes("UTF-8"));
            DocumentBuilder db = factory.newDocumentBuilder();
            xmlDoc = db.parse(xmlStream);
        } catch (Exception e)
        {
            throw new XWikiException(XWikiException.MODULE_XWIKI_DOC,
                    XWikiException.ERROR_DOC_XML_PARSING, "Error parsing xml", e, null);
        }
        return xmlDoc;
    }

    public static Document getXmlFromInputStream(InputStream docIs) {
        Document xmlDoc = null;
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = factory.newDocumentBuilder();
            xmlDoc = db.parse(docIs);
        } catch (SAXParseException e) {
            // bad xml file structure
            return null;
        } catch (Exception e) {
            log.error("Exception while get xml from inputStream: " + e.getMessage());
        }
        return xmlDoc;
    }

    public static String getStringXmlFromDocument(Document doc)
    {
        StreamResult result = new StreamResult(new StringWriter());
        try
        {
            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            //transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            DOMSource source = new DOMSource(doc);
            transformer.transform(source, result);
        } catch (Exception e)
        {
            log.error("Exception while get xml from document: " + e.getMessage(), e);
        }
        return result.getWriter().toString();
    }

    public static String getNodeString(Node node)
    {
        //if (node.getNodeType() == node.TEXT_NODE)
        ///{
        //	log.error("Node text: " + node.getNodeValue()); 
        //}

        return node.getFirstChild().getNodeValue();
    }

    public static int getNodeCount(org.w3c.dom.Document xml, String nodeName) throws Exception
    {
        NodeList nl = xml.getDocumentElement().getElementsByTagName(nodeName);
        return nl.getLength();
    }

    public static Node getNodeBy(Node node, String nodeName, int number) throws Exception
    {
        NodeList nl = node.getChildNodes();
        int founded = 0;
        if (nl.getLength() > 0)
        {
            for (int i = 0; i <= nl.getLength() - 1; i++)
            {
                Node nd = nl.item(i);
                if (nd.getNodeName().equalsIgnoreCase(nodeName))
                {
                    if (number == 0) {
                        return nd;
                    } else if (number == founded)
                    {
                        return nd;
                    }
                    founded++;
                }
            }
        }
        return null;
    }

    public static org.w3c.dom.Document getXmlFromFilePath(String FilePath) throws Exception {
        org.w3c.dom.Document xmlDoc = null;
        File f = new File(FilePath);
        f = f.getAbsoluteFile();
        //FileInputStream fis = new FileInputStream(f);
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = factory.newDocumentBuilder();
            xmlDoc = db.parse(f);
        } catch (Exception e)
        {
            //log.error("Exception while get xml from string: " + e.getMessage());
        }
        return xmlDoc;
    }

    public static Node getNodeBy(org.w3c.dom.Document from, String nodeName, int number) throws Exception
    {
        NodeList nl = from.getDocumentElement().getElementsByTagName(nodeName);
        return nl.item(number);
    }
}
