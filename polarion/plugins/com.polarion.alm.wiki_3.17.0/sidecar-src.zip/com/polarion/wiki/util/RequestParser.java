package com.polarion.wiki.util;

import java.io.File;
import java.net.URL;
import java.util.HashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.polarion.wiki.svn.SvnUtil;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.web.Utils;

public class RequestParser
{
    private static final Log logger = LogFactory.getLog(RequestParser.class);

    public static HashMap parseQuery(String path, XWikiContext context)
    {
        if (logger.isDebugEnabled()) {
            logger.debug("context.getRequest().getPathInfo() = " + path);
        }

        HashMap<String, String> qr = new HashMap<String, String>();

        String action = "", projectGroup = "", project = "", space = "", name = "";

        int GroupIndex, ProjectIndex, PageIndex;

        int QuestInd = path.indexOf("?");

        if (QuestInd != -1)
        {
            path = path.substring(0, QuestInd);
        }

        if ((path.indexOf("/delattachment") == 0 || path.indexOf("/download") == 0))
        {
            int end = path.lastIndexOf("/");
            //int pathLegth = path.length(); 
            path = path.substring(0, end);
        }

        GroupIndex = path.indexOf("/group/");
        ProjectIndex = path.indexOf("/project/");
        PageIndex = path.indexOf("/page/");

        // parsing of action
        action = path.substring(1, path.indexOf("/", 1));

        // parsing space/name
        if (PageIndex != -1)
        {
            int cnt = path.indexOf("/", PageIndex + 6);

            int lastSlash = path.lastIndexOf("/");

            if (cnt != -1)
            {
                space = path.substring(PageIndex + 6, lastSlash);
                name = path.substring(lastSlash + 1, path.length());
            }
            else if (cnt == -1)
            {
                space = Constants.DEFAULT_SPACE;

                if ((lastSlash + 1) == path.length())
                {
                    name = Constants.DEFAULT_PAGE;
                }
                else
                {
                    name = path.substring(lastSlash + 1, path.length());
                }
            }
        }

        // parsing project name
        if (ProjectIndex != -1)
        {
            project = path.substring(ProjectIndex + 9, path.indexOf("/", ProjectIndex + 9));
        }

        if (GroupIndex != -1 && (GroupIndex > ProjectIndex) && (GroupIndex < PageIndex)) //CHANGE: GroupIndex > ProjectIndex
        {
            if (ProjectIndex != -1) {
                projectGroup = path.substring(GroupIndex + 7, ProjectIndex);
            } else if (ProjectIndex == -1 && PageIndex != -1)
            {
                projectGroup = path.substring(GroupIndex + 7, PageIndex);
            } else {
                projectGroup = path.substring(GroupIndex + 7, path.length());
            }
        }

        // check if document is from XWikiTemplates dir
        if ((PageIndex == -1) && (ProjectIndex == -1) && (GroupIndex == -1))
        {
            int slash2 = path.indexOf("/", 1);
            int slash3 = path.indexOf("/", slash2 + 1);

            space = path.substring(slash2 + 1, slash3);
            name = path.substring(slash3 + 1);
        }

        // detection of web of the document
        String location = "";
        if (PageIndex != -1) {
            location = path.substring(path.indexOf("/", 1) + 1, PageIndex + 6) + space;
        } else if (GroupIndex != -1)
        {
            if (space.equalsIgnoreCase("")) {
                space = "_default";
            }
            if (!path.endsWith("/page") || !path.endsWith("/page/"))
            {
                if (path.endsWith("/")) {
                    location = path.substring(path.indexOf("/", 1) + 1, path.length()) + "page/" + space;
                } else {
                    location = path.substring(path.indexOf("/", 1) + 1, path.length()) + "/page/" + space;
                }
            }
            else
            {
                if (path.endsWith("/")) {
                    location = path.substring(path.indexOf("/", 1) + 1, path.length()) + space;
                } else {
                    location = path.substring(path.indexOf("/", 1) + 1, path.length()) + "/" + space;
                }

            }
        } else {
            location = space;
        }

        if (context.get("service") != null && ((String) context.get("service")).equalsIgnoreCase("SpaceIndex"))
        {
            location = location.replaceAll("_default", name);
        }

        if ((name == null) || (name.equals("")))
        {
            name = Constants.DEFAULT_PAGE;
        }

        if ((space == null) || (space.equals("")))
        {
            space = Constants.DEFAULT_SPACE;
        }

        if ((GroupIndex != -1) && (!name.equalsIgnoreCase("BrowseProjects")))
        {
            // or overview page
            if ("Home".equals(name)) {
                name = Constants.OVERVIEW_PAGE;
            }
            if ("Dashboard".equals(name)) {
                name = Constants.DASHBOARD_PAGE;
            }
        }

        action = Utils.decode(action, context);
        if (action != null)
        {
            qr.put("action", action);
            logger.debug("Action - " + qr.get("action"));
        }

        projectGroup = Utils.decode(projectGroup, context);
        if (projectGroup != null)
        {
            qr.put("projectGroup", projectGroup);
            logger.debug("Project Group - " + qr.get("projectGroup"));
        }

        project = Utils.decode(project, context);
        if (project != null)
        {
            qr.put("project", project);
            logger.debug("Project - " + qr.get("project"));
        }

        space = Utils.decode(space, context);
        if (space != null)
        {
            qr.put("space", space);
            logger.debug("Space - " + qr.get("space"));
        }

        //	name = Utils.decode(name, context);		
        if (name != null && !name.equals(""))
        {
            qr.put("name", name);
            logger.debug("Name - " + qr.get("name"));
        }

        qr.put("location", location);

        return qr;
    }

    public static boolean isAutosaved(XWikiDocument doc, XWikiContext context)
    {
        try
        {
            if (doc.getSpace().indexOf("/") != -1)
            {
                String filename = doc.getSpace().replace('/', '+') + "+" + doc.getName() + ".xml";
                String realPath = context.getEngineContext().getRealPath("/templates/drafts/" + filename);
                File file = new File(realPath);

                if (file.exists())
                {
                    return true;
                }
            }
        } catch (Exception e)
        {
            logger.error("Exception while checking autosaved page" + e.getMessage());
        }

        return false;

    }

    public static boolean deleteAutosavedDoc(XWikiDocument doc, XWikiContext context)
    {
        String filename = doc.getSpace().replace('/', '+') + "+" + doc.getName() + ".xml";
        String realPath = context.getEngineContext().getRealPath("/templates/drafts/" + filename);
        File file = new File(realPath);

        if (file.exists())
        {
            file.delete();
        }

        if (file.exists())
        {
            return false;
        }

        return true;

    }

    public static boolean isAutosavePage(XWikiDocument doc, XWikiContext context)
    {
        String url = context.getURL().toString();
        if (isAutosaved(doc, context) && (url.indexOf("page=old") == -1)
                && (url.indexOf("page=autosaved") == -1))
        {
            return true;
        }

        return false;

    }

    public static boolean isDocumentPage(String space)
    {
        if (com.polarion.wiki.util.Constants.defineNamesLowerCase.contains(space.toLowerCase()))
        {
            return false;
        }
        return true;
    }

    public static URL getInnerURL(XWikiContext context)
    {
        String url = context.getURL().toString();
        HashMap hm = parseQuery(context.getRequest().getPathInfo(), context);

        String index = "";
        String location = (String) hm.get("location");
        String service = context.get("service").toString();
        String space = SvnUtil.REPOSITORY_SPACE;
        String docPanel = "";

        if (service.equals("SpaceIndex"))
        {
            index = SvnUtil.SPACE_PARAM + location;
        }
        else if (service.equals("Search"))
        {
            service = "WebSearch";
            space = "Panels";
            String search_inProject = (String) hm.get("name");
            String project = (String) hm.get("project");

            if (search_inProject.equals(SpaceParser.DEFAULT_PAGE_NAME))
            {
                if (!project.equals("")) {
                    search_inProject = project + "/";
                } else {
                    search_inProject = "";
                }
            }
            else if (!search_inProject.equals(""))
            {
                search_inProject = SpaceParser.PAGE + search_inProject;
                if (!project.equals("")) {
                    search_inProject = SpaceParser.PROJECT + project + "/" + search_inProject;
                }
            }

            if (search_inProject.equals(SpaceParser.PAGE + "repo_root")) {
                search_inProject = "/";
            }

            Object txt = context.getRequest().get("text");
            String text = "";
            if (txt != null) {
                text = txt.toString();
            }

            index = "?startId=Y&text=" + text + "&search_in=" + search_inProject;
        }
        else if (service.equals("Overview"))
        {
            if (!index.equals("")) {
                docPanel = "&parentSpace=" + location;
            } else {
                docPanel = "?parentSpace=" + location;
            }
            service = "WikiOverview";
            space = SvnUtil.PANELS_SPACE;
            ;
        }
        else
        {
            String project = (String) hm.get("project");
            if (!index.equals("")) {
                docPanel = "&parentSpace=project/" + project + "/page/_default";
            } else {
                docPanel = "?parentSpace=project/" + project + "/page/_default";
            }
            service = "Modules";

            //load service as template from Panels by name
            space = SvnUtil.PANELS_SPACE;
        }

        String path = cutURLToAction(url) + "/" + space + "/" + service + index + docPanel;

        URL urlNew;
        try
        {
            urlNew = new URL(path);
        } catch (Exception e)
        {
            return context.getURL();
        }

        return urlNew;
    }

    public static String cutURLToAction(String path)
    {
        return path.substring(0, path.indexOf("/", path.indexOf("/bin/") + 5));
    }

    public static String getPathInfo(XWikiContext context)
    {
        String url = context.getURL().toString();
        int QuestIndex = url.indexOf('?');
        if (QuestIndex != -1) {
            url = url.substring(0, QuestIndex);
        }
        return url.substring(url.indexOf("/bin/") + 4);
    }

    /**
     * 
     * @param doc make sure if doc's name or space contains u25 than it is replaced with % before saving
     */
    public static void decodeName(XWikiDocument doc)
    {
        if (doc.getName().indexOf("u25") != -1) {
            doc.setName(doc.getName().replaceAll("u25", "%"));
        }
        if (doc.getSpace().indexOf("u25") != -1) {
            doc.setSpace(doc.getSpace().replaceAll("u25", "%"));
        }
    }

    /**
     * 
     * @param doc make sure if doc's name or space contains % than it is replaced with u25 before 
     */
    public static void encodeName(XWikiDocument doc)
    {
        if (doc.getName().indexOf("%") != -1) {
            doc.setName(doc.getName().replaceAll("\\%", "u25"));
        }
        if (doc.getSpace().indexOf("%") != -1) {
            doc.setSpace(doc.getSpace().replaceAll("\\%", "u25"));
        }
    }

}
