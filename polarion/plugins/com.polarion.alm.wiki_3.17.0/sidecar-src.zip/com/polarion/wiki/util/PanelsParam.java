package com.polarion.wiki.util;

import java.io.InputStream;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.xpn.xwiki.XWikiConstant;
import com.xpn.xwiki.XWikiContext;

public class PanelsParam
{
    static HashMap params = new HashMap();

    public static void loadParams(XWikiContext context)
    {
        //
        try {
            if (context.getEngineContext() != null)
            {
                InputStream is = context.getEngineContext().getResourceAsStream("/WEB-INF/" + XWikiConstant.PANELS_FILE_NAME);
                if (is != null)
                {
                    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                    DocumentBuilder db = factory.newDocumentBuilder();
                    Document xmlDoc = db.parse(is);
                    NodeList ndl = xmlDoc.getElementsByTagName("panel");

                    for (int i = 0; i < ndl.getLength(); i++)
                    {
                        Node nd = ndl.item(i);
                        NodeList chld = nd.getChildNodes();

                        String name = "";
                        String val = "";
                        for (int j = 0; j < chld.getLength(); j++)
                        {
                            Node ch_nd = chld.item(j);
                            String nd_name = ch_nd.getNodeName();
                            if (nd_name.equalsIgnoreCase("name"))
                            {
                                name = ch_nd.getFirstChild().getNodeValue();
                            }

                            if (nd_name.equalsIgnoreCase("panel-class"))
                            {
                                val = ch_nd.getFirstChild().getNodeValue();
                            }
                        }
                        params.put(name, val);
                    }
                }
            }
        } catch (Exception e) {
        }

    }

    public static String getPanelClass(String panelName)
    {
        return (String) params.get(panelName);
    }
}
