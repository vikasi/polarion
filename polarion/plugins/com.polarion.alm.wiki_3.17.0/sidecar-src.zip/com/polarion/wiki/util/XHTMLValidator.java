package com.polarion.wiki.util;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.ErrorListener;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXParseException;

import com.polarion.core.util.logging.Logger;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;

/*
 * class for check document html content
 */

public class XHTMLValidator
{

    static Logger log = Logger.getLogger(XHTMLValidator.class);
    final public static String VALIDATOR_HEADER = "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
            "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" " +
            "\"xhtml1-transitional.dtd\">" +
            "<!DOCTYPE root SYSTEM \"xhtml1-transitional.dtd\">" +
            "<html xmlns=\"http://www.w3.org/1999/xhtml\">" +
            "<head>" +
            "<title>validator</title>" +
            "<meta http-equiv=\"Content-Type\" " +
            "content=\"text/html; charset=UTF-8\" />" +
            "</head>" +
            "<body  id=\"body\">" +
            "<div>\r\n";

    final public static String VALIDATOR_FOTTER = "\r\n</div></body></html>";
    final public static String VALIDATOR_STRICT = "strict_xhtml.xsd";
    final public static String VALIDATOR_TRANSITIONAL = "transitional_xhtml.xsd";
    final public static String VALIDATOR_FRAMESET = "frameset_xhtml.xsd";
    private TransformerException exceptionResult1 = null;
    private SAXParseException exceptionResult2 = null;

    public XHTMLValidator()
    {

    }

    public void validateDocumentContent(String content, XWikiContext context, String type) throws XWikiException
    {
        validateHXTML(XHTMLValidator.VALIDATOR_HEADER + content.trim() + XHTMLValidator.VALIDATOR_FOTTER, context, type, "");
    }

    public String validateHXTML(String content, XWikiContext context, String type, String dtdpath) throws XWikiException
    {
        content = "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
                "<!DOCTYPE html SYSTEM \"" + dtdpath + "//xhtml1-transitional.dtd\">" + content;
        validateHXTMLDTD(content, context, type, dtdpath);

        return content;
        // Shema validation work only with internrt access
/*		
		 try 
		 {
			content = encodeContent(content);
			ByteArrayInputStream xmlStream = new ByteArrayInputStream(content.trim().getBytes(context.getWiki().getEncoding()));
			SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
			InputStream xsltinputstream = getClass().getClassLoader().getResourceAsStream(type);
			Source schemaFile = new StreamSource(xsltinputstream);
			Schema schema = factory.newSchema(schemaFile);
			Validator validator = schema.newValidator();
			Source source = new StreamSource(xmlStream);
			xmlStream.close();
			validator.validate(source);
		}
		catch (SAXParseException ex) 
		{
			String errorString = getSourceString(ex.getLineNumber(), content);
			//String lineError = getLineError(ex.)
            throw new XWikiException(XWikiException.MODULE_XWIKI_CONTENT,
                    XWikiException.ERROR_DOC_XML_PARSING,
                    "Exception validation.",  ex, null, errorString);

		}
		catch (IOException ex){
            throw new XWikiException(XWikiException.MODULE_XWIKI_CONTENT,
                    XWikiException.ERROR_DOC_XML_PARSING,
                    "Exception validation.", ex);

		}  		
		catch (Exception ex){
            throw new XWikiException(XWikiException.MODULE_XWIKI_CONTENT,
                    XWikiException.ERROR_DOC_XML_PARSING,
                    "Exception validation.", ex);

		}
*/
    }

    public void validateHXTMLDTD(String content, XWikiContext context, String type, String dtdpath) throws XWikiException
    {

        try {

            content = encodeContent(content);
            content = content.replaceAll("align=\"both\"", "align=\"left\""); //workaround for DPP-9930 - Cannot PDF-export a page with work items imported from word

            /* 
             * fix for DPP-10887 - If module-workitems macro with the custom field contain table export to pdf fail
             * cause: spaces in ID attributes are not allowed in doctype
             */
            content = content.replaceAll("([ ]*)id=\"polarion_wiki([^>]*)\"", "");

            ByteArrayInputStream xmlStream = new ByteArrayInputStream(content.trim().getBytes(context.getWiki().getEncoding()));

            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setValidating(true);
            DocumentBuilder builder = factory.newDocumentBuilder();
            builder.setErrorHandler(new innerErrorHandler());
            Document xmlDocument = builder.parse(xmlStream);

            DOMSource source = new DOMSource(xmlDocument);
            StreamResult result = new StreamResult(new ByteArrayOutputStream());
            TransformerFactory tf = TransformerFactory.newInstance();
            tf.setErrorListener(new innerErrorListener());
            Transformer transformer = tf.newTransformer();
            transformer.setErrorListener(new innerErrorListener());
            transformer.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, dtdpath + "//xhtml1-transitional.dtd");
            transformer.transform(source, result);
        } catch (SAXParseException ex)
        {
            String errorString = getSourceString(ex.getLineNumber(), content);
            throw new XWikiException(XWikiException.MODULE_XWIKI_CONTENT,
                    XWikiException.ERROR_DOC_XML_PARSING,
                    "Exception validation.", ex, null, errorString);

        } catch (IOException ex) {
            throw new XWikiException(XWikiException.MODULE_XWIKI_CONTENT,
                    XWikiException.ERROR_DOC_XML_PARSING,
                    "Exception validation.", ex);

        } catch (Exception ex) {
            throw new XWikiException(XWikiException.MODULE_XWIKI_CONTENT,
                    XWikiException.ERROR_DOC_XML_PARSING,
                    "Exception validation.", ex);

        }

        if (exceptionResult1 != null)
        {
            String errorString = exceptionResult1.getMessageAndLocation();
            throw new XWikiException(XWikiException.MODULE_XWIKI_CONTENT,
                    XWikiException.ERROR_DOC_XML_PARSING,
                    "Exception validation.", exceptionResult1, null, errorString);

        }
        else if (exceptionResult2 != null)
        {
            String errorString = getSourceString(exceptionResult2.getLineNumber(), content);
            throw new XWikiException(XWikiException.MODULE_XWIKI_CONTENT,
                    XWikiException.ERROR_DOC_XML_PARSING,
                    "Exception validation.", exceptionResult2, null, errorString);
        }

    }

    static String getSourceString(int line, String content)
    {

        if (line == 0) {
            return "";
        }
        String res = "";
        int n = 1;
        try
        {
            StringReader sr = new StringReader(content);
            BufferedReader bfr = new BufferedReader(sr);
            while ((res = bfr.readLine()) != null)
            {
                if (n == line) {
                    break;
                }
                n++;
            }

        } catch (IOException e)
        {
            return "";
        }
        return res;
    }

    public static String converMessageText(String text)
    {
        if (text == null) {
            return "";
        }
        return text.replaceAll("<", "&#60;").replaceAll(">", "&#62;");
    }

    private String encodeContent(String content)
    {

        content = content.replaceAll("&#45;", "-");
        content = content.replaceAll("&#35;", "#");

        content = content.replaceAll("&", "&amp;");
        content = content.replaceAll("#", "%23");
        content = content.replaceAll("<hr class=\"line\"/>", "");
        content = content.replaceAll("<p class=\"paragraph\"></p>", "");

        return content;
    }

    class innerErrorListener implements ErrorListener
    {
        @Override
        public void error(TransformerException exception)
        {
            log.error(exception);
            //	exceptionResult1 = exception;
        }

        @Override
        public void fatalError(TransformerException exception)
        {
            log.error(exception);
            //	exceptionResult1 = exception;
        }

        @Override
        public void warning(TransformerException exception)
        {
            log.warn(exception);
        }

    }

    class innerErrorHandler implements ErrorHandler
    {
        @Override
        public void error(SAXParseException exception)
        {
            log.error(exception);
            //	exceptionResult2 = exception;
        }

        @Override
        public void fatalError(SAXParseException exception)
        {
            log.error(exception);
            //	exceptionResult2 = exception;
        }

        @Override
        public void warning(SAXParseException exception)
        {
            log.warn(exception);
        }
    }
}
