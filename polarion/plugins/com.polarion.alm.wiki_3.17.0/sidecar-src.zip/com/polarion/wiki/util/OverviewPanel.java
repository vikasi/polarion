package com.polarion.wiki.util;

import java.io.File;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.polarion.core.boot.BootPlugin;
import com.polarion.core.util.ObjectUtils;
import com.polarion.core.util.logging.Logger;
import com.polarion.core.util.xml.DOMHelper;
import com.xpn.xwiki.XWikiConstant;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.doc.XWikiDocument;

public class OverviewPanel {

    private static HashMap<String, HashMap<String, String>> reportsMap = new HashMap<String, HashMap<String, String>>();
    // page name -> page type (e.g. Home->home)
    private static HashMap<String, String> typeMap = new HashMap<String, String>();

    private final static String SCOPE_REPOSITORY = "repository"; //$NON-NLS-1$
    private final static String SCOPE_PROJECT = "project"; //$NON-NLS-1$
    private final static String SCOPE_SPACE = "space"; //$NON-NLS-1$

    private OverviewPanel() {
        // this class should never be instantiated
    }

    public static String getScope(String group, String project, String space) {
        String scope = SCOPE_REPOSITORY;
        if ((project == null || project.equalsIgnoreCase("")) && space.equalsIgnoreCase(Constants.DEFAULT_SPACE)) { //$NON-NLS-1$
            scope = SCOPE_REPOSITORY;
        } else if (space.equals(Constants.DEFAULT_SPACE)) {
            scope = SCOPE_PROJECT;
        } else {
            scope = SCOPE_SPACE;
        }
        if (group != null && !group.equalsIgnoreCase("")) { //$NON-NLS-1$
            scope = SCOPE_REPOSITORY;
        }
        //for modules only project level exist!
        if (space.equals(Constants.MODULES) || space.equals(Constants.TEST_RUNS) || space.equals(Constants.PLANS)) {
            scope = SCOPE_PROJECT;
        }
        if (space.equals(Constants.USERS)) {
            scope = SCOPE_SPACE;
        }
        return scope;
    }

    private static String getLocation(String space) {
        if (space.equals(Constants.MODULES)) {
            return Constants.MODULES_FOLDER;
        } else if (space.equals(Constants.USERS)) {
            return Constants.USERS_FOLDER;
        } else if (space.equals(Constants.TEST_RUNS)) {
            return Constants.TEST_RUNS_FOLDER;
        } else if (space.equals(Constants.PLANS)) {
            return Constants.PLANS_FOLDER;
        } else {
            return Constants.WIKI_FOLDER;
        }
    }

    private static String getKey(String page, String location) {
        return page + "-" + location; //$NON-NLS-1$
    }

    public static boolean hasPage(String space, String page, String scope) {
        return (getPath(space, getPageName(space, page), scope) != null);
    }

    private static String getPageName(String space, String page) {
        if (space.contains(Constants.USERS)) {
            return "My Polarion";
        }
        if (space.contains(Constants.TEST_RUNS)) {
            return "Test Run";
        }
        if (space.contains(Constants.PLANS)) {
            return "Plan";
        }
        return page;
    }

    // public for tests
    public static String getPath(String space, String page, String scope) {

        String key = getKey(getPageName(space, page), getLocation(space));
        HashMap<String, String> res = reportsMap.get(key);
        if (res != null) {
            return res.get(scope);
        }
        return null;
    }

    public static XWikiDocument getPage(XWikiContext context, String space, String page, String scope) {
        String path = getPath(space, page, scope);
        if (path != null) {
            try {
                InputStream is = context.getEngineContext().getResourceAsStream("/templates/" + path); //$NON-NLS-1$
                ByteBuffer content = ConvertUtil.inputStreamToByteBuffer(is);
                XWikiDocument old = new XWikiDocument();
                old.fromXML(new String(content.array(), DOMHelper.ENCODING_UTF8));
                return old;
            } catch (Exception e) {
                Logger.getLogger(OverviewPanel.class).error("Failed to get built-in page: page=" + page + ", scope=" + scope, e); //$NON-NLS-1$ //$NON-NLS-2$
                return null;
            }
        }
        return null;
    }

    public static boolean isPageExists(XWikiContext context, String space, String page, String scope) {
        String path = context.getEngineContext().getRealPath("/templates/" + getPath(space, getPageName(space, page), scope)); //$NON-NLS-1$
        if (path == null) {
            return false;
        }
        File pageFile = new File(path);
        return pageFile.exists();
    }

    private static void validateLocation(String location) {
        if ((location == null) || (!location.equals(Constants.MODULES_FOLDER) && !location.equals(Constants.WIKI_FOLDER)
                && !location.equals(Constants.USERS_FOLDER) && !location.equals(Constants.TEST_RUNS_FOLDER)
                && !location.equals(Constants.PLANS_FOLDER))) {
            throw new RuntimeException("Unknown location in built-in pages configuration: " + location); //$NON-NLS-1$
        }
    }

    public static void init(XWikiContext context) {
        try {
            if (context.getEngineContext() != null) {
                InputStream is = context.getEngineContext().getResourceAsStream("/WEB-INF/" + XWikiConstant.REPORTS_FILE_NAME); //$NON-NLS-1$
                if (is != null) {
                    init(is, BootPlugin.getPolarionProductId());
                }
            }
        } catch (Exception e) {
            Logger.getLogger(OverviewPanel.class).error("Failed to initialize built-in pages", e); //$NON-NLS-1$
        }
    }

    // public for tests
    public static void init(InputStream is, String product) throws Exception {
        reportsMap.clear();
        typeMap.clear();
        Document doc = DOMHelper.parseDocument(is, null);
        List pageEls = DOMHelper.getContainedElements(doc.getDocumentElement(), "page"); //$NON-NLS-1$
        for (Iterator iter = pageEls.iterator(); iter.hasNext();) {
            Element pageEl = (Element) iter.next();
            String pageName = DOMHelper.getAttributeValue(pageEl, "name"); //$NON-NLS-1$
            String pageType = DOMHelper.getAttributeValue(pageEl, "type"); //$NON-NLS-1$
            String pageLocation = DOMHelper.getAttributeValue(pageEl, "location"); //$NON-NLS-1$
            validateLocation(pageLocation);

            typeMap.put(pageName, pageType);

            HashMap<String, String> scopeMap = new HashMap<String, String>();
            List scopeEls = DOMHelper.getContainedElements(pageEl, "scope"); //$NON-NLS-1$
            readScopeMap(scopeEls, scopeMap);

            List selectorEls = DOMHelper.getContainedElements(pageEl, "selector"); //$NON-NLS-1$
            for (Iterator it = selectorEls.iterator(); it.hasNext();) {
                Element selectorEl = (Element) it.next();
                String selectorProduct = DOMHelper.getAttributeValue(selectorEl, "product"); //$NON-NLS-1$
                if (ObjectUtils.equalsWithNull(product, selectorProduct)) {
                    List selectorScopeEls = DOMHelper.getContainedElements(selectorEl, "scope"); //$NON-NLS-1$
                    readScopeMap(selectorScopeEls, scopeMap);
                }
            }

            reportsMap.put(getKey(pageName, pageLocation), scopeMap);
        }
    }

    private static void readScopeMap(List scopeEls, Map<String, String> result) {
        for (Iterator it = scopeEls.iterator(); it.hasNext();) {
            Element scopeEl = (Element) it.next();
            String scope = DOMHelper.getAttributeValue(scopeEl, "target"); //$NON-NLS-1$
            String path = DOMHelper.getContainedText(scopeEl).trim();
            result.put(scope, path);
        }
    }

    public static String getType(String pageName) {
        return typeMap.get(pageName);
    }

}
