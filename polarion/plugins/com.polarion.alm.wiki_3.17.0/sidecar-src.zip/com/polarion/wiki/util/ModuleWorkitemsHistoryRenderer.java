/*
 * Copyright (C) 2004-2009 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2009 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.polarion.wiki.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.polarion.alm.projects.IProjectService;
import com.polarion.alm.projects.model.IProject;
import com.polarion.alm.projects.web.server.HatService;
import com.polarion.alm.projects.web.shared.JSHat;
import com.polarion.alm.tracker.ITrackerService;
import com.polarion.alm.tracker.model.IModule;
import com.polarion.alm.tracker.model.IWorkItem;
import com.polarion.alm.tracker.web.internal.shared.JSComment;
import com.polarion.alm.tracker.web.internal.shared.JSFieldDiff;
import com.polarion.platform.core.PlatformContext;
import com.polarion.platform.persistence.diff.IDiffManager;
import com.polarion.platform.persistence.diff.IFieldDiff;
import com.polarion.platform.persistence.model.IPObject;
import com.polarion.portal.server.HTMLBuilder;
import com.polarion.portal.server.IJSObjectTransformer;
import com.polarion.portal.server.PObjectDataProvider;
import com.polarion.portal.shared.IJSUIObject;
import com.polarion.portal.shared.Styles;
import com.polarion.reina.web.shared.IJSUIValue;
import com.polarion.reina.web.shared.html.HTMLConst;
import com.polarion.reina.web.shared.html.IHTMLBuilder;
import com.polarion.reina.web.shared.localization.Localization;
import com.polarion.reina.web.shared.renderers.JSRendererFactory;
import com.polarion.subterra.base.location.ILocation;
import com.polarion.subterra.base.location.Location;
import com.polarion.wiki.integration.utils.MacroRenderer;
import com.polarion.wiki.integration.utils.MacroUtils.ShortLongDisplay;
import com.xpn.xwiki.api.Document;

/**
 * @author <a href="mailto:dev@polarion.com">Michal Antolik</a>, Polarion Software
 */

public class ModuleWorkitemsHistoryRenderer {

//	public enum Status{
//		NO_CHANGE,
//		CHANGED,
//		ADDED,
//		REMOVED;
//	}
//	
//	public class Line{
//		public IWorkItem leftWI;
//		public String leftContent = "";
//		
//		public IWorkItem rightWI;
//		public String rightContent = "";
//		
//		public Status status = Status.NO_CHANGE;
//	}

    private Document leftdoc;
    private Document rightdoc;

    private HashMap<String, String> leftWiParentWiMap = new HashMap<String, String>();
    private HashMap<String, IWorkItem> leftWiInstanceMap = new HashMap<String, IWorkItem>();

    private HashMap<String, String> rightWiParentWiMap = new HashMap<String, String>();
    private HashMap<String, IWorkItem> rightWiInstanceMap = new HashMap<String, IWorkItem>();

    private Set<String> added;
    private Set<String> removed;
    private Set<String> changed;

//	private List<Line> lines = new ArrayList<Line>();

    final private static ITrackerService trackerService = (ITrackerService) PlatformContext.getPlatform().lookupService(ITrackerService.class);
    final private static IProjectService projectService = (IProjectService) PlatformContext.getPlatform().lookupService(IProjectService.class);

    public ModuleWorkitemsHistoryRenderer(Document leftdoc, Document rightdoc) {
        this.leftdoc = leftdoc;
        this.rightdoc = rightdoc;
    }

    public String render() {
        String origModuleName = leftdoc.getName();
        String projectId = leftdoc.getDoc().getProject();

        ILocation loc = Location.getLocation(origModuleName);
        IProject project = projectService.getProject(projectId);
        IModule module = trackerService.getModuleManager().getModule(project, loc);

        if ((module == null) || (module.isUnresolvable())) {
            return "No workitems.";
        }

        String leftRev = leftdoc.getRevision();
        String rightRev = rightdoc.getRevision();

        IModule leftModule = (IModule) trackerService.getDataService().getVersionedInstance(module.getObjectId(), leftRev);
        IModule rightModule = (IModule) trackerService.getDataService().getVersionedInstance(module.getObjectId(), rightRev);

        fillMaps(leftModule.getRootNode(), leftWiParentWiMap, leftWiInstanceMap);
        fillMaps(rightModule.getRootNode(), rightWiParentWiMap, rightWiInstanceMap);

        makeDiff(leftModule, rightModule);

        return print();
    }

    public static boolean isWikiDocumentForModule(Document doc) {
        String moduleName = doc.getName();
        String projectId = doc.getDoc().getProject();
        if ((projectId == null) || (projectId.equals(""))) { //$NON-NLS-1$
            return false;
        }
        ILocation loc = Location.getLocation(moduleName);
        IProject project = projectService.getProject(projectId);
        IModule module = trackerService.getModuleManager().getModule(project, loc);

        if ((module == null) || (module.isUnresolvable())) {
            return false;
        }

        return true;
    }

    private void fillMaps(IModule.IStructureNode root, Map<String, String> wiParentWiMap, Map<String, IWorkItem> wiInstanceMap) {
        IWorkItem wi = root.getWorkItem();
        if (wi != null) { //otherwise the root is virtual
            wiInstanceMap.put(wi.getId(), wi);
            IWorkItem parentWI = root.getParent().getWorkItem();
            if (parentWI != null) {
                wiParentWiMap.put(wi.getId(), parentWI.getId());
            } else {
                wiParentWiMap.put(wi.getId(), ""); //$NON-NLS-1$
            }
        }

        for (IModule.IStructureNode node : root.getChildren()) {
            fillMaps(node, wiParentWiMap, wiInstanceMap);
        }
    }

    @SuppressWarnings("unchecked")
    private String print() {

        String TITLE_DATA_STYLE = "font-size:11px;white-space:nowrap;border-right:1px solid #D2D7DA;border-bottom:1px solid #D2D7DA;background-color:#E9F3FA;height:23px;padding-right:4px;padding-left:4px;padding-bottom:2px"; //$NON-NLS-1$
        String FIELD_NAME_STYLE = "font-size:11px;white-space:nowrap;border-right:1px solid #D2D7DA;border-bottom:1px solid #D2D7DA;background-color:#D4E4F5;height:23px;padding-right:4px;padding-left:4px;padding-bottom:2px"; //$NON-NLS-1$

        IDiffManager diffManager = trackerService.getDataService().getDiffManager();
        MacroRenderer mr = MacroRenderer.getInstance();

        HTMLBuilder builder = new HTMLBuilder();

        if (!removed.isEmpty()) {
            builder.appendHTML("<div><strong>" + Localization.getString("wiki.history.label.removed") + Localization.getString("definition.colon") + "</strong></div>"); //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
            builder.appendTable("0", "1", null, "border-left:1px solid #D2D7DA;border-top:1px solid #D2D7DA;width:100%"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
            builder.appendElementStart(HTMLConst.TR, null, null, null);

            builder.appendElementStart(HTMLConst.TH, null, Styles.TABLE_HEADER_STYLE, null);
            builder.appendText(Localization.getString("definition.id")); //$NON-NLS-1$
            builder.appendElementEnd(HTMLConst.TH);

            builder.appendElementStart(HTMLConst.TH, null, Styles.TABLE_HEADER_STYLE, null);
            builder.appendText(Localization.getString("definition.title")); //$NON-NLS-1$
            builder.appendElementEnd(HTMLConst.TH);

            builder.appendElementStart(HTMLConst.TH, null, "width:100%;" + Styles.TABLE_HEADER_STYLE, null); //$NON-NLS-1$
            builder.appendText(Localization.getString("definition.description")); //$NON-NLS-1$
            builder.appendElementEnd(HTMLConst.TH);

            for (String wiID : removed) {
                List<String> fieldsList = new ArrayList<String>();
                fieldsList.add(IWorkItem.KEY_DESCRIPTION);
                IJSUIObject jo = mr.transformInstance(leftWiInstanceMap.get(wiID), fieldsList);

                builder.appendElementEnd(HTMLConst.TR);

                builder.appendElementStart(HTMLConst.TD, null, Styles.TABLE_CELL_STYLE, null);
//				JSRendererFactory.getInstance().render(builder, jo, true, true, IJSUIValue.STYLE_IMAGE_SHORT_TEXT);
                builder.appendHTML(mr.getLink4MacroObject(leftWiInstanceMap.get(wiID), null, ShortLongDisplay.SHORT, null, "/", false, null, null, null, true, leftdoc.context)); //$NON-NLS-1$
                builder.appendElementEnd(HTMLConst.TD);

                builder.appendElementStart(HTMLConst.TD, null, Styles.TABLE_CELL_STYLE, null);
                JSRendererFactory.getInstance().render(builder, jo.getValue(IWorkItem.KEY_TITLE), true, true, IJSUIValue.STYLE_IMAGE_TEXT);
                builder.appendElementEnd(HTMLConst.TD);

                builder.appendElementStart(HTMLConst.TD, null, Styles.TABLE_CELL_STYLE, null);
                JSRendererFactory.getInstance().render(builder, jo.getValue(IWorkItem.KEY_DESCRIPTION), true, true, IJSUIValue.STYLE_IMAGE_TEXT);
                builder.appendElementEnd(HTMLConst.TD);

                builder.appendElementEnd(HTMLConst.TR);
            }
            builder.appendElementEnd(HTMLConst.TABLE);
            builder.appendHTML("<br />"); //$NON-NLS-1$
        }

        if (!added.isEmpty()) {
            builder.appendHTML("<div><strong>" + Localization.getString("wiki.history.label.added") + Localization.getString("definition.colon") + "</strong></div>"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$
            builder.appendTable("0", "1", null, "border-left:1px solid #D2D7DA;border-top:1px solid #D2D7DA;width:100%"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
            builder.appendElementStart(HTMLConst.TR, null, null, null);

            builder.appendElementStart(HTMLConst.TH, null, Styles.TABLE_HEADER_STYLE, null);
            builder.appendText(Localization.getString("definition.id")); //$NON-NLS-1$
            builder.appendElementEnd(HTMLConst.TH);

            builder.appendElementStart(HTMLConst.TH, null, Styles.TABLE_HEADER_STYLE, null);
            builder.appendText(Localization.getString("definition.title")); //$NON-NLS-1$
            builder.appendElementEnd(HTMLConst.TH);

            builder.appendElementStart(HTMLConst.TH, null, "width:100%;" + Styles.TABLE_HEADER_STYLE, null); //$NON-NLS-1$
            builder.appendText(Localization.getString("definition.description")); //$NON-NLS-1$
            builder.appendElementEnd(HTMLConst.TH);

            for (String wiID : added) {
                List<String> fieldsList = new ArrayList<String>();
                fieldsList.add(IWorkItem.KEY_DESCRIPTION);
                IJSUIObject jo = mr.transformInstance(rightWiInstanceMap.get(wiID), fieldsList);

                builder.appendElementEnd(HTMLConst.TR);

                builder.appendElementStart(HTMLConst.TD, null, Styles.TABLE_CELL_STYLE, null);
//				JSRendererFactory.getInstance().render(builder, jo, true, true, IJSUIValue.STYLE_IMAGE_SHORT_TEXT);
                builder.appendHTML(mr.getLink4MacroObject(rightWiInstanceMap.get(wiID), null, ShortLongDisplay.SHORT, null, "/", false, null, null, null, true, leftdoc.context)); //$NON-NLS-1$
                builder.appendElementEnd(HTMLConst.TD);

                builder.appendElementStart(HTMLConst.TD, null, Styles.TABLE_CELL_STYLE, null);
                JSRendererFactory.getInstance().render(builder, jo.getValue(IWorkItem.KEY_TITLE), true, true, IJSUIValue.STYLE_IMAGE_TEXT);
                builder.appendElementEnd(HTMLConst.TD);

                builder.appendElementStart(HTMLConst.TD, null, Styles.TABLE_CELL_STYLE, null);
                JSRendererFactory.getInstance().render(builder, jo.getValue(IWorkItem.KEY_DESCRIPTION), true, true, IJSUIValue.STYLE_IMAGE_TEXT);
                builder.appendElementEnd(HTMLConst.TD);

                builder.appendElementEnd(HTMLConst.TR);
            }
            builder.appendElementEnd(HTMLConst.TABLE);
            builder.appendHTML("<br />"); //$NON-NLS-1$
        }

        if (!changed.isEmpty()) {
            HTMLBuilder builder2 = new HTMLBuilder();
            for (String wiID : changed) {
                IWorkItem leftWI = leftWiInstanceMap.get(wiID);
                IWorkItem rightWI = rightWiInstanceMap.get(wiID);

                IFieldDiff[] diffs = diffManager.generateDiff(
                        leftWI,
                        rightWI,
                        IWorkItem.DIFF_IGNORED_FIELDS, IWorkItem.FIELD_ORDER);
                boolean equalsParents = leftWiParentWiMap.get(wiID).equals(rightWiParentWiMap.get(wiID));
                boolean noDiff = (diffs == null) || (diffs.length == 0);
                if (noDiff && equalsParents) {
                    continue; //nothing changed
                }

                if (!noDiff) {
                    //most of code copied from LiveDocOverview

                    HTMLBuilder builder4 = new HTMLBuilder();

                    IJSObjectTransformer transformerBefore = (IJSObjectTransformer) leftWI.adapt(IJSObjectTransformer.class);
                    IJSObjectTransformer transformerAfter = (IJSObjectTransformer) rightWI.adapt(IJSObjectTransformer.class);
                    for (IFieldDiff field : diffs) {
                        IPObject object;
                        if (field.getAdded() == null) {
                            object = leftWI;
                        } else {
                            object = rightWI;
                        }
                        JSFieldDiff diffJS = PObjectDataProvider.transformDiffToJS(field, transformerBefore, transformerAfter);
                        HTMLBuilder builder3 = new HTMLBuilder();

                        builder3.appendElementStart(HTMLConst.TD, null, null, null);
                        builder3.appendElementEnd(HTMLConst.TD);

                        builder3.appendElementStart(HTMLConst.TD, null, FIELD_NAME_STYLE, null);
                        builder3.appendText(diffJS.getLabel());
                        builder3.appendElementEnd(HTMLConst.TD);

                        builder3.appendElementStart(HTMLConst.TD, null, Styles.TABLE_CELL_WRAP_STYLE, null);
                        boolean fstdiff = renderFieldDiff(builder3, diffJS, true, object);
                        builder3.appendElementEnd(HTMLConst.TD);

                        builder3.appendElementStart(HTMLConst.TD, null, Styles.TABLE_CELL_WRAP_STYLE, null);
                        boolean snddiff = renderFieldDiff(builder3, diffJS, false, object);
                        builder3.appendElementEnd(HTMLConst.TD);
                        builder3.appendElementEnd(HTMLConst.TR);
                        if (fstdiff || snddiff) {
                            builder4.appendHTML(builder3.toString());
                        }
                    }
                    if (!builder4.toString().equals("")) { //$NON-NLS-1$
                        builder2.appendElementEnd(HTMLConst.TR);
                        builder2.appendCellStart("4", null, null, null, null, TITLE_DATA_STYLE); //$NON-NLS-1$
                        builder2.appendHTML(mr.getLink4MacroObject(rightWiInstanceMap.get(wiID), null, ShortLongDisplay.LONG, null, "/", false, null, null, null, true, leftdoc.context)); //$NON-NLS-1$
                        builder2.appendElementEnd(HTMLConst.TD);
                        builder2.appendElementEnd(HTMLConst.TR);
                        builder2.appendHTML(builder4.toString());
                    }
                }
            }
            String changedHtml = builder2.toString();
            if (!changedHtml.equals("")) { //$NON-NLS-1$
                builder.appendHTML("<div><strong>" + Localization.getString("wiki.history.label.changed") + Localization.getString("definition.colon") + "</strong></div>"); //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
                builder.appendTable("0", "1", null, "border-left:1px solid #D2D7DA;border-top:1px solid #D2D7DA;width:100%"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
                builder.appendElementStart(HTMLConst.TR, null, null, null);

                builder.appendElementStart(HTMLConst.TH, null, "width:10%;" + Styles.TABLE_HEADER_STYLE, null); //$NON-NLS-1$
                builder.appendText(Localization.getString("wiki.history.label.workitem")); //$NON-NLS-1$
                builder.appendElementEnd(HTMLConst.TH);

                builder.appendElementStart(HTMLConst.TH, null, "width:10%;" + Styles.TABLE_HEADER_STYLE, null); //$NON-NLS-1$
                builder.appendText(Localization.getString("definition.field")); //$NON-NLS-1$
                builder.appendElementEnd(HTMLConst.TH);

                builder.appendElementStart(HTMLConst.TH, null, "width:40%;" + Styles.TABLE_HEADER_STYLE, null); //$NON-NLS-1$
                builder.appendText(Localization.getString("definition.revision") + Localization.getString("definition.colon") + " " + leftdoc.getRevision()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
                builder.appendElementEnd(HTMLConst.TH);

                builder.appendElementStart(HTMLConst.TH, null, "width:45%;" + Styles.TABLE_HEADER_STYLE, null); //$NON-NLS-1$
                builder.appendText(Localization.getString("definition.revision") + Localization.getString("definition.colon") + " " + rightdoc.getRevision()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
                builder.appendElementEnd(HTMLConst.TH);
                builder.appendHTML(changedHtml);
                builder.appendElementEnd(HTMLConst.TABLE);
            }
        }

        if (builder.toString().equals("")) { //$NON-NLS-1$
            builder.appendText(Localization.getString("wiki.history.label.noChangeInWorkitems")); //$NON-NLS-1$
        }
        return builder.toString();
    }

    @SuppressWarnings("unchecked")
    public boolean renderFieldDiff(IHTMLBuilder builder, JSFieldDiff field, boolean before, IPObject object) {
        boolean shouldrender = false;
        if (field.isCollection()) {
            Collection collection = null;
            if (before) {
                collection = field.getRemoved();
            } else {
                collection = field.getAdded();
            }
            if (collection != null) {
                Object[] arr = collection.toArray();
                List hats = null;
                if ((arr.length > 0) && (arr[0] instanceof JSComment)) {
                    hats = HatService.getHatsAvailableToCurrentUser(object.getContextId());
                }
                for (Iterator iter = collection.iterator(); iter.hasNext();) {
                    Object element = iter.next();
                    if (hats != null) {
                        //we have JSComment list
                        JSComment comment = (JSComment) element;
                        List visible = comment.getVisibleToParsed();
                        if (visible.size() != 0) {
                            boolean found = false;
                            for (Iterator it = hats.iterator(); it.hasNext();) {
                                JSHat definedHat = (JSHat) it.next();
                                if (visible.contains(definedHat.getId() + "")) {
                                    found = true;
                                    break;
                                }
                            }
                            if (!found) {
                                builder.appendText("You are not allowed to see this comment.");
                                builder.appendElementStart("BR", null, null, null); //$NON-NLS-1$
                                builder.appendElementEnd("BR"); //$NON-NLS-1$
                                continue;
                            }
                        }
                    }

                    JSRendererFactory.getInstance().render(builder, element, false, true);
                    builder.appendElementStart("BR", null, null, null); //$NON-NLS-1$
                    builder.appendElementEnd("BR"); //$NON-NLS-1$
                    shouldrender = true;
                }
            }
        } else {
            Object fieldData = null;
            if (before) {
                fieldData = field.getBefore();
            } else {
                fieldData = field.getAfter();
            }
            if (fieldData != null) {
                JSRendererFactory.getInstance().render(builder, fieldData, false, true);
                shouldrender = true;
            }
        }

        return shouldrender;
    }

    private void makeDiff(IModule leftModule, IModule rightModule) {

        Set<String> leftWIs = leftWiInstanceMap.keySet();
        Set<String> rightWIs = rightWiInstanceMap.keySet();

        removed = new HashSet<String>(leftWIs);
        removed.removeAll(rightWIs);

        added = new HashSet<String>(rightWIs);
        added.removeAll(leftWIs);

        changed = new HashSet<String>(leftWIs);
        changed.removeAll(removed);

//		Iterator<IWorkItem> leftIt = leftModule.getContainedWorkItems().iterator();
//    	Iterator<IWorkItem> rightIt = rightModule.getContainedWorkItems().iterator();
//    	
//		IWorkItem rightWI = rightIt.next();
//		IWorkItem leftWI = leftIt.next(); 
//		
//		while(leftIt.hasNext()){
//			if(leftWI.getId().equals(rightWI.getId())){
//				//compare according fields
//				
//			}
//			if(rightWiInstanceMap.containsKey(leftWI.getId())){
//				//WI was moved to another position/root => jump over WIs on the right while both side will match
//			} else {
//				//WI was removed => jump over left WI
//			}
//		}

    }
}
