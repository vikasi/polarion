package com.polarion.wiki.util;

public class PlainTextExtractor
{
    private final String WIKI_SPECAIL_CHARS = "*o/\\~-_#1.|[]?";
    private final String SKIP_CHARS = "\n\r\t ";
    private int lastPos = 0;
    private int maxMatch = 0;
    private int maxPos = -1;
    private int macroStart = -1;
    private int macroFinish = 0;
    private int matchesCount = 0;
    private int saveMacroStart;
    private int saveMacroFinish;

    private boolean isWikiSpecialChar(char ch)
    {
        return WIKI_SPECAIL_CHARS.indexOf(ch) > -1;
    }

    public void reset()
    {
        lastPos = 0;
        maxMatch = 0;
        maxPos = -1;
        macroStart = -1;
        macroFinish = 0;
        matchesCount = 0;
    }

    private boolean isSkipChar(char ch)
    {
        return SKIP_CHARS.indexOf(ch) > -1;
    }

    private int getNextContentPos(int pos, String text)
    {
        boolean openTag = false;

        while (pos < text.length())
        {
            char ch = text.charAt(pos);
            if (ch == '<') {
                openTag = true;
            }
            if (ch == '{')
            {
                int i = text.indexOf("}", pos);
                if (i > 0)
                {
                    String macroName = text.substring(pos + 1, i);
                    //bypass code inside {code} macro
                    if ((macroName.indexOf("code") > -1) || macroName.indexOf("table:") > -1 || macroName.equals("table"))
                    {
                        if (macroFinish > macroStart)
                        {
                            saveMacroStart = macroStart;
                            saveMacroFinish = macroFinish;
                            macroStart = pos;
                            macroFinish = pos;
                        } else {
                            macroFinish = i;
                        }
                        pos = i + 1;
                        continue;
                    }
                    else
                    {
                        pos = i + 1;
                        continue;
                    }
                }
            }
            if (!openTag && !isSkipChar(ch)) {
                return pos;
            }
            if (ch == '>') {
                openTag = false;
            }
            pos++;
        }
        return pos;
    }

    private int getNextSearchPos(int pos, String text)
    {
        while (pos < text.length())
        {
            char ch = text.charAt(pos);
            if (!isSkipChar(ch)) {
                return pos;
            }
            pos++;
        }
        return pos;
    }

    private boolean isInsideMacro(int pos)
    {
        if ((macroStart == macroFinish) && (pos > macroStart)) {
            return true;
        } else {
            return ((pos > macroStart) && (pos < macroFinish));
        }
    }

    public int findTextPos(String content, String searchText)
    {
        int i = 0;
        int j = 0;
        int startPos = -1;
        reset();
        searchText = searchText.trim();
        int searchLength = searchText.length();
        while (i < content.length())
        {
            //char ch = getNextChar(int pos, String content, XWikiContext context);
            //find first enterence
            i = getNextContentPos(i, content);
            j = getNextSearchPos(j, searchText);
            if (j == searchLength)
            {
                //complete match found
                lastPos = i;
                //for some macros like {table} or {code} return begin of the macro if the selection inside
                //and text inside the macro
                if (isInsideMacro(startPos)) {
                    startPos = macroStart;
                }
                matchesCount++;
                if (matchesCount > 1) {
                    return -1;
                } else
                {
                    maxMatch = searchLength;
                    maxPos = startPos;
                    //return startPos;
                    //continue search for duplicate
                    j = 0;
                    startPos = -1;
                }
            }
            if (i == content.length())
            {
                return maxPos;
            }

            char chC = content.charAt(i);
            char chS = searchText.charAt(j);
            if (chC == chS)
            {
                if (startPos == -1) {
                    startPos = i;
                }
                j++;
            }
            else
            {
                if (startPos != -1)
                {//it might some wiki char if it so igonore it
                    if (!isWikiSpecialChar(chC))
                    {
                        //store max matching pos
                        if ((j > maxMatch) && (j > 5))
                        {
                            if (isInsideMacro(startPos)) {
                                maxPos = macroStart;
                            } else {
                                maxPos = startPos;
                            }
                            maxMatch = j;
                        }
                        // else reset
                        i = startPos;
                        if (i < macroStart)
                        {
                            macroStart = saveMacroStart;
                            macroFinish = saveMacroFinish;
                        }

                        j = 0;
                        startPos = -1;
                    }
                }
            }
            ;
            i++;

            if (j == searchLength)
            {
                lastPos = i;
                //for some macros like {table} or {code} return begin of the macro if the selection inside
                //and text inside the macro
                if (isInsideMacro(startPos)) {
                    startPos = macroStart;
                }
                matchesCount++;
                if (matchesCount > 1) {
                    return -1;
                } else
                {
                    maxMatch = searchLength;
                    maxPos = startPos;
                    //return startPos;
                    //continue search for duplicate
                    if (i < macroStart)
                    {
                        macroStart = saveMacroStart;
                        macroFinish = saveMacroFinish;
                    }

                    j = 0;
                    startPos = -1;
                }
            }
        }
        return maxPos;
    }

    public int getLastPos()
    {
        return lastPos;
    }

    public void Validate(String text, String textSearch, int i)
    {
        reset();
        int j = findTextPos(text, textSearch);
        if ((i == -1) && (j != -1)) {
            System.err.println("Not found: " + textSearch);
        } else if (i != j) {
            System.err.println("Wrong position:" + new Integer(i).toString() + " of " + textSearch + "Found at: " + new Integer(j).toString());
        }
    }

    public void test()
    {

        Validate("ARAMP", "RAS", -1);
        Validate("ARAM", "RAM ", 1);
        Validate("ARASIS DOE", "RASIS DOK", 1);
        Validate("ARAM", "RAM", 1);
        Validate("ARAM\r\n", "RAM", 1);
        Validate("A~~RAM~~S", "RAMS", 3);
        Validate("ABBAMBAS", "BAS", 5);
        Validate("ABBA*BA*~~S~~", "BAS", 5);
        Validate("SSABS", "SS", 0);
        Validate("Some \r\n\r\n\\\\1.Wiki para\r\ntext", "Wiki para\r\n\r\n", 13);
        Validate("Some \r\n\r\n\\\\1.Wiki para\r\ntext 1.1 Paragraph 1", "Wiki para\r\n\r\n  text Paragraph 1", 13);
        //int i = getNextCharPos(0, "<bla><blai>some text");
        Validate("<b><i>text\r\n<\\b><\\i>", "\r\n\ttext", 6);
        Validate("Some  \r\n\r\n\\1.Wiki para\r\n<sup>text<\\sup>", "Wiki para\r\n\r\ntext", 13);
        Validate("text {code}some bla-bla {code}", "some bla-bla", 5);
        Validate("text \r\n{code}some bla-bla {code}", "ext some bla-bla", 1);
        Validate("text \r\n{code}some bla-bla {code}", "ext some bla", 1);
        Validate("{code}some bla-bla {code} 1", "some bla-bla\r\n1", 0);
        Validate("{code}some bla-bla {code}", "some bla-bla", 0);
        Validate("tar {code}some {code} 1", "ar some \r\n1", 1);
        Validate("text 1{table}Item1 | Item 2\r\nItem3 | Item 4 {table}", "Item 2 Item3 Item 4", 6);

        Validate("t {code:xml} tag {code}", "tag", 2);
        Validate("t {code:xml}<u>some tag</u> {code}", "tag", 2);

        Validate("text 1{table}Item1 | Item 2", "ext 1 Item1 Item 2", 1);
        Validate("te\r\n{image: img1.jpg}some \r\n{image: img3.jpg}\r\n ext}", "some ext", 21);
        Validate("a text and the text", "text", -1);
        Validate("a text and a link [_default.WeHome]", "and a link WeHome", 7);

    }
}
