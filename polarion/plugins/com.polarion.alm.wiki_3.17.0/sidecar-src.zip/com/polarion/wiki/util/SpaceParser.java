package com.polarion.wiki.util;

import java.security.PrivilegedAction;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.polarion.alm.projects.IProjectService;
import com.polarion.alm.projects.model.IProject;
import com.polarion.platform.core.PlatformContext;
import com.polarion.platform.security.ISecurityService;
import com.polarion.subterra.base.location.ILocation;
import com.polarion.wiki.svn.ISvnProvider;

public class SpaceParser {
    private static final String WIKI_ROOT_FOLDER = "/" + ISvnProvider.WIKI_ROOT_FOLDER;
    public static final String PROJECT = "project/";
    public static final String GROUP = "group/";
    public static final String PAGE = "page/";
    public static String DEFAULT_SPACE_NAME = Constants.DEFAULT_SPACE;
    public static String DEFAULT_PAGE_NAME = Constants.DEFAULT_PAGE;

    /**
     * mixedSpace = project/ProjectName/page/SpaceName mixedSpace = page/SpaceName - return null
     * 
     * or
     * 
     * mixedSpace = projectName/SpaceName mixedSpace = /SpaceName
     * 
     * @param mixedSpace
     * @return ProjectName
     */
    public static String getProject(String mixedSpace) {
        if (mixedSpace == null) {
            return null;
        }
        mixedSpace = checkWeb(mixedSpace);
        int projectIndex = mixedSpace.indexOf(PROJECT);
        int pageIndex = mixedSpace.lastIndexOf(PAGE);

        if (projectIndex == -1 || pageIndex == -1) {
            return null;
        }

        String project = mixedSpace.substring(projectIndex + PROJECT.length(), pageIndex - 1);
        return project;
    }

    public static String getGroup(String mixedSpace) {
        if (mixedSpace == null) {
            return null;
        }
        mixedSpace = checkWeb(mixedSpace);
        int groupIndex = mixedSpace.indexOf(GROUP);

        if (groupIndex == -1) {
            return null;
        }

        return mixedSpace.substring(groupIndex + GROUP.length(), mixedSpace.indexOf(PAGE) - 1);
    }

    /**
     * mixedSpace = project/ProjectName/page/SpaceName mixedSpace = page/SpaceName
     * 
     * @param mixedSpace
     * @return SpaceName
     */
    public static String getSpace(String mixedSpace) {
        if (mixedSpace == null) {
            return null;
        }
        mixedSpace = checkWeb(mixedSpace);
        if (mixedSpace.indexOf("page/") != -1) {
            return mixedSpace.substring(mixedSpace.lastIndexOf("page/") + 5).trim();
        } else {
            return mixedSpace.substring(mixedSpace.lastIndexOf("/") + 1).trim();
        }
    }

    /**
     * mixedSpace = project/ProjectName/page/SpaceName mixedSpace = page/SpaceName
     * 
     * @param mixedSpace
     * @return SpaceName
     */
    public static String getPage(String mixedSpace) {
        if (mixedSpace == null) {
            return null;
        }
        mixedSpace = checkWeb(mixedSpace);
        if (mixedSpace.lastIndexOf("/") != -1) {
            return mixedSpace.substring(mixedSpace.lastIndexOf("/") + 1);
        } else if (mixedSpace.lastIndexOf(".") != -1) {
            return mixedSpace.substring(mixedSpace.lastIndexOf(".") + 1);
        } else {
            return null;
        }
    }

    /**
     * if mixedSpace start with / - is root space
     * 
     * @param mixedSpace
     * @return
     */
    public static boolean isRoot(String mixedSpace) {
        if (mixedSpace == null) {
            return false;
        }

        if (mixedSpace.startsWith("page/")) {
            return true;
        }

        if (mixedSpace.indexOf("/") == 0) {
            return true;
        }

        return (getProject(mixedSpace) == null);
    }

    public static String checkWeb(String web) {
        Pattern urlPattern = Pattern.compile("^[^//]+[//]{1}[^//]+$");
        Matcher urlMatcher = urlPattern.matcher(web);

        if (web.lastIndexOf("/") == 0 /* && web.indexOf("page/")== -1 */) {
            web = "page" + web;
        }
        /*
        else if (web.lastIndexOf("/") > 0 && web.indexOf("page/") == -1 && web.indexOf("project/") == -1) {
            String project = web.substring(0, web.lastIndexOf("/"));
            String page = web.substring(web.lastIndexOf("/") + 1);
            web = "project/" + project + "/page/" + page;
        }
        */
        else if (urlMatcher.matches() && web.indexOf("page/") == -1)
        {
            String project = web.substring(0, web.lastIndexOf("/"));
            String page = web.substring(web.lastIndexOf("/") + 1);
            web = "project/" + project + "/page/" + page;
        }

        if (!web.equalsIgnoreCase("") && web.lastIndexOf("/") > 0)
        {
            if (!web.startsWith(PROJECT) && !web.startsWith(PAGE) && !web.startsWith(GROUP))
            {
                String project = web.substring(0, web.lastIndexOf("/"));
                String page = web.substring(web.lastIndexOf("/") + 1);
                web = "project/" + project + "/page/" + page;
            }
        }

        return web;
    }

    /**
     * since polarion3.0 projectId can be diffetrent than project folder name
     * @param location
     * @return
     */
    public static String getProject(final ILocation location) {
        ISecurityService securityService = (ISecurityService) PlatformContext.getPlatform().lookupService(ISecurityService.class);
        PrivilegedAction action = new PrivilegedAction() {
            @Override
            public Object run() {
                IProjectService projectService = (IProjectService) PlatformContext.getPlatform().lookupService(
                        IProjectService.class);
                IProject project = projectService.getProjectOwningLocation(location);
                if (project == null) {
                    return ISvnProvider.REPO_ROOT_AS_PROJECT_NAME;
                }
                return project.getId();
            }
        };
        return (String) securityService.doAsSystemUser(action);
    }

    public static String getSpace(ILocation location) {
        if (LocationMapping.isModule(location)) {
            return Constants.MODULES;
        }
        if (LocationMapping.isUser(location)) {
            return Constants.USERS;
        }
        if (LocationMapping.isTestRun(location)) {
            return Constants.TEST_RUNS;
        }
        if (LocationMapping.isPlan(location)) {
            return Constants.PLANS;
        }
        int wikiRootPosition = location.findComponentSequence(WIKI_ROOT_FOLDER);
        int spacePosition = wikiRootPosition + 1; // space is child of _wiki
        return location.getComponent(spacePosition);
    }

    public static String getPage(ILocation location) {
        if (LocationMapping.isModule(location)) {
            int modulePos = location.findComponentSequence(Constants.MODULES_FOLDER);
            return location.getComponent(modulePos + 1);
        }
        if (LocationMapping.isUser(location)) {
            int modulePos = location.findComponentSequence(Constants.USERS_FOLDER);
            return location.getComponent(modulePos + 1);
        }
        if (LocationMapping.isTestRun(location)) {
            int modulePos = location.findComponentSequence(Constants.TEST_RUNS_FOLDER);
            return location.getComponent(modulePos + 1);
        }
        if (LocationMapping.isPlan(location)) {
            int modulePos = location.findComponentSequence(Constants.PLANS_FOLDER);
            return location.getComponent(modulePos + 1);
        }
        int wikiRootPosition = location.findComponentSequence(WIKI_ROOT_FOLDER);
        int pagePosition = wikiRootPosition + 2; // page is child of space and space is child of _wiki
        return location.getComponent(pagePosition);
    }

    public static String getDocWeb(ILocation location)
    {
        return getProject(location) + "/" + getSpace(location);
    }

    public static String getMixedSpace(ILocation location) {
        String project = getProject(location);
        String space = getSpace(location);

        if (ISvnProvider.REPO_ROOT_AS_PROJECT_NAME.equals(project)) {
            return "page/" + space;
        }
        return "project/" + project + "/page/" + space;
    }

    public static String getFullName(ILocation location) {
        String mixedSpace = getMixedSpace(location);
        String page = getPage(location);
        return mixedSpace + "/" + page;
    }

    public static String getMixedSpace(String project, String space) {
        if (ISvnProvider.REPO_ROOT_AS_PROJECT_NAME.equals(project) || project == null) {
            project = "";
        }
        return checkWeb(project + "/" + space);
    }

    public static String getFullName(String project, String space, String page) {
        return getMixedSpace(project, space) + "/" + page;
    }

    /**
     * @author VKO
     * @param link
     * 			wiki link as it is in wiki editor (for exam.: project1/space1.page1)
     * @return
     * 			mixed fullname of page
     */
    public static String getFullNameFromWikiLink(String link) {
        String mixed = "";
        if (link.startsWith("/")) {
            mixed = "/";
            link = link.substring(1);
        }
        int slashInd = link.indexOf("/");
        if (slashInd >= 0) {
            mixed += PROJECT + link.substring(0, slashInd) + "/";
        }
        int dotInd = link.indexOf(".");
        if (dotInd < 0) {
            /* if (link.equals("")){
            	mixed += PAGE + "/_default/" + link;
            }else{
            	mixed += PAGE + "/_default/Home";
            } */
            mixed += PAGE + link;
        } else {
            mixed += PAGE + link.substring(slashInd + 1, dotInd) + "/" + link.substring(dotInd + 1);
        }
        return mixed;
    }

    /**
     * @author VKO
     * @param href
     * @return for short form of link - expanded link (with _default and Home)
     */

    public static String expandLink(String href) {
        int slashIndex = href.indexOf("/");
        if (slashIndex == href.length() - 1) {
            href += DEFAULT_SPACE_NAME;
        }
        if (slashIndex > -1 && href.indexOf(".") == -1) {
            href += "." + DEFAULT_PAGE_NAME;
        }
        return href;
    }

    public static String removeGroup(String web) {
        boolean isGroup = web.startsWith(GROUP);
        int indPage = web.indexOf(PAGE);
        if (isGroup) {
            web = web.substring(indPage);
        }
        return web;
    }
}
