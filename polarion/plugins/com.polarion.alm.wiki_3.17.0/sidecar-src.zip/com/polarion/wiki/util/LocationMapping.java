package com.polarion.wiki.util;

import com.polarion.subterra.base.location.ILocation;
import com.polarion.wiki.svn.ISvnProvider;

/**
 * 
 * @author VKO
 * There is the place for different typr of location mappings
 * (for example: links like [page] from modules should point to default space,
 * not to current space)
 *
 */

public class LocationMapping
{
    //link rendering mappings
    public static String getMappedSpace(String mixedSpace) {
        String res = mixedSpace;
        String space = SpaceParser.getSpace(mixedSpace);
        if (Constants.MODULES.equals(space) || Constants.USERS.equals(space)
                || Constants.TEST_RUNS.equals(space) || Constants.PLANS.equals(space)) {
            res = SpaceParser.getMixedSpace(SpaceParser.getProject(mixedSpace), Constants.DEFAULT_SPACE);
        }
        return res;
    }

    public static boolean isModule(ILocation loc) {
        if (loc == null)
        {
            return false;
        }
        if (!loc.containsComponent(ISvnProvider.WIKI_ROOT_FOLDER) && loc.containsComponent(Constants.MODULES_FOLDER))
        {
            return true;
        }
        return false;
    }

    public static boolean isUser(ILocation loc) {
        if (loc == null)
        {
            return false;
        }
        if (!loc.containsComponent(ISvnProvider.WIKI_ROOT_FOLDER) && loc.containsComponent(Constants.USERS_FOLDER))
        {
            return true;
        }
        return false;
    }

    public static boolean isTestRun(ILocation loc) {
        if (loc == null) {
            return false;
        }
        if (!loc.containsComponent(ISvnProvider.WIKI_ROOT_FOLDER) && loc.containsComponent(Constants.TEST_RUNS_FOLDER)) {
            return true;
        }
        return false;
    }

    public static boolean isPlan(ILocation loc) {
        if (loc == null) {
            return false;
        }
        if (!loc.containsComponent(ISvnProvider.WIKI_ROOT_FOLDER) && loc.containsComponent(Constants.PLANS_FOLDER)) {
            return true;
        }
        return false;
    }

}
