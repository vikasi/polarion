package com.polarion.wiki.integration.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.polarion.alm.projects.model.IProject;
import com.polarion.alm.projects.model.IUniqueObject;
import com.polarion.alm.tracker.model.IModule;
import com.polarion.alm.tracker.model.IWorkItem;
import com.polarion.alm.tracker.web.internal.server.tree.TreeCreator;
import com.polarion.alm.tracker.web.internal.server.tree.TreeNode;
import com.polarion.alm.tracker.web.internal.server.tree.TreeQuery;
import com.polarion.alm.ui.shared.FieldRenderType;
import com.polarion.core.util.logging.Logger;
import com.polarion.platform.ITransactionService;
import com.polarion.platform.core.PlatformContext;
import com.polarion.platform.internal.security.FieldReadDeniedContext;
import com.polarion.platform.persistence.model.IPObject;
import com.polarion.platform.spi.cache.InternalROTxContext;
import com.polarion.portal.shared.navigation.IPage;
import com.polarion.reina.web.shared.localization.Localization;
import com.polarion.wiki.integration.utils.MacroUtils.FieldProperty;
import com.xpn.xwiki.XWikiContext;

public class ModuleWorkItemsMacroParser extends MacroParser {

    private static final Logger log = Logger.getLogger(ModuleWorkItemsMacroParser.class);

    private static final int DEFAULT_TOP = 10000;

    final static private MP[] rule1 = {
            MP.MODULE_NAME, MP.PROJECT, MP.DISPLAY_TABLE, MP.EXPAND_YES_NO, MP.FIELDS, MP.TOP, MP.SORTBY, MP.WIDTH, MP.HEIGHT, MP.ROOT, MP.REVISION, MP.LINK, MP.DESCRIPTION_FIELDS
    };
    final static private MP[] rule2 = {
            MP.MODULE_NAME, MP.PROJECT, MP.DISPLAY_DOCUMENT, MP.EXPAND_YES_NO, MP.FIELDS, MP.TOP, MP.SORTBY, MP.WIDTH, MP.HEIGHT, MP.ROOT, MP.REVISION, MP.LINK, MP.DESCRIPTION_FIELDS
    };
    final static private MP[] rule3 = {
            MP.MODULE_NAME, MP.PROJECT, MP.DISPLAY_COUNT, MP.ROOT, MP.REVISION, MP.LINK
    };

    //WITH QUERY WITH REVISION
    final static private MP[] rule4 = {
            MP.MODULE_NAME, MP.PROJECT, MP.DISPLAY_TABLE, MP.EXPAND_YES_NO, MP.FIELDS, MP.TOP, MP.SORTBY, MP.WIDTH, MP.HEIGHT, MP.ROOT, MP.QUERY, MP.LINK, MP.DESCRIPTION_FIELDS, MP.REVISION
    };
    final static private MP[] rule5 = {
            MP.MODULE_NAME, MP.PROJECT, MP.DISPLAY_DOCUMENT, MP.EXPAND_YES_NO, MP.FIELDS, MP.TOP, MP.SORTBY, MP.WIDTH, MP.HEIGHT, MP.ROOT, MP.QUERY, MP.LINK, MP.DESCRIPTION_FIELDS, MP.REVISION
    };
    final static private MP[] rule6 = {
            MP.MODULE_NAME, MP.PROJECT, MP.DISPLAY_COUNT, MP.ROOT, MP.QUERY, MP.LINK, MP.DESCRIPTION_FIELDS, MP.REVISION
    };

    //WITH QUERY_NAME WITH REVISION
    final static private MP[] rule7 = {
            MP.MODULE_NAME, MP.PROJECT, MP.DISPLAY_TABLE, MP.EXPAND_YES_NO, MP.FIELDS, MP.TOP, MP.SORTBY, MP.WIDTH, MP.HEIGHT, MP.ROOT, MP.QUERY_NAME, MP.LINK, MP.DESCRIPTION_FIELDS, MP.REVISION
    };
    final static private MP[] rule8 = {
            MP.MODULE_NAME, MP.PROJECT, MP.DISPLAY_DOCUMENT, MP.EXPAND_YES_NO, MP.FIELDS, MP.TOP, MP.SORTBY, MP.WIDTH, MP.HEIGHT, MP.ROOT, MP.QUERY_NAME, MP.LINK, MP.DESCRIPTION_FIELDS, MP.REVISION
    };
    final static private MP[] rule9 = {
            MP.MODULE_NAME, MP.PROJECT, MP.DISPLAY_COUNT, MP.ROOT, MP.QUERY_NAME, MP.LINK, MP.DESCRIPTION_FIELDS, MP.REVISION
    };

    //WITH PROJECT/QUERY_NAME WITH REVISION
    final static private MP[] rule10 = {
            MP.MODULE_NAME, MP.PROJECT, MP.DISPLAY_TABLE, MP.EXPAND_YES_NO, MP.FIELDS, MP.TOP, MP.SORTBY, MP.WIDTH, MP.HEIGHT, MP.ROOT, MP.PROJECT_SLASH_QUERY_NAME, MP.LINK, MP.DESCRIPTION_FIELDS, MP.REVISION
    };
    final static private MP[] rule11 = {
            MP.MODULE_NAME, MP.PROJECT, MP.DISPLAY_DOCUMENT, MP.EXPAND_YES_NO, MP.FIELDS, MP.TOP, MP.SORTBY, MP.WIDTH, MP.HEIGHT, MP.ROOT, MP.PROJECT_SLASH_QUERY_NAME, MP.LINK, MP.DESCRIPTION_FIELDS, MP.REVISION
    };
    final static private MP[] rule12 = {
            MP.MODULE_NAME, MP.PROJECT, MP.DISPLAY_COUNT, MP.ROOT, MP.PROJECT_SLASH_QUERY_NAME, MP.LINK, MP.DESCRIPTION_FIELDS, MP.REVISION
    };

    static final private List<MP[]> rules = new ArrayList<MP[]>();

    static {
        rules.add(rule1);
        rules.add(rule2);
        rules.add(rule3);
        rules.add(rule4);
        rules.add(rule5);
        rules.add(rule6);
        rules.add(rule7);
        rules.add(rule8);
        rules.add(rule9);
        rules.add(rule10);
        rules.add(rule11);
        rules.add(rule12);
    }

    static final private Set<MP> uniqueParameters = getUniqueParameters(rules);

    private boolean isDocumentWorkitems;

    private IProject project;
    private String name;
    private String query;
    private ModuleHelper moduleHelper;
    private Set<String> objectsPassedQuery;
    private Map<String, FieldProperty> fields;

    public ModuleWorkItemsMacroParser(XWikiContext context) {
        super(context, rules, uniqueParameters);
    }

    public IProject getProject() {
        return project;
    }

    public String getProjectId() {
        return (project != null) ? project.getId() : null;
    }

    public String getName() {
        return name;
    }

    public String getQuery() {
        return query;
    }

    public String getRoot() {
        return map.get(MP.ROOT);
    }

    public IModule getModule() {
        return moduleHelper.getModule();
    }

    public String getModuleLink(Map<String, String> parameters) {
        return moduleHelper.getModuleLink(parameters);
    }

    public String parseParameters(Collection<String> parameters) {
        col = parameters;
        utils.addParameterNameToValue(MP.MODULE_NAME.getName(), col);
        return parseParameters();
    }

    @Override
    public String parseParameters() {

        String error = super.parseParameters();
        if (error != null) {
            return error;
        }

        error = loadProject();
        if (error != null) {
            return error;
        }

        loadName();
        String revision = null;
        for (Object element : col) {
            String value = (String) element;
            if (value.startsWith("revision=")) { //$NON-NLS-1$
                revision = value.substring(9);
            }
        }
        moduleHelper = new ModuleHelper(trackerService,
                project, getName(), revision);

        error = loadQuery();
        if (error != null) {
            return error;
        }

        if (query != null) {
            objectsPassedQuery = getObjectPassedQuerry(query);
        }

        fields = fieldParser.getWorkItemFields(map, errors, false, true);
        if (!errors.isEmpty()) {
            return renderer.renderErrors(errors, macroText, forPdf);
        }

        return null;
    }

    private String loadQuery() {
        boolean hasQueryParameter = map.containsKey(MP.QUERY)
                || map.containsKey(MP.QUERY_NAME)
                || map.containsKey(MP.PROJECT_SLASH_QUERY_NAME);

        if (hasQueryParameter) {
            query = utils.getQuery(map, project, errors);
            if (query == null) {
                return renderer.renderErrors(errors, macroText, forPdf);
            }
            IModule module = moduleHelper.getModule();
            if (module == null || module.isUnresolvable() || module.isOldStyleModule()) {
                query = "(" + query + ") AND (module.id:\"" + getName() + "\") AND (project.id:\"" + getProjectId() + "\")"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
            } else {
                String moduleQuery = trackerService.getModuleManager().getModuleWorkItemsQuery(module.getProject(), module.getModuleLocation());
                query = "(" + query + ") AND " + moduleQuery; //$NON-NLS-1$ //$NON-NLS-2$ 

            }

        }

        return null;
    }

    private void loadName() {
        name = map.get(MP.MODULE_NAME);
        if (name.matches("(\\s)*@current(\\s)*")) { //$NON-NLS-1$
            name = context.getDoc().getName();
        }
    }

    private String loadProject() {
        if (map.containsKey(MP.PROJECT)) {
            project = projectService.getProject(map.get(MP.PROJECT));
        }

        if (project == null) {
            //search on current scope, but only if scope is project!
            project = utils.getCurrentProject(context);
            if (project == null) {
                return renderer.renderError(MP.PROJECT.getName(), Localization.getString("macro.general.parameterProjectIsNotSet"), macroText, forPdf); //$NON-NLS-1$
            }
        }
        return null;
    }

    @Override
    @SuppressWarnings("unchecked")
    public String parse(final Collection<String> col, final String macroText, final boolean forPdf) {
        ITransactionService txService = PlatformContext.getPlatform().lookupService(ITransactionService.class);
        boolean failed = true;
        boolean tx = txService.canBeginTx();
        if (tx) {
            txService.beginTx();
        }
        try {
            String parsed;
            try (InternalROTxContext context = new InternalROTxContext(!FieldReadDeniedContext.isPerFieldSecurityEnabled())) {
                parsed = parseImpl(col, macroText, forPdf);
            }

            failed = false;
            return parsed;
        } finally {
            if (tx) {
                try {
                    txService.endTx(failed);
                } catch (Exception ex) {
                    log.error(ex.getMessage(), ex);
                }
            }
        }
    }

    private String parseImpl(Collection<String> col, String macroText, boolean forPdf) {
        this.col = col;
        this.macroText = macroText;
        isDocumentWorkitems = macroText.contains("document-workitems:"); //$NON-NLS-1$
        this.forPdf = forPdf;
        Set<IPObject> objectsLeftDueHierarchy = new HashSet<IPObject>();

        try {

            utils.addDefaultParameter(MP.DISPLAY_DOCUMENT.getName(), "document", col); //$NON-NLS-1$

            String err = parseParameters();
            if (err != null) {
                return err;
            }

            boolean withLink = utils.showLink(map);

            List<TreeNode> tree = null;
            List<IPObject> list = Collections.EMPTY_LIST;

            String moduleName = getName();

            IModule module = getModule();

            String rev = map.get(MP.REVISION);

            String docLabel = Localization.getString("definition.document") + Localization.getString("definition.colon"); //$NON-NLS-1$ //$NON-NLS-2$
            String moduleLabel = Localization.getString("definition.module") + Localization.getString("definition.colon"); //$NON-NLS-1$ //$NON-NLS-2$

            String rootInfo = getRoot() != null ? " (root:" + getRoot() + ")" : ""; //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$

            String queryText = (isDocumentWorkitems ? docLabel + " " : moduleLabel + " ") + moduleName + rootInfo; //$NON-NLS-1$ //$NON-NLS-2$

            int originalSize = 0;

            String query = getQuery();
            boolean hasQuery = query != null;
            if (hasQuery) {
                queryText = query;
            }

            if (!module.isUnresolvable()) {

                tree = getStructuredTreeForModule(objectsLeftDueHierarchy);
                int[] sizeRef = new int[] { 0 };
                sizeOf(tree, sizeRef);
                originalSize = sizeRef[0];
                String restriction = map.get(MP.TOP);
                int top = DEFAULT_TOP;
                if ((restriction != null) && (restriction.length() > 0)) {
                    try {
                        top = Integer.parseInt(restriction);
                    } catch (NumberFormatException ignored) {
                        //
                    }
                }
                if (top < 0) {
                    top = DEFAULT_TOP;
                }
                if (top == 0) {
                    top = Integer.MAX_VALUE;
                }
                list = getListFromModuleTree(tree, objectsLeftDueHierarchy, top);
            }

            String moreLink = null;
            if (withLink) {
                Map<String, String> parameters = new HashMap<String, String>();
                parameters.put(IPage.TAB, IPage.TAB_TREE);
                parameters.put(IPage.TREE_DEPTH, "0"); //$NON-NLS-1$
                if (hasQuery) {
                    parameters.put(IPage.QUERY, queryText);
                }
                if (rev != null) {
                    parameters.put(IPage.REVISION, rev);
                }
                moreLink = getModuleLink(parameters);

            }

            if (map.containsKey(MP.DISPLAY_LIST)) {
                Map<String, FieldProperty> fields = getFields();
                utils.setWidthForFields(fields, null);
                return renderer.renderListOfPObjects(
                        list,
                        fields,
                        utils.getExpandMode(map),
                        utils.getPolarionServerURL(context),
                        null,
                        utils.getWidth(map),
                        utils.getHeight(map),
                        forPdf,
                        withLink,
                        context
                        );
            } else if (map.containsKey(MP.DISPLAY_COUNT)) {
                return renderer.getRenderedCount(originalSize, forPdf, withLink ? (utils.getPolarionServerURL(context) + moreLink) : null);
            } else if (map.containsKey(MP.DISPLAY_TABLE)) {
                Map<String, FieldProperty> fields = getFields();

                if (module.usesOutlineNumbering()) {
                    if (!map.containsKey(MP.FIELDS)) {
                        fields.remove(IUniqueObject.KEY_ID);
                        FieldProperty property = fields.get(IWorkItem.KEY_TITLE);
                        if (property != null) {
                            Map<String, String> fieldProperties = new HashMap<String, String>();
                            fieldProperties.put(IUniqueObject.KEY_ID, IWorkItem.KEY_TITLE);
                            property.props = fieldProperties;
                        }
                    } else {
                        String fieldsGroup = map.get(MP.FIELDS);
                        if (fieldsGroup != null) {
                            String[] fs = fieldsGroup.split("[,]"); //$NON-NLS-1$
                            if (fs != null && fs.length > 0) {
                                FieldProperty property = fields.get(fs[0]);
                                if (property != null) {
                                    Map<String, String> fieldProperties = new HashMap<String, String>();
                                    fieldProperties.put(IUniqueObject.KEY_ID, fs[0]);
                                    property.props = fieldProperties;
                                }
                            }
                        }
                    }
                } else {
                    FieldProperty property = fields.get(IUniqueObject.KEY_ID);
                    if (property != null) {
                        Map<String, String> fieldProperties = new HashMap<String, String>();
                        fieldProperties.put(IUniqueObject.KEY_ID, IUniqueObject.KEY_ID);
                        property.props = fieldProperties;
                    } else {
                        String fieldsGroup = map.get(MP.FIELDS);
                        if (fieldsGroup != null) {
                            String[] fs = fieldsGroup.split("[,]"); //$NON-NLS-1$
                            if (fs != null && fs.length > 0) {
                                property = fields.get(fs[0]);
                                if (property != null) {
                                    Map<String, String> fieldProperties = new HashMap<String, String>();
                                    fieldProperties.put(IUniqueObject.KEY_ID, fs[0]);
                                    property.props = fieldProperties;
                                }
                            }
                        }
                    }
                }

                utils.setWidthForFields(fields, null);

                return renderer.renderHierarchicTable(
                        fields,
                        macroText,
                        tree,
                        objectsLeftDueHierarchy,
                        originalSize,
                        queryText,
                        moreLink,
                        context,
                        null,
                        utils.getExpandMode(map),
                        utils.getWidth(map),
                        utils.getHeight(map),
                        forPdf,
                        withLink);
            } else if (map.containsKey(MP.DISPLAY_DOCUMENT)) {
                Set<String> doNotSetWidth = new HashSet<String>();
                if (forPdf) {
                    doNotSetWidth.add(IWorkItem.KEY_COMMENTS);
                }
                Map<String, FieldProperty> fields = fieldParser.getWorkItemFields(map, errors, true, true);
                Map<String, String> fieldProperties = new HashMap<String, String>();
                if (!errors.isEmpty()) {
                    return renderer.renderErrors(errors, macroText, forPdf);
                }

                if (!fields.containsKey(IWorkItem.KEY_TITLE)) {
                    Map<String, FieldProperty> newFields = new LinkedHashMap<String, FieldProperty>();
                    newFields.put(IWorkItem.KEY_TITLE, utils.new FieldProperty(FieldRenderType.DEFAULT, null, FieldParser.getDefaultWorkItemFieldProportion(IWorkItem.KEY_TITLE), null));
                    newFields.putAll(fields);
                    fields = newFields;
                }
                if (map.containsKey(MP.DESCRIPTION_FIELDS)) {
                    Map<String, FieldProperty> descFields = fieldParser.parseFields(map.get(MP.DESCRIPTION_FIELDS), errors, true);
                    for (String fieldName : descFields.keySet()) {
                        Map<String, FieldProperty> newFields = new LinkedHashMap<String, FieldProperty>();
                        fields.put(fieldName, utils.new FieldProperty(FieldRenderType.TEXT_DESC, null, FieldParser.getDefaultWorkItemFieldProportion(fieldName), null));
                        newFields.putAll(fields);
                        fields = newFields;
                        doNotSetWidth.add(fieldName);
                    }
                } else {
                    Map<String, FieldProperty> newFields = new LinkedHashMap<String, FieldProperty>();
                    fields.put(IWorkItem.KEY_DESCRIPTION, utils.new FieldProperty(FieldRenderType.TEXT_DESC, null, FieldParser.getDefaultWorkItemFieldProportion(IWorkItem.KEY_DESCRIPTION), null));
                    newFields.putAll(fields);
                    fields = newFields;
                    doNotSetWidth.add(IWorkItem.KEY_DESCRIPTION);
                }
                if (module.usesOutlineNumbering()) {
                    if (!map.containsKey(MP.FIELDS)) {
                        fields.remove(IUniqueObject.KEY_ID);
                    }
                } else {
                    if (!fields.containsKey(IUniqueObject.KEY_ID)) {
                        Map<String, FieldProperty> newFields = new LinkedHashMap<String, FieldProperty>();
                        newFields.put(IUniqueObject.KEY_ID, utils.new FieldProperty(FieldRenderType.IMGTXT, FieldParser.getDefaultWorkItemFieldPercentualWidth(IUniqueObject.KEY_ID), null, null));
                        newFields.putAll(fields);
                        fields = newFields;
                    } else {
                        Map<String, FieldProperty> newFields = new LinkedHashMap<String, FieldProperty>();
                        newFields.put(IUniqueObject.KEY_ID, fields.get(IUniqueObject.KEY_ID));
                        fields.remove(IUniqueObject.KEY_ID);
                        newFields.putAll(fields);
                        fields = newFields;
                    }
                    FieldProperty property = fields.get(IUniqueObject.KEY_ID);
                    if (property != null) {
                        fieldProperties.put(IUniqueObject.KEY_ID, IUniqueObject.KEY_ID);
                        property.props = fieldProperties;
                    }
                }

                utils.setWidthForFields(fields, doNotSetWidth);

                if (withLink) {
                    Map<String, String> parameters = new HashMap<String, String>();
                    if (hasQuery) {
                        parameters.put(IPage.QUERY, queryText);
                    }
                    if (moduleHelper.isClassicModule()) {
                        parameters.put(IPage.TAB, IPage.TAB_MULTIEDIT);
                    }
                    if (rev != null) {
                        parameters.put(IPage.REVISION, rev);
                    }
                    moreLink = moduleHelper.getModuleLink(parameters);
                } else {
                    moreLink = null;
                }

                return renderer.getRenderedDocument(
                        fields,
                        macroText,
                        list,
                        tree,
                        objectsLeftDueHierarchy,
                        originalSize,
                        queryText,
                        moreLink,
                        context,
                        null,
                        utils.getExpandMode(map),
                        utils.getWidth(map),
                        utils.getHeight(map),
                        forPdf,
                        withLink,
                        module);
            } else {
                return Localization.getString("macro.general.noDisplayParameter"); //shouldn't happen //$NON-NLS-1$
            }
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            errors.put("Error", Localization.getString("macro.general.parsingUnknownException") + e.getLocalizedMessage()); //$NON-NLS-1$//$NON-NLS-2$
            return renderer.renderErrors(errors, macroText, forPdf);
        }

    }

    public Map<String, FieldProperty> getFields() {
        return fields;
    }

    private void traverseDocument(TreeNode node, String root, List<TreeNode> result) {
        if (node != null) {
            if (root.equalsIgnoreCase(node.getObject().getLocalId().getObjectName())) {
                result.add(node);
            }
            if (node.getChildren() != null) {
                for (TreeNode childNode : node.getChildren()) {
                    traverseDocument(childNode, root, result);
                }
            }
        }
    }

    public List<TreeNode> getStructuredTreeForModule(Set<IPObject> objectsLeftDueHierarchy) {
        List<TreeNode> originalTree = TreeCreator.getInstance(new TreeQuery(getModule())).create();
        List<TreeNode> result = originalTree;
        final String root = getRoot();
        if (root != null) {
            result = new ArrayList<TreeNode>();
            for (TreeNode node : originalTree) {
                traverseDocument(node, root, result);
            }
        }

        if (objectsPassedQuery != null) {
            List<TreeNode> nodesToRemove = new ArrayList<TreeNode>();
            for (TreeNode rootNode : result) {
                //now mark or remove nodes, which didn't satisfy query
                deleteNode(rootNode, objectsPassedQuery, objectsLeftDueHierarchy, nodesToRemove);
            }
            for (TreeNode node : nodesToRemove) {
                if (node.getParent() != null) {
                    node.removeFromParent();
                } else {
                    result.remove(node);
                }
            }
        }

        return result;
    }

    private void sizeOf(List<TreeNode> tree, int[] sizeRef) {
        sizeRef[0] += tree.size();
        for (TreeNode n : tree) {
            sizeOf(n.getChildren(), sizeRef);
        }
    }

    private boolean deleteNode(TreeNode node, Set<String> objectsPassedQuery, Set<IPObject> objectsLeftDueHierarchy, List<TreeNode> nodesToRemove) {
        //should be deleted this node?
        boolean delete = !objectsPassedQuery.contains(node.getObject().getLocalId().setRevision(null).toString());
        boolean childsDeleted = true;

        for (TreeNode child : node.getChildren()) {
            if (!deleteNode(child, objectsPassedQuery, objectsLeftDueHierarchy, nodesToRemove)) {
                childsDeleted = false;
            }
        }
        if (delete) {
            if (childsDeleted) {
                //we will remove this node later
                nodesToRemove.add(node);
            } else {
                //we won't remove this node, cause has children which satisfied query, but we will mark it
                objectsLeftDueHierarchy.add(node.getObject());
            }
        }

        return delete && childsDeleted;
    }

    private List<IPObject> getListFromModuleTree(List<TreeNode> tree, final Set<IPObject> objectsLeftDueHierarchy, int limit) {
        List<IPObject> list = new ArrayList<IPObject>();
        getListFromModuleTree(tree, objectsLeftDueHierarchy, list, limit);
        return list;
    }

    private void getListFromModuleTree(List<TreeNode> tree, Set<IPObject> objectsLeftDueHierarchy, List<IPObject> result, int limit) {
        for (Iterator<TreeNode> i = tree.iterator(); i.hasNext();) {
            TreeNode node = i.next();
            IPObject o = node.getObject();
            if (result.size() < limit) {
                if (!objectsLeftDueHierarchy.contains(o)) {
                    result.add(o);
                }
                if (node.hasChildren()) {
                    getListFromModuleTree(new ArrayList<TreeNode>(node.getChildren()), objectsLeftDueHierarchy, result, limit);
                }
            } else {
                if (node.getParent() != null) {
                    node.removeFromParent();
                }
                i.remove();
            }
        }
    }

    @SuppressWarnings("unchecked")
    private Set<String> getObjectPassedQuerry(String query) {
        Set<String> res = new HashSet<String>();

        List<IPObject> queriesList = trackerService.queryWorkItems(query, null);
        for (IPObject o : queriesList) {
            res.add(o.getLocalId().toString());
        }

        return res;
    }
}
