/*
 * Copyright (C) 2004-2009 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2009 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.polarion.wiki.integration;

import org.jetbrains.annotations.NotNull;

import com.polarion.alm.reports.server.ReportsProvider;
import com.polarion.alm.reports.shared.ReportData;
import com.polarion.portal.shared.navigation.IScope;
import com.polarion.reina.web.shared.localization.Localization;
import com.polarion.wiki.integration.plans.HighchartMacroWrapper;
import com.xpn.xwiki.XWikiContext;

public final class HighchartReportMacro extends AbstractReportMacro {

    private static final String CONTENT_NOT_AVAILABLE = Localization.getString("macro.highchartReport.contentNotAvailable"); //$NON-NLS-1$

    @Override
    public String getLocaleKey() {
        return "macro.highchart-report"; //$NON-NLS-1$
    }

    @Override
    public String getName() {
        return "highchart-report"; //$NON-NLS-1$
    }

    @NotNull
    private static Integer convertSize(@NotNull String size) {
        try {
            return new Integer(size);
        } catch (Exception e) {
            return 0;
        }
    }

    @Override
    public String getReportContent(ReportData reportData, String width, String height, String action) {
        if (reportData.reportData != null) {
            String content = reportData.reportData;
            XWikiContext xContext = getXWikiContext(getParameters());
            return new HighchartMacroWrapper.JsRenderer(xContext, content, convertSize(height), convertSize(width)).render(false);
        } else {
            return CONTENT_NOT_AVAILABLE;
        }
    }

    @Override
    public boolean getReportData(IScope scope) throws Exception {
        ReportsProvider.getReportData(scope, getReportPath(), null, new String[0], getCallBack());
        return true;
    }

}
