package com.polarion.wiki.integration.link;

import org.radeox.macro.parameter.MacroParameter;

public class ProjectLink {

    private String alias;
    private String project;
    private boolean isThis;
    private boolean isAll;

    public ProjectLink(MacroParameter parameter) {
        setup(parameter);
    }

    private void setup(MacroParameter parameter) {
        String projectOrAlias = parameter.get(0);
        String project = parameter.get(1);
        String alias = null;

        if (project == null) {
            project = projectOrAlias;
        } else {
            alias = projectOrAlias;
        }

        if (project == null) {
            return;
        }

        if (contains(project, "@all")) {
            setAll(true);
        }

        if (contains(project, "@this")) {
            setThis(true);
        }

        if (isAll() == false && isThis() == false) {
            setProject(project);
        }

        setAlias(alias);
    }

    /**
     * If @this is present in link method will set the current project, nothing otherwise
     * @param currentProject
     */
    public void setCurrentProject(String currentProject) {
        if (isThis) {
            setProject(currentProject);
        }
    }

    private boolean contains(String source, String string) {
        return (source.indexOf(string) != -1);
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public boolean isAll() {
        return isAll;
    }

    public void setAll(boolean isAll) {
        this.isAll = isAll;
    }

    public boolean isThis() {
        return isThis;
    }

    public void setThis(boolean isThis) {
        this.isThis = isThis;
    }

    public String getProject() {
        return project;
    }

    public void setProject(String project) {
        this.project = project;
    }

}
