package com.polarion.wiki.integration.link;

public interface ILink
{
    // Fields
    String ITEM_DISPLAY = "display";
    String ITEM_FIELDS = "fields";
    String ITEM_PROJECT = "project";
    String ITEM_QUERY = "query";
    String ITEM_QUERY_NAME = "queryname";
    String ITEM_QUERY_NAME_UPPER = "queryName";
    String ITEM_SORTBY = "sortby";
    String ITEM_OUTPUT = "output";
    String ITEM_TABLEWIDTH = "tablewidth";
    String ITEM_TABLEHEIGTH = "tableheight";
    String ITEM_EXPAND = "expand";
    String ITEM_TOP = "top";
    String ITEM_ID = "id";

    //Separators
    String FIELD_TYPE_SEPARATOR = " as ";
    String FIELD_SEPARATOR = ",";

    //View types
    String FIELD_TYPE_TEXT = "text";
    String FIELD_TYPE_IMAGE = "image";
    String FIELD_TYPE_IMGTXT = "image-text";
    String FIELD_TYPE_TXTIMG = "text-image";
    String FIELD_TYPE_HIDDEN = "hidden";

    //Output type
    String FIELD_OUTPUT_SINGLE = "single";
    String FIELD_OUTPUT_LIST = "list";
    String FIELD_OUTPUT_TABLE = "table";
    String FIELD_OUTPUT_COUNT = "count";

    String EXPAND_YES = "yes";
    String EXPAND_NO = "no";

    String PAGE_NAME = "name";
    String PAGE_TITLE = "title";
    String PAGE_UPDATED = "updated";
    String PAGE_CREATED = "created";

    String getQuery();

    String getProject();

    String getOutputType();
}
