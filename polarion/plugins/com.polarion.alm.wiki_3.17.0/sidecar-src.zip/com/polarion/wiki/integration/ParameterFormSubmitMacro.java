package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.portal.server.HTMLBuilder;
import com.polarion.reina.web.shared.localization.Localization;
import com.polarion.wiki.integration.utils.MacroRenderer;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.xpn.xwiki.XWikiContext;

public class ParameterFormSubmitMacro extends BaseLocaleMacro {

    final private MacroUtils utils = MacroUtils.getInstance();

    @Override
    public void execute(Writer writer, MacroParameter params) throws IllegalArgumentException, IOException {
        Map<String, String> errors = new HashMap<String, String>();
        XWikiContext context = MacroUtils.getInstance().getXWikiContext(params);
        String compare = (String) context.get("compareMode"); //$NON-NLS-1$
        boolean isCompare = "1".equals(compare); //$NON-NLS-1$

        String macroText = "parameter-form-submit";

        String pdf = (String) context.get("pdf_generate"); //$NON-NLS-1$
        boolean isPDF = "1".equals(pdf) || "print".equals(context.getAction()) || "1".equals(context.get("documentLikeEditor"));
        boolean forPdf = utils.isPdfOutput(params.getContext());

//		String content = params.getContent();
//		if (content == null) {
//			content = "";
//		}

        if (!errors.isEmpty()) {
            writer.write(MacroRenderer.getInstance().renderErrors(errors, macroText, forPdf));
            return;
        }

        if (isPDF) {
            return;
        }

        HTMLBuilder builder = new HTMLBuilder();

//        builder.appendHTML(content);

        if (isCompare) {
            renderPlaceholder(builder, macroText);
        } else {
            String text = Localization.getString("form.documentsAndWiki.button.apply"); //$NON-NLS-1$
            String disabled = ""; //$NON-NLS-1$
            if ("preview".equals(context.getAction())) { //$NON-NLS-1$
                disabled = " onclick=\"alert('" + Localization.getString("macro.parameter-editor.applyDisabled") + "');return false;\""; //$NON-NLS-1$ //$NON-NLS-3$
            }
            builder.appendHTML("<input type=\"submit\" class=\"polarion-Button\" style=\"vertical-align:middle;width:60px;\" value=\"" + text + "\"" + disabled + "/>"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
        }

        writer.write(builder.toString());
    }

    private void renderPlaceholder(HTMLBuilder builder, String macroText) {
        builder.appendImage("/polarion/ria/images/wiki/macro.gif", null, null, macroText); //$NON-NLS-1$
    }

    @Override
    public String getLocaleKey() {
        return "macro.parameter.form.submit";
    }

}
