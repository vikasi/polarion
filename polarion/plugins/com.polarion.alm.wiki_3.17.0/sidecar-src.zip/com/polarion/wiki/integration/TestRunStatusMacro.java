package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.tracker.model.ITestRun;
import com.polarion.alm.ui.shared.wiki.ParameterNames;
import com.polarion.core.util.ObjectUtils;
import com.polarion.platform.persistence.IEnumOption;
import com.polarion.portal.server.HTMLBuilder;
import com.polarion.portal.server.PObjectDataProvider;
import com.polarion.portal.shared.IJSUIObject;
import com.polarion.portal.shared.JSEnumOption;
import com.polarion.reina.web.shared.html.HTMLConst;
import com.polarion.reina.web.shared.html.IHTMLBuilder;
import com.polarion.reina.web.shared.localization.Localization;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.util.Constants;
import com.xpn.xwiki.XWikiContext;

public class TestRunStatusMacro extends BaseLocaleMacro {

    private final MacroUtils utils = MacroUtils.getInstance();

    @Override
    public String getLocaleKey() {
        return "macro.testrun-status"; //$NON-NLS-1$
    }

    @Override
    public void execute(Writer writer, MacroParameter params) throws IllegalArgumentException, IOException {
        String projectAndId = null;
        if (params.getLength() > 0) {
            projectAndId = params.get(0);
        }
        Map<String, String> map = params.getParams();
        if (map.containsKey(ParameterNames.TESTRUN1)) {
            projectAndId = map.get(ParameterNames.TESTRUN1);
        }
        if (ParameterNames.VALUE_CURRENT.equals(projectAndId)) {
            projectAndId = null;
        }

        XWikiContext context = MacroUtils.getInstance().getXWikiContext(params);
        renderProperty(projectAndId, writer, context);
    }

    private void renderProperty(String projectAndId, Writer writer, XWikiContext context) throws IOException {
        if (ObjectUtils.emptyString(projectAndId) && !Constants.TEST_RUNS.equals(context.getDoc().getSpaceName())) {
            utils.renderError(Localization.getString("macro.testrun-property.pleaseSpecifyTestRun"), writer); //$NON-NLS-1$
            return;
        }
        ITestRun testRun = TestRunPropertyMacro.getTestRun(projectAndId, context);
        if (testRun.isUnresolvable()) {
            utils.renderError(Localization.getString("macro.testrun-property.testRunDoesNotExist"), writer); //$NON-NLS-1$
            return;
        }

        if (testRun.getStatus() == null) {
            return;
        }
        List<String> fields = new ArrayList<String>(Collections.singleton(ITestRun.KEY_STATUS));
        IJSUIObject transformed = PObjectDataProvider.transformInstance(testRun, fields, false, null, null, true, false, null);

        String agent = context.getRequest().getHeader("user-agent");
        boolean isMSIE = agent.contains("MSIE");

        IHTMLBuilder builder = new HTMLBuilder(true);
        JSEnumOption value = (JSEnumOption) transformed.getValue(ITestRun.KEY_STATUS);
        String style = createStyle(testRun, isMSIE);
        builder.appendElementStart(HTMLConst.DIV, null, style, null);
        builder.appendImage(value.getIconUrl(), null, isMSIE ? null : "padding-top:15px;padding-left:18px;", null);
        builder.appendHTML(HTMLConst.HTML_EDIV);

        writer.write(builder.toString().trim());
    }

    @SuppressWarnings("nls")
    public String createStyle(ITestRun testRun, boolean isMSIE) {
        String style = "width:52px;height:46px;";
        if (isMSIE) {
            style += "display:inline;padding:15px;padding-left:18px;";
        } else {
            style += "border-radius:6px;display:inline-block;";
        }
        String color = testRun.getStatus().getProperty(IEnumOption.PROPERTY_KEY_COLOR);
        if (!ObjectUtils.emptyString(color)) {
            style += "background-color:" + color + ";";
        }
        return style;
    }

    public boolean isNumber(String string) {
        return Pattern.compile("^[0-9]+$").matcher(string.trim()).find(); //$NON-NLS-1$
    }
}
