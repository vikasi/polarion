package com.polarion.wiki.integration.link;

import java.net.URI;

import com.polarion.wiki.integration.Restrictable;
import com.polarion.wiki.util.Constants;
import com.polarion.wiki.util.RequestParser;
import com.polarion.wiki.util.SpaceParser;
import com.xpn.xwiki.XWikiContext;

/**
 * Polarion wiki link
 * 
 * 
 * Example of valid polarion wiki links:
 * <ul>
 * <li>MyLinkName>MyProject/MySpace.MyPage#Anchor>_blank</li>
 * <li>MyLinkName|MyProject/MySpace.MyPage#Anchor|_blank</li>
 * </ul>
 * 
 * @version $Id: $
 */
public class PageLink implements Cloneable, Restrictable {

    private static final String EMPTY_STRING = "";

    /**
     * @see #getAlias()
     */
    private String alias;

    /**
     * @see #getProject()
     */
    private String project;

    /**
     * @see #getSpace()
     */
    private String space;

    /**
     * @see #getPage()
     */
    private String page;

    /**
     * @see #getURI()
     */
    private URI uri;

    /**
     * @see #getAnchor()
     */
    private String anchor;

    /**
     * @see #getInterWikiAlias()
     */
    private String interWikiAlias;

    /**
     * @see #getTarget()
     */
    private String target;

    /**
     * @see #isUsingPipeDelimiter()
     */
    private boolean isUsingPipeDelimiter;

    /**
     * @param alias
     *            see {@link #getAlias()}
     */
    public void setAlias(String alias) {
        this.alias = alias;
    }

    /**
     * @return the string which will be displayed to the user when the link is rendered or null if no alias has been specified (in that case the page name or the URI will be displayed. Example: "My
     *         Page"
     */
    public String getAlias() {
        return alias;
    }

    /**
     * @param target
     *            see {@link #getTarget()}
     */
    public void setTarget(String target) {
        this.target = target;
    }

    /**
     * @return the browser window in which the link should be opened into or null if not defined. This element corresponds to the HTML <code>target</code> attribute for the <code>a</code> element.
     *         It is used when rendering the link and defauts to opening the link in the current page. Example: "_self", "_blank".
     */
    public String getTarget() {
        return target;
    }

    /**
     * @param space
     *            see {@link #getSpace()}
     */
    public void setSpace(String space) {
        this.space = space;
    }

    /**
     * @return the wiki Space name in which the link points to or null if not defined (in that case the link points to the current space). Example: "Main"
     */
    public String getSpace() {
        return space;
    }

    public String getProject() {
        return project;
    }

    public void setProject(String project) {
        this.project = project;
    }

    /**
     * @param anchor
     *            see {@link #getAnchor()}
     */
    public void setAnchor(String anchor) {
        this.anchor = anchor;
    }

    /**
     * @return the anchor name pointing to an anchor defined in the referenced link or null if no anchor has been specified (in which case the link points to the top of the page). Note that in XWiki
     *         anchors are automatically created for titles. Example: "TableOfContentAnchor"
     */
    public String getAnchor() {
        return anchor;
    }

    /**
     * @param interWikiAlias
     *            see {@link #getInterWikiAlias()}
     */
    public void setInterWikiAlias(String interWikiAlias) {
        this.interWikiAlias = interWikiAlias;
    }

    /**
     * @return the <a href="http://en.wikipedia.org/wiki/InterWiki">Inter Wiki</a> alias to which the link is pointing to or null if not defined. Mappings between Inter Wiki aliases and actual
     *         locations are defined in the Inter Wiki Map. Example: "wikipedia"
     */
    public String getInterWikiAlias() {
        return interWikiAlias;
    }

    /**
     * @param page
     *            see {@link #getPage()}
     */
    public void setPage(String page) {
        this.page = page;
    }

    /**
     * @return the Wiki page pointed to by this link or null if the link is pointing to an external URI. Example: "Home".
     */
    public String getPage() {
        return page;
    }

    /**
     * @param uri
     *            see {@link #getURI()}
     */
    public void setURI(URI uri) {
        this.uri = uri;
    }

    /**
     * @return the URI this link is pointing to. Valid URIs are mailto links (Example: "mailto:john@smith.com") or URL (Example: "http://www.xwiki.org").
     */
    public URI getURI() {
        return uri;
    }

    /**
     * @return true if the link is using the Pipe symbol ("|") as its separator between alias, target and link name, or false if it's using the greater than symbol (">")
     */
    public boolean isUsingPipeDelimiter() {
        return isUsingPipeDelimiter;
    }

    /**
     * @param isUsingPipeDelimiter
     *            see {@link #isUsingPipeDelimiter()}
     */
    public void setUsePipeDelimiterSymbol(boolean isUsingPipeDelimiter) {
        this.isUsingPipeDelimiter = isUsingPipeDelimiter;
    }

    /**
     * @return a String representation of the link without alias nor target. Example: "Space.Home#anchor?param1=1"
     */
    private String getLinkName() {
        StringBuffer buffer = new StringBuffer();

        if (getProject() != null) {
            buffer.append(getProject());
            buffer.append('/');
        }

        if (getSpace() != null) {
            buffer.append(getSpace());
            buffer.append('.');
        }

        if (getPage() != null) {
            buffer.append(getPage());
        } else if (getURI() != null) {
            buffer.append(getURI().toString());
        }

        if (getAnchor() != null) {
            buffer.append('#');
            buffer.append(getAnchor());
        }

        if (getInterWikiAlias() != null) {
            buffer.append('@');
            buffer.append(getInterWikiAlias());
        }

        return buffer.toString();
    }

    /**
     * Append a delimiter symbol. See {@link #isUsingPipeDelimiter()}
     * 
     * @param buffer
     *            the buffer to append to
     */
    private void appendDelimiterSymbol(StringBuffer buffer) {
        if (isUsingPipeDelimiter()) {
            buffer.append('|');
        } else {
            buffer.append('>');
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see Object#toString()
     */
    @Override
    public String toString() {
        StringBuffer buffer = new StringBuffer();

        if (getAlias() != null) {
            buffer.append(getAlias());
            appendDelimiterSymbol(buffer);
        }

        buffer.append(getLinkName());

        if (getTarget() != null) {
            appendDelimiterSymbol(buffer);
            buffer.append(getTarget());
        }

        return buffer.toString();
    }

    /**
     * @return true if the link is external (ie it's not a link on the current local wiki) or false otherwise
     */
    public boolean isExternal() {
        return (getURI() != null);
    }

    /**
     * Perform a series of normalization steps on the link. The steps are:
     * <ul>
     * <li>if the link is not a URI and it doesn't have a page defined then make it point to Home</li>
     * <li>if the link is internal and doesn't have a space defined, fill it in with the current document's space name</li>
     * </ul>
     * 
     * @param currentSpace
     *            the space to use when no space has been defined in the link
     * @return the normalized link
     */
    public PageLink getNormalizedLink(String currentSpace) {
        PageLink normalizedLink;
        try {
            normalizedLink = (PageLink) clone();
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException("Failed to clone object [" + toString() + "]");
        }

        // If no page was specified, use Home
        if (!normalizedLink.isExternal() && (normalizedLink.getPage() == null || EMPTY_STRING.equals(normalizedLink.getPage()))) {
            normalizedLink.setPage(Constants.DEFAULT_PAGE);
        }

        // If no space was specified, use the current space
        if (!normalizedLink.isExternal() && (normalizedLink.getSpace() == null || EMPTY_STRING.equals(normalizedLink.getSpace()))) {
            normalizedLink.setSpace(currentSpace);
        }

        return normalizedLink;
    }

    @Override
    public int hashCode() {
        final int PRIME = 31;
        int result = 1;
        result = PRIME * result + ((alias == null) ? 0 : alias.hashCode());
        result = PRIME * result + ((anchor == null) ? 0 : anchor.hashCode());
        result = PRIME * result + ((page == null) ? 0 : page.hashCode());
        result = PRIME * result + ((project == null) ? 0 : project.hashCode());
        result = PRIME * result + ((space == null) ? 0 : space.hashCode());
        result = PRIME * result + ((target == null) ? 0 : target.hashCode());
        result = PRIME * result + ((uri == null) ? 0 : uri.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final PageLink other = (PageLink) obj;
        if (alias == null) {
            if (other.alias != null) {
                return false;
            }
        } else if (!alias.equals(other.alias)) {
            return false;
        }
        if (anchor == null) {
            if (other.anchor != null) {
                return false;
            }
        } else if (!anchor.equals(other.anchor)) {
            return false;
        }
        if (page == null) {
            if (other.page != null) {
                return false;
            }
        } else if (!page.equals(other.page)) {
            return false;
        }
        if (project == null) {
            if (other.project != null) {
                return false;
            }
        } else if (!project.equals(other.project)) {
            return false;
        }
        if (space == null) {
            if (other.space != null) {
                return false;
            }
        } else if (!space.equals(other.space)) {
            return false;
        }
        if (target == null) {
            if (other.target != null) {
                return false;
            }
        } else if (!target.equals(other.target)) {
            return false;
        }
        if (uri == null) {
            if (other.uri != null) {
                return false;
            }
        } else if (!uri.equals(other.uri)) {
            return false;
        }
        return true;
    }

    @Override
    public boolean isUnderRestriction(XWikiContext context)
    {
        if (!RequestParser.isDocumentPage(context.getDoc().getSpace())) {
            return false;
        }
        String currentProject = context.getDoc().getProject();
        String currentSpace = SpaceParser.getSpace(context.getDoc().getSpace());
        boolean isProjectRestricted = !(project == null || "".equals(project) || currentProject.equals(project));
        boolean isSpaceRestricted = !((space == null || "".equals(space)) && SpaceParser.DEFAULT_SPACE_NAME.equals(currentSpace) || SpaceParser.DEFAULT_SPACE_NAME.equals(space));

        return isProjectRestricted || isSpaceRestricted;
    }

}
