package com.polarion.wiki.integration;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.velocity.context.Context;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.wiki.integration.utils.MP;
import com.xpn.xwiki.XWikiContext;

public class CreatePageButtonMacro extends VelocityBasedMacro {
    private static final String MACRO_NAME = "create-page-button"; //$NON-NLS-1$

    private static class CreatePageButtonMacroParser extends
            ExtendedMacroParser {

        private static final MP[] RULE1 = new MP[] { MP.PREFIX,
                MP.TEMPLATE_PROJECT, MP.TEMPLATE_SPACE, MP.TEMPLATE_PREFIX,
                MP.TARGET_PROJECT, MP.TARGET_SPACE, MP.TEMPLATE, MP.LABEL };

        private static List<MP[]> RULES = new ArrayList<MP[]>();
        static {
            RULES.add(RULE1);
        }

        private static Set<MP> UNIQUE_PARAMETERS = getUniqueParameters(RULES);

        public CreatePageButtonMacroParser(
                @SuppressWarnings("rawtypes") XWikiContext context,
                MacroParameter parameter) {
            super(context, parameter, RULES, UNIQUE_PARAMETERS, MACRO_NAME);
            utils.addDefaultParameter(MP.TEMPLATE_PREFIX.getName(), "Template", col); //$NON-NLS-1$
            //utils.addDefaultParameter(MP.LABEL.getName(), "*Create Page*", col);
        }

    }

    @Override
    protected String getMacroName() {
        return MACRO_NAME;
    }

    @Override
    public String getLocaleKey() {
        return "macro.create-page-button"; //$NON-NLS-1$
    }

    @Override
    protected String getTemplateName() {
        return "create-page-button.vm"; //$NON-NLS-1$
    }

    @Override
    protected ExtendedMacroParser loadParser(MacroParameter param,
            XWikiContext<?, ?> context) {
        return new CreatePageButtonMacroParser(context, param);
    }

    @SuppressWarnings("nls")
    @Override
    protected void initializeContext(Context vcontext,
            XWikiContext<?, ?> context, ExtendedMacroParser parser) {

        vcontext.put("prefix", parser.getParameter(MP.PREFIX));

        vcontext.put("templateProject",
                getProjectParameter(parser, MP.TEMPLATE_PROJECT, context));
        vcontext.put("templateSpace",
                getSpace(context, parser, MP.TEMPLATE_SPACE));

        String templatePrefix = parser.getParameter(MP.TEMPLATE_PREFIX);
        if (templatePrefix != null) {
            templatePrefix = templatePrefix.toLowerCase(); // because indexed as lowercase (see in tracker-hivemodule.xml)
        }
        vcontext.put("templatePrefix", templatePrefix);
        vcontext.put("template",
                getJavaScriptParameter(parser.getParameter(MP.TEMPLATE)));

        vcontext.put("targetProject",
                getProjectParameter(parser, MP.TARGET_PROJECT, context));
        vcontext.put("targetSpace", getSpace(context, parser, MP.TARGET_SPACE));

        String label = parser.getParameter(MP.LABEL);
        vcontext.put("label", label == null ? "*Create Page*" : label);

    }

    private String getSpace(XWikiContext<?, ?> context,
            ExtendedMacroParser parser, MP parameter) {
        String space = parser.getParameter(parameter);
        if (space == null) {
            space = context.getDoc().getSpaceName();
        }
        return space;
    }

    private String getProjectParameter(ExtendedMacroParser parser,
            MP parameter, XWikiContext<?, ?> context) {
        String result = parser.getParameter(parameter);
        if (result == null) {
            result = utils.getCurrentProjectId(context);
        }

        if ("@global".equals(result)) { //$NON-NLS-1$
            result = null;
        }

        return getJavaScriptParameter(result);
    }

    private String getJavaScriptParameter(String value) {
        if (value == null) {
            return "null"; //$NON-NLS-1$
        } else {
            return "'" + value + "'"; //$NON-NLS-1$//$NON-NLS-2$
        }
    }

}
