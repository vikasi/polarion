package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.Collection;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.integration.utils.PagesMacroParser;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.util.Util;

public class PagesMacro extends BaseLocaleMacro
{

    final private MacroUtils utils = MacroUtils.getInstance();

    @Override
    public void execute(Writer writer, MacroParameter parameters)
            throws IllegalArgumentException, IOException {

        String result = null;
        XWikiContext context = utils.getXWikiContext(parameters);

        Collection<String> col = utils.getParameters(parameters);
        utils.addParameterNameToValue("project", col);
        String compare = (String) context.get("compareMode");

        PagesMacroParser parser = new PagesMacroParser(context);
        String macroText = utils.buildMacroTextFromParameters("pages", col);

        XWikiDocument o = context.getDoc();

        String rev = (String) context.get("revision");
        if (o != null && rev != null && compare == null) {
            rev = o.getVersion();
        }

        if (compare != null && compare.equalsIgnoreCase("1") || rev != null) {
            if (macroText != null) {
                macroText = utils.buildMacroTextFromParametersForCompare("pages", col);
                macroText = Util.encodeLinkInCompare(macroText);
                result = "<img src=\"/polarion/ria/images/wiki/macro_pages.gif\" title=\""
                        + macroText + "\"/>";
            }
        } else {

            String pdf = (String) context.get("pdf_generate");
            if (pdf == null || pdf.equalsIgnoreCase("0")) {
                result = parser.parse(col, macroText, false);
            } else {
                result = parser.parse(col, macroText, true);
            }
        }

        result = Util.contentEncode(result);
        writer.write(result);
    }

    @Override
    public String getLocaleKey() {
        return "macro.pages";
    }

}
