/*
 * Copyright (C) 2004-2011 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2011 Polarion Software
 * All Rights Reserved.    No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.    This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.projects.model.IProject;
import com.polarion.alm.projects.model.IUniqueObject;
import com.polarion.alm.tracker.IModuleManager;
import com.polarion.alm.tracker.ITestManagementService;
import com.polarion.alm.tracker.ITrackerService;
import com.polarion.alm.tracker.internal.model.ITestRunInternal;
import com.polarion.alm.tracker.model.IModule;
import com.polarion.alm.tracker.model.ITestRun;
import com.polarion.alm.ui.client.InvalidChars;
import com.polarion.alm.ui.shared.wiki.ParameterNames;
import com.polarion.core.util.FileHelper;
import com.polarion.core.util.ObjectUtils;
import com.polarion.core.util.collection.CollectionsUtil;
import com.polarion.platform.core.PlatformContext;
import com.polarion.platform.guice.internal.GuicePlatform;
import com.polarion.portal.server.HTMLBuilder;
import com.polarion.reina.web.shared.html.HTMLConst;
import com.polarion.reina.web.shared.html.IHTMLBuilder;
import com.polarion.reina.web.shared.localization.Localization;
import com.polarion.subterra.base.location.ILocation;
import com.polarion.subterra.base.location.Location;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.util.Constants;
import com.xpn.xwiki.XWikiContext;

/**
 * @author Jiri Banszel
 */
public class ExportTestsMacro extends BaseLocaleMacro {

    private static final String FILE_EXTENSION = "xlsx"; //$NON-NLS-1$

    final private static ITrackerService trackerService = PlatformContext.getPlatform().lookupService(ITrackerService.class);

    private ITestManagementService testService;

    final private MacroUtils utils = MacroUtils.getInstance();

    @SuppressWarnings("deprecation")
    public ExportTestsMacro() {
        GuicePlatform.getGlobalInjector().injectMembers(this);
    }

    @Override
    public String getLocaleKey() {
        return "macro.export-tests"; //$NON-NLS-1$
    }

    @Inject
    public void setTestCaseService(ITestManagementService testService) {
        this.testService = testService;
    }

    @Override
    public void execute(Writer writer, MacroParameter params) throws IllegalArgumentException, IOException {
        @SuppressWarnings("unchecked")
        Map<String, String> map = params.getParams();

        String testRunProjectAndId = map.get(ParameterNames.TESTRUN1);
        String query = map.get(ParameterNames.QUERY);
        String sort = map.get(ParameterNames.SORTBY);
        String documentSpaceAndName = map.get(ParameterNames.DOCUMENT);
        String template = map.get(ParameterNames.TEMPLATE);
        String label = map.get(ParameterNames.LABEL);
        String fileName = map.get(ParameterNames.FILE_NAME);

        @SuppressWarnings("rawtypes")
        XWikiContext context = MacroUtils.getInstance().getXWikiContext(params);

        if (ObjectUtils.emptyString(testRunProjectAndId) && !Constants.TEST_RUNS.equals(context.getDoc().getSpaceName())) {
            utils.renderError(Localization.getString("macro.export-tests.specifyTestRun"), writer); //$NON-NLS-1$
            return;
        }
        ITestRun testRun = TestRunPropertyMacro.getTestRun(testRunProjectAndId, context);
        if (testRun.isUnresolvable()) {
            utils.renderError(Localization.getString("macro.export-tests.testRunDoesNotExist"), writer); //$NON-NLS-1$
            return;
        }
        if (fileName != null) {
            String invalidFileNameMsg = validateFileName(fileName);
            if (invalidFileNameMsg != null) {
                utils.renderError(invalidFileNameMsg, writer);
                return;
            }
        }
        fileName = ensureFileName(fileName, testRun);

        IModule document = null;
        if (documentSpaceAndName != null) {
            document = getDocument(documentSpaceAndName, testRun.getProject());
            if (document == null || document.isUnresolvable()) {
                utils.renderError(Localization.getString("macro.export-tests.documentDoesNotExist"), writer); //$NON-NLS-1$
                return;
            }
        }
        if (document == null && testRun.getDocument() != null && !testRun.getDocument().isUnresolvable()) {
            document = testRun.getDocument();
        }

        if (label == null) {
            label = Localization.getString("macro.export-tests.label"); //$NON-NLS-1$
        }

        query = adjustQuery(query, testRun, document);
        if (sort == null) {
            sort = IUniqueObject.KEY_ID;
        }

        renderLink(testRun, query, sort, document, template, label, writer, disabledReason(testRun, context), fileName);
    }

    private String ensureFileName(String fileName, ITestRun testRun) {
        if (fileName == null) {
            fileName = testRun.getId() + "." + FILE_EXTENSION; //$NON-NLS-1$
        } else if (!FileHelper.getExtension(fileName).equalsIgnoreCase(FILE_EXTENSION)) {
            fileName = fileName + "." + FILE_EXTENSION; //$NON-NLS-1$
        }
        return fileName;
    }

    private String validateFileName(String fileName) {
        if (!InvalidChars.FILE.server().isValidName(fileName)) {
            return Localization.getString("macro.import-test-results.unsupportedCharactersInFileName", fileName); //$NON-NLS-1$
        }
        return null;
    }

    private String adjustQuery(String query, ITestRun testRun, IModule document) {
        if (document != null) {
            // document filter
            if (ObjectUtils.emptyString(query)) {
                return testRun.createFilterForNotExecutedTestCases();
            } else {
                return query;
            }
        } else {
            if (ObjectUtils.emptyString(query)) {
                return testRun.createQueryForNotExecutedTestCases();
            } else {
                List<String> projectIds = ((ITestRunInternal) testRun).getProjectIdsFromSpan();
                return "project.id:(" + CollectionsUtil.toString(projectIds, " ") + ") AND (" + query + ")"; //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
            }
        }
    }

    private String disabledReason(ITestRun testRun, XWikiContext context) {
        if (!testService.getPolicy().canExecuteTestsUsingExcel()) {
            return Localization.getString("permission.denied.executeTestRun.excelRoundTrip"); //$NON-NLS-1$
        }
        if (!testService.getPolicy().canExecuteTestRun(testRun)) {
            return testService.getPolicy().getCannotExecuteTestRunReason(testRun);
        }
        if (isInHistoryMode(context)) {
            return Localization.getString("macro.import-test-results.macroCannotBeUsedInHistoryMode"); //$NON-NLS-1$
        }
        return null;
    }

    private boolean isInHistoryMode(XWikiContext context) {
        return (String) context.get("revision") != null || "1".equals(context.get("compareMode")) || trackerService.getDataService().getCurrentBaselineRevision() != null; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    }

    private IModule getDocument(String documentSpaceAndName, IProject project) {
        ILocation location = Location.getLocation(documentSpaceAndName);
        if (location.getComponentCount() == 1) {
            location = IModuleManager.DEFAULT_SPACE_LOCATION.append(documentSpaceAndName);
        }
        IModuleManager moduleManager = trackerService.getModuleManager();
        return moduleManager.getModule(project, location);
    }

    private void renderLink(ITestRun testRun, String query, String sort, IModule document, String template, String label, Writer writer, String disabledReason, String fileName) throws IOException {
        IHTMLBuilder builder = new HTMLBuilder(true);
        if (disabledReason == null) {
            List<String> args = Arrays.asList(
                    testRun.getProject().getId(),
                    testRun.getId(),
                    query,
                    sort,
                    document != null ? document.getModuleLocation().getLocationPath() : null,
                    template,
                    fileName);
            String onclick = utils.buildJSCall("top.exportTests", args); //$NON-NLS-1$
            builder.appendHyperlinkStart((String) null, null, null, "cursor: pointer;", "onclick=\"" + utils.escapeValue(builder.escapeForAttribute(onclick)) + "\""); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
            builder.appendText(utils.escapeValue(label));
            builder.appendElementEnd(HTMLConst.A);
        } else {
            String tooltip = disabledReason;
            builder.appendElementStart(HTMLConst.SPAN, null, "color: gray;", " title=\"" + utils.escapeValue(builder.escapeForAttribute(tooltip)) + "\""); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
            builder.appendText(utils.escapeValue(label));
            builder.appendElementEnd(HTMLConst.SPAN);
        }
        writer.write(builder.toString());
    }

}
