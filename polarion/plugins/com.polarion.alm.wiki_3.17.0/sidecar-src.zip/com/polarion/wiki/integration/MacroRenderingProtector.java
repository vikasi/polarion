/*
 * Copyright (C) 2004-2013 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2013 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.polarion.wiki.integration;

import org.jetbrains.annotations.NotNull;

import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.render.PreTagSubstitution;

/**
 * This is temporary code, protecting rendered content from further Wiki rendering,
 * which messes up content in some cases related to special characters 
 * (e.g. strings containing " (", i.e. space followed by opening bracket).
 * See DPP-50795.
 * 
 * In the long run this should be replaced by some nicer solution.
 */
public class MacroRenderingProtector {

    @NotNull
    public static String protect(@NotNull XWikiContext<?, ?> xWikiContext, @NotNull String content) {
        return getPre2Substitution(xWikiContext).substitute(wrapToPreLevel2(content));
    }

    @NotNull
    private static String wrapToPreLevel2(@NotNull String content) {
        return "{" + PreTagSubstitution.PRE2_TAG + "}" + content + "{/" + PreTagSubstitution.PRE2_TAG + "}"; //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    }

    @NotNull
    private static PreTagSubstitution getPre2Substitution(@NotNull XWikiContext<?, ?> xWikiContext) {
        return (PreTagSubstitution) xWikiContext.get(PreTagSubstitution.PRE2_CONTEXT_VARIABLE_KEY);
    }

}
