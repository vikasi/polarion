package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.tracker.model.ITestRecord;
import com.polarion.alm.tracker.model.ITrackerProject;
import com.polarion.alm.tracker.model.IWikiPage;
import com.polarion.platform.core.PlatformContext;
import com.polarion.platform.persistence.IDataService;
import com.polarion.platform.persistence.IEnumOption;
import com.polarion.platform.persistence.IEnumeration;
import com.polarion.portal.shared.navigation.PortalService;
import com.polarion.subterra.base.data.model.TypeFactory;
import com.polarion.wiki.integration.TestRunResultsList.TestRunResults;
import com.polarion.wiki.integration.utils.MP;
import com.polarion.wiki.integration.utils.MacroParser;
import com.polarion.wiki.integration.utils.MacroRenderer;
import com.polarion.wiki.integration.utils.MacroRenderer.ItemTableModel;
import com.polarion.wiki.integration.utils.MacroRenderer.PageTableModel;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.integration.utils.MacroUtils.ExpandMode;
import com.polarion.wiki.integration.utils.MacroUtils.FieldProperty;
import com.polarion.wiki.integration.utils.PageQueryUtils;
import com.polarion.wiki.web.BaselineServlet;
import com.xpn.xwiki.XWikiContext;

@SuppressWarnings("nls")
public class TestRunsMacro extends BaseLocaleMacro {

    private static final String STATISTICS = "statistics."; //$NON-NLS-1$
    private static final String OWNER = "owner"; //$NON-NLS-1$
    private static final String ID = "id"; //$NON-NLS-1$
    private static final MacroUtils utils = MacroUtils.getInstance();
    private static final String EXECUTED_FIELD_ID = STATISTICS + "executed"; //$NON-NLS-1$

    private final class TestRunTableModel extends PageTableModel {
        private final TestRunsMacroParser parser;
        @SuppressWarnings("rawtypes")
        private TestRunResultsList testRunResultsList;

        private TestRunTableModel(Map<String, FieldProperty> fields,
                String title, List<IWikiPage> pages, int realSize,
                TestRunsMacroParser parser,
                @SuppressWarnings("rawtypes") XWikiContext context,
                MacroRenderer renderer) {
            renderer.super(fields, context, title, pages, realSize);
            this.parser = parser;

            String serverUrl = utils.getPolarionServerURL(context);
            testRunResultsList = new TestRunResultsList(
                    parser.getTestResultMap(), parser.getProject(), serverUrl,
                    null);

            for (IWikiPage page : pages) {
                testRunResultsList.addTestRun(getTestRunId(parser, page), null); //TODO
            }
        }

        @Override
        public String getItemName() {
            return "testrun";
        }

        @Override
        public String getTitle(boolean forPdf) {
            return super.getTitle(forPdf);
        }

        @Override
        public String getFieldName(String columnId) {
            if (ID.equals(columnId)) {
                return "Test Run Id";
            } else if (OWNER.equals(columnId)) {
                return "Owner";
            } else if (columnId.startsWith(STATISTICS)) {
                return "<img src=\"" + getResultIconUrl(columnId) + "\"/> " //$NON-NLS-1$ //$NON-NLS-2$
                        + getResultName(columnId);
            } else {
                return super.getFieldName(columnId);
            }
        }

        @Override
        public String getCellContent(int rowIndex, String columnId,
                boolean forPdf) {
            IWikiPage page = (IWikiPage) getRowElement(rowIndex);

            String result;
            if (ID.equals(columnId)) {
                String hash = PortalService.getPortal().createProjectWikiUrlHash(page.getProjectId(), page.getSpaceId(), page.getId(), BaselineServlet.getCurrentBaselineRevision(), null);
                String name = getTestRunId(parser, page);
                result = "<a  target=\"_top\" title=\"" + name + "\" href=\"/polarion/#" + hash + "\">" + //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
                        name + "</a>"; //$NON-NLS-1$
            } else if (OWNER.equals(columnId)) {
                result = super.getCellContent(rowIndex, "createdby", forPdf); //$NON-NLS-1$
            } else if (columnId.startsWith(STATISTICS)) {

                TestRunResults results = testRunResultsList
                        .getTestRunResults(rowIndex);

                if (EXECUTED_FIELD_ID.equals(columnId)) {
                    return results.renderExecuted(forPdf);
                } else {
                    String resultId = columnId.substring(STATISTICS.length());
                    return results.renderResult(resultId, forPdf);
                }

            } else {
                result = super.getCellContent(rowIndex, columnId, forPdf);
            }
            return result;
        }

        private String getTestRunId(final TestRunsMacroParser parser, IWikiPage page) {
            return page.getPageName().substring(parser.getPrefix().length());
        }

        private String getResultIconUrl(String fieldId) {
            if (EXECUTED_FIELD_ID.equals(fieldId)) {
                return "/polarion/ria/images/enums/req_status_implemented.gif"; //$NON-NLS-1$
            } else {
                String resultId = fieldId.substring(STATISTICS.length());
                return testRunResultsList.getResultIcon(resultId);
            }
        }

        private String getResultName(String fieldId) {
            if (EXECUTED_FIELD_ID.equals(fieldId)) {
                return "Executed";
            } else {
                String resultId = fieldId.substring(STATISTICS.length());
                return testRunResultsList.getResultName(resultId);
            }
        }

    }

    private static class TestRunsMacroParser extends MacroParser {

        private static final MP[] RULE1 = new MP[] { MP.QUERY, MP.TOP,
                MP.FIELDS, MP.PREFIX, MP.TEST_RESULT_ENUM, MP.SORTBY,
                MP.PROJECT, MP.SPACE_PAGES };
        private static final MP[] RULE2 = new MP[] { MP.TOP, MP.FIELDS,
                MP.PREFIX, MP.TEST_RESULT_ENUM, MP.SORTBY, MP.PROJECT,
                MP.SPACE_PAGES };

        private static final List<MP[]> RULES = new ArrayList<MP[]>(2);

        static {
            RULES.add(RULE1);
            RULES.add(RULE2);
        }

        private static final Set<MP> UNIQUE_PARAMETERS = getUniqueParameters(RULES);

        private String query;

        private ITrackerProject project;

        private String space;

        private Map<String, IEnumOption> resultOptions = new LinkedHashMap<String, IEnumOption>();

        private Map<String, FieldProperty> fields;

        private IDataService dataService = (IDataService) PlatformContext
                .getPlatform().lookupService(IDataService.class);

        public TestRunsMacroParser(MacroParameter parameter,
                @SuppressWarnings("rawtypes") XWikiContext context) {
            super(context, RULES, UNIQUE_PARAMETERS);
            col = utils.getParameters(parameter);
            macroText = utils
                    .buildMacroTextFromParameters("testruns", col); //$NON-NLS-1$

            utils.addDefaultParameter(MP.PREFIX.getName(), "TestRun_", col);
            utils.addDefaultParameter(MP.TEST_RESULT_ENUM.getName(),
                    ITestRecord.TEST_RESULT_ENUM_ID, col);

            utils.addParameterNameToValue(MP.QUERY.getName(), col);

        }

        @Override
        public String parseParameters() {

            String error = super.parseParameters();

            if (error == null) {

                loadProject();

                loadSpace();
                loadQuery();
                loadResultOptions();
                loadFields();

                if (errors.size() > 0) {
                    error = renderer.renderErrors(errors, macroText, forPdf);
                }
            }

            return error;
        }

        private void loadSpace() {
            space = map.get(MP.SPACE_PAGES);
            if (space == null) {
                space = context.getDoc().getSpaceName();
            }
        }

        private void loadProject() {
            String projectId = map.get(MP.PROJECT);
            if (projectId == null) {
                project = utils.getCurrentProject(context);
                if (project == null) {
                    errors.put("Current scope not project scope.",
                            "This macro can be only used in repository scope only, "
                                    + "if project parameter is used.");
                }
            } else {
                project = trackerService.getTrackerProject(projectId);
            }
        }

        protected void loadFields() {
            if (map.containsKey(MP.FIELDS)) {
                fields = fieldParser.parseFields(map.get(MP.FIELDS), errors,
                        false);
            } else {
                fields = fieldParser.parseFields("id,owner,statistics", errors, //$NON-NLS-1$
                        false);
            }
            if (fields.remove("statistics") != null) { //$NON-NLS-1$
                StringBuilder fieldString = new StringBuilder();
                fieldString.append(EXECUTED_FIELD_ID).append(","); //$NON-NLS-1$
                for (String fieldId : resultOptions.keySet()) {
                    fieldString.append(STATISTICS + fieldId).append(","); //$NON-NLS-1$
                }
                Map<String, FieldProperty> statisticFields = fieldParser
                        .parseFields(fieldString.toString(), errors, false);
                fields.putAll(statisticFields);
            }

            for (String fieldId : fields.keySet()) {
                if (!EXECUTED_FIELD_ID.equals(fieldId)
                        && fieldId.startsWith(STATISTICS)) {
                    String resultId = fieldId.substring(STATISTICS.length());
                    if (!resultOptions.containsKey(resultId)) {
                        errors.put(fieldId, resultId
                                + " is not a valid test result."); //$NON-NLS-1$
                    }
                }
            }
        }

        @SuppressWarnings("unchecked")
        private void loadResultOptions() {
            String testResultEnum = map.get(MP.TEST_RESULT_ENUM);
            IEnumeration resultEnum = dataService.getEnumerationForEnumId(
                    TypeFactory.getInstance().getEnumType(testResultEnum),
                    getProject().getContextId());
            for (IEnumOption option : (Collection<IEnumOption>) resultEnum
                    .getAllOptions()) {
                resultOptions.put(option.getId().toLowerCase(), option);
            }
        }

        protected void loadQuery() {
            String userQuery = PageQueryUtils.modifyQueryFields(map
                    .get(MP.QUERY));
            if (userQuery != null) {
                userQuery = userQuery.replaceAll(OWNER + ":", "author.id:"); //$NON-NLS-1$ //$NON-NLS-2$
            }

            query = "pageName:" + getPrefix() + "*"; //$NON-NLS-1$ //$NON-NLS-2$
            query += " AND project.id:\"" + project.getId() + "\""; //$NON-NLS-1$ //$NON-NLS-2$
            query += " AND space.id:\"" + getSpace() + "\""; //$NON-NLS-1$ //$NON-NLS-2$
            query += userQuery != null ? " AND (" + userQuery + ")" : ""; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

        }

        public String getPrefix() {
            return map.get(MP.PREFIX);
        }

        public String getPageQuery() {
            return query;
        }

        public Map<String, FieldProperty> getFields() {
            return fields;
        }

        public ITrackerProject getProject() {
            return project;
        }

        public Map<String, IEnumOption> getTestResultMap() {
            return resultOptions;
        }

        public String getSortBy() {
            String sortBy = map.get(MP.SORTBY);
            if (sortBy != null) {
                sortBy = sortBy.replaceAll("(~)?" + ID, "$1pageName").replaceAll(//$NON-NLS-1$ //$NON-NLS-2$
                        "(~)?" + OWNER, "$1author.name"); //$NON-NLS-1$ //$NON-NLS-2$
            }
            return PageQueryUtils.modifySortFields(sortBy);
        }

        public int getTop() {
            int top = Integer.MAX_VALUE;
            String topString = map.get(MP.TOP);
            if (topString != null && !topString.isEmpty()) {
                top = Integer.parseInt(topString);
            }
            return top;
        }

        public String getSpace() {
            return space;
        }

    }

    @Override
    public String getLocaleKey() {
        return "macro.testruns";
    }

    @Override
    public void execute(Writer writer, MacroParameter parameter)
            throws IllegalArgumentException, IOException {

        @SuppressWarnings("rawtypes")
        final XWikiContext context = utils.getXWikiContext(parameter);

        final TestRunsMacroParser parser = new TestRunsMacroParser(parameter,
                context);
        String parseResult = parser.parseParameters();
        if (parseResult == null) {
            IDataService dataService = (IDataService) PlatformContext.getPlatform().lookupService(IDataService.class);
            List<IWikiPage> pages = dataService.searchInstances(IWikiPage.PROTO, parser.getPageQuery(), parser.getSortBy());
            int originalSize = pages.size();
            pages = pages.subList(0, Math.min(originalSize, parser.getTop()));

            final MacroRenderer renderer = MacroRenderer.getInstance();

            ItemTableModel tableModel = new TestRunTableModel(
                    parser.getFields(), "Test Runs", pages, originalSize,
                    parser, context, renderer);

            writer.write(renderer.renderTable(null, context, ExpandMode.YES,
                    null, null, false, tableModel));
        } else {
            writer.write(parseResult);
        }
    }
}
