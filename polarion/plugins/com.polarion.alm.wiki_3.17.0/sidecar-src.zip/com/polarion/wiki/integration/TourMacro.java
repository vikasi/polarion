package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.core.util.logging.Logger;

public class TourMacro extends BaseLocaleMacro
{
    static Logger log = Logger.getLogger(TourMacro.class);

    @Override
    public void execute(Writer writer, MacroParameter parameter) throws IllegalArgumentException, IOException {

        String tour = parameter.get(0);
        if (tour != null) {
            if (log.isDebugEnabled()) {
                log.debug("tour:" + tour);
            }
        }
        writer.write("<div style=\"width:100%;\"><iframe scrolling='no' frameborder='0' id='tour' src='/polarion/tour' style='width:100%;border: 1px solid #aedd7b;margin: 0px' border='0' ></iframe></div>");
    }

    @Override
    public String getLocaleKey()
    {
        return "macro.tour";
    }

}
