package com.polarion.wiki.integration;

import java.net.URL;
import java.security.PrivilegedExceptionAction;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.security.auth.Subject;

import com.polarion.alm.projects.IProjectService;
import com.polarion.alm.projects.model.IProject;
import com.polarion.alm.projects.model.IUser;
import com.polarion.alm.tracker.ITrackerService;
import com.polarion.alm.tracker.SavedQuery;
import com.polarion.alm.tracker.model.IWorkItem;
import com.polarion.core.util.logging.Logger;
import com.polarion.platform.core.PlatformContext;
import com.polarion.platform.hivemind.EclipseHiveMindPlatform;
import com.polarion.platform.persistence.model.IPObject;
import com.polarion.platform.persistence.model.IPObjectList;
import com.polarion.platform.security.ISecurityService;
import com.polarion.wiki.integration.link.ILink;
import com.polarion.wiki.integration.link.ProjectLink;
import com.polarion.wiki.integration.link.UserLink;
import com.polarion.wiki.integration.link.WorkItemLink;
import com.polarion.wiki.svn.ISvnProvider;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.plugin.XWikiDefaultPlugin;

/**
 * Pluging for load WorkItems from project
 * Load project and WorkItem links
 */
public class IntegrationPlugin extends XWikiDefaultPlugin {
    static Logger log = Logger.getLogger(IntegrationPlugin.class);

    private ISecurityService securityService;
    private IProjectService projectService;
    private ITrackerService tracker;
    private XWikiContext context;
    private static long request_unicID = 0;
    private String urlPrefix;

    public IntegrationPlugin(String name, String className, XWikiContext context) {
        super(name, className, context);
        init(context);

        platformInit();
        serviceInit();
    }

    @Override
    public String getName() {
        return "integrationplugin";
    }

    @Override
    public void flushCache() {
    }

    @Override
    public void init(XWikiContext context) {
        super.init(context);
        this.context = context;
        URL url = context.getURL();
        urlPrefix = url.getProtocol() + "://" + url.getAuthority() + "/polarion";
    }

    public static synchronized long getUniqID() {
        if (request_unicID == Long.MAX_VALUE) {
            request_unicID = 0;
        }
        return request_unicID++;
    }

    public static String getUniqName() {
        Calendar cl = Calendar.getInstance();
        long id = cl.getTimeInMillis();
        return "dv_" + id + "_" + getUniqID();
    }

    public IPObjectList getUserList(UserLink userLink) {
        IPObjectList list = null;
        //try{
        if (userLink.getSelector().equalsIgnoreCase(ILink.ITEM_QUERY)) {
            list = projectService.searchUsers(userLink.getQuery());
        } else {
            if (userLink.getProject() == null || userLink.getProject().equals("") || userLink.getProject().equalsIgnoreCase(ISvnProvider.REPO_ROOT_AS_PROJECT_NAME)) {
                list = projectService.getUsers();
            } else {
                IProject project = projectService.getProject(userLink.getProject());
                list = projectService.getProjectUsers(project);
            }
        }
        /*}catch(Exception e){
        	log.error(e);
        }*/
        return list;
    }

    public Collection getRolesForUser(final IUser user, final String projectStr) {

        Subject subj = null;

        try {
            try {
                subj = securityService.getCurrentSubject();
            } catch (Exception e) {
                log.error("Can't get subject while getRolesForUser: " + e.getMessage());
            }

            return (Collection) securityService.doAsUser(subj, new PrivilegedExceptionAction() {

                @Override
                public Object run() throws Exception {

                    Collection roles = null;
                    if (projectStr == null || projectStr.equalsIgnoreCase(ISvnProvider.REPO_ROOT_AS_PROJECT_NAME)) {
                        roles = securityService.getRolesForUser(user.getId());
                    } else {
                        IProject project = projectService.getProject(projectStr);
                        roles = securityService.getRolesForUser(user.getId(), project.getContextId());
                    }
                    return roles;
                }
            });

        } catch (Exception e) {
            log.error("Exception getRolesForUser: " + e.getMessage());
            return Collections.EMPTY_LIST;
        }

    }

    /*
     * return IWorkItems array from macros. 
     * load IWorkItems use platform search
    */
    public IWorkItem[] getLinkItemArray(WorkItemLink workItemLink) throws Exception {
        // PBO modify to ajax
        if (!workItemLink.getItem().equalsIgnoreCase(ILink.ITEM_QUERY)) {
            return getLinkItemArray(workItemLink.getProject(), workItemLink.getItem(), workItemLink.getAlias(), workItemLink);
        } else {
            return getLinkItemByQueryArray(workItemLink);
        }
    }

    /**
     * @param workItemLink - macros information
     * @return get query and load array IWorkItems
     */
    public IWorkItem[] getLinkItemByQueryArray(WorkItemLink workItemLink) throws Exception {

        String query = workItemLink.getQuery();
        if (query.startsWith("\"") && query.endsWith("\""))
        {
            query = query.substring(1, query.length() - 1);
        }
        query = query.replaceAll("&#35;", "#");
        query = query.replaceAll("&#93;", "]");
        query = query.replaceAll("&#91;", "[");

        return getItemFromQuery(workItemLink.getQueryProject(), "(" + query + ")", workItemLink.getSortBy(), workItemLink.getTop(), workItemLink);
    }

    /**
     * @param project - project name
     * @param item    - WorkItem name
     * @param alias   - always ""
     * @param workItemLink - macros information
     * load array for single WorkItem 
     */
    public IWorkItem[] getLinkItemArray(String project, String item, String alias, WorkItemLink workItemLink) throws Exception {
        if (item == null) {
            return null;
        }

        String checkedproject = project.trim();
        String checkeditem = item.trim();

        IWorkItem[] workItemArray = getItem(checkedproject, checkeditem, workItemLink.getSortBy(), workItemLink.getTop(), workItemLink);

        if (workItemArray == null) {
            return null;
        }

        if (workItemArray.length > 1 && workItemLink.getOutputType().equalsIgnoreCase(ILink.FIELD_OUTPUT_SINGLE))
        {
            workItemLink.setOutputTypeTable();
            workItemLink.setExpand(true);
        }
        return workItemArray;
    }

    /**
     * @param  project name
     * @return real project name
     */
    public String getRealProject(final String projectName) {
        Subject subj = null;

        try {
            try {
                subj = securityService.getCurrentSubject();
            } catch (Exception e) {
                log.error("Can't get subject while getProjectsLinksList: " + e.getMessage());
            }

            return (String) securityService.doAsUser(subj, new PrivilegedExceptionAction() {

                @Override
                public Object run() throws Exception {
                    IProject realProject = projectService.getProject(projectName);
                    return realProject.getId();
                }
            });

        } catch (Exception e) {
            log.error("Exception getProjectsLinksList: " + e.getMessage());
            return "Project not found";
        }
    }

    /**
     * @param projectLink
     * @return link to the project
     */
    public String getProjectLink(ProjectLink projectLink) {
        return getProjectLink(projectLink.getProject(), projectLink.getAlias());
    }

    public String getProjectLink(final String project, final String alias) {
        Subject subj = null;

        try {
            try {
                subj = securityService.getCurrentSubject();
            } catch (Exception e) {
                log.error("Can't get subject while getProjectsLinksList: " + e.getMessage());
            }

            return (String) securityService.doAsUser(subj, new PrivilegedExceptionAction() {

                @Override
                public Object run() throws Exception {
                    IProject realProject = getProject(project);
                    return "<a target=\"_blank\" href=\"" + urlPrefix + "/#/project/" + realProject.getId()
                            + "\">" + ((alias == null) ? realProject.getName() : alias) + "</a>";
                }
            });

        } catch (Exception e) {
            log.error("Exception getProjectsLinksList: " + e.getMessage());
            return "Project not found";
        }
    }

    /**
     * @param project name
     * @param IWorkItem
     * return link for the WorkItem
     */
    public String getWorkItemLink(final String project, final String alias, final IWorkItem item)
    {
        String url = "";
        try {
            if (project != null && !project.equalsIgnoreCase("")) {
                return url + "/polarion/#/project/" + project + "/workitem/?id=" + item.getId();
            } else {
                return url + "/polarion/#/workitem/?id=" + item.getId();
            }
        } catch (Exception e)
        {
            return url + "/polarion/#";
        }
    }

    public String getWorkItemMore(final String project, final String alias, final String query)
    {
        String url = "";

        if (project != null && !project.equalsIgnoreCase("")) {
            return url + "/polarion/#/project/" + project + "/workitems?query=" + query;
        } else {
            return url + "/polarion/#/workitems?query=" + query;
        }
    }

    public String getWorkItemSingle(final String project, final String alias, final String id)
    {
        String url = "";

        if (project != null && !project.equalsIgnoreCase("")) {
            return url + "/polarion/#/project/" + project + "/workitem/?id=" + id;
        } else {
            return url + "/polarion/#/workitem/?id=" + id;
        }

    }

    public String getWorkItemLinkPdf(final String project, final String alias, final IWorkItem item)
    {
        String url = getMainURL();
        try {
            if (project != null && !project.equalsIgnoreCase("")) {
                return url + "polarion/#/project/" + project + "/workitem/?id=" + item.getId();
            } else {
                return url + "polarion/#/workitem/?id=" + item.getId();
            }
        } catch (Exception e)
        {
            return url + "polarion/#";
        }
    }

    public String getWorkItemMorePdf(final String project, final String alias, final String query)
    {
        String url = getMainURL();

        if (project != null && !project.equalsIgnoreCase("")) {
            return url + "polarion/#/project/" + project + "/workitems?query=" + query;
        } else {
            return url + "polarion/#/workitems?query=" + query;
        }
    }

    public String getWorkItemSinglePdf(final String project, final String alias, final String id)
    {
        String url = getMainURL();

        if (project != null && !project.equalsIgnoreCase("")) {
            return url + "polarion/#/project/" + project + "/workitem/?id=" + id;
        } else {
            return url + "polarion/#/workitem/?id=" + id;
        }

    }

    private String getMainURL()
    {
        String url = context.getURLFactory().getURL();
        return url;
    }

    /**
     * @return all projects in SVN
     */
    public String[] getProjectsList() {
        Subject subj = null;

        try {
            try {
                subj = securityService.getCurrentSubject();
            } catch (Exception e) {
                log.error("Can't get subject while getProjectsList: " + e.getMessage());
            }

            return (String[]) securityService.doAsUser(subj, new PrivilegedExceptionAction() {

                @Override
                public Object run() throws Exception {
                    IPObjectList Projects = selectProjects();
                    String IntProjectsList[] = new String[Projects.size()];

                    int i = 0;

                    for (Iterator iter = Projects.iterator(); iter.hasNext(); i++) {
                        try {
                            IProject iproject = (IProject) iter.next();
                            IntProjectsList[i] = iproject.getName();
                        } catch (Exception e) {
                            log.error("Exception in Polarion project: " + e.getMessage());
                        }
                    }

                    return IntProjectsList;
                }
            });
        } catch (Exception e) {
            log.error("Exception getProjectsList: " + e.getMessage());
            return null;
        }
    }

    /**
     * @return links for all projects in SVN
     */
    public String[] getProjectsLinksList() {
        Subject subj = null;

        try {
            try {
                subj = securityService.getCurrentSubject();
            } catch (Exception e) {
                log.error("Can't get subject while getProjectsLinksList: " + e.getMessage());
            }

            return (String[]) securityService.doAsUser(subj, new PrivilegedExceptionAction() {

                @Override
                public Object run() throws Exception {
                    IPObjectList Projects = selectProjects();
                    String IntProjectsList[] = new String[Projects.size()];

                    int i = 0;

                    for (Iterator iter = Projects.iterator(); iter.hasNext(); i++) {
                        try {
                            IProject iproject = (IProject) iter.next();
                            IntProjectsList[i] = "<a target=\"_blank\" href=\"/polarion/#/project/" + iproject.getId()
                                    + "\">" + iproject.getName() + "</a>";
                        } catch (Exception e) {
                            log.error("Exception in Polarion project: " + e.getMessage());
                        }
                    }

                    return IntProjectsList;
                }
            });
        } catch (Exception e) {
            log.error("Exception getProjectsLinksList: " + e.getMessage());
            return null;
        }
    }

    /**
     * @param project name
     * @param query
     * @param sortBy
     * @return IWorkItems use query string
     */
    @SuppressWarnings("unchecked")
    public IWorkItem[] getItemFromQuery(final String projectName, final String query, final String sortBy, final int top, final WorkItemLink workItemLink) throws Exception {
        Subject subj = null;

        try {
            try {
                subj = securityService.getCurrentSubject();
            } catch (Exception e) {
                log.error("Can't get subject while getItemsList: " + e.getMessage());
            }

            return (IWorkItem[]) securityService.doAsUser(subj, new PrivilegedExceptionAction() {

                @Override
                public Object run() throws Exception {

                    List<IPObject> wiList = null;

                    if (projectName != null /*&& query.indexOf(":") != -1*/)
                    {
                        IProject realProject = projectService.getProject(projectName);
                        String projectQuery = IWorkItem.KEY_PROJECT + ".id:\"" + realProject.getId() + "\"";
                        wiList = (tracker.queryWorkItems(query + " AND " + projectQuery, null));
                        //XXX dedug info 
                        log.info("QUERY-1: " + query + " AND " + projectQuery + "SIZE RESULT: " + (wiList != null ? wiList.size() : "NULL!!!"));
                        //wiList = tracker.queryWorkItems(realProject, query, sortBy);
                    }
                    else //if (query.indexOf(":") != -1)
                    {
                        wiList = tracker.queryWorkItems(query, sortBy);
                        //XXX dedug info 
                        log.info("QUERY-2: " + query + "SIZE RESULT: " + (wiList != null ? wiList.size() : "NULL!!!"));

                    }

                    int return_rec = top;
                    if (wiList.size() < top || top == 0) {
                        return_rec = wiList.size();
                    }

                    if (workItemLink != null) {
                        workItemLink.setTotal(wiList.size());
                    }

                    IWorkItem IntProjectsList[] = new IWorkItem[return_rec];

                    int i = 0;

                    for (Iterator iter = wiList.iterator(); iter.hasNext(); i++) {
                        IWorkItem workItem = (IWorkItem) iter.next();
                        try {
                            if (i == return_rec) {
                                break;
                            }
                            IntProjectsList[i] = workItem;

                        } catch (Exception e) {
                            log.error("Exception in Polarion work item: " + e.getMessage());
                            IntProjectsList[i] = null;
                        }
                    }

                    if (IntProjectsList.length > 0) {
                        return IntProjectsList;
                    }

                    IProject realProject = projectService.getProject(projectName);
                    // search in saved query
                    List queryList = (tracker.getSavedQueriesManager()).getSavedQueries(realProject, tracker.getTrackerUser(securityService.getCurrentUser()));
                    for (int j = 0; j < queryList.size(); j++)
                    {
                        if (((SavedQuery) queryList.get(j)).name.equalsIgnoreCase(query))
                        {
                            String savedQuery = ((SavedQuery) queryList.get(j)).query;
                            if (workItemLink != null) {
                                workItemLink.setSavedQuery(savedQuery);
                            }
                            wiList = tracker.queryWorkItems(realProject, savedQuery, sortBy);
                            //XXX dedug info 
                            log.info("QUERY-3: " + savedQuery + "SIZE RESULT: " + (wiList != null ? wiList.size() : "NULL!!!"));
                            break;
                        }
                    }

                    i = 0;

                    return_rec = top;
                    if (wiList.size() < top || top == 0) {
                        return_rec = wiList.size();
                    }

                    if (workItemLink != null) {
                        workItemLink.setTotal(wiList.size());
                    }
                    IWorkItem IntProjectsList_query[] = new IWorkItem[return_rec];
                    for (Iterator iter = wiList.iterator(); iter.hasNext(); i++) {
                        IWorkItem workItem = (IWorkItem) iter.next();
                        try {
                            if (i == return_rec) {
                                break;
                            }
                            IntProjectsList_query[i] = workItem;

                        } catch (Exception e) {
                            log.error("Exception in Polarion work item: " + e.getMessage());
                            IntProjectsList_query[i] = null;
                        }
                    }

                    return IntProjectsList_query;

                }
            });
        } catch (Exception e) {
            log.error("Exception getItemFromQuery: " + e.getMessage());
            throw new Exception(e);
        }
    }

    /**
     * @param project name
     * @return WorkItems from project
     */
    @SuppressWarnings("unchecked")
    public String[] getItemsList(final String projectName) {
        Subject subj = null;

        try {
            try {
                subj = securityService.getCurrentSubject();
            } catch (Exception e) {
                log.error("Can't get subject while getItemsList: " + e.getMessage());
            }

            return (String[]) securityService.doAsUser(subj, new PrivilegedExceptionAction() {

                @Override
                public Object run() throws Exception {
                    IProject realProject = projectService.getProject(projectName);
                    String projectQuery = IWorkItem.KEY_PROJECT + ".id:\"" + realProject.getId() + "\"";
                    List<IPObject> wiList = tracker.queryWorkItems(projectQuery, null);
                    //IPObjectList wiList = tracker.queryWorkItems(project, null, null);
                    //XXX dedug info 
                    log.info("QUERY-4: " + projectQuery + "SIZE RESULT: " + (wiList != null ? wiList.size() : "NULL!!!"));

                    String IntProjectsList[] = new String[wiList.size()];

                    int i = 0;

                    for (Iterator iter = wiList.iterator(); iter.hasNext(); i++) {
                        IWorkItem workItem = (IWorkItem) iter.next();
                        try {
                            IntProjectsList[i] = workItem.getId();
                        } catch (Exception e) {
                            log.error("Exception in Polarion work item: " + e.getMessage());
                            IntProjectsList[i] = workItem.toString();
                        }
                    }

                    return IntProjectsList;
                }
            });
        } catch (Exception e) {
            log.error("Exception getItemsList: " + e.getMessage());
            return null;
        }
    }

    /**
     * @param workItemLink macros info
     * @return single IWorkItem from macros 
     */
    public IWorkItem[] getItem(WorkItemLink workItemLink) {
        return getItem(workItemLink.getProject(), workItemLink.getItem(), workItemLink.getSortBy(), workItemLink.getTop(), workItemLink);
    }

    @SuppressWarnings("unchecked")
    public IWorkItem[] getItem(final String projectName, final String item, final String sortBy, final int top, final WorkItemLink workItemLink) {
        Subject subj = null;

        try {
            try {
                subj = securityService.getCurrentSubject();
            } catch (Exception e) {
                log.error("Can't get subject while getItemsList: " + e.getMessage());
            }

            return (IWorkItem[]) securityService.doAsUser(subj, new PrivilegedExceptionAction() {

                @Override
                public Object run() throws Exception {
                    IProject realProject = projectService.getProject(projectName);
                    String query = item;
                    String projectQuery = IWorkItem.KEY_PROJECT + ".id:\"" + realProject.getId() + "\"";
                    List<IPObject> wiList = tracker.queryWorkItems("id:" + query + " AND " + projectQuery, null);
                    //XXX dedug info 
                    log.info("QUERY-5: " + query + " AND " + projectQuery + "SIZE RESULT: " + (wiList != null ? wiList.size() : "NULL!!!"));
                    //IPObjectList wiList = tracker.queryWorkItems(project, "id:"+query, null);
                    if (workItemLink != null) {
                        workItemLink.setTotal(wiList.size());
                    }

                    IWorkItem IntProjectsList[] = new IWorkItem[wiList.size()];

                    int i = 0;

                    for (Iterator iter = wiList.iterator(); iter.hasNext(); i++) {
                        IWorkItem workItem = (IWorkItem) iter.next();
                        try {
                            IntProjectsList[i] = workItem;

                        } catch (Exception e) {
                            log.error("Exception in Polarion work item: " + e.getMessage());
                            IntProjectsList[i] = null;
                        }
                    }

                    if (IntProjectsList.length > 0) {
                        return IntProjectsList;
                    }

                    // search in saved query
                    List queryList = (tracker.getSavedQueriesManager()).getSavedQueries(realProject, tracker.getTrackerUser(securityService.getCurrentUser()));
                    for (int j = 0; i < queryList.size(); j++)
                    {
                        if (((SavedQuery) queryList.get(j)).name.equalsIgnoreCase(query))
                        {
                            String savedQuery = ((SavedQuery) queryList.get(j)).query;
                            if (workItemLink != null) {
                                workItemLink.setSavedQuery(savedQuery);
                            }
                            wiList = tracker.queryWorkItems(realProject, savedQuery, sortBy);
                            //XXX dedug info 
                            log.info("QUERY-6: " + savedQuery + "SIZE RESULT: " + (wiList != null ? wiList.size() : "NULL!!!"));
                            break;
                        }
                    }

                    i = 0;

                    int return_rec = top;
                    if (wiList.size() < top || top == 0) {
                        return_rec = wiList.size();
                    }

                    if (workItemLink != null) {
                        workItemLink.setTotal(wiList.size());
                    }
                    IWorkItem IntProjectsList_query[] = new IWorkItem[return_rec];
                    for (Iterator iter = wiList.iterator(); iter.hasNext(); i++) {
                        IWorkItem workItem = (IWorkItem) iter.next();
                        try {
                            if (i == return_rec) {
                                break;
                            }
                            IntProjectsList_query[i] = workItem;

                        } catch (Exception e) {
                            log.error("Exception in Polarion work item: " + e.getMessage());
                            IntProjectsList_query[i] = null;
                        }
                    }

                    return IntProjectsList_query;
                }
            });
        } catch (Exception e) {
            log.error("Exception getItem: " + e.getMessage());
            return null;
        }
    }

    /**
     * @param project name
     * @return links for WorkItems in project
     */
    @SuppressWarnings("unchecked")
    public String[] getItemsLinksList(final String projectName) {
        Subject subj = null;

        try {
            try {
                subj = securityService.getCurrentSubject();
            } catch (Exception e) {
                log.error("Can't get subject while getItemsLinksList: " + e.getMessage());
            }

            return (String[]) securityService.doAsUser(subj, new PrivilegedExceptionAction() {

                @Override
                public Object run() throws Exception {
                    IProject realProject = projectService.getProject(projectName);
                    String projectQuery = IWorkItem.KEY_PROJECT + ".id:\"" + realProject.getId() + "\"";
                    List<IPObject> wiList = tracker.queryWorkItems(projectQuery, null);
                    //IPObjectList wiList = tracker.queryWorkItems(project, null, null);
                    //XXX dedug info 
                    log.info("QUERY-7: " + projectQuery + "SIZE RESULT: " + (wiList != null ? wiList.size() : "NULL!!!"));

                    String IntProjectsList[] = new String[wiList.size()];

                    int i = 0;

                    for (Iterator iter = wiList.iterator(); iter.hasNext(); i++) {
                        IWorkItem workItem = (IWorkItem) iter.next();
                        IntProjectsList[i] = "<a target='_blank' href='/polarion/#/projects/" + realProject.getId()
                                + "/workitem/" + workItem.getId() + "'>" + workItem.getId() + "</a>";
                    }

                    return IntProjectsList;
                }
            });
        } catch (Exception e) {
            log.error("Exception getItemsLinksList: " + e.getMessage());
            return null;
        }
    }

    private IPObjectList selectProjects() {
        return projectService.searchProjects(null);
    }

    private IProject getProject(String projectId) {
        return projectService.getProject(projectId);
    }

    private void platformInit() {
        if (!PlatformContext.isInitialized()) {
            EclipseHiveMindPlatform platform = new EclipseHiveMindPlatform();
            PlatformContext.initPlatform(platform);
        }
    }

    private void serviceInit() {
        securityService = (ISecurityService) PlatformContext.getPlatform().lookupService(ISecurityService.class);
        projectService = (IProjectService) PlatformContext.getPlatform().lookupService(IProjectService.class);
        tracker = (ITrackerService) PlatformContext.getPlatform().lookupService(ITrackerService.class);
    }

    @SuppressWarnings("unchecked")
    public int getWorkItemsCount(final String projectName, final String query)
    {
        Subject subj = null;
        try {
            subj = securityService.getSystemUserSubject();

            Integer count = (Integer) securityService.doAsUser(subj, new PrivilegedExceptionAction() {
                @Override
                public Object run() throws Exception {
                    List<IPObject> wiList = null;

                    if (projectName != null && !"".equals(projectName)) {
                        IProject project = projectService.getProject(projectName);
                        String projectQuery = IWorkItem.KEY_PROJECT + ".id:\"" + project.getId() + "\"";
                        wiList = tracker.queryWorkItems(query + " AND " + projectQuery, null);
                        //wiList = tracker.queryWorkItems(project, query, null);
                        //XXX dedug info 
                        log.info("QUERY-8: " + query + " AND " + projectQuery + "SIZE RESULT: " + (wiList != null ? wiList.size() : "NULL!!!"));
                    } else {
                        wiList = tracker.queryWorkItems(query, null);
                        //XXX dedug info 
                        log.info("QUERY-9: " + query + "SIZE RESULT: " + (wiList != null ? wiList.size() : "NULL!!!"));
                    }

                    return wiList == null ? new Integer(0) : new Integer(wiList.size());
                }
            });
            return count.intValue();
        } catch (Exception e) {
            log.error("Error while getWorkItemsCount: " + e.getMessage());
        }
        return -1;
    }
}
