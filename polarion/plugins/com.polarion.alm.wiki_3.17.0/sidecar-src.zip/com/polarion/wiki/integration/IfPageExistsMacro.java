/*
 * $Id$
 *
 * Copyright (C) 2004-2008 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2008 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.Map;

import org.radeox.api.engine.context.RenderContext;
import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.core.util.ObjectUtils;
import com.polarion.core.util.logging.Logger;
import com.polarion.subterra.base.location.ILocation;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.svn.ISvnProvider;
import com.polarion.wiki.svn.WikiSvnBaseStore;
import com.polarion.wiki.util.RequestParser;
import com.polarion.wiki.util.SpaceParser;
import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.render.XWikiRadeoxRenderEngine;

/**
 * 
 * @author Jiri Banszel
 * @version $Revision$ $Date$
 *
 */
public class IfPageExistsMacro extends BaseLocaleMacro {

    /* (non-Javadoc)
     * @see org.radeox.macro.LocaleMacro#getLocaleKey()
     */
    @Override
    public String getLocaleKey() {
        return "macro.if-page-exists";
    }

    /* (non-Javadoc)
     * @see org.radeox.macro.BaseMacro#execute(java.io.Writer, org.radeox.macro.parameter.MacroParameter)
     */
    @Override
    public void execute(Writer writer, MacroParameter params) throws IllegalArgumentException, IOException {
        boolean pageExists = false;

        RenderContext rcontext = params.getContext();
        XWikiRadeoxRenderEngine eg = (XWikiRadeoxRenderEngine) rcontext.getRenderEngine();
        XWikiContext context = eg.getContext();

        Map requestParams;
        try {
            requestParams = RequestParser.parseQuery(XWiki.getRequestURL(context.getRequest()).toString(), context);
        } catch (XWikiException e) {
            Logger.getLogger(this).error("Failed to parse request parameters", e);
            return;
        }
        String groupLocation = MacroUtils.getInstance().getCurrentGroupLocation(requestParams);

        // there can be no page at project group level
        if (ObjectUtils.emptyString(groupLocation)) {
            String page = params.get(0);
            if (page != null) {
                String projectId = MacroUtils.getInstance().getCurrentProjectId(context);
                String space = SpaceParser.getSpace(context.getDoc().getSpace());
                pageExists = pageExists(projectId, space, page, context);
            }
        }

        if (pageExists) {
            writer.append(params.getContent());
        }
    }

    private boolean pageExists(String projectId, String space, String page, XWikiContext context) {
        ISvnProvider svnProvider = ((WikiSvnBaseStore) context.getDoc().getStore()).getSvnProvider();
        String project = (projectId != null) ? projectId : ISvnProvider.REPO_ROOT_AS_PROJECT_NAME;
        ILocation location = svnProvider.getDocumentWikiLocation(project, space, page);
        String fullname = SpaceParser.getFullName(location);
        return context.getWiki().exists(fullname, context);
    }

}
