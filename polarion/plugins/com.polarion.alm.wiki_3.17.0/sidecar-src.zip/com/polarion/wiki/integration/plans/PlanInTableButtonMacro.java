/*
 * Copyright (C) 2004-2013 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2013 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.polarion.wiki.integration.plans;

import java.io.IOException;
import java.io.Writer;
import java.util.Map;

import org.jetbrains.annotations.NotNull;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.tracker.ITrackerService;
import com.polarion.alm.tracker.model.IPlan;
import com.polarion.alm.ui.server.plans.PlansUtil;
import com.polarion.alm.ui.server.wiki.macro.impl.PlainMacroImpl;
import com.polarion.platform.core.PlatformContext;
import com.polarion.portal.server.HTMLBuilder;
import com.polarion.reina.web.shared.html.HTMLConst;
import com.polarion.reina.web.shared.localization.Localization;
import com.polarion.wiki.integration.XWikiGwtMacro;

public class PlanInTableButtonMacro extends XWikiGwtMacro {

    public static final String MACRO_ID = "plan-open-in-table"; //$NON-NLS-1$

    @NotNull
    private static final ITrackerService trackerService = PlatformContext.getPlatform().lookupService(ITrackerService.class);

    @Override
    @NotNull
    protected String getMacroId() {
        return MACRO_ID;
    }

    @Override
    protected boolean hasLicense() {
        return trackerService.getTrackerPolicy().canUsePlans();
    }

    @Override
    public void execute(Writer writer, MacroParameter parameters) throws IllegalArgumentException, IOException {
        new DataRenderer(new Data(parameters)).render(writer);
    }

    private class Data extends MacroData {

        @NotNull
        final PlanInTableButtonMacroParameters parameters;

        Data(@NotNull MacroParameter inputParameters) {
            super(inputParameters);
            parameters = new PlanInTableButtonMacroParameters(macroContext, new PlainMacroImpl(getMacroText(inputParameters)));
        }

        @Override
        @NotNull
        public Map<String, String> getErrors() {
            return parameters.validate();
        }
    }

    class DataRenderer extends MacroDataRenderer<Data> {
        DataRenderer(final Data data) {
            super(data);
        }

        @Override
        @NotNull
        protected IMacroContentRenderer getContentRenderer() {
            final IPlan plan = data.parameters.getPlan();
            return new IMacroContentRenderer() {

                @Override
                public void render(HTMLBuilder builder) {
                    renderUrl(builder, plan);
                    renderOverview(builder, plan);
                }
            };
        }
    }

    private static void renderUrl(@NotNull HTMLBuilder builder, @NotNull IPlan plan) {
        String url = PlansUtil.getOpenInTableUrl(plan);
        String valuePart = "value=\"" + url + "\""; //$NON-NLS-1$//$NON-NLS-2$
        builder.appendElementStart(HTMLConst.DIV, null, null, "id=\"url\" " + valuePart); //$NON-NLS-1$
        builder.appendHTML(HTMLConst.HTML_EDIV);
    }

    private static void renderOverview(@NotNull HTMLBuilder builder, @NotNull IPlan plan) {
        String overview = Localization.getString("macro.plan-open-in-table.overview", String.valueOf(getPlannedItemCount(plan))); //$NON-NLS-1$
        String valuePart = "value=\"" + builder.escapeForAttribute(overview) + "\""; //$NON-NLS-1$//$NON-NLS-2$
        builder.appendElementStart(HTMLConst.DIV, null, null, "id=\"overview\" " + valuePart); //$NON-NLS-1$
        builder.appendHTML(HTMLConst.HTML_EDIV);
    }

    private static int getPlannedItemCount(@NotNull IPlan plan) {
        return plan.getResolvableItems().size();
    }
}
