package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;

import org.apache.velocity.VelocityContext;
import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.core.util.EscapeChars;
import com.polarion.platform.persistence.internal.PersistencePermission;
import com.polarion.portal.server.HTMLBuilder;
import com.polarion.reina.web.shared.localization.Localization;
import com.polarion.wiki.integration.utils.MacroRenderer;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.web.BaselineServlet;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.api.XWiki;

public class ParameterFormSaveMacro extends BaseLocaleMacro {

    final private MacroUtils utils = MacroUtils.getInstance();

    @Override
    public void execute(Writer writer, MacroParameter params) throws IllegalArgumentException, IOException {
        Map<String, String> errors = new HashMap<String, String>();
        XWikiContext context = MacroUtils.getInstance().getXWikiContext(params);
        String compare = (String) context.get("compareMode"); //$NON-NLS-1$
        boolean isCompare = "1".equals(compare); //$NON-NLS-1$

        String macroText = "parameter-form-save"; //$NON-NLS-1$

        String pdf = (String) context.get("pdf_generate"); //$NON-NLS-1$
        boolean isPDF = "1".equals(pdf) || "print".equals(context.getAction()) || "1".equals(context.get("documentLikeEditor")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
        boolean forPdf = utils.isPdfOutput(params.getContext());

        if (!errors.isEmpty()) {
            writer.write(MacroRenderer.getInstance().renderErrors(errors, macroText, forPdf));
            return;
        }

        if (isPDF) {
            return;
        }

        HTMLBuilder builder = new HTMLBuilder();

        if (isCompare) {
            renderPlaceholder(builder, macroText);
        } else {
            VelocityContext velocityContext = (VelocityContext) context.get("vcontext"); //$NON-NLS-1$
            XWiki xwiki = (XWiki) velocityContext.get("xwiki"); //$NON-NLS-1$
            String text = Localization.getString("macro.parameter-form-save.button.label"); //$NON-NLS-1$
            String disabled = ""; //$NON-NLS-1$
            String disabledMessage = null;

            if (!"view".equals(context.getAction()) || BaselineServlet.getCurrentBaselineRevision() != null) { //$NON-NLS-1$
                disabledMessage = Localization.getString("macro.parameter-form-save.message.saveDisabled"); //$NON-NLS-1$
            }
            if (!xwiki.hasPermission(PersistencePermission.ACTION_MODIFY)) {
                disabledMessage = Localization.getString("administration.workItems.tooltip.noPermission"); //$NON-NLS-1$
            }

            if (disabledMessage != null) {
                disabled = " onclick=\"alert('" + EscapeChars.forJavascriptString(disabledMessage) + "');return false;\""; //$NON-NLS-1$ //$NON-NLS-2$ 
            }

            builder.appendHTML("<input title=\"" + Localization.getString("macro.parameter-form-save.button.tooltip") + "\" type=\"submit\" name=\"saveAsDefault\"  class=\"polarion-Button\" style=\"vertical-align:middle;width:120px;\" value=\"" + text + "\"" + disabled + "/>"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
        }

        writer.write(builder.toString());
    }

    private void renderPlaceholder(HTMLBuilder builder, String macroText) {
        builder.appendImage("/polarion/ria/images/wiki/macro.gif", null, null, macroText); //$NON-NLS-1$
    }

    @Override
    public String getLocaleKey() {
        return "macro.parameter.form.save"; //$NON-NLS-1$
    }

}
