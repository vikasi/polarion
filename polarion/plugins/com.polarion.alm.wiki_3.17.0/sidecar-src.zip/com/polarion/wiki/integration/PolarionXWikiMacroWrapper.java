/*
 * Copyright (C) 2004-2013 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2013 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.Map;

import org.jetbrains.annotations.NotNull;
import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.server.ServerUiContext;
import com.polarion.alm.shared.api.utils.html.HtmlBuilderTargetSelector;
import com.polarion.alm.shared.render.RenderableUtil;
import com.polarion.alm.ui.server.wiki.macro.MacroContext;
import com.polarion.alm.ui.server.wiki.macro.PlainMacro;
import com.polarion.alm.ui.server.wiki.macro.PolarionWikiMacro;
import com.polarion.alm.ui.server.wiki.macro.impl.PlainMacroImpl;
import com.polarion.core.util.exceptions.UserFriendlyRuntimeException;
import com.polarion.core.util.logging.Logger;
import com.polarion.portal.server.HTMLBuilder;
import com.polarion.reina.web.shared.localization.Localization;
import com.polarion.wiki.integration.utils.MacroParameterValidationContextXWikiImpl;
import com.polarion.wiki.integration.utils.MacroRenderer;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.xpn.xwiki.XWikiContext;

public abstract class PolarionXWikiMacroWrapper<T extends PolarionWikiMacro> extends BaseLocaleMacro {

    @NotNull
    protected static final MacroRenderer renderer = MacroRenderer.getInstance();

    @Override
    public final String getLocaleKey() {
        return "macro." + getMacroId(); //$NON-NLS-1$
    }

    @NotNull
    protected abstract String getMacroId();

    @NotNull
    protected abstract T createMacro(@NotNull MacroContext context, @NotNull PlainMacro plainMacro);

    @Override
    public final void execute(final Writer writer, final MacroParameter params) throws IllegalArgumentException, IOException {
        XWikiContext<?, ?> xWikiContext = null;
        try {
            xWikiContext = MacroUtils.getInstance().getXWikiContext(params);
            MacroParameterValidationContextXWikiImpl context = new MacroParameterValidationContextXWikiImpl(xWikiContext);

            T macroImpl = createMacro(context, new PlainMacroImpl(getMacroText(params)));
            if (!macroImpl.hasLicense()) {
                writer.write(renderer.renderInaccessibleMessage(true, false));
                return;
            }
            if (!macroImpl.hasPermission()) {
                writer.write(renderer.renderInaccessibleMessage(false, true));
                return;
            }

            Map<String, String> errors = macroImpl.validate();
            if (!errors.isEmpty()) {
                writer.write(renderer.renderErrors(errors, getMacroTextForErrors(params), MacroUtils.getInstance().isPdfExport(xWikiContext)));
                return;
            }

            if (!macroImpl.isAvailableInCompare() && isInCompare(xWikiContext)) {
                writer.write(getMacroPlaceholder(params));
                return;
            }

            writer.write(renderMacroContent(xWikiContext, macroImpl));
        } catch (Exception e) {
            String message = ""; //$NON-NLS-1$
            if (e instanceof UserFriendlyRuntimeException) {
                message = e.getMessage();
            } else {
                Logger.getLogger(this).error("Exception in rendering the " + getMacroId() + " macro: ", e); //$NON-NLS-1$ //$NON-NLS-2$
                message = Localization.getString("macro.exception", getMacroId()); //$NON-NLS-1$
            }
            boolean pdfExport = MacroUtils.getInstance().isPdfExport(xWikiContext);
            writer.write(renderer.renderError(Localization.getString("definition.error"), message, getMacroTextForErrors(params), pdfExport)); //$NON-NLS-1$
        }
    }

    /**
     * @param xWikiContext 
     * @param macro
     * @return render html
     */
    @NotNull
    protected String renderMacroContent(@NotNull XWikiContext<?, ?> xWikiContext, @NotNull T macro) {
        HtmlBuilderTargetSelector<String> render = RenderableUtil.render(ServerUiContext.getInstance(), macro);
        if (shouldBeWrapedByPre2Level()) {
            return MacroRenderingProtector.protect(xWikiContext, render.forFrame().toString());
        } else {
            return render.oldWiki().toString();
        }
    }

    /**
     * Return true when macro will produce code that should not be after that processed by wiki.
     * Subclasses can override it.
     */
    protected boolean shouldBeWrapedByPre2Level() {
        return true;
    }

    @NotNull
    private String getMacroText(@NotNull MacroParameter parameters) {
        return MacroUtils.getInstance().buildMacroTextFromParametersSimple(getMacroId(), MacroUtils.getInstance().getParameters(parameters));
    }

    @NotNull
    private String getMacroTextForErrors(@NotNull MacroParameter parameters) {
        return MacroUtils.getInstance().buildMacroTextFromParameters2(getMacroId(), parameters);
    }

    private boolean isInCompare(@NotNull XWikiContext<?, ?> xWikiContext) {
        String compare = (String) xWikiContext.get("compareMode"); //$NON-NLS-1$
        return compare != null && compare.equalsIgnoreCase("1"); //$NON-NLS-1$
    }

    @SuppressWarnings("deprecation")
    @NotNull
    private String getMacroPlaceholder(@NotNull MacroParameter parameters) {
        MacroUtils utils = MacroUtils.getInstance();
        XWikiContext context = utils.getXWikiContext(parameters);

        HTMLBuilder builder = new HTMLBuilder(false, utils.isPdfExport(context));
        String macroText = getMacroText(parameters);
        builder.appendImage("/polarion/ria/images/wiki/macro.gif", null, null, macroText.substring(1, macroText.length() - 1)); //$NON-NLS-1$ 
        return builder.toString();
    }
}
