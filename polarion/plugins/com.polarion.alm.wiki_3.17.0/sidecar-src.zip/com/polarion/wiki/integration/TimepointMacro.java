package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.tracker.model.ITimePoint;
import com.polarion.alm.tracker.model.ITrackerProject;
import com.polarion.wiki.integration.utils.MacroUtils;

/**
 * Renders nearest time point of current project.<p>
 * 
 * Syntax:
 * <pre>
 *   {timepoint}
 * </pre> 
 *
 */
public class TimepointMacro extends BaseLocaleMacro {

    @Override
    public String getLocaleKey() {
        return "macro.timepoint";
    }

    @Override
    public void execute(Writer writer, MacroParameter params) throws IllegalArgumentException, IOException {
        String label = MacroUtils.NOT_AVAILABLE;
        MacroUtils utils = MacroUtils.getInstance();
        ITrackerProject project = utils.getCurrentProject(params.getContext());
        ITimePoint timePoint = (project != null) ? project.getNearestTimePoint() : null;
        if ((timePoint != null) && (!timePoint.isUnresolvable())) {
            label = utils.format(timePoint.getName()) + " (" + utils.format(timePoint.getTime()) + ")";
        }
        writer.write(label);
    }

}
