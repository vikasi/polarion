package com.polarion.wiki.integration.link;

import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.content.parsers.ContentParser;
import com.xpn.xwiki.content.parsers.ContentParserException;

/**
 * @see com.polarion.wiki.integration.link.PageLink
 * @version $Id: $
 */
public class PageLinkParser implements ContentParser {

    /**
     * Preferred separator for separating link parts (alias, link and target).
     */
    private static final String LINK_SEPARATOR_GREATERTHAN = ">";

    /**
     * Other allowed separator for separating link parts (alias, link and target).
     */
    private static final String LINK_SEPARATOR_PIPE = "|";

    /**
     * Parse the raw content representing a Wiki link (as typed by the user) and transfer it into a structured form as a {@link PageLink} Object.
     * 
     * @param contentToParse
     *            the raw content to parse. This is the link content without the square brackets.
     * @return a {@link PageLink} object containing the parsed data
     * @exception ContentParserException
     *                in case of an error while parsing, like a malformed element for example
     */
    public PageLink parse(String contentToParse) throws ContentParserException {
        StringBuffer content = new StringBuffer(contentToParse.trim());

        PageLink pageLink = new PageLink();

        // Note: It's important to parse the alias and the target in that order. See
        // {@link #parseAlias} for more detailas as to why.
        parseAlias(content, pageLink);
        parseTarget(content, pageLink);

        pageLink.setInterWikiAlias(parseElementAfterString(content, "@"));

        pageLink.setURI(parseURI(content));
        pageLink.setAnchor(parseElementAfterString(content, "#"));

        pageLink.setProject(parseElementBeforeString(content, "/"));
        pageLink.setSpace(parseElementBeforeString(content, "."));

        // What remains in the content buffer is the page name if any. If the content is empty then
        // it means no page was specified. This is allowed and in that case when the link is
        // rendered it'll be pointing to Home.
        if (content.length() > 0) {
            pageLink.setPage(content.toString());
        }

        return pageLink;
    }

    /**
     * Find out the alias part of the full link.
     * 
     * <p>
     * Note: As it's possible to specify a target we need a way to differentiate the following 2 links:
     * <ul>
     * <li>[Web Home>_blank] -> alias = null, link = "Web Home", target = "_blank"</li>
     * <li>[Web Home>Home] -> alias = "Web Home", link = "Home", target = null</li>
     * </ul>
     * The rule we have chosen is to force targets to start with an underscore character ("_").
     * </p>
     * 
     * @param content
     *            the string to parse. This parameter will be modified by the method to remove the parsed content.
     * @param pageLink
     *            the link on which to set the alias and the delimiter symbol used
     */
    protected void parseAlias(StringBuffer content, PageLink pageLink) {
        String alias = null;

        // An alias only exists if there's a separator ("|" or ">").
        int separatorIndex = content.indexOf(LINK_SEPARATOR_PIPE);
        if (separatorIndex == -1) {
            separatorIndex = content.indexOf(LINK_SEPARATOR_GREATERTHAN);
        } else {
            pageLink.setUsePipeDelimiterSymbol(true);
        }

        if (separatorIndex != -1) {
            String text = content.substring(0, separatorIndex).trim();

            // Have we discovered a link or an alias?
            if (separatorIndex == content.length() - 1) {
                alias = text;
                content = new StringBuffer("");
            } else if (content.charAt(separatorIndex + 1) != '_') {
                alias = text;
                content.delete(0, separatorIndex + 1);
            }
        }

        pageLink.setAlias(alias);
    }

    /**
     * Find out the target part of the full link.
     * 
     * <p>
     * Note: The target element must start with an underscore ("_"). See {@link #parseAlias(StringBuffer, PageLink)} for more details as to why.
     * </p>
     * 
     * @param content
     *            the string to parse. This parameter will be modified by the method to remove the parsed content.
     * @param pageLink
     *            the link on which to set the target and the delimiter symbol used
     * @throws ContentParserException
     *             if the target does not start with an underscore
     */
    protected void parseTarget(StringBuffer content, PageLink pageLink) throws ContentParserException {
        String target = null;

        int separatorIndex = content.lastIndexOf(LINK_SEPARATOR_PIPE);
        if (separatorIndex == -1) {
            separatorIndex = content.lastIndexOf(LINK_SEPARATOR_GREATERTHAN);
        } else {
            pageLink.setUsePipeDelimiterSymbol(true);
        }

        if (separatorIndex != -1) {
            target = content.substring(separatorIndex + 1).trim();
            if (!target.startsWith("_")) {
                throw new ContentParserException(XWikiException.ERROR_XWIKI_CONTENT_LINK_INVALID_TARGET,
                        "Invalid link " + "format. The target element must start with an underscore, got [" + target
                                + "]");
            }
            content.delete(separatorIndex, content.length());
        }

        pageLink.setTarget(target);
    }

    /**
     * Find out the URI part of the full link. Supported URIs are either "mailto:" or any URL in the form "protocol://".
     * 
     * @param content
     *            the string to parse. This parameter will be modified by the method to remove the parsed content.
     * @return the parsed URI or null if no URI was specified
     * @throws ContentParserException
     *             if the URI is malformed
     */
    protected URI parseURI(StringBuffer content) throws ContentParserException {
        String mailtoString = "mailto:";
        String urlPattern = "://";

        URI uri = null;

        // First, look for an email URI
        int index = content.indexOf(mailtoString);
        if (index != -1) {
            String text = content.substring(index);
            try {
                uri = new URI(text);
            } catch (URISyntaxException e) {
                throw new ContentParserException(XWikiException.ERROR_XWIKI_CONTENT_LINK_INVALID_URI,
                        "Invalid mailto URI [" + text + "]", e);
            }
            content.delete(index, content.length());
        } else {
            // Look for a "://" pattern
            index = content.indexOf(urlPattern);
            if (index != -1) {
                // We consider that the whole content till the "://" pattern represents a protocol.
                // Indeed, if a URL is specified then virtua wiki aliases and spaces should not be
                // allowed. This will be caught by the URL constructor class which will throw an
                // exception.
                String text = content.toString();
                text = text.replaceAll(" ", "&nbsp;");
                try {
                    uri = new URI(new URL(text).toString());
                } catch (Exception e) {
                    throw new ContentParserException(XWikiException.ERROR_XWIKI_CONTENT_LINK_INVALID_URI,
                            "Invalid URL format [" + text + "]", e);
                }
                content.setLength(0);
            }
        }

        return uri;
    }

    /**
     * Find out the element located to the left of the passed separator.
     * 
     * @param content
     *            the string to parse. This parameter will be modified by the method to remove the parsed content.
     * @param separator
     *            the separator string to locate the element
     * @return the parsed element or null if the separator string wasn't found
     */
    protected String parseElementBeforeString(StringBuffer content, String separator) {
        String element = null;

        int index = content.indexOf(separator);
        if (index != -1) {
            element = content.substring(0, index).trim();
            content.delete(0, index + 1);
        }

        return element;
    }

    /**
     * Find out the element located to the right of the passed separator.
     * 
     * @param content
     *            the string to parse. This parameter will be modified by the method to remove the parsed content.
     * @param separator
     *            the separator string to locate the element
     * @return the parsed element or null if the separator string wasn't found
     */
    protected String parseElementAfterString(StringBuffer content, String separator) {
        String element = null;

        int index = content.lastIndexOf(separator);
        if (index != -1) {
            element = content.substring(index + separator.length()).trim();
            content.delete(index, content.length());
        }

        return element;
    }
}
