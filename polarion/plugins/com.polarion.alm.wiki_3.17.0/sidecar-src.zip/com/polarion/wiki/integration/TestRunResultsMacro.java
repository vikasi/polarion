package com.polarion.wiki.integration;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.velocity.context.Context;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.tracker.model.ITestRecord;
import com.polarion.alm.tracker.model.ITestRun;
import com.polarion.alm.tracker.model.ITrackerProject;
import com.polarion.platform.core.PlatformContext;
import com.polarion.platform.persistence.IDataService;
import com.polarion.platform.persistence.IEnumOption;
import com.polarion.platform.persistence.IEnumeration;
import com.polarion.subterra.base.data.model.TypeFactory;
import com.polarion.wiki.integration.TestRunResultsList.TestRunResults;
import com.polarion.wiki.integration.utils.MP;
import com.xpn.xwiki.XWikiContext;

public class TestRunResultsMacro extends VelocityBasedMacro {
    private static final String MACRO_NAME = "testrun-results"; //$NON-NLS-1$

    private static class TestRunResultsMacroParser extends ExtendedMacroParser {

        private static MP[] RULE1 = new MP[] { MP.TEST_RUN, MP.TEST_RESULT_ENUM, MP.QUERY };
        private static MP[] RULE2 = new MP[] { MP.TEST_RUN, MP.TEST_RESULT_ENUM };

        private static List<MP[]> RULES = new ArrayList<MP[]>();
        static {
            RULES.add(RULE1);
            RULES.add(RULE2);
        }

        private static Set<MP> UNIQUE_PARAMETERS = getUniqueParameters(RULES);

        @SuppressWarnings("rawtypes")
        public TestRunResultsMacroParser(XWikiContext context, MacroParameter parameter) {
            super(context, parameter, RULES, UNIQUE_PARAMETERS, MACRO_NAME);
            utils.addParameterNameToValue(MP.TEST_RUN.getName(), col);
            utils.addDefaultParameter(MP.TEST_RESULT_ENUM.getName(), ITestRecord.TEST_RESULT_ENUM_ID, col);
        }
    }

    @Override
    protected String getMacroName() {
        return MACRO_NAME;
    }

    @Override
    public String getLocaleKey() {
        return "macro.testrun-results"; //$NON-NLS-1$
    }

    @Override
    protected void initializeContext(Context vcontext, XWikiContext<?, ?> context, ExtendedMacroParser parser) {
        ITrackerProject project = utils.getCurrentProject(context);

        IDataService dataService = (IDataService) PlatformContext.getPlatform().lookupService(IDataService.class);
        IEnumeration testResultEnum = dataService.getEnumerationForEnumId(TypeFactory.getInstance().getEnumType(parser.getParameter(MP.TEST_RESULT_ENUM)), project.getContextId());

        Map<String, IEnumOption> resultMap = loadTestResults(testResultEnum);

        String serverUrl = utils.getPolarionServerURL(context);

        TestRunResultsList resultList = new TestRunResultsList(resultMap, project, serverUrl, parser.getParameter(MP.QUERY));
        String projectAndId = parser.getParameter(MP.TEST_RUN);
        ITestRun testRun = TestRunPropertyMacro.getTestRun(projectAndId, context);
        if (testRun == null || testRun.isUnresolvable()) {
            testRun = null;
        }
        TestRunResults results = resultList.addTestRun(projectAndId, testRun);
        vcontext.put("results", results); //$NON-NLS-1$
    }

    @Override
    protected ExtendedMacroParser loadParser(MacroParameter param, XWikiContext<?, ?> context) {
        TestRunResultsMacroParser parser = new TestRunResultsMacroParser(context, param);
        return parser;
    }

    @Override
    protected String getTemplateName() {
        return "testrun-results.vm"; //$NON-NLS-1$
    }

    @SuppressWarnings("unchecked")
    private Map<String, IEnumOption> loadTestResults(IEnumeration testResultEnum) {
        Map<String, IEnumOption> resultMap = new HashMap<String, IEnumOption>();

        for (IEnumOption result : (Collection<IEnumOption>) testResultEnum.getAllOptions()) {
            resultMap.put(result.getId(), result);
        }
        return resultMap;
    }
}
