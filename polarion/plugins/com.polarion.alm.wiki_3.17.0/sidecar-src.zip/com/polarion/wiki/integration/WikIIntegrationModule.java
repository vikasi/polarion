package com.polarion.wiki.integration;

import com.google.inject.AbstractModule;
import com.google.inject.assistedinject.FactoryModuleBuilder;
import com.polarion.alm.ui.server.tracker.ActivityStreamRenderer;

public class WikIIntegrationModule extends AbstractModule {

    @Override
    protected void configure() {
        install(new FactoryModuleBuilder().implement(ActivityStreamRenderer.class, ActivityStreamRenderer.class).build(ActivityStreamRenderer.Factory.class));
    }

}
