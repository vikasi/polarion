package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.radeox.api.engine.RenderEngine;
import org.radeox.api.engine.context.RenderContext;
import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.projects.IProjectService;
import com.polarion.alm.projects.model.IProject;
import com.polarion.alm.projects.model.IProjectGroup;
import com.polarion.alm.qcentre.internal.projectscore.TestDataAssembler.TestCoverage;
import com.polarion.alm.qcentre.internal.projectscore.TestDataAssembler.TestRatio;
import com.polarion.alm.qcentre.report.FormatterTool;
import com.polarion.alm.reports.server.ReportsPolicy;
import com.polarion.alm.tracker.ITrackerService;
import com.polarion.core.util.logging.Logger;
import com.polarion.platform.core.PlatformContext;
import com.polarion.platform.service.repository.IRepositoryService;
import com.polarion.qcentre.factbase.IBaseElement;
import com.polarion.qcentre.factbase.IFactBase;
import com.polarion.qcentre.factbase.serialization.CachedFactBaseRepository;
import com.polarion.qcentre.factbase.serialization.FactBaseRepository;
import com.polarion.qcentre.factbase.tools.render.BasicElementRenderer;
import com.polarion.subterra.base.location.Location;
import com.polarion.wiki.integration.utils.MacroRenderer;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.util.RequestParser;
import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.render.XWikiRadeoxRenderEngine;

/**
 * {fact:base=repo-analysis|value=NOF} -> number of files
 * {fact:base=repo-analysis|value=NOU} -> number of project users
 * 
 * @author Michal Antolik
 *
 */
public class FactMacro extends BaseLocaleMacro {

    private static final Logger log = Logger.getLogger(FactMacro.class);

    private IProjectService ps = (IProjectService) PlatformContext.getPlatform().lookupService(IProjectService.class);
    private ITrackerService ts = (ITrackerService) PlatformContext.getPlatform().lookupService(ITrackerService.class);

    private static final MacroUtils utils = MacroUtils.getInstance();
    private static final MacroRenderer renderer = MacroRenderer.getInstance();
    private static final ReportsPolicy policy = ReportsPolicy.getPolicy();

    private static final String OVERALL_TEST_RESULTS = "overall-test-results";
    private static final String OVERALL_TEST_COVERAGE = "overall-test-coverage";

    private static final String DEFAULT_DISPLAY = "content";

    @Override
    @SuppressWarnings("unchecked")
    public void execute(Writer writer, MacroParameter params)
            throws IllegalArgumentException, IOException {

        Map<String, String> errors = new HashMap<String, String>();
        Collection<String> col = utils.getParameters(params);
        String macroText = utils.buildMacroTextFromParameters("fact", col);
        boolean forPdf = utils.isPdfOutput(params.getContext());

        try {
            String base = null;
            String value = null;
            String display = DEFAULT_DISPLAY;

            for (String p : col) {
                if (p.matches("base(\\s)*=.*")) {
                    base = utils.getValueFromParameter(p);
                } else if (p.matches("value(\\s)*=.*")) {
                    value = utils.getValueFromParameter(p);
                } else if (p.matches("display(\\s)*=.*")) {
                    display = utils.getValueFromParameter(p);
                } else {
                    String[] parts = p.split("[=]");
                    errors.put(parts[0], "Parameter is not suitable for this macro.");
                }
            }

            if (base == null) {
                errors.put("base", "Base parameter is not set");
            }

            if (value == null) {
                errors.put("value", "Value parameter is not set");
            }

            if (!errors.isEmpty()) {
                writer.write(renderer.renderErrors(errors, macroText, forPdf));
                return;
            }

            RenderContext context = params.getContext();
            RenderEngine engine = context.getRenderEngine();
            XWikiContext xcontext = ((XWikiRadeoxRenderEngine) engine).getContext();

            Map requestParams = RequestParser.parseQuery(XWiki.getRequestURL(xcontext.getRequest()).toString(), xcontext);

            String currentProject = (String) requestParams.get("project");
            String currentProjectGroup = (String) requestParams.get("projectGroup");

            String artifactId = getArtifactId(currentProject, currentProjectGroup);
            CachedFactBaseRepository cachedFactBaseRepository = new CachedFactBaseRepository(FactBaseRepository.getFactBaseRepository());
            String factBaseId = base.trim();
            String content = null;
            IFactBase factBase = null;
            if (cachedFactBaseRepository.exists(factBaseId, artifactId, null, false)) {
                factBase = cachedFactBaseRepository.loadFactBase(factBaseId, artifactId, null, false);
            }
            if (factBase != null) {
                value = value.trim();
                IBaseElement el = factBase.findElement(value);
                if (el != null) {
                    if (OVERALL_TEST_RESULTS.equals(value) && currentProject != null) {
                        content = TestRatio.render(currentProject, true);
                    } else if (OVERALL_TEST_COVERAGE.equals(value) && currentProject != null) {
                        content = TestCoverage.render(currentProject, true);
                    }
                    if (content == null) {
                        if (DEFAULT_DISPLAY.equals(display)) {
                            content = new FormatterTool().formatHTML(el);
                        } else {
                            content = new BasicElementRenderer().getPlainTextHeaderLabel(el);
                        }
                    }
                }
            }
            if (content == null || "".equals(content)) {
                content = MacroUtils.NOT_AVAILABLE;
            }
            writer.append(utils.escapeValue(utils.trimValue(content)));
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            errors.put("Error", "Parsing unknown exception, cause:" + e.getLocalizedMessage());
            writer.write(renderer.renderErrors(errors, macroText, forPdf));
        }
    }

    private String getArtifactId(String project, String projectGroup) {
        if (!isEmpty(project)) {
            IProject pr = ts.getTrackerProject(project);
            return pr.getId();
        } else if (!isEmpty(projectGroup)) {
            IProjectGroup group = ps.getProjectGroupAtLocation(Location.getLocation(IRepositoryService.DEFAULT, "/" + projectGroup, null));
            return group.getObjectId().toNormalizedString();
        } else {
            IProjectGroup group = ps.getProjectGroupAtLocation(Location.getLocation(IRepositoryService.DEFAULT, "/", null));
            return group.getObjectId().toNormalizedString();
        }
    }

    private boolean isEmpty(String s) {
        return (s == null) || (s.trim().length() == 0);
    }

    @Override
    public String getLocaleKey() {
        return "macro.polarionfact";
    }

}
