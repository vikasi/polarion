package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;

import org.jetbrains.annotations.NotNull;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.server.ServerUiContext;
import com.polarion.alm.server.api.transaction.ReadOnlyTransactionImpl;
import com.polarion.alm.shared.api.model.tr.internal.InternalTestRun;
import com.polarion.alm.shared.api.utils.html.HtmlBuilderTarget;
import com.polarion.alm.shared.api.utils.links.PortalLink;
import com.polarion.alm.tracker.IModuleManager;
import com.polarion.alm.tracker.ITestManagementPolicy;
import com.polarion.alm.tracker.ITestManagementService;
import com.polarion.alm.tracker.internal.model.ITestRunInternal;
import com.polarion.alm.tracker.model.IModule;
import com.polarion.alm.tracker.model.ITestRun;
import com.polarion.alm.tracker.model.IWorkItem;
import com.polarion.alm.ui.server.wiki.macro.impl.PlainMacroImpl;
import com.polarion.alm.ui.server.wiki.testsexecutionbutton.TestsExecutionButtonParameters;
import com.polarion.platform.guice.internal.GuicePlatform;
import com.polarion.platform.persistence.IDataService;
import com.polarion.reina.web.shared.localization.Localization;

/**
 * This is server side representation of Tests Execution Button Macro
 */
public class TestsExecutionButtonMacro extends XWikiGwtMacro {

    public static final String MACRO_ID = "execute-testrun-button"; //$NON-NLS-1$

    private IDataService dataService;
    private ITestManagementPolicy policy;

    @SuppressWarnings("deprecation")
    public TestsExecutionButtonMacro() {
        super();
        GuicePlatform.getGlobalInjector().injectMembers(this);
    }

    @Inject
    public void setDataService(IDataService dataService) {
        this.dataService = dataService;
    }

    @Inject
    public void setTestService(ITestManagementService testService) {
        policy = testService.getPolicy();
    }

    @Override
    @NotNull
    protected String getMacroId() {
        return MACRO_ID;
    }

    private class Data extends MacroData {

        @NotNull
        final TestsExecutionButtonParameters parameters;

        Data(@NotNull MacroParameter inputParameters) {
            super(inputParameters);
            parameters = new TestsExecutionButtonParameters(macroContext, new PlainMacroImpl(getMacroText(inputParameters)));
        }

        @Override
        @NotNull
        public Map<String, String> getErrors() {
            return parameters.validate();
        }

        @Override
        @NotNull
        public Map<String, String> getParameters() {
            Map<String, String> map = new HashMap<String, String>();
            map.put("url", constructURL(parameters)); //$NON-NLS-1$
            map.put("testrun", parameters.getTestRun().getId()); //$NON-NLS-1$
            map.put("overview", Localization.getString("macro.tests-execution-button.overview", String.valueOf(queryCount()))); //$NON-NLS-1$ //$NON-NLS-2$
            map.put("buttonEnabled", String.valueOf(isButtonEnabled(parameters.getTestRun()))); //$NON-NLS-1$
            return map;
        }

        /**
         * Get number of waiting test cases.
         */
        private int queryCount() {
            ITestRunInternal testRun = (ITestRunInternal) parameters.getTestRun();
            String documentFilter = null;
            IModule document = parameters.getDocument();
            if (document != null && !document.isUnresolvable()) {
                IModuleManager moduleManager = document.getTrackerService().getModuleManager();
                documentFilter = moduleManager.getModuleWorkItemsQuery(document.getProject(), document.getModuleLocation());
            }
            if (testRun.waitingTestsHaveTestRecords()) {
                String filter = documentFilter;
                String queryFromParameter = parameters.getQueryFromParameter();
                if (queryFromParameter != null) {
                    if (filter == null) {
                        filter = queryFromParameter;
                    } else {
                        filter += " AND (" + queryFromParameter + ")"; //$NON-NLS-1$ //$NON-NLS-2$
                    }
                }
                return testRun.getWaitingTestsCount(filter);
            } else {
                String query = parameters.getQuery();
                if (documentFilter != null) {
                    query += " AND " + documentFilter; //$NON-NLS-1$
                }
                return dataService.searchInstances(IWorkItem.PROTO, query, null).size();
            }
        }
    }

    @Override
    public void execute(Writer writer, MacroParameter parameters) throws IllegalArgumentException, IOException {
        new DataRenderer(new Data(parameters)).render(writer);
    }

    class DataRenderer extends MacroDataRenderer<Data> {
        DataRenderer(final Data data) {
            super(data);
        }
    }

    private String constructURL(TestsExecutionButtonParameters parameters) {
        String projectId = parameters.getTestRun().getProjectId();
        String testRunId = parameters.getTestRun().getId();
        String sortby = parameters.getSortby();
        if (!parameters.isDocumentOrQueryConfigured()) {
            ReadOnlyTransactionImpl transaction = new ReadOnlyTransactionImpl();
            InternalTestRun testRun = (InternalTestRun) transaction.testRuns().getBy().ids(projectId, testRunId);
            return testRun.links().waitingTestCases(sortby).toEncodedRelativeUrl();
        }
        String query = parameters.getQuery();
        String documentName = parameters.getDocumentName();
        String spaceName = parameters.getSpaceName();

        HtmlBuilderTarget target = ServerUiContext.getInstance().createHtmlBuilderFor().oldWiki().target();
        PortalLink portalLink;
        if (documentName != null) {
            portalLink = ServerUiContext.getInstance().createPortalLink().project(projectId).document(spaceName, documentName).sidebarTestRun(testRunId).tabTree().query(query);
        } else {
            portalLink = ServerUiContext.getInstance().createPortalLink().project(projectId).workItems().sidebarTestRun(testRunId).sorting(sortby).query(query);
        }
        return target.toEncodedUrl(portalLink);
    }

    private boolean isButtonEnabled(ITestRun testRun) {
        return policy.canExecuteTestRun(testRun) && !testRun.isTemplate();
    }

    @Override
    protected boolean hasLicense() {
        return policy.canUseTestManagement();
    }

}
