package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

public class HintMacro extends BaseLocaleMacro
{
    @Override
    public void execute(Writer writer, MacroParameter params) throws IllegalArgumentException, IOException {
        String content = params.getContent();
        if (content == null) {
            content = "";
        }

        StringBuilder sb = new StringBuilder();
        sb.append("<div class='hint'>");
        sb.append(content);
        sb.append("</div>");
        writer.write(sb.toString());
    }

    @Override
    public String getLocaleKey() {
        return "macro.hint";
    }

}
