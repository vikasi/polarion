/*
   * Copyright (C) 2004-2011 Polarion Software
   * All rights reserved.
   * Email: dev@polarion.com
   *
   *
   * Copyright (C) 2004-2011 Polarion Software
   * All Rights Reserved.    No use, copying or distribution of this
   * work may be made except in accordance with a valid license
   * agreement from Polarion Software.    This notice must be
   * included on all copies, modifications and derivatives of this
   * work.
   *
   * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
   * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
   * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
   * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
   * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
   *
   */
package com.polarion.wiki.integration.plans;

import org.jetbrains.annotations.NotNull;

import com.polarion.alm.server.api.model.rp.widget.plan.PlanProgressRenderer;
import com.polarion.alm.ui.server.wiki.macro.MacroContext;
import com.polarion.alm.ui.server.wiki.macro.PlainMacro;
import com.polarion.alm.ui.server.wiki.plan.progress.PlanProgressMacro;
import com.polarion.wiki.integration.PolarionXWikiMacroWrapper;

public class PlanProgressMacroWrapper extends PolarionXWikiMacroWrapper<PlanProgressMacro> {
    private static final String MACRO_ID = "plan-progress"; //$NON-NLS-1$

    @Override
    @NotNull
    protected String getMacroId() {
        return MACRO_ID;
    }

    @Override
    @NotNull
    protected PlanProgressMacro createMacro(@NotNull MacroContext context, @NotNull PlainMacro plainMacro) {
        return createMacro(context, plainMacro, PlanProgressRenderer.ProgressBarSize.NORMAL);
    }

    @NotNull
    protected PlanProgressMacro createMacro(@NotNull MacroContext context, @NotNull PlainMacro plainMacro, @NotNull PlanProgressRenderer.ProgressBarSize progressBarSize) {
        return new PlanProgressMacro(context, plainMacro, progressBarSize);
    }

}
