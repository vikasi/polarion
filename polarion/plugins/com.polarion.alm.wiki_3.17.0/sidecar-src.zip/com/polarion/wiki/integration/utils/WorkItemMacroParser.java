package com.polarion.wiki.integration.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.polarion.alm.tracker.model.ITrackerProject;
import com.polarion.alm.tracker.model.IWorkItem;
import com.polarion.core.util.logging.Logger;
import com.polarion.reina.web.shared.localization.Localization;
import com.polarion.wiki.integration.utils.MacroUtils.FieldProperty;
import com.xpn.xwiki.XWikiContext;

public class WorkItemMacroParser extends MacroParser {

    private static final Logger log = Logger.getLogger(WorkItemMacroParser.class);

    final static private MP[] rule1 = {
            MP.ID, MP.DISPLAY_SHORT_LONG, MP.EXPAND_YES_NO, MP.FIELDS, MP.LABEL, MP.LINK
    };

    final static private MP[] rule2 = {
            MP.PROJECT_SLASH_ID, MP.DISPLAY_SHORT_LONG, MP.EXPAND_YES_NO, MP.FIELDS, MP.LABEL, MP.LINK
    };

    static final private List<MP[]> rules = new ArrayList<MP[]>();

    static {
        rules.add(rule1);
        rules.add(rule2);
    }

    static final private Set<MP> uniqueParameters = getUniqueParameters(rules);

    public WorkItemMacroParser(XWikiContext context) {
        super(context, rules, uniqueParameters);
    }

    @Override
    public String parse(Collection<String> col, String macroText, boolean forPdf) {
        this.col = col;
        this.macroText = macroText;
        this.forPdf = forPdf;

        IWorkItem wi = null;

        try {
            utils.addParameterNameToValue("id", col); //$NON-NLS-1$
            utils.addDefaultParameter(MP.DISPLAY_SHORT_LONG.getName(), "short", col); //$NON-NLS-1$

            String err = parseParameters();
            if (err != null) {
                return err;
            }

            boolean withLink = utils.showLink(map);

            ITrackerProject project = getProject(context, map, errors);
            if (project == null) {
                return renderer.renderErrors(errors, macroText, forPdf);
            }
            wi = project.getWorkItem(map.get(MP.ID));
            String rev = (String) context.get("revision"); //$NON-NLS-1$
            if (rev != null) {
                wi = (IWorkItem) trackerService.getDataService().getVersionedInstance(wi.getUri(), rev);
            }

//			if(wi.isUnresolvable()){
//				errors.put(MP.ID.getName(), "Work item with ID '" + map.get(MP.ID) + "' doesn't exist.");
//				return renderer.renderErrors(errors, macroText, forPdf);
//			}

            String fs = map.get(MP.FIELDS);
            if (fs != null) {
                //render fields behind work item id 
                Map<String, FieldProperty> fields = fieldParser.getWorkItemFields(map, errors, false, false);
                if (!errors.isEmpty()) {
                    return renderer.renderErrors(errors, macroText, forPdf);
                }
                utils.setWidthForFields(fields, null);

                String renderedFields = renderer.getRenderedFields(
                        fields,
                        wi,
                        utils.getExpandMode(map),
                        utils.getLinkDisplay(map),
                        utils.getPolarionServerURL(context),
                        map.get(MP.LABEL),
                        null,
                        map.get(MP.WIDTH),
                        map.get(MP.HEIGHT),
                        forPdf,
                        withLink,
                        context
                        );
                renderedFields = handleWILinks(renderedFields);
                return renderedFields;
            } else {
                //render only work item id (+title)
                return renderer.getLink4MacroObject(
                        wi,
                        macroText,
                        utils.getLinkDisplay(map),
                        map.get(MP.LABEL),
                        utils.getPolarionServerURL(context),
                        forPdf,
                        null,
                        null,
                        null,
                        withLink,
                        context);
            }
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            errors.put("Error", Localization.getString("macro.general.parsingUnknownException") + e.getLocalizedMessage()); //$NON-NLS-1$//$NON-NLS-2$
            return renderer.renderErrors(errors, macroText, forPdf);
        }

    }

    private String handleWILinks(String renderedFields) {
        return renderedFields.replaceAll("<a href=\"#/project/", "<a href=\"/polarion/#/project/"); //$NON-NLS-1$ //$NON-NLS-2$
    }

    private ITrackerProject getProject(XWikiContext context, Map<MP, String> map, Map<String, String> errors) {
        if (map.containsKey(MP.PARSING_PROJECT)) {
            return utils.getTrackerProject(map.get(MP.PARSING_PROJECT), errors);
        } else {
            ITrackerProject p = utils.getCurrentProject(context);
            if (p == null) {
                errors.put(MP.PROJECT.getName(), Localization.getString("macro.general.currentScopeIsNotProject")); //$NON-NLS-1$
            }
            return p;
        }
    }

}
