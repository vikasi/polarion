package com.polarion.wiki.integration.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.polarion.alm.projects.model.IProject;
import com.polarion.core.util.logging.Logger;
import com.polarion.reina.web.shared.localization.Localization;
import com.polarion.wiki.integration.utils.MacroUtils.FieldProperty;
import com.xpn.xwiki.XWikiContext;

public class ProjectMacroParser extends MacroParser {

    private static final Logger log = Logger.getLogger(ProjectMacroParser.class);

    final static private MP[] rule1 = {
            MP.PROJECT_ID, MP.DISPLAY_SHORT_LONG, MP.EXPAND_YES_NO, MP.FIELDS, MP.LABEL, MP.LINK
    };
    static final private List<MP[]> rules = new ArrayList<MP[]>();

    static {
        rules.add(rule1);
    }

    static final private Set<MP> uniqueParameters = getUniqueParameters(rules);

    public ProjectMacroParser(XWikiContext context) {
        super(context, rules, uniqueParameters);
    }

    @Override
    public String parse(Collection<String> col, String macroText, boolean forPdf) {
        this.col = col;
        this.macroText = macroText;
        this.forPdf = forPdf;

        try {

            utils.addParameterNameToValue("id", col); //$NON-NLS-1$
            utils.addDefaultParameter(MP.DISPLAY_SHORT_LONG.getName(), "short", col); //$NON-NLS-1$

            String err = parseParameters();
            if (err != null) {
                return err;
            }

            boolean withLink = utils.showLink(map);

            IProject project = null;
            String projectId = map.get(MP.PROJECT_ID);
            if (!projectId.matches("(\\s)*@current(\\s)*")) { //$NON-NLS-1$
                project = utils.getProject(map.get(MP.PROJECT_ID), errors);
                if (project == null) {
                    return renderer.renderErrors(errors, macroText, forPdf);
                }
            } else {
                //search on current scope, but only if scope is project!
                project = utils.getCurrentProject(context);
            }
            if (project == null) {
                return renderer.renderError(MP.PROJECT_ID.getName(), Localization.getString("macro.general.parameterProjectIsNotSet"), macroText, forPdf); //$NON-NLS-1$
            }

            String fs = map.get(MP.FIELDS);
            if (fs != null) {
                Map<String, FieldProperty> fields = fieldParser.getProjectFields(map, errors);
                if (!errors.isEmpty()) {
                    return renderer.renderErrors(errors, macroText, forPdf);
                }

                //render fields behind work item id 
                return renderer.getRenderedFields(
                        fields,
                        project,
                        utils.getExpandMode(map),
                        utils.getLinkDisplay(map),
                        utils.getPolarionServerURL(context),
                        map.get(MP.LABEL),
                        null,
                        map.get(MP.WIDTH),
                        map.get(MP.HEIGHT),
                        forPdf,
                        withLink,
                        context
                        );
            } else {
                //render only work item id (+title)
                return renderer.getLink4MacroObject(
                        project,
                        macroText,
                        utils.getLinkDisplay(map),
                        map.get(MP.LABEL),
                        utils.getPolarionServerURL(context),
                        forPdf,
                        null,
                        null,
                        null,
                        withLink,
                        context
                        );
            }
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            errors.put("Error", Localization.getString("macro.general.parsingUnknownException") + e.getLocalizedMessage()); //$NON-NLS-1$//$NON-NLS-2$
            return renderer.renderErrors(errors, macroText, forPdf);
        }

    }

}
