package com.polarion.wiki.integration.link;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.polarion.alm.projects.IProjectService;
import com.polarion.alm.projects.model.IProject;
import com.polarion.alm.tracker.ITrackerService;
import com.polarion.alm.tracker.SavedQuery;
import com.polarion.platform.core.PlatformContext;
import com.polarion.platform.security.ISecurityService;
import com.xpn.xwiki.api.WorkItem;

public class WorkItemValidator extends Validator
{
    @SuppressWarnings("unused")
    private WorkItem wi;
    private static Pattern pQueryName = Pattern.compile("(\\w+)/" + ILink.ITEM_QUERY_NAME);

    private ISecurityService securityService = (ISecurityService) PlatformContext.getPlatform().lookupService(ISecurityService.class);
    private IProjectService projectService = (IProjectService) PlatformContext.getPlatform().lookupService(IProjectService.class);
    private ITrackerService tracker = (ITrackerService) PlatformContext.getPlatform().lookupService(ITrackerService.class);

    @SuppressWarnings("unchecked")
    public WorkItemValidator(WorkItem wi, Collection fields) {
        super();
        this.wi = wi;
        predefined.put(FIELDS, new HashSet<Collection>(fields));
    }

    @Override
    public void setupDefaults() {
        super.setupDefaults();
        params.add(ILink.ITEM_QUERY_NAME);
        params.add(ILink.ITEM_DISPLAY);
        params.add(ILink.ITEM_ID);
        params.add(ILink.ITEM_TOP);

        Set<String> display = new HashSet<String>();
        display.add("short");
        display.add("long");
        display.add("link");

        predefined.put("display", display);
    }

    @Override
    protected boolean validateToken(String token, String value) {
        boolean validToken = true;
        if (token.equals(ILink.ITEM_TOP)) {
            validToken = pInteger.matcher(value).matches();
            if (!validToken) {
                errors.add("Invalid parameter in token \"" + token + "\". It must be a digital value.");
            }
        } else if (pQueryName.matcher(token).matches()) {
            validToken = validateQueryName(token, value);
        } else {
            validToken = super.validateToken(token, value);
        }

        return validToken;
    }

    @Override
    protected boolean validateField(String fieldName) {
        Set fields = predefined.get(FIELDS);
        if (fields.contains(fieldName) || wi.isCustomField(fieldName)) {
            return true;
        }
        errors.add("Unknown field \"" + fieldName + "\". Please verify spelling. Example: " + fields.toString());
        return false;
    }

    protected boolean validateQueryName(String token, String value) {
        Matcher mQueryName = pQueryName.matcher(token);
        if (mQueryName.find() && mQueryName.groupCount() > 0) {
            String projectName = mQueryName.group(1);
            IProject project = null;
            List queryList = null;
            try {
                project = projectService.getProject(projectName);
                queryList = (tracker.getSavedQueriesManager()).getSavedQueries(project, tracker.getTrackerUser(securityService.getCurrentUser()));
            } catch (IllegalArgumentException e) {
                errors.add("Project does not exist \"" + projectName + "\". Please verify spelling.");
                return false;
            }
            Iterator it = queryList.iterator();
            while (it.hasNext()) {
                if (((SavedQuery) it.next()).name.equals(value)) {
                    return true;
                }
            }
        }
        errors.add("Query does not exist \"" + value + "\". Please verify spelling.");
        return false;
    }
}
