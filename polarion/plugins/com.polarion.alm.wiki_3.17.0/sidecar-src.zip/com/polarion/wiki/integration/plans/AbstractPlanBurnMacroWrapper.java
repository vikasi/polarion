/*
?* Copyright (C) 2004-2013 Polarion Software
?* All rights reserved.
?* Email: dev@polarion.com
?*
?*
?* Copyright (C) 2004-2013 Polarion Software
?* All Rights Reserved.? No use, copying or distribution of this
?* work may be made except in accordance with a valid license
?* agreement from Polarion Software.? This notice must be
?* included on all copies, modifications and derivatives of this
?* work.
?*
?* POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
?* ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
?* INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
?* FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
?* SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
?* OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
?*
?*/
package com.polarion.wiki.integration.plans;

import org.jetbrains.annotations.NotNull;

import com.polarion.alm.ui.server.wiki.plan.burn.AbstractPlanBurnMacro;

public abstract class AbstractPlanBurnMacroWrapper extends HighchartMacroWrapper<AbstractPlanBurnMacro> {

    @Override
    protected int getHeight(@NotNull AbstractPlanBurnMacro macro) {
        return macro.getParameters().getHeight();
    }

    @Override
    protected int getWidth(@NotNull AbstractPlanBurnMacro macro) {
        return macro.getParameters().getWidth();
    }

}
