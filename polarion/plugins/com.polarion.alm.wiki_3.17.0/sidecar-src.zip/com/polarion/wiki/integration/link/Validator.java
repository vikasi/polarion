package com.polarion.wiki.integration.link;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.regex.Pattern;

import com.polarion.core.util.logging.Logger;

public class Validator
{
    protected static final String FIELDS = "##fields";
    protected static final String FIELD_TYPE = "##fieldtype";

    static Logger log = Logger.getLogger(Validator.class);

    protected static Pattern pInteger = Pattern.compile("[0-9]+");
    protected static Pattern pTableSize = Pattern.compile("[0-9]+|[0-9]+px|[0-9]+\\%");
    protected static Pattern pQuery = Pattern.compile("\\w+/" + ILink.ITEM_QUERY);

    protected Map<String, Set> predefined;
    protected Set<String> params = new HashSet<String>();

    protected List<String> errors;
    private boolean valid = true;

    public Validator() {
        errors = new ArrayList<String>();
        setupDefaults();
    }

    @SuppressWarnings("unchecked")
    public Validator(Collection fields) {
        this();
        predefined.put(FIELDS, new HashSet<Collection>(fields));
    }

    public boolean validate(Map parameters) {
        List<String> ls = new ArrayList<String>();
        Set ms = parameters.entrySet();
        Iterator itr = ms.iterator();
        while (itr.hasNext())
        {
            Map.Entry me = (Map.Entry) itr.next();
            if (me != null)
            {
                String fld = (String) me.getKey();
                String[] val = (String[]) me.getValue();
                ls.add((fld + "=" + val[0]).replaceAll("p_r", "%"));
            }
        }
        return validate(ls);
    }

    public boolean validate(Collection parameters) {
        //valid = true;		
        Iterator iter = parameters.iterator();
        while (iter.hasNext()) {
            try
            {
                String param = (String) iter.next();
                String[] pair = param.split("=");
                String token = pair[0];
                String value = "";
                if (pair.length > 1) {
                    value = pair[1].trim();
                }
                valid = validateToken(token, value) && valid;
            } catch (Exception e)
            {
                log.error(e);
            }
        }
        return valid;
    }

    protected boolean validateToken(String token, String value) {
        boolean validToken = true;
        if (params.contains(token)) {
            if (params.contains(token) && value.equals("")) {
                valid = false;
                errors.add("Parameter \"" + token + "\" values missing");
            } else if (token.equals(ILink.ITEM_FIELDS)) {
                validToken = validateFields(value);
            } else if (predefined.containsKey(token)) {
                validToken = validatePredefined(token, value, "Invalid parameter in token \"" + token + "\". It must have predefined value.");
            } else if (token.equals(ILink.ITEM_TABLEHEIGTH) || token.equals(ILink.ITEM_TABLEWIDTH)) {
                validToken = validateTableSize(token, value);
            } else if (token.equals(ILink.ITEM_SORTBY)) {
                validToken = validatePredefined(FIELDS, value, "Unknown field \"" + value + "\". Please verify spelling");
            }
        }
        else if (!token.equalsIgnoreCase("xpage")) {
            if (!pQuery.matcher(token).matches()) {
                valid = false;
                errors.add("Unknown token \"" + token + "\". Please verify spelling");
            }
        }
        return validToken;
    }

    public void addError(String error) {
        valid = false;
        errors.add(error);
    }

    public List /*String*/getErrors() {
        return errors;
    }

    public String getErrorsText() {
        StringBuffer str = new StringBuffer();
        Iterator it = errors.iterator();
        while (it.hasNext()) {
            str.append((String) it.next());
            str.append("\n");
        }
        return str.toString();
    }

    protected void setupDefaults() {
        //since macros syntax is case-insensitive use string constants in lower case
        params.add(ILink.ITEM_QUERY);
        params.add(ILink.ITEM_PROJECT);
        params.add(ILink.ITEM_FIELDS);
        params.add(ILink.ITEM_SORTBY);
        params.add(ILink.ITEM_OUTPUT);
        params.add(ILink.ITEM_TABLEHEIGTH);
        params.add(ILink.ITEM_TABLEWIDTH);
        params.add(ILink.ITEM_EXPAND);

        predefined = new HashMap<String, Set>();

        Set<String> output = new HashSet<String>();
        output.add(ILink.FIELD_OUTPUT_LIST);
        output.add(ILink.FIELD_OUTPUT_TABLE);

        Set<String> expand = new HashSet<String>();
        expand.add(ILink.EXPAND_YES);
        expand.add(ILink.EXPAND_NO);

        Set<String> fieldType = new HashSet<String>();
        fieldType.add(ILink.FIELD_TYPE_HIDDEN);
        fieldType.add(ILink.FIELD_TYPE_IMAGE);
        fieldType.add(ILink.FIELD_TYPE_IMGTXT);
        fieldType.add(ILink.FIELD_TYPE_TEXT);
        fieldType.add(ILink.FIELD_TYPE_TXTIMG);

        predefined.put(ILink.ITEM_OUTPUT, output);
        predefined.put(ILink.ITEM_EXPAND, expand);
        predefined.put(FIELD_TYPE, fieldType);
    }

    protected boolean validateTableSize(String token, String value) {
        if (!pTableSize.matcher(value).matches()) {
            errors.add("Invalid parameter in token \"" + token + "\". It must be a digital value.");
            return false;
        }
        return true;
    }

    protected boolean validatePredefined(String token, String value, String errorMsg) {
        Set validValues = predefined.get(token);
        if (!validValues.contains(value)) {
            errorMsg += " Example: " + validValues.toString();
            errors.add(errorMsg);
            return false;
        }
        return true;
    }

    protected boolean validateFields(String value) {
        boolean valid = true;
        StringTokenizer st = new StringTokenizer(value, ILink.FIELD_SEPARATOR);
        while (st.hasMoreTokens()) {
            String data = st.nextToken().trim();
            String fieldName = data;
            int index = data.indexOf(ILink.FIELD_TYPE_SEPARATOR);
            if (index != -1) {
                fieldName = data.substring(0, index).trim();
                String fieldType = data.substring(index + ILink.FIELD_TYPE_SEPARATOR.length()).trim();
                boolean validType = validatePredefined(FIELD_TYPE, fieldType, "Unknown type \"" + fieldType + "\" of field \"" + fieldName + "\".");
                valid = valid && validType;
            }
            valid = validateField(fieldName) && valid;
        }
        return valid;
    }

    protected boolean validateField(String fieldName) {
        return validatePredefined(FIELDS, fieldName, "Unknown field \"" + fieldName + "\". Please verify spelling. ");
    }
}
