package com.polarion.wiki.integration;

import java.io.Writer;

import org.radeox.api.engine.RenderEngine;
import org.radeox.api.engine.context.RenderContext;
import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.render.XWikiRadeoxRenderEngine;

public class AMacro extends BaseLocaleMacro
{

    @Override
    public void execute(Writer writer, MacroParameter mp)
    {
        try {
            RenderContext context = mp.getContext();
            RenderEngine engine = context.getRenderEngine();
            XWikiContext xcontext = ((XWikiRadeoxRenderEngine) engine).getContext();
            String anchorImg = xcontext.getWiki().getSkinFile("anchor.gif", xcontext);

            String name = "\"PolarionAnchor" + mp.get(0).trim() + "\"";
            boolean visible = false;
            if (mp.getLength() > 1) {
                visible = mp.get(1).trim().equals("visible");
            }
            String anchor = "<a id=" + name + " name=" + mp.get(0).trim() + ">" + (visible ? "<img title=\"" + mp.get(0).trim() + "\" src=\"" + anchorImg + "\" alt=\"" + anchorImg + "\" >" : "") + "</a>";
            writer.write(anchor);
        } catch (Exception e) {

        }
    }

    @Override
    public String getLocaleKey()
    {
        return "macro.polariona";
    }

}
