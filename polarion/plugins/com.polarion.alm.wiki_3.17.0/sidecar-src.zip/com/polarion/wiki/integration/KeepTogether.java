/*
 * Copyright (C) 2004-2009 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2009 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.wiki.integration.utils.MacroUtils;

/**
 * This macro ensures that text inside macro is always rendered at one
 * page in PDF. 
 * 
 * POLARION-MACRO-KEEP-TOGETHER is changed in "xhtml2fo.xsl" to fo:block with
 * attribute keep-together.within-page="always".
 * 
 * @author <a href="mailto:dev@polarion.com">Michal Antolik</a>, Polarion Software
 *
 */
public class KeepTogether extends BaseLocaleMacro {

    @Override
    public void execute(Writer writer, MacroParameter parameters)
            throws IllegalArgumentException, IOException {

        boolean forPdf = MacroUtils.getInstance().isPdfOutput(parameters.getContext());
        if (forPdf) {
            //macro is applicable only to PDF
            writer.write("<div class=\"POLARION-MACRO-KEEP-TOGETHER\">");
            writer.write(parameters.getContent() == null ? "" : parameters.getContent());
            writer.write("</div>");
        } else {
            writer.write(parameters.getContent() == null ? "" : parameters.getContent());
        }
    }

    @Override
    public String getLocaleKey() {
        return "macro.polarionkeeptogether";
    }
}
