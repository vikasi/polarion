package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

public class ProjectsMacro extends BaseLocaleMacro {

    @Override
    public void execute(Writer writer, MacroParameter parameters)
            throws IllegalArgumentException, IOException {
        // TODO Auto-generated method stub
        writer.write("projects");
    }

    @Override
    public String getLocaleKey() {
        return "macro.polarionprojects";
    }

}
