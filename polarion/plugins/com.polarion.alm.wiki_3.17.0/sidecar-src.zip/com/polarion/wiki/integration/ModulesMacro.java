package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.tracker.ITrackerService;
import com.polarion.alm.tracker.model.IModule;
import com.polarion.alm.tracker.model.ITrackerProject;
import com.polarion.alm.tracker.model.ITypeOpt;
import com.polarion.core.util.logging.Logger;
import com.polarion.platform.core.PlatformContext;
import com.polarion.reina.web.shared.localization.Localization;
import com.polarion.subterra.base.location.Location;
import com.polarion.wiki.integration.utils.MacroRenderer;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.integration.utils.ModuleHelper;
import com.xpn.xwiki.XWikiContext;

public class ModulesMacro extends BaseLocaleMacro
{
    private static final Logger log = Logger.getLogger(ModulesMacro.class);

    final private MacroUtils utils = MacroUtils.getInstance();
    final private MacroRenderer renderer = MacroRenderer.getInstance();

    private String macroText;
    private boolean forPdf;
    private Map<String, String> errors;

    final private static ITrackerService trackerService = (ITrackerService) PlatformContext.getPlatform().lookupService(ITrackerService.class);

    @Override
    public void execute(Writer writer, MacroParameter parameter) throws IllegalArgumentException, IOException {
        try {
            final ITrackerProject project;
            XWikiContext context = utils.getXWikiContext(parameter);
            macroText = utils.buildMacroTextFromParameters2("modules", parameter);
            forPdf = utils.isPdfExport(context);
            errors = new HashMap<String, String>();

            String projectId = parameter.get("project"); //$NON-NLS-1$
            if (projectId == null) {
                project = utils.getCurrentProject(context);
                if (project == null) {
                    errors.put("context", "{modules} macro used outside of project context and project parameter not passed"); //$NON-NLS-1$
                } else {
                    projectId = project.getId();
                }
            } else {
                project = trackerService.getTrackerProject(projectId);
                if (project == null) {
                    errors.put("project", "Project with id '" + projectId + "' doesn't exist."); //$NON-NLS-1$
                }
            }

            if (!errors.isEmpty()) {
                writer.write(renderer.renderErrors(errors, macroText, forPdf));
                return;
            }

            List<IModule> modules = trackerService.getModuleManager().getModules(project, Location.getLocation("")); //$NON-NLS-1$

            StringBuffer content = new StringBuffer();
            content.append("<table class='wiki-spaces-table' cellpadding='0' cellspacing='0'><tbody>"). //$NON-NLS-1$
                    append("<tr style='color: rgb(102, 102, 102); height: 23px;'><th></th><th>" + Localization.getString("form.modules.label.module") + "</th><th>" + Localization.getString("form.modules.label.type") + "</th><th>" + Localization.getString("form.modules.label.actions") + "</th></tr>"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$

            for (IModule module : modules) {
                String moduleName = module.getModuleName();
                moduleName = moduleName.replaceAll("\\[", "&#91;"); //$NON-NLS-1$ //$NON-NLS-2$
                moduleName = moduleName.replaceAll("\\]", "&#93;"); //$NON-NLS-1$ //$NON-NLS-2$
                String baseModuleUrl = new ModuleHelper(module).getModuleLink();

                content.append("<tr>"). //$NON-NLS-1$
                        append("<td>"). //$NON-NLS-1$
                        append("<input type=\"checkbox\"/ name=\"selectModuleCheckbox\" value=\"" + moduleName + "\">"). //TODO escaping !!! //$NON-NLS-1$ //$NON-NLS-2$
                        append("</td>"). //$NON-NLS-1$
                        append("<td style='width: 100%;'>"). //$NON-NLS-1$
                        append("<a href='" + baseModuleUrl + "' target='_top'>"). //$NON-NLS-1$ //$NON-NLS-2$
                        append("<img alt=\"module_icon\" src='/polarion/ria/images/details/document.png' style='vertical-align: middle; margin-right:2px;'/>"). //$NON-NLS-1$
                        append(moduleName).
                        append("</a>"); //$NON-NLS-1$
                IModule derivedFrom = module.getDerivedFrom();
                if (derivedFrom != null) {
                    String revision = derivedFrom.getObjectId().getLocalId().getRevision();
                    String moduleLink = new ModuleHelper(derivedFrom).getModuleLink();
                    revision = revision == null ? "" : " " + Localization.getString("form.modules.label.rev") + revision; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
                    String link1 = "<a href='" + moduleLink + "' target='_top'>" + derivedFrom.getModuleName() + "</a>"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
                    String link2 = "<a href='javascript:top.updateDerivedModule(\"" + projectId + "\",\"" + moduleName + "\",null)'>" + Localization.getString("form.modules.label.update") + "</a>"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$

                    content.append(" " + Localization.getString("form.modules.label.derivedFrom", link1 + revision, link2)); //$NON-NLS-1$//$NON-NLS-2$
                }

                content.append("</td>"). //$NON-NLS-1$
                        append("<td>"); //$NON-NLS-1$
                boolean one = true;
                for (ITypeOpt option : module.getAllowedWITypes()) {
                    if (!one) {
                        content.append(",&nbsp;"); //$NON-NLS-1$
                    }
                    content.append(option.getName());
                    if (one) {
                        one = false;
                    }
                }
                content.append("</td>"). //$NON-NLS-1$
                        append("<td nowrap='yes'>"). //$NON-NLS-1$
                        //				append("<a href='"+baseModuleUrl+"/workitems?table_mode=module' target='_top'>").				
                        //				append("<img src='/polarion/ria/images/details/table.gif'/> Work Items").
                        //				append("</a>").
                        append("<a href='" + baseModuleUrl + "?tab=multiedit' target='_top'>"). //$NON-NLS-1$ //$NON-NLS-2$
                        append("<img style=\"margin-right:1px;\" alt=\"wi_multi_edit\" src='/polarion/ria/images/details/wi_multi_edit.gif' title='" + Localization.getString("form.modules.tooltip.editWorkItems") + "'/>"). //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
                        append("</a>"). //$NON-NLS-1$
                        append("<a href='javascript:top.removeModule(\"" + projectId + "\",\"" + moduleName + "\")'>"). //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
                        append("<img style=\"margin-right:3px;\" alt=\"minus\" src='/polarion/ria/images/actions/delete.gif' title='" + Localization.getString("form.modules.tooltip.delete") + "' />"). //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$
                        append("</a>"). //$NON-NLS-1$
                        append("<a href='javascript:top.duplicateModule(\"" + projectId + "\",\"" + moduleName + "\")'>"). //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
                        append("<img style=\"margin-right:3px;\" alt=\"duplicate_module\" src='/polarion/ria/images/actions/duplicate_module.gif' title='" + Localization.getString("form.modules.tooltip.reuse") + "' />"). //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$
                        append("</a>"). //$NON-NLS-1$
                        append("</td>"). //$NON-NLS-1$
                        append("</tr>"); //$NON-NLS-1$
            }
            content.append("</tbody></table>"); //$NON-NLS-1$

            // reuse button on old modules page temporary commented
            content.append("<table style=\"background:#f5f5f5;margin-top:5px;\" onClick=\"top.reuseModules('" + projectId + "', getElementsByName('selectModuleCheckbox'))\" class=\"com_polarion_reina_web_js_widgets_JSPopupButton_Button\" style=\"cursor:pointer;\">"); //$NON-NLS-1$ //$NON-NLS-2$
            content.append("<tr><td style=\"padding:4px;vertical-align:middle;\">"); //$NON-NLS-1$
            content.append(Localization.getString("form.modules.button.reuseSelected")); //$NON-NLS-1$
            content.append("</td></tr></tbody></table>"); //$NON-NLS-1$
            writer.write(content.toString());
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            errors.put("Error", "Parsing unknown exception, cause:" + e.getLocalizedMessage());
            writer.write(renderer.renderErrors(errors, macroText, forPdf));
        }
    }

    @Override
    public String getLocaleKey()
    {
        return "macro.polarionmodules"; //$NON-NLS-1$
    }

}
