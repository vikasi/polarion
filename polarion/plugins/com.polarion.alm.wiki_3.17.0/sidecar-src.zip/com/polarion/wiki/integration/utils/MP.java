package com.polarion.wiki.integration.utils;

import java.util.Set;

public enum MP {

    ID(1, "id", false, false, Const.WI_ID, null, false), //$NON-NLS-1$
    USER_ID(1, "id", false, false, Const.WI_ID, null, false), //$NON-NLS-1$
    PROJECT_ID(1, "id", false, false, Const.WI_ID, null, false), //$NON-NLS-1$
    PROJECT_SLASH_ID(1, "id", false, false, Const.WI_ID + "[/]" + Const.WI_ID, "projectId/workitemId", false), //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    NAME(0, "name", false, false, "(.)+", null, false), //$NON-NLS-1$//$NON-NLS-2$
//	DISPLAY_SHORT			("display", false, true, "short"),
//	DISPLAY_LONG			("display", false, true, "long"),
    DISPLAY_SHORT_LONG(0, "display", false, true, "(long|short)", "short,long", true), //$NON-NLS-1$ //$NON-NLS-2$ 
    DISPLAY_TABLE(0, "display", false, true, "table", "table", true), //$NON-NLS-1$ //$NON-NLS-2$
    DISPLAY_LIST(0, "display", false, true, "list", "list", true), //$NON-NLS-1$ //$NON-NLS-2$
    DISPLAY_DOCUMENT(0, "display", false, true, "document", "document", true), //$NON-NLS-1$ //$NON-NLS-2$
    DISPLAY_COUNT(0, "display", false, true, "count", "count", true), //$NON-NLS-1$//$NON-NLS-2$
    EXPAND_YES_NO(0, "expand", true, true, "(.)+", "yes,no", true, Const.VV_EXPAND_YES_NO, Const.ERR_MSG_EXPAND_YES_NO), //$NON-NLS-1$ //$NON-NLS-2$
    FIELDS(0, "fields", true, true, "(.)+", null, true), //$NON-NLS-1$ //$NON-NLS-2$
    LABEL(0, "label", true, true, "(.)+", null, true), //$NON-NLS-1$ //$NON-NLS-2$
    QUERY(2, "query", false, false, "(.)+", null, false), //$NON-NLS-1$ //$NON-NLS-2$
    SQL_QUERY(2, "sqlQuery", false, false, "(.)+", null, false), //$NON-NLS-1$ //$NON-NLS-2$
    DOCUMENT_QUERY(2, "query", true, true, "(.)*", null, false), //$NON-NLS-1$ //$NON-NLS-2$
    QUERY_NAME(0, "queryName", false, false, Const.WI_ID, null, false), //$NON-NLS-1$
    MODULE_NAME(0, "name", false, false, "[^/]+/?[^/]*", "spaceId/name or name", false), //$NON-NLS-1$ //$NON-NLS-2$
    PARSING_PROJECT(0, "parsingProject", true, true, "(.)+", null, true), //only for parsing reason //$NON-NLS-1$ //$NON-NLS-2$
    PROJECT_SLASH_QUERY_NAME(0, "queryName", false, false, Const.WI_ID + "/" + Const.WI_ID, "projectId/queryName", false), //$NON-NLS-1$ //$NON-NLS-2$
    PROJECT(3, "project", true, true, Const.WI_ID, null, true), //$NON-NLS-1$
    PROJECT2(3, "project", false, true, Const.WI_ID, null, false), //$NON-NLS-1$
    GROUP(0, "group", true, true, "(.)+", null, true), //$NON-NLS-1$ //$NON-NLS-2$
    TOP(0, "top", true, true, Const.WI_ID, null, true, Const.VV_INTEGER, Const.ERR_MSG_TOP), //$NON-NLS-1$
    SORTBY(0, "sortby", true, true, Const.WI_ID, null, true, Const.VV_SORT_BY, Const.ERR_MSG_SORT_BY), //$NON-NLS-1$
    GROUPBY(0, "groupby", true, true, Const.VV_GROUP_BY, "module", true, Const.VV_GROUP_BY, Const.ERR_MSG_GROUP_BY), //$NON-NLS-1$
    WIDTH(0, "width", true, true, Const.WI_ID, null, true, Const.VV_WIDTH_HEIGHT, Const.ERR_MSG_WIDTH_HEIGHT), //$NON-NLS-1$
    HEIGHT(0, "height", true, true, Const.WI_ID, null, true, Const.VV_WIDTH_HEIGHT, Const.ERR_MSG_WIDTH_HEIGHT), //$NON-NLS-1$
    PAGE(0, "page", true, true, "(.)+", "home,table,multiedit", true, Const.VV_PAGE, Const.ERR_MSG_PAGE), //$NON-NLS-1$ //$NON-NLS-2$
    ROOT(0, "root", true, true, Const.WI_ID, null, true), //$NON-NLS-1$
    REVISION(0, "revision", true, true, "(.)+", null, true), //$NON-NLS-1$ //$NON-NLS-2$
    ROLES(0, "roles", true, true, "(.)+", null, true), //$NON-NLS-1$//$NON-NLS-2$
    PROPERTY(0, "property", false, false, "(.)+", null, false), //$NON-NLS-1$ //$NON-NLS-2$
    LINK(0, "link", true, true, "(.)+", "yes,no", true), //$NON-NLS-1$ //$NON-NLS-2$
    DESCRIPTION_FIELDS(0, "descriptionFields", true, true, "(.)+", null, true), //$NON-NLS-1$ //$NON-NLS-2$
    SORTBY_PAGES(0, "sortby", false, true, "(name|title|updated|created|~name|~title|~updated|~created)", "name,title,updated,created,~name,~title,~updated,~created", true), //$NON-NLS-1$ //$NON-NLS-2$
    DISPLAY_PAGES(0, "display", false, true, "(table|list)", "list,table", true), //$NON-NLS-1$ //$NON-NLS-2$
    SPACE_PAGES(0, "space", true, true, Const.WI_ID, null, true), //$NON-NLS-1$
    PREFIX(0, "prefix", true, true, ".+", null, true), //$NON-NLS-1$ //$NON-NLS-2$
    TEST_RESULT_ENUM(0, "testResultEnum", true, true, ".+", null, true), //$NON-NLS-1$ //$NON-NLS-2$
    TEST_RUN(0, "testRun", false, false, ".+", null, false), //$NON-NLS-1$ //$NON-NLS-2$
    TEST_RUN_FIELD(0, "testRunField", true, true, ".+", null, true), //$NON-NLS-1$ //$NON-NLS-2$
    ADDITIONAL_FIELDS(0, "additionalFields", true, true, "[^,^:]+:[^,^:]*(,[^,^:]+:[^,^:]*)*,?", "&lt;field:value&gt;,&lt;field:value&gt;,...", true), //$NON-NLS-1$ //$NON-NLS-2$
    TEMPLATE_PROJECT(0, "templateProject", true, true, ".+", null, true), //$NON-NLS-1$ //$NON-NLS-2$
    TEMPLATE_SPACE(0, "templateSpace", true, true, ".+", null, true), //$NON-NLS-1$ //$NON-NLS-2$
    TEMPLATE_PREFIX(0, "templatePrefix", true, true, ".+", null, true), //$NON-NLS-1$ //$NON-NLS-2$
    TEMPLATE(0, "template", true, true, ".+", null, true), //$NON-NLS-1$//$NON-NLS-2$
    TARGET_PROJECT(0, "targetProject", true, true, ".+", null, true), //$NON-NLS-1$ //$NON-NLS-2$
    TARGET_SPACE(0, "targetSpace", true, true, ".+", null, true), //$NON-NLS-1$//$NON-NLS-2$
    DOCUMENT_NAME(0, "document", true, true, Const.WI_ID, null, false), //$NON-NLS-1$
    DOCUMENT_NAME2(0, "document", false, false, "[^/]+/?[^/]*", "spaceId/name or name", false), ; //$NON-NLS-1$ //$NON-NLS-2$

    private final int group; //0 means: is not in group
    private final String name;
    private boolean optional = true;
    private final boolean optionalForUser;
    private boolean mustPrefix = true;
    private final String regexp;
    private final String valueForUser;
    private String validValueRegex = null;
    private String errorMsg = null;

    /**
     * 
     * @param name the name of the parameter
     * @param optional true, if parameter is optional in specific set of parameters
     * @param mustPrefix true, if parameter have to be always like "name=value"
     * @param regex regural expression matches the parameter
     */
    MP(int group, String name, boolean optional, boolean mustPrefix, String regex, String valueForUser, boolean optionalForUser) {
        this.group = group;
        this.name = name;
        this.optional = optional;
        this.mustPrefix = mustPrefix;
        regexp = regex;
        this.valueForUser = valueForUser;
        this.optionalForUser = optionalForUser;
    }

    MP(int group, String name, boolean optional, boolean mustPrefix, String regex, String valueForUser, boolean optionalForUser, String validValueRegex, String errorMsg) {
        this.group = group;
        this.name = name;
        this.optional = optional;
        this.mustPrefix = mustPrefix;
        regexp = regex;
        this.valueForUser = valueForUser;
        this.optionalForUser = optionalForUser;
        this.validValueRegex = validValueRegex;
        this.errorMsg = errorMsg;
    }

    public String getName() {
        return name;
    }

    public boolean isOptional() {
        return optional;
    }

    public boolean isOptionalForUser() {
        return optionalForUser;
    }

    public boolean mustHavePrefix() {
        return mustPrefix;
    }

    public String getValueForUser() {
        if (valueForUser == null) {
            return null;
        } else {
            return "&#91;" + valueForUser + "&#93;"; //$NON-NLS-1$//$NON-NLS-2$
        }
    }

    /**
     * 
     * @return id of group or 0, which means, is not in group
     */
    public int getGroup() {
        return group;
    }

    public String getRegexp() {
        return name + "[\\s]*=[\\s]*" + regexp; //$NON-NLS-1$
    }

    public String getPrefixRegexp() {
        return name + "[\\s]*=(.)*"; //$NON-NLS-1$
    }

    public String checkValue(String value) {
        if (validValueRegex == null) {
            return null;
        }
        if (value.matches(validValueRegex)) {
            return null;
        } else {
            return errorMsg.replace("%value%", value); //$NON-NLS-1$
        }
    }

    public boolean hasCompatible(Set<MP> source) {
        if (group == 0) {
            return false;
        }

        for (MP s : source) {
            if (s.getGroup() == group) {
                return true;
            }
        }
        return false;
    }

    public class Const {
        public static final String WI_ID = "[^/]+"; //$NON-NLS-1$

        public static final String VV_INTEGER = "[0-9]+"; //$NON-NLS-1$
        public static final String VV_WIDTH_HEIGHT = "[0-9]+|[0-9]+px|[0-9]+\\%"; //$NON-NLS-1$
        public static final String VV_GROUP_BY = "module"; //$NON-NLS-1$
//		public static final String VV_GROUP = "/";
        public static final String VV_PAGE = "(home|table|multiedit)";
        public static final String VV_EXPAND_YES_NO = "(yes|no)";
        public static final String VV_SORT_BY = "((\\s)*([~])?([a-zA-Z0-9-_])+(\\s)*)+";
        public static final String VV_HTML_PADDING = "(([0-9]+|([0-9]+.[0-9]+))([%]|px|em|ex|cm|mm|in|pt|pc)?(\\s)+){0,3}(([0-9]+|([0-9]+.[0-9]+))([%]|px|em|ex|cm|mm|in|pt|pc)?)";
        public static final String VV_HTML_SIZE = "([0-9]+|([0-9]+.[0-9]+))(\\s)*([%]|px|em|ex|cm|mm|in|pt|pc)?";

        public static final String ERR_MSG_HTML_SIZE = "Invalid parameter value. It should be CSS allowable value.";
        public static final String ERR_MSG_WIDTH_HEIGHT = "Invalid value <i>%value%</i>. It should be \"NUM %\" or \"NUM px\", where NUM is a positive number or zero.";
//		public static final String ERR_MSG_GROUP = "Invalid value <i>%value%</i>. Currently only \"/\" is supported.";
        public static final String ERR_MSG_TOP = "Invalid value <i>%value%</i>. It should be a positive number.";
        public static final String ERR_MSG_GROUP_BY = "Invalid value <i>%value%</i>. Currently only \"module\" is supported.";
        public static final String ERR_MSG_PAGE = "Invalid value <i>%value%</i>. It should be one of these values: \"home\", \"table\" or \"multiedit\".";
        public static final String ERR_MSG_EXPAND_YES_NO = "Invalid value <i>%value%</i>. It should be one of these values: \"yes\" or \"no\".";
        public static final String ERR_MSG_SORT_BY = "Invalid value <i>%value%</i>. It should be 'fieldName' for ascending sorting or '~fieldName' for descending. If You would like to have more criteria, use 'fieldName1 ~fieldName2'";
        public static final String ERR_MSG_VALIGN = "Invalid value <i>%value%</i>. It should be one of these values: top, middle, bottom.";
        public static final String ERR_MSG_ALIGN = "Invalid value <i>%value%</i>. It should be one of these values: left, right, center.";
        public static final String ERR_MSG_BOLD_COLUMNS = "Invalid value <i>%value%</i>. It should be comma separated positive numbers.";
        public static final String ERR_MSG_METHOD = "Invalid value <i>%value%</i>. It should be one of these values: get or post."; //$NON-NLS-1$
    }
}
