/**
 * 
 */
package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.text.DateFormat;
import java.util.HashMap;
import java.util.Map;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.portal.web.announcements.internal.server.core.impl.AnnouncementsProvider;
import com.polarion.alm.portal.web.announcements.server.core.AnnouncementsException;
import com.polarion.alm.portal.web.announcements.server.core.IAnnouncement;
import com.polarion.alm.portal.web.announcements.server.core.IAnnouncementsProvider;
import com.polarion.alm.portal.web.announcements.server.security.IAnnouncementsPolicy;
import com.polarion.alm.projects.IProjectService;
import com.polarion.alm.projects.model.IProject;
import com.polarion.alm.projects.model.IProjectGroup;
import com.polarion.alm.tracker.ITrackerService;
import com.polarion.core.util.logging.Logger;
import com.polarion.platform.core.PlatformContext;
import com.polarion.platform.service.repository.IRepositoryService;
import com.polarion.reina.web.shared.localization.Localization;
import com.polarion.subterra.base.data.identification.IContextId;
import com.polarion.subterra.base.location.Location;
import com.polarion.wiki.integration.utils.MacroRenderer;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.util.RequestParser;
import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiContext;

/**
 * {announcements}
 * 
 * @author Michal Antolik
 *
 */
public class AnnouncementsMacro extends BaseLocaleMacro {

    private static final Logger log = Logger.getLogger(AnnouncementsMacro.class);

    private static final String NO_ANNOUNCEMENTS = "<div class='hint'>" +
            "Currently there are no announcements.<br />" +
            "You can create one by clicking the 'Add new' link below." +
            "</div>";

    private static IAnnouncementsProvider newsProvider = new AnnouncementsProvider();
    private static IProjectService ps = (IProjectService) PlatformContext.getPlatform().lookupService(IProjectService.class);
    private static ITrackerService ts = (ITrackerService) PlatformContext.getPlatform().lookupService(ITrackerService.class);

    final private MacroUtils utils = MacroUtils.getInstance();
    final private MacroRenderer renderer = MacroRenderer.getInstance();

    private String currentProject;
    private String currentProjectGroup;

    private String macroText;
    private boolean forPdf;
    private Map<String, String> errors;

    private void init(MacroParameter params) {
        currentProject = null;
        currentProjectGroup = null;
        macroText = utils.buildMacroTextFromParameters2("announcements", params);
        forPdf = utils.isPdfExport(utils.getXWikiContext(params));
        errors = new HashMap<String, String>();

//        if (params.getLength() > 0) {
//        	errors.put("Bad parameters", "This macro doesn't need any parameters.");
//        }
    }

    /* (non-Javadoc)
     * @see org.radeox.macro.BaseMacro#execute(java.io.Writer, org.radeox.macro.parameter.MacroParameter)
     */
    @Override
    @SuppressWarnings("unchecked")
    public void execute(Writer writer, MacroParameter params)
            throws IllegalArgumentException, IOException {

        try {
            init(params);
            XWikiContext xcontext = utils.getXWikiContext(params);

            Map requestParams = RequestParser.parseQuery(XWiki.getRequestURL(xcontext.getRequest()).toString(), xcontext);
            currentProject = (String) requestParams.get("project");
            currentProjectGroup = (String) requestParams.get("projectGroup");

            IContextId contextId = getContextId(currentProject, currentProjectGroup);

            writer.write(generateHTML(contextId));

        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            errors.put("Error", "Parsing unknown exception, cause:" + e.getLocalizedMessage());
            writer.write(renderer.renderErrors(errors, macroText, forPdf));
        }

    }

    private IContextId getContextId(String projectId, String groupId) {

        IContextId contextId;
        if (!isEmpty(projectId)) {
            IProject project = ts.getTrackerProject(projectId);
            contextId = project.getContextId();
        } else if (!isEmpty(groupId)) {
//	        IProjectGroup group = ps.getProjectGroupAtLocation(Location.getLocation(IRepositoryService.DEFAULT,"/"+groupId,null));
            //projectsgroup fetch announcements from repository location
            IProjectGroup group = ps.getProjectGroupAtLocation(Location.getLocation(IRepositoryService.DEFAULT, "/", null));
            contextId = group.getContextId();
        } else {
            IProjectGroup group = ps.getProjectGroupAtLocation(Location.getLocation(IRepositoryService.DEFAULT, "/", null));
            contextId = group.getContextId();
        }

        return contextId;
    }

    private String generateHTML(IContextId contextId) {
        IAnnouncement[] items;
        try {
            items = newsProvider.getItems(contextId);

        } catch (AnnouncementsException e) {
//				log.error("Failed to read announcements", e);
            String msg = e.getLocalizedMessage();
            if (msg == null) {
                msg = e.getClass().getName();
            }
            return msg;
        }

        String ext = getLinkExtension();

        StringBuilder b = new StringBuilder();

        b.append("<div>");

        DateFormat df = utils.getDateFormat();

        if (!Boolean.getBoolean("com.polarion.announcements.enabled")) {
            b.append("<div class='hint'>" + Localization.getString("wiki.announcements.disabled") + "</div>");
        } else if (items.length > 0) {
            //announcements are sorted from newer to older, so take 5
            b.append("<ul>");
            for (int i = 0, maxi = (items.length > 4 ? 5 : items.length); i < maxi; i++) {
                IAnnouncement an = items[i];
                b.append("<li><a ").
                        append(forPdf ? "style=\"text-decoration: none;font-size:11px;color: #336699\"" : "").
                        append("href='/polarion/announcements").
                        append(ext).
                        append("'>").
                        append(an.getTitle()).
                        append("</a>");
                if (an.getDate() != null) {
                    b.append("<div class='dateFooter'");
                    b.append(forPdf ? "style=\"color:gray;font-size:11px;\"" : "");
                    b.append(">");
                    b.append(df.format(an.getDate()));
                    b.append("</div>");
                }
                b.append("</li>");
            }
            b.append("</ul>");
        } else {
            b.append(NO_ANNOUNCEMENTS);
        }

        IAnnouncementsPolicy policy = (IAnnouncementsPolicy) PlatformContext.getPlatform().lookupService(IAnnouncementsPolicy.class);

        b.append("<div style=\"text-align: right;\"> ");

        if (!policy.canAdd(contextId)) {
            b.append("<a class='graylinks' " + (forPdf ? "style=\"color:gray;font-size:11px;\"" : "") + "href='' onclick=\"alert('You do not have rights to add announcement')\">Add new</a>");
        } else {
            b.append("<a class='graylinks' " + (forPdf ? "style=\"color:gray;font-size:11px;\"" : "") + "href='/polarion/announcements/addform");
            b.append(ext);
            b.append("'>Add new</a>");
        }

        b.append("&nbsp;|&nbsp;");
        b.append("<a class='graylinks' href='/polarion/announcements/");
        b.append(ext);
        b.append("'>More...</a>");
        b.append("</div>");
        b.append("</div>");

        return b.toString();
    }

    /* (non-Javadoc)
     * @see org.radeox.macro.LocaleMacro#getLocaleKey()
     */
    @Override
    public String getLocaleKey() {
        return "macro.polarionannouncements";
    }

    private boolean isEmpty(String s) {
        return (s == null) || (s.trim().length() == 0);
    }

    private String getLinkExtension() {
        if (!isEmpty(currentProject)) {
            return "?project=" + currentProject.trim();
        } else if (!isEmpty(currentProjectGroup)) {
            return "?group=" + currentProjectGroup.trim();
        }

        return "";
    }

//			/polarion/announcements?group=PROJECT/GROUP/PATH (musi byt aby fungovalo back tlacitko)
}
