/*
 * Copyright (C) 2004-2013 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2013 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.polarion.wiki.integration.plans;

import java.io.IOException;
import java.io.Writer;
import java.util.Map;

import org.jetbrains.annotations.NotNull;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.server.api.model.rp.widget.plan.WorkItemsBoardRenderer;
import com.polarion.alm.shared.api.model.plan.internal.InternalPlan;
import com.polarion.alm.tracker.ITrackerService;
import com.polarion.alm.ui.server.wiki.macro.impl.PlainMacroImpl;
import com.polarion.alm.ui.server.wiki.plan.board.WorkItemsBoardParameters;
import com.polarion.alm.ui.shared.wiki.ParameterNames;
import com.polarion.platform.core.PlatformContext;
import com.polarion.portal.server.HTMLBuilder;
import com.polarion.portal.shared.wiki.SharedMacroContextImpl;
import com.polarion.wiki.integration.XWikiGwtMacro;

public class WorkItemsBoardMacro extends XWikiGwtMacro {

    @NotNull
    private static final ITrackerService trackerService = PlatformContext.getPlatform().lookupService(ITrackerService.class);

    @Override
    @NotNull
    protected String getMacroId() {
        return WorkItemsBoardParameters.MACRO_ID;
    }

    @Override
    public boolean hasLicense() {
        return trackerService.getTrackerPolicy().canUsePlans();
    }

    @Override
    public void execute(Writer writer, MacroParameter parameters) throws IllegalArgumentException, IOException {
        new DataRenderer(new Data(parameters)).render(writer);
    }

    private class Data extends MacroData {

        @NotNull
        final WorkItemsBoardParameters parameters;

        Data(@NotNull MacroParameter inputParameters) {
            super(inputParameters);
            parameters = new WorkItemsBoardParameters(macroContext, new PlainMacroImpl(getMacroText(inputParameters)));
        }

        @Override
        @NotNull
        public Map<String, String> getErrors() {
            return parameters.validate();
        }

        @Override
        @NotNull
        public Map<String, String> getParameters() {
            Map<String, String> map = parameters.getMap();

            SharedMacroContextImpl.persist(macroContext, map);

            map.put(ParameterNames.PLAN, parameters.getPlan().getReferenceToCurrent().toPath());

            return map;
        }
    }

    class DataRenderer extends MacroDataRenderer<Data> {

        DataRenderer(@NotNull final Data data) {
            super(data);
        }

        @Override
        protected void renderStatical(@NotNull HTMLBuilder builder) throws Exception {
            if (data.wikiContext.isInCompareMode()) {
                super.renderStatical(builder);
            } else {
                String html = new WorkItemsBoardRenderer(data.parameters).getResult();
                builder.appendHTML(html);
            }
        }

    }

}
