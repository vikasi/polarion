package com.polarion.wiki.integration.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.polarion.alm.projects.model.IProject;
import com.polarion.alm.projects.model.IProjectGroup;
import com.polarion.alm.projects.model.IUniqueObject;
import com.polarion.core.util.RunnableWEx;
import com.polarion.core.util.logging.Logger;
import com.polarion.platform.persistence.IQueryHelper;
import com.polarion.platform.persistence.WrapperException;
import com.polarion.platform.persistence.model.IPObject;
import com.polarion.platform.persistence.model.IPObjectList;
import com.polarion.platform.service.repository.IRepositoryService;
import com.polarion.platform.sql.InterruptedStatementException;
import com.polarion.reina.web.shared.localization.Localization;
import com.polarion.subterra.base.location.Location;
import com.polarion.wiki.integration.utils.MacroUtils.ExpandMode;
import com.polarion.wiki.integration.utils.MacroUtils.FieldProperty;
import com.xpn.xwiki.XWikiContext;

public class WorkItemsMacroParser extends MacroParser {

    private static final Logger log = Logger.getLogger(WorkItemsMacroParser.class);

    final static private MP[] rule1 = {
            MP.QUERY, MP.PROJECT, MP.DISPLAY_LIST, MP.EXPAND_YES_NO, MP.FIELDS, MP.TOP, MP.SORTBY, MP.WIDTH, MP.HEIGHT, MP.LINK
    };
    final static private MP[] rule2 = {
            MP.QUERY, MP.PROJECT, MP.DISPLAY_TABLE, MP.EXPAND_YES_NO, MP.FIELDS, MP.TOP, MP.SORTBY, MP.WIDTH, MP.HEIGHT, MP.LINK
    };
    final static private MP[] rule3 = {
            MP.QUERY, MP.PROJECT, MP.DISPLAY_DOCUMENT, MP.EXPAND_YES_NO, MP.FIELDS, MP.TOP, MP.SORTBY, MP.WIDTH, MP.HEIGHT, MP.ROOT, MP.LINK
    };
    final static private MP[] rule4 = {
            MP.QUERY, MP.GROUP, MP.DISPLAY_LIST, MP.EXPAND_YES_NO, MP.FIELDS, MP.TOP, MP.SORTBY, MP.WIDTH, MP.HEIGHT, MP.LINK
    };
    final static private MP[] rule5 = {
            MP.QUERY, MP.GROUP, MP.DISPLAY_TABLE, MP.EXPAND_YES_NO, MP.FIELDS, MP.TOP, MP.SORTBY, MP.WIDTH, MP.HEIGHT, MP.LINK
    };
    final static private MP[] rule6 = {
            MP.QUERY, MP.GROUP, MP.DISPLAY_DOCUMENT, MP.EXPAND_YES_NO, MP.FIELDS, MP.TOP, MP.SORTBY, MP.WIDTH, MP.HEIGHT, MP.ROOT, MP.LINK
    };
    final static private MP[] rule7 = {
            MP.QUERY, MP.PROJECT, MP.DISPLAY_COUNT, MP.LINK
    };
    final static private MP[] rule8 = {
            MP.QUERY, MP.GROUP, MP.DISPLAY_COUNT, MP.LINK
    };
    final static private MP[] rule9 = {
            MP.QUERY_NAME, MP.PROJECT, MP.DISPLAY_COUNT, MP.LINK
    };
//    final static private MP[] rule10 = {
//        MP.QUERY_NAME, MP.GROUP, MP.DISPLAY_COUNT
//    };
    final static private MP[] rule11 = {
            MP.QUERY_NAME, MP.PROJECT, MP.DISPLAY_LIST, MP.EXPAND_YES_NO, MP.FIELDS, MP.TOP, MP.SORTBY, MP.WIDTH, MP.HEIGHT
    };
    final static private MP[] rule12 = {
            MP.QUERY_NAME, MP.PROJECT, MP.DISPLAY_TABLE, MP.EXPAND_YES_NO, MP.FIELDS, MP.TOP, MP.SORTBY, MP.WIDTH, MP.HEIGHT
    };
    final static private MP[] rule13 = {
            MP.QUERY_NAME, MP.PROJECT, MP.DISPLAY_DOCUMENT, MP.EXPAND_YES_NO, MP.FIELDS, MP.TOP, MP.SORTBY, MP.WIDTH, MP.HEIGHT
    };
//    final static private MP[] rule14 = {
//        MP.QUERY_NAME, MP.GROUP, MP.DISPLAY_LIST, MP.EXPAND_YES_NO, MP.FIELDS, MP.TOP, MP.SORTBY, MP.WIDTH, MP.HEIGHT
//    };
//    final static private MP[] rule15 = {
//        MP.QUERY_NAME, MP.GROUP, MP.DISPLAY_TABLE, MP.EXPAND_YES_NO, MP.FIELDS, MP.TOP, MP.SORTBY, MP.WIDTH, MP.HEIGHT
//    };
//    final static private MP[] rule16 = {
//        MP.QUERY_NAME, MP.GROUP, MP.DISPLAY_DOCUMENT, MP.EXPAND_YES_NO, MP.FIELDS, MP.TOP, MP.SORTBY, MP.WIDTH, MP.HEIGHT
//    };

    final static private MP[] rule17 = {
            MP.PROJECT_SLASH_QUERY_NAME, MP.PROJECT, MP.DISPLAY_LIST, MP.EXPAND_YES_NO, MP.FIELDS, MP.TOP, MP.SORTBY, MP.WIDTH, MP.HEIGHT
    };
    final static private MP[] rule18 = {
            MP.PROJECT_SLASH_QUERY_NAME, MP.PROJECT, MP.DISPLAY_TABLE, MP.EXPAND_YES_NO, MP.FIELDS, MP.TOP, MP.SORTBY, MP.WIDTH, MP.HEIGHT
    };
    final static private MP[] rule19 = {
            MP.PROJECT_SLASH_QUERY_NAME, MP.PROJECT, MP.DISPLAY_DOCUMENT, MP.EXPAND_YES_NO, MP.FIELDS, MP.TOP, MP.SORTBY, MP.WIDTH, MP.HEIGHT
    };
//    final static private MP[] rule20 = {
//        MP.PROJECT_SLASH_QUERY_NAME, MP.GROUP, MP.DISPLAY_LIST, MP.EXPAND_YES_NO, MP.FIELDS, MP.TOP, MP.SORTBY, MP.WIDTH, MP.HEIGHT
//    };
//    final static private MP[] rule21 = {
//        MP.PROJECT_SLASH_QUERY_NAME, MP.GROUP, MP.DISPLAY_TABLE, MP.EXPAND_YES_NO, MP.FIELDS, MP.TOP, MP.SORTBY, MP.WIDTH, MP.HEIGHT
//    };
//    final static private MP[] rule22 = {
//        MP.PROJECT_SLASH_QUERY_NAME, MP.GROUP, MP.DISPLAY_DOCUMENT, MP.EXPAND_YES_NO, MP.FIELDS, MP.TOP, MP.SORTBY, MP.WIDTH, MP.HEIGHT
//    };
    final static private MP[] rule23 = {
            MP.PROJECT_SLASH_QUERY_NAME, MP.PROJECT, MP.DISPLAY_COUNT, MP.LINK
    };
//    final static private MP[] rule24 = {
//        MP.PROJECT_SLASH_QUERY_NAME, MP.GROUP, MP.DISPLAY_COUNT
//    };

    final static private MP[] rule25 = {
            MP.SQL_QUERY, MP.DISPLAY_LIST, MP.EXPAND_YES_NO, MP.FIELDS, MP.TOP, MP.WIDTH, MP.HEIGHT
    };
    final static private MP[] rule26 = {
            MP.SQL_QUERY, MP.DISPLAY_TABLE, MP.EXPAND_YES_NO, MP.FIELDS, MP.TOP, MP.WIDTH, MP.HEIGHT
    };
    final static private MP[] rule27 = {
            MP.SQL_QUERY, MP.DISPLAY_DOCUMENT, MP.EXPAND_YES_NO, MP.FIELDS, MP.TOP, MP.WIDTH, MP.HEIGHT
    };
    final static private MP[] rule28 = {
            MP.SQL_QUERY, MP.DISPLAY_COUNT, MP.EXPAND_YES_NO, MP.FIELDS, MP.TOP, MP.WIDTH, MP.HEIGHT
    };

    static final private List<MP[]> rules = new ArrayList<MP[]>();

    static {
        rules.add(rule1);
        rules.add(rule2);
        rules.add(rule3);
        rules.add(rule4);
        rules.add(rule5);
        rules.add(rule6);
        rules.add(rule7);
        rules.add(rule8);
        rules.add(rule9);
//         ruleList.add(rule10);
        rules.add(rule11);
        rules.add(rule12);
        rules.add(rule13);
//         ruleList.add(rule14);
//         ruleList.add(rule15);
//         ruleList.add(rule16);
        rules.add(rule17);
        rules.add(rule18);
        rules.add(rule19);
//         ruleList.add(rule20);
//         ruleList.add(rule21);
//         ruleList.add(rule22);
        rules.add(rule23);
//         ruleList.add(rule24);
        rules.add(rule25);
        rules.add(rule26);
        rules.add(rule27);
        rules.add(rule28);
    }

    static final private Set<MP> uniqueParameters = getUniqueParameters(rules);

    public WorkItemsMacroParser(XWikiContext context) {
        super(context, rules, uniqueParameters);
    }

    @Override
    @SuppressWarnings("unchecked")
    public String parse(Collection<String> col, String macroText, boolean forPdf) {
        this.col = col;
        this.macroText = macroText;
        this.forPdf = forPdf;

        if (col != null) {
            for (Iterator iterator = col.iterator(); iterator.hasNext();) {
                String value = (String) iterator.next();
                if (value.startsWith("revision=")) { //$NON-NLS-1$
                    macroText = macroText.replaceAll(value + "|", ""); //$NON-NLS-1$ //$NON-NLS-2$
                    context.put("revision", value.substring(9)); //$NON-NLS-1$
                    iterator.remove();
                }
            }
        }

        Map<String, FieldProperty> fields = null;
        int originalListSize = 0;
        List<IPObject> list = null;
        IProject project = null;
        String projectId = null;
        String query = null;
        String moreLink = null;
        String projectsQuery = null;

        try {
            utils.addDefaultParameter(MP.DISPLAY_TABLE.getName(), "table", col); //$NON-NLS-1$

            String err = parseParameters();
            if (err != null) {
                return err;
            }

            boolean withLink = utils.showLink(map);

            if (map.containsKey(MP.PROJECT)) {
                project = utils.getProject(map.get(MP.PROJECT), errors);
                if (project == null) {
                    return renderer.renderErrors(errors, macroText, forPdf);
                }
            }

            if (map.containsKey(MP.SQL_QUERY)) {
                map.put(MP.GROUP, "/"); //$NON-NLS-1$
            }

            if (map.containsKey(MP.GROUP)) {
                String groupLocation = map.get(MP.GROUP);
                if (!groupLocation.equals("/")) { //$NON-NLS-1$
                    StringBuilder sb = new StringBuilder();

                    IProjectGroup group = null;
                    group = projectService.getProjectGroupAtLocation(Location.getLocation(IRepositoryService.DEFAULT, groupLocation, null));

                    IPObjectList projects = group.getDeepContainedProjects();
                    Iterator<IPObject> it = projects.iterator();
                    while (it.hasNext()) {
                        IProject p = (IProject) it.next();

                        sb.append("("); //$NON-NLS-1$
                        sb.append(IUniqueObject.KEY_PROJECT);
                        sb.append(".id:\""); //$NON-NLS-1$
                        sb.append(p.getId());
                        sb.append("\")"); //$NON-NLS-1$
                        if (it.hasNext()) {
                            sb.append(" OR "); //$NON-NLS-1$
                        }
                    }

                    projectsQuery = sb.toString();
                }
            } else if (project == null) {
                //search on current scope, but only if scope is project!
                project = utils.getCurrentProject(context);
//	            if(project == null){
//            		return renderer.renderError(MP.PROJECT.getName(), "Parameter 'project' is not set, and current scope is not project.", macroText, forPdf);
//	            }
            }

            if (project != null) {
                projectId = project.getId();
                projectsQuery = IUniqueObject.KEY_PROJECT + ".id:\"" + project.getId() + "\""; //$NON-NLS-1$ //$NON-NLS-2$
            }

            query = utils.getQuery(map, project, errors);
            if (query == null) {
                return renderer.renderErrors(errors, macroText, forPdf);
            }

            String origQuery = query;

            if (projectsQuery != null) {
                if (query.equals("")) { //$NON-NLS-1$
                    query = projectsQuery;
                } else {
                    query = "(" + query + ") AND (" + projectsQuery + ")"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
                }
            }

            final String sort = map.get(MP.SORTBY);

            String revision = (String) context.get("revision"); //$NON-NLS-1$

//            SEARCH START
            final String paramSqlQuery = query;

            RunnableWEx<List<IPObject>> searchRunable = new RunnableWEx<List<IPObject>>() {
                @Override
                public List<IPObject> runWEx() throws Exception {
                    List<IPObject> result = null;

                    if (map.containsKey(MP.SQL_QUERY)) {
                        String sqlQuery = map.get(MP.SQL_QUERY);
                        result = trackerService.getDataService().sqlSearch(sqlQuery);
                    } else {
                        result = trackerService.queryWorkItems(paramSqlQuery, sort);
                    }

                    return result;
                }
            };
            try {
                if (revision != null) {
                    /* DPP-34477 - Revert: Work-Items macro displayed in revision searches in HEAD
                     * 
                     * => Revision parameter is ignored for now.
                     */
                    //  list = trackerService.getDataService().doInBaseline(revision, searchRunable);
                    list = searchRunable.runWEx();
                    // DPP-34477 End
                } else {
                    list = searchRunable.runWEx();
                }
            } catch (Exception e) {
                if ((e instanceof WrapperException) && (((WrapperException) e).getCause() instanceof InterruptedStatementException)) {
                    errors.put("Error", Localization.getString("macro.workitems.queryCanceled")); //$NON-NLS-1$//$NON-NLS-2$
                } else {
                    errors.put("Error", Localization.getString("macro.workitems.queryIsInvalid") + " " + e.getLocalizedMessage()); //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$
                }
            }
            if (map.containsKey(MP.SQL_QUERY)) {
                String sqlQuery = map.get(MP.SQL_QUERY);
                origQuery = IQueryHelper.FIELD_SQL + ":(" + sqlQuery + ")"; //$NON-NLS-1$ //$NON-NLS-2$
                query = map.get(MP.SQL_QUERY);
            }

            if (list == null) {
                list = new ArrayList<IPObject>();
            }

            originalListSize = list.size();
            list = utils.getTopItems(list, map.get(MP.TOP), 50);

            fields = fieldParser.getWorkItemFields(map, errors, false, false);

            if (withLink) {
                if (project == null) {
                    moreLink = utils.getGroupQueryLink(map.get(MP.GROUP), origQuery, sort, revision);
                } else {
                    moreLink = utils.getProjectQueryLink(projectId, origQuery, sort, revision);
                }
            }

            moreLink = utils.escapeURLValue(moreLink);
            if (!errors.isEmpty()) {
                return renderer.renderErrors(errors, macroText, forPdf);
            }

            if (map.containsKey(MP.DISPLAY_LIST)) {
                return renderer.renderListOfPObjects(
                        list,
                        fields,
                        utils.getExpandMode(map),
                        utils.getPolarionServerURL(context),
                        null,
                        utils.getWidth(map),
                        utils.getHeight(map),
                        forPdf,
                        withLink,
                        context);
            } else if (map.containsKey(MP.DISPLAY_COUNT)) {
                if (withLink) {
                    return renderer.getRenderedCount(originalListSize, forPdf, moreLink);
                } else {
                    return renderer.getRenderedCount(originalListSize, forPdf, null);
                }

            } else if (map.containsKey(MP.DISPLAY_TABLE)) {
                utils.setWidthForFields(fields, null);
                FieldProperty property = fields.get(IUniqueObject.KEY_ID);
                if (property != null) {
                    Map<String, String> fieldProperties = new HashMap<String, String>();
                    fieldProperties.put(IUniqueObject.KEY_ID, IUniqueObject.KEY_ID);
                    property.props = fieldProperties;
                } else {
                    String fieldsGroup = map.get(MP.FIELDS);
                    if (fieldsGroup != null) {
                        String[] fs = fieldsGroup.split("[,]"); //$NON-NLS-1$
                        if (fs != null && fs.length > 0) {
                            property = fields.get(fs[0]);
                            if (property != null) {
                                Map<String, String> fieldProperties = new HashMap<String, String>();
                                fieldProperties.put(IUniqueObject.KEY_ID, fs[0]);
                                property.props = fieldProperties;
                            }
                        }
                    }
                }
                if (list.isEmpty()) {
                    map.put(MP.EXPAND_YES_NO, ExpandMode.NO.getName());
                }
                return renderer.renderFlatTable(
                        fields,
                        macroText,
                        list,
                        originalListSize,
                        query,
                        moreLink,
                        context,
                        null,
                        utils.getExpandMode(map),
                        utils.getWidth(map),
                        utils.getHeight(map),
                        forPdf,
                        withLink);
            } else {
                return Localization.getString("macro.general.sorryNothing");//shouldn't happen  //$NON-NLS-1$
            }
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            errors.put("Error", Localization.getString("macro.general.parsingUnknownException") + e.getLocalizedMessage()); //$NON-NLS-1$ //$NON-NLS-2$
            return renderer.renderErrors(errors, macroText, forPdf);
        }
    }
}
