package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.wiki.integration.utils.MacroRenderer;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.xpn.xwiki.XWikiContext;

public class PanelMacro extends BaseLocaleMacro {

    @Override
    public void execute(Writer writer, MacroParameter parameters) throws IllegalArgumentException, IOException {
        String content = parameters.getContent();
        if (content == null) {
            content = "No Content.";
        }

        //width
        String width = parameters.get("width");
        if (isEmpty(width)) {
            width = "100%"; //default value
        }

        //width
        String height = parameters.get("height");
        if (isEmpty(height)) {
            height = ""; //default value
        }

        //footer
        String footer = parameters.get("footer");
        if (isEmpty(footer)) {
            footer = null; //default value
        }

        //expand
        boolean expanded = true;
        String expand = parameters.get("expand");
        if (!isEmpty(expand)) {
            if (expand.matches("(\\s)no(\\s)")) {
                expanded = false;
            }
        }

        XWikiContext context = MacroUtils.getInstance().getXWikiContext(parameters);
        String pdf = (String) context.get("pdf_generate");

        String uniqueId = IntegrationPlugin.getUniqName();
        String result;
        if (pdf == null || pdf.equalsIgnoreCase("0")) {
            result = MacroRenderer.getInstance().renderPanel(uniqueId, content, footer, expanded, width, height, false, context);
        } else {
            result = MacroRenderer.getInstance().renderPanel(uniqueId, content, footer, expanded, width, height, true, context);
        }
        writer.write(result);
    }

    @Override
    public String getLocaleKey() {
        return "macro.polarionpanel";
    }

    private boolean isEmpty(String s) {
        return (s == null) || ("".equals(s.trim()));
    }
}
