package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.Map;

import org.radeox.api.engine.RenderEngine;
import org.radeox.api.engine.context.RenderContext;
import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.tracker.model.ITrackerProject;
import com.polarion.core.util.logging.Logger;
import com.polarion.portal.internal.shared.navigation.BaselineHelper;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.util.RequestParser;
import com.polarion.wiki.web.BaselineServlet;
import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.render.XWikiRadeoxRenderEngine;

public class PortalLinkMacro extends BaseLocaleMacro
{

    private static Logger log = Logger.getLogger(PortalLinkMacro.class);

    @SuppressWarnings("unchecked")
    @Override
    public void execute(Writer writer, MacroParameter params) throws IllegalArgumentException, IOException {
        String content = params.getContent();
        if (content == null) {
            content = "";
        }
        //do not create links in content
        content = content.replaceAll(":", "&#58;");

        String link = params.get(0);
        if (link == null) {
            throw new IllegalArgumentException("link cannot be empty");
        }
        link = link.trim();

        Map<String, String> parameters = MacroUtils.getInstance().getParameterMap(params);
        String addcontext = parameters.get("addcontext");
        String prefix = "/polarion/#" + BaselineHelper.getBaselineURLPart(BaselineServlet.getCurrentBaselineRevision(), true, false);
        if (addcontext != null && addcontext.equalsIgnoreCase("yes")) {
            try {
                RenderContext context = params.getContext();
                RenderEngine engine = context.getRenderEngine();
                XWikiContext xcontext = ((XWikiRadeoxRenderEngine) engine).getContext();
                MacroUtils utils = MacroUtils.getInstance();
                ITrackerProject project = utils.getCurrentProject(params.getContext());
                if (project == null) {
                    Map requestParams = RequestParser.parseQuery(XWiki.getRequestURL(xcontext.getRequest()).toString(), xcontext);
                    String groupLocation = (String) requestParams.get("projectGroup");
                    if (groupLocation != null && !"".equals(groupLocation)) {
                        groupLocation = groupLocation.replaceAll("/", "//");
                        prefix = prefix + "/group/" + groupLocation;
                    }
                } else {
                    prefix = prefix + "/project/" + project.getLocalId().getObjectName();
                }

                link = prefix + link;
            } catch (Exception e) {
                log.error(e.getLocalizedMessage(), e);
            }
        } else if (!link.startsWith("/polarion")) {
            link = prefix + link;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("<a target='_top' href='" + link + "'>");
        sb.append(content);
        sb.append("</a>");
        writer.write(sb.toString());
    }

    @Override
    public String getLocaleKey() {
        return "macro.portallink";
    }

}
