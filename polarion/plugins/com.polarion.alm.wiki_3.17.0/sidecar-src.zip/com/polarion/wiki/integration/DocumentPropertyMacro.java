package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.tracker.ITrackerService;
import com.polarion.alm.tracker.model.IModule;
import com.polarion.alm.tracker.model.ITrackerProject;
import com.polarion.alm.ui.shared.FieldRenderType;
import com.polarion.platform.core.PlatformContext;
import com.polarion.portal.shared.IJSUIObject;
import com.polarion.wiki.integration.utils.MacroRenderer;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.integration.utils.ModuleHelper;

public class DocumentPropertyMacro extends BaseLocaleMacro {

    final private static ITrackerService trackerService = PlatformContext.getPlatform().lookupService(ITrackerService.class);
    final private MacroUtils utils = MacroUtils.getInstance();

    final private static String MODULE_NAME_PREFIX = "name"; //$NON-NLS-1$
    final private static String MODULE_NAME_PREFIX_OLD = "moduleName"; //$NON-NLS-1$
    final private static String MSG_BAD_PARAMETERS = "Bad Parameters"; //$NON-NLS-1$

    @Override
    public void execute(Writer writer, MacroParameter params) throws IllegalArgumentException, IOException {
        String moduleName = null;
        String property = null;
        if (params.getLength() > 1) {
            moduleName = params.get(0);
            property = params.get(1);
        } else {
            utils.renderError(MSG_BAD_PARAMETERS, writer);
            return;
        }
        if (moduleName != null && property != null) {
            if (moduleName.startsWith(MODULE_NAME_PREFIX)) {
                moduleName = moduleName.substring(MODULE_NAME_PREFIX.length() + 1);
            }
            if (moduleName.startsWith(MODULE_NAME_PREFIX_OLD)) {
                moduleName = moduleName.substring(MODULE_NAME_PREFIX_OLD.length() + 1);
            }
            renderProperty(moduleName, property, writer, params);
        } else {
            utils.renderError(MSG_BAD_PARAMETERS, writer);
            return;
        }
    }

    private void renderProperty(String moduleName, String property, Writer writer, MacroParameter params) throws IOException {
        ITrackerProject project = utils.getCurrentProject(params.getContext());
        IModule module = new ModuleHelper(trackerService, project, moduleName, null).getModule();

        if (module.getValue(property) != null) {
            List<String> fields = new ArrayList<String>();
            fields.add(property);
            IJSUIObject instance = MacroRenderer.transformInstance(module, fields);
            String renderField = MacroRenderer.renderField(instance, property, FieldRenderType.TXTIMG, false, false, module, null);
            writer.write(renderField);
        } else {
            writer.write(utils.format(null));
        }
        return;
    }

    @Override
    public String getLocaleKey() {
        return "macro.document-property"; //$NON-NLS-1$
    }
}
