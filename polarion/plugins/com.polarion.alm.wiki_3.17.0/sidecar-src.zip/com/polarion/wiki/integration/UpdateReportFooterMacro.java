/*
 * Copyright (C) 2004-2009 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2009 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;

import org.radeox.api.engine.RenderEngine;
import org.radeox.api.engine.context.RenderContext;
import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.reports.server.ReportsPolicy;
import com.polarion.wiki.integration.utils.MacroRenderer;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.web.BaselineServlet;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.render.XWikiRadeoxRenderEngine;

/**
 * @author <a href="mailto:dev@polarion.com">Jakub Stroleny</a>, Polarion Software
 */
public class UpdateReportFooterMacro extends BaseLocaleMacro {

    private String reportPath;
    private String calculation;

    private static final String LIVE_PLAN = "xml/live-plan.xml";

    private static final String PARAM_REPORT_PATH = "report-path";
    private static final String PARAM_CALCULATION = "calculation";

    private static final MacroUtils utils = MacroUtils.getInstance();
    private static final MacroRenderer renderer = MacroRenderer.getInstance();
    private static final ReportsPolicy policy = ReportsPolicy.getPolicy();

    @Override
    public String getLocaleKey() {
        return "macro.polarionreportfooter";
    }

    @Override
    public String getName() {
        return "update-report-footer";
    }

    public String getReportPath(MacroParameter params) {
        return params.get(PARAM_REPORT_PATH);
    }

    public String getCalculation(MacroParameter params) {
        String calc = params.get(PARAM_CALCULATION);
        return calc != null ? calc : "all";
    }

    @Override
    public void execute(Writer writer, MacroParameter params)
            throws IllegalArgumentException, IOException {
        init(writer, params);
    }

    @SuppressWarnings("unchecked")
    private void init(Writer writer, MacroParameter params) throws IOException {
        RenderContext context = params.getContext();
        RenderEngine engine = context.getRenderEngine();
        XWikiContext xcontext = ((XWikiRadeoxRenderEngine) engine).getContext();
        boolean forPdf = utils.isPdfExport(utils.getXWikiContext(params));
        reportPath = getReportPath(params);
        calculation = getCalculation(params);
        String uniqName = IntegrationPlugin.getUniqName();

        if (forPdf || (BaselineServlet.getCurrentBaselineRevision() != null)) {
            return;
        }

        boolean canUse = true;
        if ("update-report-footer".equals(getName())) {
            if (LIVE_PLAN.equals(reportPath)) {
                canUse = policy.canUseLiveplan();
            } else {
                canUse = policy.canUseDashboardMacros();
            }
        }
        if (!canUse) {
            writer.write(renderer.renderInaccessibleMessage(true, canUse));
            return;
        }

        if (isEmpty(reportPath)) {
            writer.append("UpdateReportFooter: Parameter report-path have to be set");
            return;
        }
        if (isEmpty(calculation) && !LIVE_PLAN.equals(reportPath)) {
            writer.append("UpdateReportFooter: Parameter Calculation have to be set");
            return;
        }

        String url = xcontext.getURL().getPath();
        url = url.substring(0, url.indexOf("bin/") + 4) + "updatechart" + url.substring(url.indexOf("/", url.indexOf("bin/") + 4), url.length());
        url += "?myaction=init";
        url += "&data=" + reportPath;
        url += "&calculation=" + calculation;
        url += "&id=" + uniqName;

        String functionName = "updatechart_" + uniqName;

        StringBuilder js = new StringBuilder();
        js.append("function ");
        js.append(functionName).append("(e) {");
        js.append("if (e == 'refresh') {");
        js.append("location.reload(true);");
        js.append("} else {");
        js.append("document.getElementById(\"update-report-footer_").append(uniqName).append("\").innerHTML=e;}}");

        StringBuilder sb = new StringBuilder();
        sb.append("<script type=\"text/javascript\" id=\"scriptmacro_");
        sb.append(uniqName).append("\">");
        sb.append(js);
        sb.append("executeCommand('").append(url).append("', ").append(functionName).append(");");
        sb.append("</script>");
        sb.append("<div style=\"text-align: left;font-size:90%;color:gray\" id=\"update-report-footer_" + uniqName + "\">");
        sb.append("<img alt=\"Loading...\" title=\"Loading...\" src=\"/polarion/wiki/skins/sidecar/progress_small.gif\"/>");
        sb.append("</div>");

        writer.write(sb.toString());
    }

    private boolean isEmpty(String s) {
        return (s == null) || (s.trim().length() == 0);
    }

}
