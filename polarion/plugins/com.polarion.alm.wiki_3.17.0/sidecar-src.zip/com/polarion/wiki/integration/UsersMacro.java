package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.Collection;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.integration.utils.UsersMacroParser;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.util.Util;

/**
 * {users: QUERY} 
 * {users|project=PolarionSVN}
 * Parameters like for workitems
 * 
 * @author Michal Antolik
 *
 */
public class UsersMacro extends BaseLocaleMacro {

    final private MacroUtils utils = MacroUtils.getInstance();

    @Override
    @SuppressWarnings("unchecked")
    public void execute(Writer writer, MacroParameter parameters)
            throws IllegalArgumentException, IOException {

        XWikiContext context = utils.getXWikiContext(parameters);
        Collection<String> col = utils.getParameters(parameters);

        utils.addParameterNameToValue("query", col);

        String displayMethod = parameters.get("display");

        String pdf = (String) context.get("pdf_generate");
        String compare = (String) context.get("compareMode");

        if ((compare != null && compare.equalsIgnoreCase("1")))
        {
            String result = null;
            result = utils.buildMacroTextFromParametersForCompare("users", col);
            if (result != null) {
                result = Util.encodeLinkInCompare(result);
            }
            result = "<img src=\"/polarion/ria/images/wiki/macro_users.gif\" alt=\"" + result + "\"/>";

            writer.write(result);
        }
        else if ((pdf == null || pdf.equalsIgnoreCase("0")) && !"count".equals(displayMethod)) {
            String ajaxLink = utils.getAjaxLink(col, context, "usersmacroaction");
            writer.write(ajaxLink);
        } else {
            UsersMacroParser parser = new UsersMacroParser(context);
            String macroText = utils.buildMacroTextFromParameters("users", col);

            String result = parser.parse(col, macroText, true);
            writer.write(result);
        }

    }

    @Override
    public String getLocaleKey() {
        return "macro.polarionusers";
    }

}
