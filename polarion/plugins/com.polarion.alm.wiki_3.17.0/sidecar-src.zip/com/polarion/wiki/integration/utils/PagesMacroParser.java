package com.polarion.wiki.integration.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jetbrains.annotations.Nullable;

import com.polarion.alm.projects.IProjectService;
import com.polarion.alm.projects.model.IProject;
import com.polarion.alm.projects.model.IProjectGroup;
import com.polarion.alm.tracker.model.IModule;
import com.polarion.alm.tracker.model.IWikiPage;
import com.polarion.core.util.logging.Logger;
import com.polarion.platform.core.PlatformContext;
import com.polarion.platform.persistence.IDataService;
import com.polarion.platform.persistence.IPersistencePolicy;
import com.polarion.platform.persistence.model.IPObject;
import com.polarion.platform.persistence.model.IPObjectList;
import com.polarion.platform.service.repository.IRepositoryService;
import com.polarion.reina.web.shared.localization.Localization;
import com.polarion.subterra.base.location.Location;
import com.polarion.wiki.integration.link.ILink;
import com.polarion.wiki.integration.utils.MacroUtils.FieldProperty;
import com.polarion.wiki.util.Constants;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.doc.XWikiDocument;

public class PagesMacroParser extends MacroParser
{

    private IProjectService ps = PlatformContext.getPlatform().lookupService(IProjectService.class);

    private static final Logger log = Logger.getLogger(RecentlyModifiedWorkitemsMacroParser.class);

    final static private MP[] rule1 = {
            MP.PROJECT2, MP.QUERY, MP.TOP, MP.SORTBY_PAGES, MP.FIELDS, MP.SPACE_PAGES
    };

    final static private MP[] rule2 = {
            MP.PROJECT2, MP.TOP, MP.SORTBY_PAGES, MP.FIELDS, MP.SPACE_PAGES
    };

    final static private MP[] rule3 = {
            MP.QUERY, MP.TOP, MP.SORTBY_PAGES, MP.FIELDS, MP.SPACE_PAGES
    };

    final static private MP[] rule4 = {
            MP.TOP, MP.SORTBY_PAGES, MP.FIELDS, MP.SPACE_PAGES
    };

    final static private MP[] rule35 = {
            MP.TOP, MP.SPACE_PAGES
    };

    final static private MP[] rule5 = {
            MP.PROJECT2
    };

    final static private MP[] rule6 = {
            MP.QUERY, MP.SPACE_PAGES
    };

    final static private MP[] rule7 = {
            MP.PROJECT2, MP.TOP, MP.FIELDS, MP.SPACE_PAGES
    };

    final static private MP[] rule8 = {
            MP.PROJECT2, MP.SORTBY_PAGES, MP.FIELDS
    };

    final static private MP[] rule9 = {
            MP.QUERY, MP.TOP, MP.FIELDS
    };

    final static private MP[] rule10 = {
            MP.QUERY, MP.SORTBY_PAGES, MP.FIELDS, MP.SPACE_PAGES
    };

    final static private MP[] rule11 = {
            MP.PROJECT2, MP.QUERY, MP.TOP, MP.SORTBY_PAGES, MP.DISPLAY_PAGES, MP.FIELDS, MP.SPACE_PAGES
    };

    final static private MP[] rule12 = {
            MP.PROJECT2, MP.TOP, MP.SORTBY_PAGES, MP.DISPLAY_PAGES, MP.FIELDS, MP.SPACE_PAGES
    };

    final static private MP[] rule13 = {
            MP.QUERY, MP.TOP, MP.SORTBY_PAGES, MP.DISPLAY_PAGES, MP.FIELDS, MP.SPACE_PAGES
    };

    final static private MP[] rule14 = {
            MP.TOP, MP.SORTBY_PAGES, MP.DISPLAY_PAGES, MP.FIELDS, MP.SPACE_PAGES
    };

    final static private MP[] rule15 = {
            MP.PROJECT2, MP.DISPLAY_PAGES, MP.FIELDS, MP.SPACE_PAGES
    };

    final static private MP[] rule16 = {
            MP.QUERY, MP.DISPLAY_PAGES, MP.FIELDS, MP.SPACE_PAGES
    };

    final static private MP[] rule17 = {
            MP.PROJECT2, MP.TOP, MP.DISPLAY_PAGES, MP.FIELDS, MP.SPACE_PAGES
    };

    final static private MP[] rule18 = {
            MP.PROJECT2, MP.SORTBY_PAGES, MP.DISPLAY_PAGES, MP.FIELDS, MP.SPACE_PAGES
    };

    final static private MP[] rule19 = {
            MP.QUERY, MP.TOP, MP.DISPLAY_PAGES, MP.FIELDS, MP.SPACE_PAGES
    };

    final static private MP[] rule20 = {
            MP.QUERY, MP.SORTBY_PAGES, MP.DISPLAY_PAGES, MP.FIELDS, MP.SPACE_PAGES
    };

    final static private MP[] rule21 = {
            MP.QUERY, MP.SORTBY_PAGES, MP.DISPLAY_PAGES, MP.TOP, MP.FIELDS, MP.SPACE_PAGES
    };

    // group
    final static private MP[] rule22 = {
            MP.GROUP, MP.FIELDS, MP.SPACE_PAGES
    };

    final static private MP[] rule23 = {
            MP.GROUP, MP.SORTBY_PAGES, MP.FIELDS, MP.SPACE_PAGES
    };

    final static private MP[] rule24 = {
            MP.GROUP, MP.SORTBY_PAGES, MP.TOP, MP.FIELDS, MP.SPACE_PAGES
    };

    final static private MP[] rule25 = {
            MP.GROUP, MP.SORTBY_PAGES, MP.DISPLAY_PAGES, MP.TOP, MP.FIELDS, MP.SPACE_PAGES
    };

    final static private MP[] rule26 = {
            MP.GROUP, MP.DISPLAY_PAGES, MP.TOP, MP.FIELDS, MP.SPACE_PAGES
    };

    final static private MP[] rule27 = {
            MP.GROUP, MP.DISPLAY_PAGES, MP.SORTBY_PAGES, MP.FIELDS, MP.SPACE_PAGES
    };

    final static private MP[] rule28 = {
            MP.GROUP, MP.QUERY, MP.SORTBY_PAGES, MP.DISPLAY_PAGES, MP.TOP, MP.FIELDS, MP.SPACE_PAGES
    };

    final static private MP[] rule29 = {
            MP.GROUP, MP.QUERY, MP.SORTBY_PAGES, MP.FIELDS, MP.SPACE_PAGES
    };

    final static private MP[] rule30 = {
            MP.GROUP, MP.QUERY, MP.SORTBY_PAGES, MP.DISPLAY_PAGES, MP.FIELDS, MP.SPACE_PAGES
    };

    final static private MP[] rule31 = {
            MP.GROUP, MP.QUERY, MP.DISPLAY_PAGES, MP.TOP, MP.FIELDS, MP.SPACE_PAGES
    };

    final static private MP[] rule32 = {
            MP.GROUP, MP.QUERY, MP.SORTBY_PAGES, MP.TOP, MP.FIELDS, MP.SPACE_PAGES
    };

    final static private MP[] rule33 = {
            MP.GROUP, MP.QUERY, MP.FIELDS, MP.SPACE_PAGES
    };

    final static private MP[] rule34 = {
            MP.GROUP, MP.QUERY, MP.TOP, MP.FIELDS, MP.SPACE_PAGES
    };

    final static private MP[] rule36 = {
            MP.PROJECT2, MP.QUERY, MP.DISPLAY_PAGES
    };

    final static private MP[] rule37 = {
            MP.PROJECT2, MP.QUERY
    };

    static final private List<MP[]> rules = new ArrayList<MP[]>();

    static {
        rules.add(rule1);
        rules.add(rule2);
        rules.add(rule3);
        rules.add(rule4);
        rules.add(rule35);
        rules.add(rule5);
        rules.add(rule6);
        rules.add(rule7);
        rules.add(rule8);
        rules.add(rule9);
        rules.add(rule10);
        rules.add(rule11);
        rules.add(rule12);
        rules.add(rule13);
        rules.add(rule14);
        rules.add(rule15);
        rules.add(rule16);
        rules.add(rule17);
        rules.add(rule18);
        rules.add(rule19);
        rules.add(rule20);
        rules.add(rule21);
        rules.add(rule22);
        rules.add(rule23);
        rules.add(rule24);
        rules.add(rule25);
        rules.add(rule26);
        rules.add(rule27);
        rules.add(rule28);
        rules.add(rule29);
        rules.add(rule30);
        rules.add(rule31);
        rules.add(rule32);
        rules.add(rule33);
        rules.add(rule34);
        rules.add(rule36);
        rules.add(rule37);
    }

    static final private Set<MP> uniqueParameters = getUniqueParameters(rules);

    private static final Comparator DATE_UPDATED_COMPARATOR_ASC = new Comparator() {
        @Override
        public int compare(Object o1, Object o2) {
            Date u1 = (Date) ((IPObject) o1).getValue(IModule.KEY_UPDATED);
            Date u2 = (Date) ((IPObject) o2).getValue(IModule.KEY_UPDATED);
            return compareAsc(u1, u2);
        }
    };

    private static final Comparator DATE_CREATED_COMPARATOR_ASC = new Comparator() {
        @Override
        public int compare(Object o1, Object o2) {
            Date u1 = (Date) ((IPObject) o1).getValue(IModule.KEY_CREATED);
            Date u2 = (Date) ((IPObject) o2).getValue(IModule.KEY_CREATED);
            return compareAsc(u1, u2);
        }
    };

    private static final Comparator PAGE_NAME_COMPARATOR_ASC = new Comparator() {
        @Override
        public int compare(Object o1, Object o2) {
            return compareAsc(getNameForCompare(o1), getNameForCompare(o2));
        }
    };

    private static int compareAsc(Comparable u1, Comparable u2) {
        if (u1 == null) {
            return (u2 == null) ? 0 : 1;
        } else {
            return (u2 == null) ? -1 : u1.compareTo(u2);
        }
    }

    private static String getNameForCompare(Object o) {
        if (o instanceof IModule) {
            return ((IModule) o).getModuleName().toLowerCase();
        } else if (o instanceof IWikiPage) {
            return ((IWikiPage) o).getPageName().toLowerCase();
        }
        return null;
    }

    private static final Comparator PAGE_TITLE_OR_NAME_COMPARATOR_ASC = new Comparator() {
        @Override
        public int compare(Object o1, Object o2) {
            return compareAsc(getTitleOrNameForCompare(o1), getTitleOrNameForCompare(o2));
        }
    };

    @Nullable
    private static String getTitleOrNameForCompare(Object o) {
        if (o instanceof IModule) {
            return ((IModule) o).getTitleOrName().toLowerCase();
        } else if (o instanceof IWikiPage) {
            return ((IWikiPage) o).getTitleOrName().toLowerCase();
        }
        return null;
    }

    public PagesMacroParser(XWikiContext context) {
        super(context, rules, uniqueParameters);

    }

    @Override
    @SuppressWarnings("unchecked")
    public String parse(Collection<String> col, String macroText, boolean forPdf) {
        this.col = col;
        this.macroText = macroText;
        this.forPdf = forPdf;

        try {
            // check parameters
            String err = parseParameters();
            if (err != null) {
                return err;
            }

            // parameters
            int top = (map.get(MP.TOP) != null && map.get(MP.TOP) != "") ? Integer.parseInt(map.get(MP.TOP)) : -1; //$NON-NLS-1$
            String query = map.get(MP.QUERY);
            String sortBy = map.get(MP.SORTBY_PAGES) != null ? map.get(MP.SORTBY_PAGES) : ILink.PAGE_TITLE;
            String display = map.get(MP.DISPLAY_PAGES);
            if (display == null) {
                display = ILink.FIELD_OUTPUT_LIST;
            }
            String groupLocation = map.get(MP.GROUP);
            String space = map.get(MP.SPACE_PAGES);
            String projectId = map.get(MP.PROJECT2);

            String originalQuery = query;
            query = PageQueryUtils.modifyQueryFields(query);

            sortBy = PageQueryUtils.modifySortFields(sortBy);

            Map<String, FieldProperty> fields = fieldParser.getPageFields(map, errors);

            if (space != null) {
                space = space.trim();
                if (space.equals("@current")) { //$NON-NLS-1$
                    space = context.getDoc().getSpaceName();
                } else if (space.equals("@all")) { //$NON-NLS-1$
                    space = null;
                }
            } else {
                ParsedFromQuery parsed = parseFromQuery(query, "space.id"); //$NON-NLS-1$
                if (parsed != null) {
                    query = parsed.query;
                    space = parsed.value;
                }
            }

            if (projectId == null) {
                ParsedFromQuery parsed = parseFromQuery(query, "project.id"); //$NON-NLS-1$
                if (parsed != null) {
                    query = parsed.query;
                    projectId = parsed.value;
                }
            }

            IProject currentProject = utils.getCurrentProject(context);
            IProjectGroup currentGroup;
            if (currentProject != null) {
                currentGroup = currentProject.getProjectGroup();
            } else {
                currentGroup = utils.getCurrentProjectGroup(context);
            }
            if (currentGroup == null) {
                currentGroup = getRootProjectGroup();
            }

            IProject project = null;
            IProjectGroup group = null;
            boolean digDeepIntoGroup = false;

            if (projectId != null) {
                projectId = projectId.trim();
                if (projectId.equals("@current")) { //$NON-NLS-1$
                    project = currentProject;
                    if (project == null) {
                        errors.put(MP.PROJECT.getName(), Localization.getString("macro.general.currentScopeIsNotProject")); //$NON-NLS-1$
                    }
                } else {
                    project = utils.getProject(projectId, errors);
                }
                if (project == null) {
                    return renderer.renderErrors(errors, macroText, forPdf);
                }
            } else if (groupLocation != null) {
                groupLocation = groupLocation.trim();
                if (groupLocation.equalsIgnoreCase("/")) { //$NON-NLS-1$
                    group = getRootProjectGroup();
                } else if (groupLocation.equals("@all")) { //$NON-NLS-1$ 
                    group = getRootProjectGroup();
                    digDeepIntoGroup = true;
                } else if (groupLocation.equals("@current")) { //$NON-NLS-1$
                    group = currentGroup;
                } else if (!isEmpty(groupLocation)) {
                    group = ps.getProjectGroupAtLocation(Location.getLocation(IRepositoryService.DEFAULT, "/" + groupLocation, null)); //$NON-NLS-1$
                }
                if (group == null) {
                    errors.put(MP.PROJECT.getName(), Localization.getString("macro.general.projectGroupDoesNotExist", groupLocation)); //$NON-NLS-1$
                    return renderer.renderErrors(errors, macroText, forPdf);
                }
            } else if (currentProject != null) {
                project = currentProject;
            } else {
                group = currentGroup;
            }

            boolean isProject = project != null;
            boolean justGroup = !digDeepIntoGroup && isRootGroup(group);

            Collection<IProject> projects;
            if (project != null) {
                projects = Collections.singleton(project);
            } else if (justGroup) {
                projects = null;
            } else if (digDeepIntoGroup) {
                projects = group.getSortedDeepContainedProjects();
            } else {
                projects = group.getSortedContainedProjects();
            }

            List res = new ArrayList();

            if (justGroup || (projects != null && !projects.isEmpty())) {
                res.addAll(searchModules(convertToModuleQuery(query), projects, space));
                res.addAll(searchWikiPages(query, projects, space));
            }

            sort(res, sortBy);

            List<XWikiDocument> resTop = null;
            if (top != -1 && top < res.size()) {
                resTop = res.subList(0, top);
            } else {
                resTop = res;
            }

            String title = ""; //$NON-NLS-1$

            if (query != null) {
                title = Localization.getString("macro.general.title.wikiPages") + " " + originalQuery; //$NON-NLS-1$ //$NON-NLS-2$
            } else if (group != null) {
                if (digDeepIntoGroup) {
                    title = Localization.getString("macro.general.title.wikiPages") + " " + Localization.getString("macro.general.title.allPages"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
                }
                else {
                    title = Localization.getString("macro.general.title.wikiPages") + " " + (group.getName().equalsIgnoreCase(IRepositoryService.DEFAULT) ? Constants.ROOT_REPO_LEVEL : group.getName()); //$NON-NLS-1$ //$NON-NLS-2$
                }
            }
            else {
                title = Localization.getString("macro.general.title.wikiPages") + " " + ((projectId == null) ? Constants.ROOT_REPO_LEVEL : utils.getProjectName(projectId)); //$NON-NLS-1$ //$NON-NLS-2$
            }

            title = title.replaceAll("\\[", "&#91;"); //$NON-NLS-1$//$NON-NLS-2$
            title = title.replaceAll("\\]", "&#93;"); //$NON-NLS-1$ //$NON-NLS-2$
            if (display.equalsIgnoreCase(ILink.FIELD_OUTPUT_LIST)) {
                return MacroRenderer.getInstance().renderRecentlyModiefiedPagesList(resTop, fields, context, isProject);
            } else {
                utils.setWidthForFields(fields, null);
            }
            return MacroRenderer.getInstance().renderRecentlyModifiedPagesTable(resTop, title, res.size(), fields, utils.getPolarionServerURL(context), forPdf, context, isProject);

        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            errors.put("Error", Localization.getString("macro.general.parsingUnknownException") + e.getLocalizedMessage()); //$NON-NLS-1$//$NON-NLS-2$
            return renderer.renderErrors(errors, macroText, forPdf);
        }
    }

    private boolean isRootGroup(IProjectGroup group) {
        return group != null && group.getParentProjectGroup().getParentProjectGroup() == null;
    }

    private IProjectGroup getRootProjectGroup() {
        return ps.getProjectGroupAtLocation(Location.getLocation(IRepositoryService.DEFAULT, "/", null)); //$NON-NLS-1$
    }

    private static final class ParsedFromQuery {
        public String query;
        public String value;

        public ParsedFromQuery(String query, String value) {
            super();
            this.query = query;
            this.value = value;
        }
    }

    private ParsedFromQuery parseFromQuery(String query, String key) {
        if (query == null) {
            return null;
        }
        Pattern pattern = Pattern.compile("\\Q" + key + "\\E:([^\" ]+|\"(.*?)\")"); //$NON-NLS-1$ //$NON-NLS-2$
        Matcher matcher = pattern.matcher(query);
        if (matcher.find()) {
            String value = matcher.group(2);
            if (value == null) {
                value = matcher.group(1);
            }
            query = matcher.replaceFirst(""); //$NON-NLS-1$
            return new ParsedFromQuery(query, value);
        }
        return null;
    }

    private String convertToModuleQuery(String query) {
        if (query == null) {
            return null;
        }
        query = query.replaceAll("pageName:", "moduleName:"); //$NON-NLS-1$ //$NON-NLS-2$
        return query;
    }

    private void sort(List modulesOrWikiPages, String sortBy) {
        if (sortBy == null) {
            return;
        }
        if (sortBy.equalsIgnoreCase(IWikiPage.KEY_UPDATED)) {
            Collections.sort(modulesOrWikiPages, DATE_UPDATED_COMPARATOR_ASC);
        } else if (sortBy.equalsIgnoreCase(IWikiPage.KEY_CREATED)) {
            Collections.sort(modulesOrWikiPages, DATE_CREATED_COMPARATOR_ASC);
        } else if (sortBy.equalsIgnoreCase(IWikiPage.KEY_PAGENAME)) {
            Collections.sort(modulesOrWikiPages, PAGE_NAME_COMPARATOR_ASC);
        } else if (sortBy.equalsIgnoreCase(IWikiPage.KEY_TITLE)) {
            Collections.sort(modulesOrWikiPages, PAGE_TITLE_OR_NAME_COMPARATOR_ASC);
        } else if (sortBy.equalsIgnoreCase("~" + IWikiPage.KEY_UPDATED)) { //$NON-NLS-1$
            Collections.sort(modulesOrWikiPages, Collections.reverseOrder(DATE_UPDATED_COMPARATOR_ASC));
        } else if (sortBy.equalsIgnoreCase("~" + IWikiPage.KEY_CREATED)) { //$NON-NLS-1$
            Collections.sort(modulesOrWikiPages, Collections.reverseOrder(DATE_CREATED_COMPARATOR_ASC));
        } else if (sortBy.equalsIgnoreCase("~" + IWikiPage.KEY_PAGENAME)) { //$NON-NLS-1$
            Collections.sort(modulesOrWikiPages, Collections.reverseOrder(PAGE_NAME_COMPARATOR_ASC));
        } else if (sortBy.equalsIgnoreCase("~" + IWikiPage.KEY_TITLE)) { //$NON-NLS-1$
            Collections.sort(modulesOrWikiPages, Collections.reverseOrder(PAGE_TITLE_OR_NAME_COMPARATOR_ASC));
        }

    }

    private boolean isEmpty(String s) {
        return (s == null) || (s.trim().length() == 0);
    }

    private List<IWikiPage> searchWikiPages(String userQuery, Collection<IProject> projects, String spaceId) {
        IDataService dataService = MacroUtils.getInstance().trackerService.getDataService();
        List<IWikiPage> wikiPages = new ArrayList<IWikiPage>();
        String query = getWikiQuery(userQuery, projects, spaceId);
        IPObjectList searchInstances = dataService.searchInstances(IWikiPage.PROTO, query, null);
        IPersistencePolicy persistencePolicy = trackerService.getDataService().getPersistencePolicy();
        for (Iterator iterator = searchInstances.iterator(); iterator.hasNext();) {
            IWikiPage wikiPage = (IWikiPage) iterator.next();
            if (persistencePolicy.canReadInstance(wikiPage)) {
                wikiPages.add(wikiPage);
            }
        }
        return wikiPages;
    }

    private String getWikiQuery(String userQuery, Collection<IProject> projects, String spaceId) {
        StringBuilder buf = new StringBuilder();
        appendBasicQuery(userQuery, projects, buf);
        if (spaceId != null) {
            buf.append(" AND space.id:\""); //$NON-NLS-1$
            buf.append(spaceId);
            buf.append('"');
        }
        return buf.toString();
    }

    private Collection searchModules(String userQuery, Collection<IProject> projects, String spaceId) {
        IDataService dataService = MacroUtils.getInstance().trackerService.getDataService();
        List<IModule> modules = new ArrayList<IModule>();
        String query = getModuleQuery(userQuery, projects, spaceId);
        IPObjectList searchInstances = dataService.searchInstances(IModule.PROTO, query, null);
        IPersistencePolicy persistencePolicy = trackerService.getDataService().getPersistencePolicy();
        for (Iterator iterator = searchInstances.iterator(); iterator.hasNext();) {
            IModule module = (IModule) iterator.next();
            if (persistencePolicy.canReadInstance(module)) {
                modules.add(module);
            }
        }
        return modules;
    }

    private String getModuleQuery(String userQuery, Collection<IProject> projects, String spaceId) {
        StringBuilder buf = new StringBuilder();
        appendBasicQuery(userQuery, projects, buf);
        buf.append(" AND isOldStyleModule:false"); //$NON-NLS-1$
        if (spaceId != null && projects != null) {
            buf.append(" AND moduleLocation.grandparent:("); //$NON-NLS-1$
            for (IProject project : projects) {
                buf.append(" \""); //$NON-NLS-1$
                buf.append(project.getLocation().append("modules/" + spaceId).serialize()); //$NON-NLS-1$
                buf.append('"');
            }
            buf.append(')');
        }
        return buf.toString();
    }

    private void appendBasicQuery(String userQuery, Collection<IProject> projects, StringBuilder buf) {
        if (!isEmpty(userQuery)) {
            buf.append('(');
            buf.append(userQuery);
            buf.append(") AND "); //$NON-NLS-1$
        }
        if (projects == null) {
            if (isEmpty(userQuery)) {
                buf.append("*:* AND "); //$NON-NLS-1$
            }
            buf.append("NOT HAS_VALUE:project.id"); //$NON-NLS-1$
        } else {
            buf.append("project.id:("); //$NON-NLS-1$
            for (IProject project : projects) {
                buf.append(" \""); //$NON-NLS-1$
                buf.append(project.getId());
                buf.append('"');
            }
            buf.append(')');
        }
    }
}
