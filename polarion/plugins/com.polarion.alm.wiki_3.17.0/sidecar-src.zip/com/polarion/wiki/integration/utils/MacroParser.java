package com.polarion.wiki.integration.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.polarion.alm.projects.IProjectService;
import com.polarion.alm.tracker.ITrackerService;
import com.polarion.platform.core.PlatformContext;
import com.polarion.reina.web.shared.localization.Localization;
import com.xpn.xwiki.XWikiContext;

public class MacroParser implements IMacroParser {

    protected List<MP[]> rulesList = new ArrayList<MP[]>();
    protected Set<MP> acceptableMacroParameters = new HashSet<MP>();

    final protected MacroUtils utils = MacroUtils.getInstance();
    final protected MacroRenderer renderer = MacroRenderer.getInstance();
    final protected FieldParser fieldParser = FieldParser.getInstance();

    final protected static IProjectService projectService = (IProjectService) PlatformContext.getPlatform().lookupService(IProjectService.class);
    final protected static ITrackerService trackerService = (ITrackerService) PlatformContext.getPlatform().lookupService(ITrackerService.class);

    protected Map<MP, String> map = null;
    protected Map<String, String> errors = new HashMap<String, String>();

    protected Collection<String> col;
    protected String macroText;
    protected final XWikiContext context;
    protected boolean forPdf;

    public MacroParser(XWikiContext context) {
        this.context = context;
    }

    public MacroParser(XWikiContext context, List<MP[]> rules, Set<MP> uniqueParameters) {
        this.context = context;
        rulesList = rules;
        acceptableMacroParameters = uniqueParameters;
    }

    @Override
    public String parse(Collection<String> col, String macroText, boolean forPdf) {
        return null;
    };

    public String parseParameters() {

        if (acceptableMacroParameters.isEmpty()) {
            Collections.addAll(acceptableMacroParameters, MP.values());
        }

        Map<MP, String> params = matchMPsFromInputParameters();
        if (!errors.isEmpty()) {
            //we have some unknown parameters
            return renderer.renderErrors(errors, macroText, forPdf, rulesList);
        }

        for (MP[] mpa : rulesList) {
            Set<MP> ps = new HashSet<MP>();
            Collections.addAll(ps, mpa);

            map = parseMacroParameters(params, ps);
            if (map != null) {
                break;
            }
        }

        if (map == null) {
            return renderer.renderAcceptableMacroParameters(rulesList, macroText, forPdf);
        }

        validateMacroValues(map, errors);
        if (!errors.isEmpty()) {
            return renderer.renderErrors(errors, macroText, forPdf);
        }
        return null;
    }

    protected void validateMacroValues(Map<MP, String> map, Map<String, String> errors) {

        for (MP mp : map.keySet()) {
            //check the value for each parameter
            String errorMsg = mp.checkValue(map.get(mp));
            if (errorMsg != null) {
                errors.put(mp.getName(), errorMsg);
            }
        }

    }

    @Override
    public XWikiContext getContext() {
        return context;
    }

    private Map<MP, String> matchMPsFromInputParameters() {
        Map<MP, String> map = new HashMap<MP, String>();

        Iterator<String> it = col.iterator();
        while (it.hasNext()) {
            String o = it.next();
            boolean found = false;

            Iterator<MP> it2 = acceptableMacroParameters.iterator();
            while (it2.hasNext()) {
                MP mp = it2.next();
                if (o.trim().matches(mp.getRegexp())) {
//    				String value = o.split("[=]")[1].trim();
                    String value = o.substring(o.indexOf("=") + 1).trim(); //$NON-NLS-1$
                    map.put(mp, value);
                    found = true;
                }
            }

            if (!found) {
                //but maybe only value is not acceptable, like display=WRONG
                String parName = null;
                it2 = acceptableMacroParameters.iterator();
                while (it2.hasNext()) {
                    MP mp = it2.next();
                    if (o.matches("(\\s)*" + mp.getName() + "(\\s)*[=](.)+")) { //$NON-NLS-1$ //$NON-NLS-2$
                        found = true;
                        parName = mp.getName();
                        break;
                    }
                }

                if (!found) {
                    String[] p = o.split("[=]"); //$NON-NLS-1$
                    errors.put(p[0], Localization.getString("macro.general.parameterIsNotSuitableForThisMacro")); //$NON-NLS-1$
                } else {
                    errors.put(parName, Localization.getString("macro.general.parameterHasNonAcceptableValue")); //$NON-NLS-1$
                }

            }
        }

        return map;
    }

    /**
     * A(parameters): a,b,c,d,e,f
     * B(set): b,c,d,e,f,g,h
     * 
     * 1) C = A \ B
     * 2) D = remove from C compatible parameters which are in B (display=table and display=count are compatible)
     * 3) if C is empty go to 4) else 5)
     * 4) if a \ D has required parameters from B, we have match right rule else 5)
     * 5) choose another set B 
     * 
     * @param parameters
     * @param set
     * @return
     */
    private Map<MP, String> parseMacroParameters(Map<MP, String> parameters, Set<MP> set) {

        //1)
        Set<MP> c = utils.distictionOfSets(parameters.keySet(), set);
        if (c.isEmpty()) {
            return checkParameters(parameters, set);
        }

        //2)
        removeCompatibleParameters(c, set);
        if (c.isEmpty()) {
            return checkParameters(parameters, set);
        }

        return null;
    }

    private void removeCompatibleParameters(Set<MP> from, Set<MP> source) {
        Set<MP> compatibles = new HashSet<MP>();
        for (MP mp : from) {
            if (mp.hasCompatible(source)) {
                compatibles.add(mp);
            }
        }

        from.removeAll(compatibles);
    }

    private Map<MP, String> checkParameters(Map<MP, String> parameters, Set<MP> set) {

        if (checkRequiredParameters(set, parameters.keySet())) {
            //we have all required parameters
            parseProjectSlashParameter(parameters);
            return parameters;
        } else {
            return null;
        }
    }

    /**
     * return true if all required parameters from set are in subset
     */
    private boolean checkRequiredParameters(Set<MP> set, Set<MP> subset) {
        for (MP mp : set) {
            if (!mp.isOptional()) {
                if (!subset.contains(mp)) {
                    return false;
                }
            }
        }
        return true;
    }

    private void parseProjectSlashParameter(Map<MP, String> matched) {
        if (matched.containsKey(MP.PROJECT_SLASH_ID)) {
            String value = matched.get(MP.PROJECT_SLASH_ID);
            String[] splits = value.split("[\\s]*[/][\\s]*"); //$NON-NLS-1$
            matched.put(MP.PARSING_PROJECT, splits[0]);
            matched.put(MP.ID, splits[1]);
        } else if (matched.containsKey(MP.PROJECT_SLASH_QUERY_NAME)) {
            String value = matched.get(MP.PROJECT_SLASH_QUERY_NAME);
            String[] splits = value.split("[\\s]*[/][\\s]*"); //$NON-NLS-1$
            matched.put(MP.PARSING_PROJECT, splits[0]);
            matched.put(MP.QUERY_NAME, splits[1]);
        }
    }

    static protected Set<MP> getUniqueParameters(List<MP[]> rules) {
        Set<MP> uniqueParameters = new HashSet<MP>();

        for (MP[] rule : rules) {
            for (int i = 0, maxi = rule.length; i < maxi; i++) {
                if (!uniqueParameters.contains(rule[i])) {
                    uniqueParameters.add(rule[i]);
                }
            }
        }
        return uniqueParameters;
    }

//  private Map<MP, String> parseMacroParameters(Collection<String> parameters, Set<MP> set){
//  	
////  	Set<String> used = new HashSet<String>();
//  	//make from parameters pairs
//  	Map<MP, String> matched = new HashMap<MP, String>();
//  	for (MP mp : MP.values()){
//  		for (String o: parameters) {
//  			if(o.trim().matches(mp.getRegexp())){
//  				if(o.matches("(.)*id(.)*") && (!set.contains(mp))){ //put only id, which is in set
//  					continue;
//  				}
//  				if(o.matches("(.)*display(.)*") && (!set.contains(mp))){ //put only id, which is in set
//  					continue;
//  				}
//  				if(o.matches("(.)*project(.)*") && (!set.contains(mp))){ //put only id, which is in set
//  					continue;
//  				}
////  				if(!set.contains(mp)){ 
////  					continue;
////  				}
//  				matched.put(mp, o.trim().split("[\\s]*=[\\s]*")[1]);
////  				used.add(o);
////  				break;
//  			}
////  			if((!used.contains(o)) && (o.trim().matches(mp.getRegexp()))){
////  				matched.put(mp, o.trim().split("[\\s]*=[\\s]*")[1]);
////  				used.add(o);
////  				break;
////  			}
//  		}
//  	}
//  	
//  	Set<MP> subset = matched.keySet();
////  	subset.retainAll(set); //remove moreover parameters
//
//  	if (subset.isEmpty()){
//  		return null;
//  	}
//  	
////  	if(subset.retainAll(set)){
////  		//we have more parameters that we would like to have
////  		return null;
////  	}
//  	
//  	if (set.containsAll(subset)){
//			if(checkRequiredParameters(set, subset)){
//				//we have all required parameters
//				parseProjectSlashParameter(matched);
//				return matched;
//			}
//		}
//  	
//  	return null;
//  }
//  
}
