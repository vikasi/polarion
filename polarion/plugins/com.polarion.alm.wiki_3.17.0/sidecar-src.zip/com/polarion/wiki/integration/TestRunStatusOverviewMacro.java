/*
 * Copyright (C) 2004-2011 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2011 Polarion Software
 * All Rights Reserved.    No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.    This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.google.inject.Inject;
import com.polarion.alm.server.ServerUiContext;
import com.polarion.alm.shared.UiContext;
import com.polarion.alm.shared.api.model.tr.internal.InternalTestRun;
import com.polarion.alm.shared.api.transaction.ReadOnlyTransaction;
import com.polarion.alm.shared.api.transaction.RunnableInReadOnlyTransaction;
import com.polarion.alm.shared.api.transaction.TransactionalExecutor;
import com.polarion.alm.shared.api.utils.html.HtmlContentBuilder;
import com.polarion.alm.shared.api.utils.html.HtmlTagBuilder;
import com.polarion.alm.shared.api.utils.links.PortalLink;
import com.polarion.alm.shared.api.utils.links.TestRunRecordsLinkBuilder;
import com.polarion.alm.tracker.ITestManagementPolicy;
import com.polarion.alm.tracker.ITestManagementService;
import com.polarion.alm.tracker.internal.model.ITestRunInternal;
import com.polarion.alm.tracker.model.ITestRecord;
import com.polarion.alm.tracker.model.ITestRun;
import com.polarion.alm.tracker.model.ITrackerProject;
import com.polarion.alm.ui.shared.wiki.ParameterNames;
import com.polarion.core.util.ObjectUtils;
import com.polarion.core.util.RunnableWEx;
import com.polarion.core.util.exceptions.UserFriendlyRuntimeException;
import com.polarion.core.util.logging.Logger;
import com.polarion.platform.core.PlatformContext;
import com.polarion.platform.guice.internal.GuicePlatform;
import com.polarion.platform.persistence.IDataService;
import com.polarion.platform.persistence.IEnumOption;
import com.polarion.platform.persistence.IEnumeration;
import com.polarion.portal.server.HTMLBuilder;
import com.polarion.reina.web.shared.html.HTMLConst;
import com.polarion.reina.web.shared.html.IHTMLBuilder;
import com.polarion.reina.web.shared.localization.Localization;
import com.polarion.subterra.base.data.model.TypeFactory;
import com.polarion.wiki.integration.utils.MacroRenderer;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.util.Constants;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.doc.XWikiDocument;

public class TestRunStatusOverviewMacro extends BaseLocaleMacro {
    private static final String MACRO_ID = "macro.testrun-overview"; //$NON-NLS-1$
    private static final String MACRO_STRING = "testrun-overview"; //$NON-NLS-1$

    private static final String DEFAULT_FONT_COLOR = "#5F5F5F"; //$NON-NLS-1$

    private IDataService dataService = PlatformContext.getPlatform().lookupService(IDataService.class);
    private static final MacroUtils utils = MacroUtils.getInstance();
    private static final MacroRenderer renderer = MacroRenderer.getInstance();
    private ITestManagementPolicy policy;

    private static class Data {
        public ITestRun testRun;
        public ShowEnum show = ShowEnum.ALL;
        public IEnumeration testRunResultEnum;
        public XWikiContext context;
        public MacroParameter params;
        public boolean hasPermissions = true;
    }

    private static enum ShowEnum {
        TOP("onlyTop"), //$NON-NLS-1$
        BOTTOM("onlyBottom"), //$NON-NLS-1$
        BOTH("both"), //$NON-NLS-1$
        GRAPH("graph"), //$NON-NLS-1$
        ALL("all"); //$NON-NLS-1$

        private final String value;

        private ShowEnum(String value) {
            this.value = value;
        }

        public static ShowEnum fromValue(String value) {
            for (ShowEnum e : ShowEnum.values()) {
                if (e.value.equals(value)) {
                    return e;
                }
            }
            return null;
        }

        public static String printValues() {
            StringBuilder result = new StringBuilder();
            for (ShowEnum e : ShowEnum.values()) {
                if (result.length() > 0) {
                    result.append(", "); //$NON-NLS-1$
                }
                result.append("'").append(e).append("'"); //$NON-NLS-1$ //$NON-NLS-2$
            }
            return result.toString();
        }

        @Override
        public String toString() {
            return value;
        }
    }

    @SuppressWarnings("deprecation")
    public TestRunStatusOverviewMacro() {
        super();
        GuicePlatform.getGlobalInjector().injectMembers(this);
    }

    @Inject
    public void setTestingService(ITestManagementService testingService) {
        policy = testingService.getPolicy();
    }

    @Override
    public String getLocaleKey() {
        return MACRO_ID;
    }

    @Override
    public void execute(final Writer writer, final MacroParameter params) throws IllegalArgumentException, IOException {
        final Data data = new Data();
        data.params = params;
        try {
            data.context = MacroUtils.getInstance().getXWikiContext(params);

            if (!hasLicense()) {
                writer.write(renderer.renderInaccessibleMessage(true, false));
                return;
            }

            Map<String, String> errors = init(data);

            if (!data.hasPermissions) {
                writer.write(renderer.renderInaccessibleMessage(false, true));
                return;
            }

            if (!errors.isEmpty()) {
                writer.write(renderer.renderErrors(errors, getMacroText(data), forPdf(data)));
                return;
            }

            new ContentRenderer(data, writer).render();
        } catch (UserFriendlyRuntimeException ex) {
            Logger.getLogger(this).error("Exception in rendering the testrun-overview macro: ", ex); //$NON-NLS-1$
            writer.write(String.format("%s: %s", MACRO_STRING, ex.getMessage())); //$NON-NLS-1$
        } catch (Exception e) {
            Logger.getLogger(this).error("Exception in rendering the testrun-overview macro: ", e); //$NON-NLS-1$
            boolean pdfExport = data.context == null ? false : MacroUtils.getInstance().isPdfExport(data.context);
            writer.write(renderer.renderError("Error", Localization.getString("macro.exception", MACRO_STRING), getMacroTextForErrors(data), pdfExport)); //$NON-NLS-1$//$NON-NLS-2$
        }

    }

    private class ContentRenderer {
        @NotNull
        private final Data data;
        @NotNull
        private final Writer writer;
        @NotNull
        private final UiContext uiContext;
        @NotNull
        private final IHTMLBuilder builder;

        public ContentRenderer(@NotNull Data data, @NotNull Writer writer) {
            this.data = data;
            this.writer = writer;
            uiContext = ServerUiContext.getInstance();
            builder = (IHTMLBuilder) uiContext.createHtmlBuilderFor().oldWiki();
        }

        public void render() throws IOException {
            if (isInDocumentEditor(data)) {
                writer.write(Localization.getString("macro.testing.testrun-status-overview.macroIsNotAvailable")); //$NON-NLS-1$
                return;
            }

            if (data.show == ShowEnum.BOTH || data.show == ShowEnum.TOP || data.show == ShowEnum.BOTTOM) {
                renderButtons();
            } else if (data.show == ShowEnum.GRAPH) {
                renderGraph();
            } else {
                builder.appendHTML(HTMLConst.HTML_TABLE_TR);
                builder.appendCellStart(null, null, null, null, null, "padding-top:40px;padding-right:20px"); //$NON-NLS-1$
                renderGraph();
                builder.appendHTML(HTMLConst.HTML_ETD_TD);
                renderButtons();
                builder.appendHTML(HTMLConst.HTML_ETD_ETR_ETABLE);
            }

            writer.write(builder.toString());

        }

        private void renderGraph() {
            String paramFormat = "<set name='%s' value='%d' color='%s' />"; //$NON-NLS-1$
            StringBuilder flashVars = new StringBuilder("chartWidth=150&chartHeight=150&debugMode=1&dataXML="); //$NON-NLS-1$
            flashVars.append("<graph caption='' showPercentageValues='0' showPercentageInLabel='0' decimalPrecision='0' showValues='0' pieBorderThickness='0' animation='0' showShadow='0'>"); //$NON-NLS-1$
            for (Object cur : data.testRunResultEnum.getAllOptions()) {
                IEnumOption option = (IEnumOption) cur;
                String param = String.format(paramFormat, option.getName(), getCount(option), option.getProperty(IEnumOption.PROPERTY_KEY_COLOR));
                flashVars.append(param);
            }
            flashVars.append(String.format(paramFormat, Localization.getString("macro.testing.testrun-status-overview.button.waiting"), getWaitingCount(), "#CFCFCF")); //$NON-NLS-1$ //$NON-NLS-2$
            flashVars.append("</graph>"); //$NON-NLS-1$

            builder.appendHTML("<object classid=\"clsid:d27cdb6e-ae6d-11cf-96b8-444553540000\" codebase=\"http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0\" width=\"150\" height=\"150\" id=\"0\">"); //$NON-NLS-1$
            builder.appendHTML("<param name=\"allowScriptAccess\" value=\"always\" />"); //$NON-NLS-1$
            builder.appendHTML("<param name=\"movie\" value=\"/polarion/ria/fusioncharts/FCF_Pie2D.swf\"/>"); //$NON-NLS-1$
            builder.appendHTML("<param name=\"FlashVars\" value=\"" + flashVars + "\" />"); //$NON-NLS-1$ //$NON-NLS-2$
            builder.appendHTML("<param name=\"quality\" value=\"high\" />"); //$NON-NLS-1$
            builder.appendHTML("<param name='wmode' value='transparent' />"); //$NON-NLS-1$
            builder.appendHTML("<embed src=\"/polarion/ria/fusioncharts/FCF_Pie2D.swf\" FlashVars=\"" + flashVars //$NON-NLS-1$
                    + "\" quality=\"high\" width=\"150\" height=\"150\" name=\"0\" allowScriptAccess=\"always\" wmode=\"transparent\" type=\"application/x-shockwave-flash\" pluginspage=\"http://www.macromedia.com/g/getflashplayer\" />"); //$NON-NLS-1$
            builder.appendHTML("</object>"); //$NON-NLS-1$
        }

        private void renderButtons() {
            builder.appendHTML("<table cellpadding=\"10\" border=\"0\">"); //$NON-NLS-1$
            builder.appendHTML(HTMLConst.HTML_TBODY);
            if (ShowEnum.ALL == data.show || ShowEnum.BOTH == data.show || ShowEnum.TOP == data.show) {
                builder.appendHTML(HTMLConst.HTML_TR);
                for (Object cur : data.testRunResultEnum.getAllOptions()) {
                    IEnumOption option = (IEnumOption) cur;
                    generateButtonForExecuted(getCount(option), option.getName(), option.getProperty(IEnumOption.PROPERTY_KEY_COLOR), getLinkForResult(option));
                }
                builder.appendHTML(HTMLConst.HTML_ETR);
            }
            if (ShowEnum.ALL == data.show || ShowEnum.BOTH == data.show || ShowEnum.BOTTOM == data.show) {
                builder.appendHTML(HTMLConst.HTML_TR);
                generateButtonForExecuted(getExecutedCount(), Localization.getString("macro.testing.testrun-status-overview.button.executed"), DEFAULT_FONT_COLOR, getLinkForExecuted()); //$NON-NLS-1$
                generateButtonForWaiting();
                builder.appendHTML(HTMLConst.HTML_ETR);
            }
            builder.appendHTML(HTMLConst.HTML_ETBODY);
            builder.appendHTML(HTMLConst.HTML_ETABLE);
        }

        private String attr(@NotNull String attr, int value) {
            return attr + ":" + value + "px;"; //$NON-NLS-1$ //$NON-NLS-2$
        }

        private void generateButtonForExecuted(int count, @Nullable String label, @Nullable String color, @Nullable PortalLink link) {
            HtmlTagBuilder td = builder.append().td();

            HtmlContentBuilder contentBuilder = link != null ? generateButtonLink(td, link, false) : td.append();
            generateButtonBody(contentBuilder, count, label, color);

            td.finished();
        }

        private void generateButtonForWaiting() {
            HtmlTagBuilder td = builder.append().td();

            PortalLink link = getLinkForWaiting();
            HtmlContentBuilder contentBuilder = link != null ? generateButtonLink(td, link, true) : td.append();
            generateButtonBody(contentBuilder, getWaitingCount(), Localization.getString("macro.testing.testrun-status-overview.button.waiting"), DEFAULT_FONT_COLOR); //$NON-NLS-1$

            td.finished();
        }

        @SuppressWarnings({ "nls" })
        @NotNull
        private HtmlContentBuilder generateButtonLink(@NotNull HtmlTagBuilder parentCell, @NotNull PortalLink link, boolean updateCurrentTestRunInUiData) {
            parentCell.attributes().className("polarion-linksWithoutUnderlineOnHover");
            HtmlTagBuilder a = parentCell.append().tag().a();
            if (updateCurrentTestRunInUiData) {
                a.attributes().onClick(escapeForAttribute("top.updateTestRunUiData('" + data.testRun.getId() + "', event); return true;"));
            }
            a.attributes().href(link).target("_top");
            a.attributes().style("cursor:pointer;");
            return a.append();
        }

        @SuppressWarnings({ "nls", "deprecation" })
        private void generateButtonBody(@NotNull HtmlContentBuilder contentBuilder, int count, @Nullable String label, @Nullable String color) {
            if (color == null) {
                color = DEFAULT_FONT_COLOR;
            }
            int cellSize = 96;
            int fontSize = getFontSize(count);
            int paddingTop = (int) (cellSize * 0.45);
            int divHeight = Math.max((int) (cellSize * 0.25), fontSize / 2);

            if (forPdf(data)) {
                paddingTop = paddingTop / 2;
            }
            contentBuilder.html("<div ").html("style=\"").html(attr("width", cellSize)).html(attr("height", cellSize)).html(attr("border-radius", 6)).html(getBackgroundStyle()).html("\">");

            contentBuilder.html("<div ");
            contentBuilder.html("style=\"").html(attr("height", divHeight)).html(attr("padding-top", paddingTop)).html(attr("line-height", 0)).html(attr("font-size", fontSize)).html("font-weight:bold;");
            contentBuilder.html("color:").html(color).html(";font-family:Arial;text-align:center;");
            appendShadowStyle(contentBuilder);
            contentBuilder.html("\">");
            contentBuilder.html(count + "");
            contentBuilder.html("</div>");

            contentBuilder.html("<div ").html("style=\"overflow:hidden;line-height:1em;font-size:11px;color:").html(color).html(";font-family:Arial;text-align:center;");
            appendShadowStyle(contentBuilder);
            contentBuilder.html("\">");
            contentBuilder.html(label);
            contentBuilder.html("</div>");

            contentBuilder.html("</div>");
        }

        @SuppressWarnings("deprecation")
        @NotNull
        private String escapeForAttribute(@Nullable String path) {
            return path != null ? new HTMLBuilder().escapeForAttribute(path) : "null"; //$NON-NLS-1$
        }

        private int getFontSize(int count) {
            if (count > 9999) {
                return 32;
            }
            if (count > 999) {
                return 36;
            }
            return 44;
        }

        @NotNull
        private String getBackgroundStyle() {
            return "background-repeat:no-repeat;background-image: url('/polarion/ria/images/backgrounds/btnTesting.png');"; //$NON-NLS-1$
        }

        private boolean isIE() {
            //TODO should be replaced by some method on HtmlBuilderTarget
            return data.context.getRequest().getHeader("user-agent").contains("MSIE"); //$NON-NLS-1$ //$NON-NLS-2$
        }

        @SuppressWarnings({ "nls", "deprecation" })
        private void appendShadowStyle(@NotNull HtmlContentBuilder builder) {
            if (!isIE()) {
                final String shadowColor = "white";
                builder.html("text-shadow: 1px 1px 0 ");
                builder.html(shadowColor);
                builder.html(";");
            }
        }

        @NotNull
        private TestRunRecordsLinkBuilder getTestRunURL() {
            String projectId = data.testRun.getProjectId();
            String id = data.testRun.getId();

            return uiContext.createPortalLink().project(projectId).testRun(id).revision(getRevision()).tabRecords();
        }

        private int getCount(IEnumOption status) {
            return data.testRun.getRecordsCount(status.getId());
        }

        private PortalLink getLinkForResult(IEnumOption value) {
            if (isInCompareMode(data)) {
                return null;
            }
            return getTestRunURL().result(value.getId());
        }

        private int getExecutedCount() {
            return data.testRun.getRecordsCount();
        }

        @Nullable
        private PortalLink getLinkForExecuted() {
            if (isInCompareMode(data)) {
                return null;
            }
            return getTestRunURL();
        }

        private int getWaitingCount() {
            String revision = getRevision();
            if (revision != null) {
                return dataService.doInBaseline(revision, new RunnableWEx<Integer>() {

                    @Override
                    public Integer runWEx() throws Exception {
                        return getWaitingCountInternal();
                    }
                });
            }
            return getWaitingCountInternal();
        }

        private int getWaitingCountInternal() {
            ITestRunInternal internalTestRun = (ITestRunInternal) data.testRun;
            return internalTestRun.getWaitingTestsCount(null);
        }

        @Nullable
        private PortalLink getLinkForWaiting() {
            if (isInCompareMode(data) || getRevision() != null) {
                return null;
            }
            return TransactionalExecutor.executeSafelyInReadOnlyTransaction(new RunnableInReadOnlyTransaction<PortalLink>() {

                @Override
                @Nullable
                public PortalLink run(@NotNull ReadOnlyTransaction transaction) {
                    InternalTestRun testRun = (InternalTestRun) transaction.testRuns().getBy().oldApiObject(data.testRun);
                    return testRun.links().waitingTestCases(null);
                }
            });
        }

        @Nullable
        private String getRevision() {
            XWikiDocument o = data.context.getDoc();

            String rev = (String) data.context.get("revision"); //$NON-NLS-1$
            if (o != null && isInCompareMode(data)) {
                rev = o.getVersion();
            }
            return rev;
        }

    }

    private boolean forPdf(Data data) {
        return utils.isPdfExport(utils.getXWikiContext(data.params));
    }

    private String getMacroText(Data data) {
        return utils.buildMacroTextFromParameters2(MACRO_STRING, data.params);
    }

    private Map<String, String> init(Data data) {
        Map<String, String> errors = new HashMap<String, String>();
        Map<String, String> parameters = data.params.getParams();

        String projectAndTestrunId = null;
        if (parameters.containsKey(ParameterNames.TESTRUN1)) {
            projectAndTestrunId = parameters.get(ParameterNames.TESTRUN1);
        } else if (parameters.containsKey(ParameterNames.TESTRUN2)) {
            projectAndTestrunId = parameters.get(ParameterNames.TESTRUN2);
        } else if (data.params.getLength() > 0) {
            projectAndTestrunId = data.params.get(0);
        }
        if (ParameterNames.VALUE_CURRENT.equals(projectAndTestrunId)) {
            projectAndTestrunId = null;
        }

        if (ObjectUtils.emptyString(projectAndTestrunId) && !Constants.TEST_RUNS.equals(data.context.getDoc().getSpaceName())) {
            errors.put(Localization.getString("macro.testing.testrun-status-overview.errors.testIsNotSpecified.left"), Localization.getString("macro.testing.testrun-status-overview.errors.testIsNotSpecified.right")); //$NON-NLS-1$//$NON-NLS-2$
        } else {
            ITrackerProject project = utils.getProject(getProjectName(projectAndTestrunId, data));
            if (project != null) {
                data.hasPermissions = dataService.getPersistencePolicy().canReadInstances(ITestRun.PROTO, project.getContextId());
            }
            if (data.hasPermissions) {
                try {
                    ITestRun testRun = TestRunPropertyMacro.getTestRun(projectAndTestrunId, data.context);
                    if (testRun == null || testRun.isUnresolvable()) {
                        errors.put(Localization.getString("macro.testing.testrun-status-overview.errors.testIsNotUresolved"), projectAndTestrunId); //$NON-NLS-1$
                    } else {
                        data.testRun = testRun;

                        data.testRunResultEnum = dataService.getEnumerationForEnumId(TypeFactory.getInstance().getEnumType(ITestRecord.TEST_RESULT_ENUM_ID), data.testRun.getContextId());

                        String showValue = parameters.get(ParameterNames.SHOW);
                        if (!ObjectUtils.emptyString(showValue)) {
                            ShowEnum show = ShowEnum.fromValue(showValue);
                            if (show == null) {
                                errors.put(Localization.getString("macro.testing.testrun-status-overview.errors.showParameterIsIncorrect", ParameterNames.SHOW, ShowEnum.printValues()), showValue); //$NON-NLS-1$
                            } else {
                                data.show = show;
                            }
                        }
                    }
                } catch (Exception e) {
                    errors.put(Localization.getString("macro.testing.testrun-status-overview.errors.testIsInvalid"), projectAndTestrunId); //$NON-NLS-1$
                }
            }
        }

        return errors;
    }

    private boolean isInDocumentEditor(Data data) {
        return "1".equals(data.context.get("documentLikeEditor")); //$NON-NLS-1$ //$NON-NLS-2$
    }

    private boolean isInCompareMode(Data data) {
        return "1".equals(data.context.get("compareMode")); //$NON-NLS-1$ //$NON-NLS-2$
    }

    private String getProjectName(String projectAndId, Data data) {
        String projectId = data.context.getDoc().getProject();

        if (projectAndId != null) {
            int index = projectAndId.indexOf('/');
            if (index >= 0) {
                projectId = projectAndId.substring(0, index);
            }
        }
        return projectId;
    }

    private boolean hasLicense() {
        return policy.canUseTestManagement();
    }

    private String getMacroTextForErrors(Data data) {
        return MacroUtils.getInstance().buildMacroTextFromParameters2(MACRO_STRING, data.params);
    }

}
