package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.wiki.integration.utils.MacroUtils;

/**
 * {section}
 * {section:width=#}
 *
 */
@SuppressWarnings("nls")
public class SectionMacro extends BaseLocaleMacro {

    public static final String PDF_COLUMN_WIDTH_MARK = "POLARION_PROCESSING_FOR_PDF_WORKAROUND_WIDTH";

    private String pdfColumnHeader;
    private final MacroUtils utils = MacroUtils.getInstance();

    @Override
    public void execute(Writer writer, MacroParameter params) throws IllegalArgumentException, IOException {
        pdfColumnHeader = null;

        String content = params.getContent();
        if (content == null) {
            content = "";
        }
        content = content.trim();

        String width = null;
        Collection<String> col = utils.getParameters(params);
        for (String p : col) {
            if (p.matches("width(\\s)*=.*")) {
                width = utils.getValueFromParameter(p);
            }
        }
        StringBuilder sb = new StringBuilder();
        sb.append("<div style='width:100%'>");
        sb.append("<table ");

        if (!isEmpty(width)) {
            sb.append(" width=").append(width);
        }

        content = processPdfColumns(content, params);

        sb.append(">");
        if (pdfColumnHeader != null) {
            sb.append(pdfColumnHeader);
        }
        sb.append("<tr>").append(content).append("</tr></table>");
        sb.append("</div>");
        writer.write(sb.toString());
    }

    @Override
    public String getLocaleKey() {
        return "macro.section";
    }

    private boolean isEmpty(String s) {
        return (s == null) || ("".equals(s.trim()));
    }

    /**
     * suck columns width from {column} macro
     * @param content
     * @return
     */
    private String processPdfColumns(String content, MacroParameter params) {

        MacroUtils utils = MacroUtils.getInstance();
        boolean forpdf = utils.isPdfExport(utils.getXWikiContext(params));
        List<String> column_widths = new ArrayList<String>();

        int match = -1;
        while ((match = content.indexOf(PDF_COLUMN_WIDTH_MARK)) != -1) {
            int widthStart = content.indexOf("\"", match) + 1;
            int widthEnd = content.indexOf("\"", widthStart);

            String width = content.substring(widthStart, widthEnd);
            String fstContentPart = content.substring(0, match);
            String sndContentPart = content.substring(widthEnd + 1);

            content = fstContentPart + sndContentPart;
            column_widths.add(width);
        }

        if (forpdf) {
            StringBuilder sb = new StringBuilder();
            for (String w : column_widths) {
                sb.append("<col style=\"width:").
                        append(w).
                        append(";column-width:").
                        append(w).
                        append("\">");
            }
            pdfColumnHeader = sb.toString();
        }
        return content;
    }
}
