/*
 * Copyright (C) 2004-2009 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2009 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.LinkedHashMap;
import java.util.Map;

import com.polarion.alm.reports.server.ReportsProvider;
import com.polarion.alm.reports.shared.ReportData;
import com.polarion.alm.reports.shared.TrendChartRequest;
import com.polarion.portal.shared.navigation.IScope;
import com.polarion.wiki.integration.utils.MacroRenderer;
import com.polarion.wiki.web.BaselineServlet;
import com.xpn.xwiki.doc.XWikiDocument;

/**
 * @author <a href="mailto:dev@polarion.com">Jakub Stroleny</a>, Polarion Software
 */
public final class LinechartMacro extends AbstractReportMacro {

    private static final String PARAM_ITEMS = "items";
    private static final String PARAM_REPORTPATH = "report-path";
    private static final String PARAM_WIDTH = "width";
    private static final String PARAM_HEIGHT = "height";
    private static final String PARAM_TAGS = "tags";

    private static final String ID = "LineChart";

    private static final String ITEMS_SEPARATOR = ";";

    @Override
    public String getName() {
        return "line-chart";
    }

    @Override
    public boolean getReportData(IScope scope) throws Exception {
        TrendChartRequest request = new TrendChartRequest();
        request.calculation = null;
        request.location = getReportPath();
        request.tags = getTags();
        request.properties = getChartProperties();
        request.items = getItems();

        XWikiDocument document = getMacroUtils().getXWikiContext(getParameters()).getDoc();
        request.srcLastModTime = document.getDate().getTime();

        if (checkParameters(request)) {
            ReportsProvider.getTrendReportData(scope, request, getCallBack());
            return true;
        }
        return false;
    }

    public String getTags() {
        String tags = getParameters().get(PARAM_TAGS);
        return tags != null ? tags : "7";
    }

    public String[] getItems() {
        String itemsLine = getParameters().get(PARAM_ITEMS);
        return itemsLine != null ? itemsLine.split(ITEMS_SEPARATOR) : null;
    }

    private boolean checkParameters(TrendChartRequest request) throws IOException {
        Writer writer = getWriter();
        MacroRenderer renderer = getMacroRenderer();
        Map<String, String> errors = getErrors();

        if (isEmpty(request.tags)) {
            errors.put(PARAM_TAGS, "Tags parameter have to be set.");
        }

        if (isEmpty(request.items)) {
            errors.put(PARAM_ITEMS, "Items parameter have to be set.");
        }

        if (!errors.isEmpty()) {
            writer.write(renderer.renderErrors(errors, getMacroText(), isForPdf()));
        }
        return errors.isEmpty();
    }

    private LinkedHashMap<String, String> getChartProperties() {
        // TODO GWTMU - check Map String, String instead of Map String Object
        LinkedHashMap<String, String> properties = new LinkedHashMap<String, String>();
        Map<String, String> params = getMacroUtils().getParameterMap(getParameters());
        for (String name : params.keySet()) {
            if (name == null || name.equals(PARAM_ITEMS) || name.equals(PARAM_REPORTPATH)
                    || name.equals(PARAM_TAGS) || name.equals(PARAM_WIDTH) || name.equals(PARAM_HEIGHT)) {
                continue;
            }
            properties.put(name, getParameters().get(name));
        }
        return properties;
    }

    @Override
    public String getLocaleKey() {
        return "macro.polarionlinechart";
    }

    @Override
    public String getReportContent(ReportData data, String width, String height, String action) {
        String uniqName = IntegrationPlugin.getUniqName();
        StringBuilder sb = new StringBuilder();

        boolean inBaseline = BaselineServlet.getCurrentBaselineRevision() != null;
        boolean noData = (data.noDataMessage != null) || inBaseline;
        if (noData) {
            sb.append("<div width='200px' height='200px' style=\"text-align:center;vertical-align:middle\" >");
            sb.append("<span style=\"font-weight:bold\">No data available.</span><br />");
            if (!inBaseline) {
                sb.append("<span style=\"font-size:smaller\">Press update button below to perform calculation</span>");
            }
            sb.append("</div>");
            return sb.toString();
        }

        if (isForPdf()) {
            sb.append("<div width='200px' height='200px' style=\"text-align:center;vertical-align:middle\" >");
            sb.append("<img src='/polarion/ria/images/unexportable_content.png'/>");
            sb.append("</div>");
            return sb.toString();
        }

        sb.append("\n<div id=\"").append(ID).append("_").append(uniqName).append("\">")
                .append("<object codebase='http://fpdownload.macromedia.com/get/flashplayer/current/swflash.cab' ")
                .append("height='").append(height).append("' ")
                .append("width='").append(width).append("' ")
                .append("id='").append(ID).append("_").append(uniqName).append("' ")
                .append("classid='clsid:D27CDB6E-AE6D-11cf-96B8-444553540000'>")
                .append("<param value='/polarion/ria/charts/LineChart.swf' name='movie'>")
                .append("<param value='high' name='quality'>")
                .append("<param value='#ffffff' name='bgcolor'>")
                .append("print".equals(action) ? "" : "<param name='wmode' value='transparent'>")
                .append("<param value='sameDomain' name='allowScriptAccess'>")
                .append("<param value='sDataPath=").append(data.reportUrl).append("' name='flashVars'>")
                .append("<embed flashVars='sDataPath=").append(data.reportUrl).append("' name='flashVars' ")
                .append("pluginspage='http://www.adobe.com/go/getflashplayer' ")
                .append("type='application/x-shockwave-flash' ")
                .append("allowScriptAccess='always' loop='false' play='true' align='middle' name='LineChartLC_7' ")
                .append("print".equals(action) ? "" : " wmode='transparent' ")
                .append("height='").append(height).append("' ")
                .append("width='").append(width).append("' ")
                .append("bgcolor='#ffffff' quality='high' src='/polarion/ria/charts/LineChart.swf'>")
                .append("</embed></object></div>\n");
        return sb.toString();
    }

}
