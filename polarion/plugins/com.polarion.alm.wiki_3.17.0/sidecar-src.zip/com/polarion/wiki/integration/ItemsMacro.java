/*package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.Map;

import org.radeox.api.engine.RenderEngine;
import org.radeox.api.engine.context.RenderContext;
import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.core.util.logging.Logger;
import com.polarion.wiki.integration.link.WorkItemLink;
import com.polarion.wiki.util.RequestParser;
import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.render.XWikiRadeoxRenderEngine;

public class ItemsMacro extends BaseLocaleMacro
{
	static Logger log = Logger.getLogger(ItemsMacro.class);
	
	public void execute(Writer arg0, MacroParameter arg1) throws IllegalArgumentException, IOException
	{

		String Project = arg1.get("project", 0);
		// list/listbox/linkslist
		String Type = arg1.get("type", 1);

		log.error("ItemsMacro: " + Project + " - " + Type);
		if (null == Type)
			Type = "list";

		// get plugin
		RenderContext context = arg1.getContext();
		RenderEngine engine = context.getRenderEngine();

		XWikiContext xcontext = ((XWikiRadeoxRenderEngine) engine).getContext();
		XWiki xwiki = xcontext.getWiki();

		// Subject subj =
		// (Subject)xcontext.getRequest().getSession().getAttribute("SVN_SUBJECT");
		String ItemsList[];

		IntegrationPlugin plugin = (IntegrationPlugin) xwiki.getPlugin("integrationplugin", xcontext);
		
		String currentProject = "";
		
        currentProject = plugin.getRealProject(Project);
        
		// TODO - create velocity templates for rendering list's
		if (Type.equals("linkslist"))
			ItemsList = plugin.getItemsLinksList(Project);
		else
			ItemsList = plugin.getItemsList(Project);

		WorkItemLink workItemLink;
		if (Type.equals("listbox"))
		{
			arg0.write("<select id='workItemsList' size=5 onClick='showJumpWorkItem(\"/polarion/#/project/" + currentProject + "/workitem\");'>");
			for (int i = 0; i < ItemsList.length; i++)
			{
				arg0.write("<option id='" + ItemsList[i] + "'>");
				workItemLink = new WorkItemLink(arg1);
				workItemLink.setItem(ItemsList[i]);
				workItemLink.setAlias(ItemsList[i]);
				workItemLink.setProject(currentProject);
				try {
					arg0.write(plugin.getLinkItem(workItemLink));
				} catch (Exception e) {
	                log.error("Exception in ItemsMacro while write plugin answer: " + e.getMessage());
	            }
				//arg0.write(ItemsList[i]);
			}
			arg0.write("</select>");

			return;
		}
		
		arg0.write("<ul>");
		for (int i = 0; i < ItemsList.length; i++)
		{
			arg0.write("<li>");
			workItemLink = new WorkItemLink(arg1);
			workItemLink.setItem(ItemsList[i]);
			workItemLink.setAlias(ItemsList[i]);
			workItemLink.setProject(currentProject);
			try {
				arg0.write(plugin.getLinkItem(workItemLink));
			} catch (Exception e) {
                log.error("Exception in ItemsMacro while write plugin answer: " + e.getMessage());
            }
			//arg0.write(ItemsList[i]);
		}
		arg0.write("</ul>");
	}

	public String getLocaleKey()
	{
		return "macro.polarionitems";
	}

}*/
