/*
 * Copyright (C) 2004-2012 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2012 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.polarion.wiki.integration.utils;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import com.polarion.alm.server.ServerUiContext;
import com.polarion.alm.shared.UiContext;
import com.polarion.alm.shared.util.StringUtils;
import com.polarion.alm.ui.server.wiki.macro.MacroContext;
import com.polarion.alm.ui.server.wiki.macro.ObjectResolver;
import com.polarion.alm.ui.server.wiki.macro.impl.ObjectResolverImpl;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.doc.XWikiDocument;

/**
 * 
 */
public class MacroParameterValidationContextXWikiImpl implements MacroContext {
    private XWikiContext context;

    /**
     * @param context
     */
    public MacroParameterValidationContextXWikiImpl(XWikiContext context) {
        super();
        this.context = context;
    }

    @Override
    @NotNull
    public UiContext getUiContext() {
        return ServerUiContext.getInstance();
    }

    /**
     * @return
     */
    private XWikiDocument getDoc() {
        return context.getDoc();
    }

    public XWikiContext getContext() {
        return context;
    }

    @Override
    public String getSpaceName() {
        return getDoc().getSpaceName();
    }

    @Override
    @Nullable
    public String getProjectId() {
        return StringUtils.getNullOrNotEmpty(getDoc().getProject());
    }

    @Override
    @Nullable
    public String getProjectGroup() {
        return StringUtils.getNullOrNotEmpty(getDoc().getGroup());
    }

    @Override
    public String getDocumentName() {
        return getDoc().getName();
    }

    @Override
    public String getDocumentRevision() {
        return getDoc().getRevision();
    }

    @Override
    public String get(String propertyName) {
        Object object = context.get(propertyName);
        return object instanceof String ? (String) object : null;
    }

    @Override
    public ObjectResolver getObjectResolver() {
        return new ObjectResolverImpl();
    }

    @Override
    public boolean isInDocumentEditor() {
        return context.isInDocumentEditor();
    }

    @Override
    public boolean isInCompareMode() {
        return context.isInCompareMode();
    }

    @Override
    public boolean isInHistoryMode() {
        return context.isInHistoryMode();
    }

    @Override
    public boolean isInReadOnlyMode() {
        return context.isInReadOnlyMode();
    }

    @Override
    public String getRevision() {
        return context.getRevision();
    }

    @Override
    public boolean isInPdfMode() {
        return context.isInPdfMode();
    }
}
