package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.Map;

import org.radeox.api.engine.RenderEngine;
import org.radeox.api.engine.context.RenderContext;
import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.core.util.logging.Logger;
import com.polarion.wiki.integration.link.ProjectLink;
import com.polarion.wiki.util.RequestParser;
import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.render.XWikiRadeoxRenderEngine;

public class OldProjectMacro extends BaseLocaleMacro
{
    static Logger log = Logger.getLogger(OldProjectMacro.class);

    @Override
    public void execute(Writer writer, MacroParameter parameter) throws IllegalArgumentException, IOException {

        ProjectLink projectLink = new ProjectLink(parameter);

        /*
        // list/listbox/linkslist
        String type = parameter.get("type", 0);
        log.error("ProjectsMacro: " + type);
        if (null == type)
        	type = "list";
         */

        // get plugin
        RenderContext context = parameter.getContext();
        RenderEngine engine = context.getRenderEngine();

        XWikiContext xcontext = ((XWikiRadeoxRenderEngine) engine).getContext();
        XWiki xwiki = xcontext.getWiki();

        try {
            Map requestParams = RequestParser.parseQuery(XWiki.getRequestURL(xcontext.getRequest()).toString(), xcontext);
            String currentProject = (String) requestParams.get("project");
            projectLink.setCurrentProject(currentProject);
        } catch (XWikiException e) {
            log.error(e.getMessage());
        }

        String projectsList[];
        IntegrationPlugin plugin = (IntegrationPlugin) xwiki.getPlugin("integrationplugin", xcontext);

        // {project:@all}
        if (projectLink.isAll()) {
            projectsList = plugin.getProjectsLinksList();
            writeProjectLinkList(writer, projectsList);
            return;
        }

        // {project:@this} or {project:MyAlias|@this}
        if (projectLink.isThis()) {
            String project = plugin.getProjectLink(projectLink);
            writer.write(project);
            return;
        }

        // {project:myprojcet} or {project:MyAlias|myproject}
        String project = plugin.getProjectLink(projectLink);
        writer.write(project);

        // TODO - create velocity templates for rendering list's
        /*
        if (type.equals("linkslist"))
        	projectsList = plugin.getProjectsLinksList();
        else
        	projectsList = plugin.getProjectsList();

        if (type.equals("listbox"))
        {
        	writer.write("<select size=5>");
        	for (int i = 0; i < projectsList.length; i++)
        	{
        		writer.write("<option>");
        		writer.write(projectsList[i]);
        	}
        	writer.write("</select>");

        	return;
        }
        */
    }

    private void writeProjectLinkList(Writer writer, String[] projectsList) throws IOException {
        writer.write("<ul>");
        for (String element : projectsList) {
            writer.write("<li>");
            writer.write(element);
            writer.write("</li>");
        }
        writer.write("</ul>");
    }

    @Override
    public String getLocaleKey()
    {
        return "macro.polarionoldproject";
    }

}
