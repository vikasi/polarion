package com.polarion.wiki.integration.link;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.Vector;

import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.tracker.model.IWorkItem;
import com.polarion.wiki.integration.Restrictable;
import com.xpn.xwiki.XWikiContext;

/**
 * 
 * {wi:WI-246} Link to WI in the same project like Wiki space
 * 
 * {wi:My WorkItem|WI-246} Link to WI in the same project like Wiki space
 * 
 * {wi:project1/WI-246} Link to WI in different project then the Wiki space
 * 
 * {wi:My WorkItem|project1/WI-246}
 * 
 * @author Borovik P
 * 
 */
public class WorkItemLink implements ILink, Restrictable {

    public final String DEFAULT_TABLE_WIDTH = "100%";
    public final String DEFAULT_TABLE_HEIGHT = "100%";
    public final String DEFAULT_DISPLAY = "short";
    public final int DEFAULT_TOP = 50;

    private String item;
    private String project;
    private String alias;
    private String query_project;
    private String urlParam = "";

    private int top = -1;
    private int totalCount = 0;
    private String fields = null;
    private String query = null;
    private String savedQuery = null;
    private String sortBy = null;
    private String outputType = null;
    private String tableWidth = null;
    private String tableHeight = null;
    private String display = null;
    private String expand = null;
    private Vector fieldsMap = new Vector();
    private String[] allFields = new String[6];

    XWikiContext context;
    private boolean isUnderRestriction;

    public WorkItemLink()
    {
    }

    /**
     * constructor for request load from workitemaction
     * initial when rendering page
     * @parameter request parameter Map
     */
    public WorkItemLink(Map parameter, XWikiContext context)
    {
        this.context = context;
        // init filds
        allFields[0] = IWorkItem.KEY_ID;
        allFields[1] = IWorkItem.KEY_TITLE;
        allFields[2] = IWorkItem.KEY_TYPE;
        allFields[3] = IWorkItem.KEY_STATUS;
        allFields[4] = IWorkItem.KEY_SEVERITY;
        allFields[5] = IWorkItem.KEY_DESCRIPTION;

        LinkedList ls = new LinkedList();
        Set ms = parameter.entrySet();
        Iterator itr = ms.iterator();
        while (itr.hasNext())
        {
            Map.Entry me = (Map.Entry) itr.next();
            if (me != null)
            {
                String fld = (String) me.getKey();
                String[] val = (String[]) me.getValue();
                ls.add((fld + "=" + val[0]).replaceAll("p_r", "%"));
            }
        }
        parseItemParameters(ls);
        setup(ls);
        checkRestricted();
        setDefaults();
    }

    /**
    * constructor for macros
    * initial when rendering page
    */
    public WorkItemLink(MacroParameter parameter, XWikiContext context) {
        this.context = context;

        allFields[0] = IWorkItem.KEY_ID;
        allFields[1] = IWorkItem.KEY_TITLE;
        allFields[2] = IWorkItem.KEY_TYPE;
        allFields[3] = IWorkItem.KEY_STATUS;
        allFields[4] = IWorkItem.KEY_SEVERITY;
        allFields[5] = IWorkItem.KEY_DESCRIPTION;

        LinkedList ls = new LinkedList();
        for (int i = 0; i < parameter.getLength(); i++)
        {
            String data = parameter.get(i);
            ls.add((data));
        }
        parseItemParameters(ls);
        setup(ls);
        checkRestricted();
        setDefaults();
    }

    private void setup(LinkedList parameter) {

        if (getQuery() == null)
        {
            //String item = (String)parameter.get(0);
            String item = getItem();

            if (item == null) {
                return;
            }

            if (isMixedItem(item)) {
                setProject(parseProject(item));
                setItem(parseItem(item));
            } else {
                setItem(item);
                if (context != null) {
                    setProject(context.getDoc().getProject());
                }
            }
            setAlias(getItem());
        }
        else
        {
            setItem(ITEM_QUERY);
            if (context != null) {
                setProject(context.getDoc().getProject());
            }
        }

    }

    private void setDefaults() {
        if (tableWidth == null) {
            tableWidth = DEFAULT_TABLE_WIDTH;
        }
        if (tableHeight == null) {
            tableHeight = DEFAULT_TABLE_HEIGHT;
        }
        if (display == null) {
            display = DEFAULT_DISPLAY;
        }
        if (top < 0) {
            top = DEFAULT_TOP;
        }
    }

    /**
     * @param item, the item part from macro params, e.g.: {wi:alias|project/item}
     * @return true if item contians project and item item splited by /
     */
    private boolean isMixedItem(String item) {
        return item.indexOf('/') == -1 ? false : true;
    }

    /**
     * 
     * @param mixedItem
     * @return return project part of mixedItem
     */
    private String parseProject(String mixedItem) {
        int index = mixedItem.indexOf("/");
        if (index == -1) {
            return null;
        }
        return mixedItem.substring(0, index);
    }

    /**
     * 
     * @param mixedItem
     * @return item part of mixedItem
     */
    private String parseItem(String mixedItem) {
        int index = mixedItem.indexOf("/");
        if (index == -1) {
            return null;
        }
        return mixedItem.substring((index + 1), mixedItem.length());
    }

    /**
     * If project is null this method will set the current project, nothing otherwise
     * @param currentProject
     */
    public void setCurrentProject(String currentProject) {
        if (getProject() == null) {
            setProject(currentProject);
            if (query_project != null && query_project.equalsIgnoreCase("")) {
                setQueryProject(currentProject);
            }
        }
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    @Override
    public String getProject() {

        return project; // != null ? project : "";
    }

    /**
     * @return project from query 
     */
    public String getQueryProject() {
        return query_project != null && !query_project.equalsIgnoreCase("") ? query_project : (project.equalsIgnoreCase("") || project == null ? null : project);
    }

    public void setQueryProject(String project) {
        query_project = project;
    }

    public void setProject(String project) {
        this.project = project;
    }

    public String getItem() {
        if (item == null) {
            return "";
        }
        return item;
    }

    public void setItem(String workItem) {
        item = workItem;
    }

    public String getFields()
    {
        return fields;
    }

    @Override
    public String getQuery()
    {
        return query;
    }

    public String getSortBy()
    {
        if (sortBy == null) {
            return null;
        } else {
            return sortBy;
        }
    }

    public String getTableWidth()
    {
        return tableWidth;
    }

    public String getTableHeight()
    {
        return tableHeight;
    }

    public String getDisplay()
    {
        return display;
    }

    public void setDisplay(String display)
    {
        this.display = display;
    }

    public boolean getExpand()
    {
        if (expand != null && expand.equalsIgnoreCase("yes")) {
            return true;
        } else {
            return false;
        }
    }

    public void setExpand(boolean exp)
    {
        if (exp) {
            expand = "yes";
        }
    }

    @Override
    public String getOutputType()
    {
        if (outputType != null && !outputType.equalsIgnoreCase("")) {
            return outputType;
        } else
        {
            if (getItem().equalsIgnoreCase(ITEM_QUERY)) {
                return FIELD_OUTPUT_TABLE;
            } else if (fieldsMap.size() == 0) {
                return FIELD_OUTPUT_SINGLE;
            } else {
                return FIELD_OUTPUT_LIST;
            }
        }
    }

    public void setOutputTypeTable()
    {
        outputType = FIELD_OUTPUT_TABLE;
    }

    public Vector getFieldsMap()
    {
        return fieldsMap;
    }

    public void setSavedQuery(String savedQuery)
    {
        this.savedQuery = savedQuery;
    }

    public String getSavedQuery()
    {
        return savedQuery;
    }

    public int getTotal()
    {
        return totalCount;
    }

    public void setTotal(int total)
    {
        totalCount = total;
    }

    public int getTop()
    {

        return top;
    }

    public void setTop(String topCount)
    {
        try {
            top = Integer.parseInt(topCount);
        } catch (NumberFormatException nfe) {
        }
    }

    /**
     * @return fields array 
    */
    public String[] getFieldsArray()
    {
        String[] res = new String[fieldsMap.size()];

        for (int i = 0; i < fieldsMap.size(); i++)
        {
            String val = ((WorkItemField) fieldsMap.get(i)).getName();
            res[i] = val;
        }

        if (res.length == 0) {
            return allFields;
        }

        return res;
    }

    /**
     * 
     * @param valueField string with fields
     */
    private void parseFields(String valueField)
    {
        StringTokenizer st = new StringTokenizer(valueField, FIELD_SEPARATOR);
        while (st.hasMoreTokens())
        {
            String data = st.nextToken().trim();
            if (data.indexOf(FIELD_TYPE_SEPARATOR) > 0) {
                //fieldsMap.put( data.substring(0,data.indexOf(FIELD_TYPE_SEPARATOR)).trim().toLowerCase(), data.substring(data.indexOf(FIELD_TYPE_SEPARATOR)+3, data.length()) );
                fieldsMap.add(new WorkItemField(data.substring(0, data.indexOf(FIELD_TYPE_SEPARATOR)).trim(), data.substring(data.indexOf(FIELD_TYPE_SEPARATOR) + 3, data.length())));
            } else if (data != null && !data.equalsIgnoreCase("")) {
                //fieldsMap.put( data.trim().toLowerCase(), new String(FIELD_TYPE_IMGTXT) );
                fieldsMap.add(new WorkItemField(data.trim(), new String(FIELD_TYPE_IMGTXT)));
            }
        }
    }

    /**
     * 
     * @return parameters as URL parameters
     */
    public String createURLParam()
    {
        return urlParam.replaceAll(" = ", "=").replaceAll(" =", "=").replaceAll("= ", "=").replaceAll("%", "p_r");
    }

    /**
     * @author VKO
     * implements Restrictable.isUnderRestriction()
     */
    @Override
    public boolean isUnderRestriction(XWikiContext context) {
        return isUnderRestriction;
    }

    private void checkRestricted() {
        String currentProject = context.getDoc().getProject();
        isUnderRestriction = false;
        isUnderRestriction = getItem().equalsIgnoreCase(ITEM_QUERY);
        isUnderRestriction = isUnderRestriction || (isNotEmpty(getProject()) && !currentProject.equals(getProject()));
        isUnderRestriction = isUnderRestriction || isNotEmpty(fields) || isNotEmpty(display) || isNotEmpty(expand) || isNotEmpty(tableWidth) || isNotEmpty(tableHeight) || isNotEmpty(sortBy) || isNotEmpty(savedQuery);
    }

    private boolean isNotEmpty(String str) {
        return !(str == null || "".equals(str));
    }

    private boolean isToken(String data) {
        if (data == null) {
            return false;
        }
        String t = data.trim();
        return ITEM_QUERY.equals(t) || ITEM_QUERY_NAME.equals(t) || ITEM_FIELDS.equals(t) || ITEM_EXPAND.equals(t) || ITEM_SORTBY.equals(t) || ITEM_TABLEWIDTH.equals(t) || ITEM_OUTPUT.equals(t) || ITEM_ID.equals(t) || ITEM_TOP.equals(t)
                || ITEM_DISPLAY.equals(t);
    }

    /**
     * 
     * @param parameter list with macros parameters
     */
    private void parseItemParameters(LinkedList parameter)
    {
        for (int i = 0; i < parameter.size(); i++)
        {
            String data = (String) parameter.get(i);
            if (data != null)
            {
                int index1 = data.indexOf("=");
                if (index1 == -1)
                {
                    if (!getItem().equals("") || isToken(data)) {
                        data += "=";
                    } else {
                        data = "id=" + data;
                    }
                }

                urlParam += data.trim() + ((i != parameter.size() - 1) ? "&" : "");

                int index = data.indexOf("=");
                if (index > 0 && index != data.length())
                {
                    String nameField = data.substring(0, index).trim();
                    String valueField = data.substring(index + 1, data.length()).trim();

                    if (nameField.equalsIgnoreCase(ITEM_QUERY) || nameField.equalsIgnoreCase(ITEM_QUERY_NAME) || isMixedItem(nameField))
                    {
                        if (isMixedItem(nameField)) {
                            setQueryProject(parseProject(nameField));
                        }
                        query = valueField;
                    }
                    else if (nameField.equalsIgnoreCase(ITEM_FIELDS))
                    {
                        fields = valueField;
                        parseFields(valueField);
                    }
                    else if (nameField.equalsIgnoreCase(ITEM_EXPAND)) {
                        expand = valueField;
                    } else if (nameField.equalsIgnoreCase(ITEM_SORTBY)) {
                        sortBy = valueField;
                    } else if (nameField.equalsIgnoreCase(ITEM_TABLEWIDTH)) {
                        tableWidth = valueField;
                    } else if (nameField.equalsIgnoreCase(ITEM_TABLEHEIGTH)) {
                        tableHeight = valueField;
                    } else if (nameField.equalsIgnoreCase(ITEM_OUTPUT)) {
                        outputType = valueField;
                    } else if (nameField.equalsIgnoreCase(ITEM_ID)) {
                        setItem(valueField);
                    } else if (nameField.equalsIgnoreCase(ITEM_TOP)) {
                        setTop(valueField);
                    } else if (nameField.equalsIgnoreCase(ITEM_DISPLAY)) {
                        setDisplay(valueField);
                    }

                }
            }
        }
    }
}
