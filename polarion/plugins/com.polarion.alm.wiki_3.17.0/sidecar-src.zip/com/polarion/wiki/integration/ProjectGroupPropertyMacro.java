/**
 * 
 */
package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.projects.IProjectService;
import com.polarion.alm.projects.model.IProjectGroup;
import com.polarion.cluster.ClusterService;
import com.polarion.core.util.logging.Logger;
import com.polarion.platform.core.PlatformContext;
import com.polarion.platform.service.repository.IRepositoryService;
import com.polarion.qcentre.factbase.IBaseElement;
import com.polarion.qcentre.factbase.IFactBase;
import com.polarion.qcentre.factbase.IValueFactElement;
import com.polarion.qcentre.factbase.serialization.CachedFactBaseRepository;
import com.polarion.qcentre.factbase.serialization.FactBaseRepository;
import com.polarion.subterra.base.location.Location;
import com.polarion.wiki.integration.utils.MacroRenderer;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.util.RequestParser;
import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiContext;

/**
 * {projectgroup-property:users} project users from all contained projects
 * {projectgroup-property:location}
 * {projectgroup-property:projects}
 * {projectgroup-property:projectsDeep}
 * {projectgroup-property:repoName}
 * 
 * 
 * @author Michal Antolik
 *
 */
public class ProjectGroupPropertyMacro extends BaseLocaleMacro {

    private static final Logger log = Logger.getLogger(ProjectGroupPropertyMacro.class);

    final private MacroUtils utils = MacroUtils.getInstance();
    final private MacroRenderer renderer = MacroRenderer.getInstance();

    private static final String FACT_BASE_REPO_ANALYSIS = "repo-analysis";
    private static final String FACT_NOU = "NOU";

    private IProjectService ps = PlatformContext.getPlatform().lookupService(IProjectService.class);
    private static IRepositoryService rs = PlatformContext.getPlatform().lookupService(IRepositoryService.class);
    private static ClusterService clusterService = PlatformContext.getPlatform().lookupService(ClusterService.class);

    private String property;
    private String macroText;
    private boolean forPdf;
    private Map<String, String> errors;

    private void init(MacroParameter params) {
        macroText = utils.buildMacroTextFromParameters2("projectgroup-property", params);
        forPdf = utils.isPdfExport(utils.getXWikiContext(params));
        errors = new HashMap<String, String>();

        if (params.getLength() == 1) {
            property = params.get(0).trim();
            if (!property.matches("(users|location|projects|projectsDeep|repoName)")) {
                errors.put("Bad parameter", "The parameter should have one of these values: users,location,projects or projectsDeep.");
            }
        } else if (params.getLength() == 0) {
            errors.put(
                    "Bad parameters",
                    "Use one of these possibilites: {project-property:users},{project-property:location},{project-property:name},{project-property:description},{project-property:lead},{project-property:active},{project-property:start},{project-property:finish},{project-property:MyProject|users}");
        }
    }

    /* (non-Javadoc)
     * @see org.radeox.macro.BaseMacro#execute(java.io.Writer, org.radeox.macro.parameter.MacroParameter)
     */
    @Override
    @SuppressWarnings("unchecked")
    public void execute(Writer writer, MacroParameter params)
            throws IllegalArgumentException, IOException {

        try {
            init(params);
            if (!errors.isEmpty()) {
                writer.write(renderer.renderErrors(errors, macroText, forPdf));
                return;
            }

            XWikiContext xcontext = utils.getXWikiContext(params);

            Map requestParams = RequestParser.parseQuery(XWiki.getRequestURL(xcontext.getRequest()).toString(), xcontext);

            String groupLocation = utils.getCurrentGroupLocation(requestParams);
            IProjectGroup group = null;

            if (!isEmpty(groupLocation)) {
                group = ps.getProjectGroupAtLocation(Location.getLocation(IRepositoryService.DEFAULT, "/" + groupLocation, null));
            } else {
                group = ps.getProjectGroupAtLocation(Location.getLocation(IRepositoryService.DEFAULT, "/", null));
            }

            if (property.matches("projects")) {
                writer.write(new Integer(getProjects(group)).toString());
                return;
            }

            if (property.matches("projectsDeep")) {
                writer.write(new Integer(getProjectsDeep(group)).toString());
                return;
            }

            if (property.matches("repoName")) {
                writer.write(getRepoName());
                return;
            }

            if (property.matches("users")) {
                writer.write(getUsers(group));
                return;
            }

            if (property.matches("location")) {
                String svnUrl = rs.getAccessibleURLForLocation(group.getLocation()).toString();
                writer.write(getLocation(svnUrl, groupLocation));
                return;
            }

        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            errors.put("Error", "Parsing unknown exception, cause:" + e.getLocalizedMessage());
            writer.write(renderer.renderErrors(errors, macroText, forPdf));
        }

    }

    private String getRepoName() {
        if (clusterService.isMultiInstance()) {
            return clusterService.info().getCluster().getLabel() + " "; //$NON-NLS-1$
        }
        return ""; //$NON-NLS-1$
    }

    private boolean isEmpty(String s) {
        return (s == null) || (s.trim().length() == 0);
    }

    private int getProjects(IProjectGroup group) {
        return group.getContainedProjects().size();
    }

    private int getProjectsDeep(IProjectGroup group) {
        return group.getDeepContainedProjects().size();
    }

    private String getLocation(String svnUrl, String groupLocation) {
        StringBuilder sb = new StringBuilder();
        String label = svnUrl;
        if (!groupLocation.equals("")) {
            sb.append("<a href=\"/polarion/#/group/");
            sb.append(groupLocation);
            sb.append("/repository/browser\" target=\"_top\">");
            sb.append(label);
            sb.append("</a>");
        } else {
            sb.append("<a href=\"/polarion/#/repository/browser\" target=\"_top\">");
            sb.append(label);
            sb.append("</a>");
        }
        return sb.toString();
    }

    private String getUsers(IProjectGroup group) {
        String artifactId = group.getObjectId().toNormalizedString();

        try {
            CachedFactBaseRepository cachedFactBaseRepository = new CachedFactBaseRepository(FactBaseRepository.getFactBaseRepository());
            if (cachedFactBaseRepository.exists(FACT_BASE_REPO_ANALYSIS, artifactId, null, false)) {
                IFactBase repoAnalysisFactBase = cachedFactBaseRepository.loadFactBase(FACT_BASE_REPO_ANALYSIS, artifactId, null, false);
                IBaseElement el = repoAnalysisFactBase.findElement(FACT_NOU);
                if ((el != null) && (el instanceof IValueFactElement)) {
                    return ((IValueFactElement) el).getValue().toString();
                }
            }
        } catch (IOException e) {
//	        log.error("Failed to get fact "+FACT_BASE_REPO_ANALYSIS+"/"+FACT_NOU, e);
        }
        return MacroUtils.NOT_AVAILABLE;
    }

    /* (non-Javadoc)
     * @see org.radeox.macro.LocaleMacro#getLocaleKey()
     */
    @Override
    public String getLocaleKey() {
        return "macro.polarionprojectgroupproperty";
    }

}
