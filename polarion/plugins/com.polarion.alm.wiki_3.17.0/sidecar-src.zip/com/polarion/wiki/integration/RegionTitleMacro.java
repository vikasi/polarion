package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.portal.server.HTMLBuilder;
import com.polarion.reina.web.shared.html.HTMLConst;
import com.polarion.reina.web.shared.html.IHTMLBuilder;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.xpn.xwiki.XWikiContext;

public class RegionTitleMacro extends BaseLocaleMacro {

    private final MacroUtils utils = MacroUtils.getInstance();

    @Override
    public void execute(Writer writer, MacroParameter params)
            throws IllegalArgumentException, IOException {

        XWikiContext context = utils.getXWikiContext(params);
        String pdf = (String) context.get("pdf_generate");
        boolean forPdf = false;
        if (pdf != null && pdf.equalsIgnoreCase("1")) {
            forPdf = true;
        }

        String content = params.getContent();
        if (content == null) {
            content = "";
        }

        content = content.trim();
        String style = null;
        if (forPdf) {
            style = "border-bottom: 4px solid #E1F0FF;color: #0E4A90;font-family: Arial,helvetica,sans-serif;font-size: 23px;font-weight: bold; margin: 10px 0 10px;padding: 0;"; //$NON-NLS-1$
        }

        IHTMLBuilder builder = new HTMLBuilder();
        builder.appendElementStart(HTMLConst.DIV, "regiontitle", style, null);
        builder.appendHTML(content);
        builder.appendElementEnd(HTMLConst.DIV);
        writer.write(builder.toString());
    }

    @Override
    public String getLocaleKey() {
        return "macro.polarionregiontitle";
    }

}
