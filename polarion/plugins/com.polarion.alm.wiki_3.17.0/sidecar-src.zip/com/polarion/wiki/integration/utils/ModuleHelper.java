package com.polarion.wiki.integration.utils;

import java.util.Map;

import com.polarion.alm.projects.model.IProject;
import com.polarion.alm.tracker.IModuleManager;
import com.polarion.alm.tracker.ITrackerService;
import com.polarion.alm.tracker.model.IModule;
import com.polarion.core.util.EscapeChars;
import com.polarion.portal.shared.navigation.IPortal;
import com.polarion.portal.shared.navigation.PortalService;
import com.polarion.subterra.base.location.ILocation;
import com.polarion.subterra.base.location.Location;
import com.polarion.wiki.web.BaselineServlet;

public class ModuleHelper {

    private String space;

    private String moduleName;

    private IModule module;

    private IProject project;

    public ModuleHelper(ITrackerService trackerService, IProject project,
            String fullName, String revision) {

        this.project = project;

        int idx = fullName.indexOf("/"); //$NON-NLS-1$
        if (idx != -1) {
            space = fullName.substring(0, idx);
            moduleName = fullName.substring(idx + 1, fullName.length());
        } else {
            moduleName = fullName;
        }
        loadModule(trackerService, revision);
    }

    public ModuleHelper(IModule module) {
        this.module = module;
        project = module.getProject();
        moduleName = module.getModuleName();
        space = module.getModuleFolder();
    }

    public String getSpace() {
        return space;
    }

    public String getModuleName() {
        return moduleName;
    }

    public IModule getModule() {
        return module;
    }

    public boolean isClassicModule() {
        return space == null;
    }

    public String getModuleLink() {
        return getModuleLink(null);
    }

    public String getModuleLink(Map<String, String> parameters) {
        String moduleDSPath = IPortal.MODULES_DS_FOLDER
                + (isClassicModule() ? "" : "/" + getSpace()) + "/" //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$
                + getModuleName();

        return "/polarion/#" + PortalService.getPortal().createWorkItemInModuleHash(project.getId(), //$NON-NLS-1$
                moduleDSPath, null, null, parameters, BaselineServlet.getCurrentBaselineRevision(), true);
    }

    private void loadModule(ITrackerService trackerService, String revision) {
        String defaultSpace = "_default"; //$NON-NLS-1$
        IModuleManager moduleManager = trackerService.getModuleManager();

        if (space == null) {
            ILocation loc = Location.getLocation(moduleName);
            module = moduleManager.getModule(project, loc);
            if (module == null || module.isUnresolvable()) {
                loc = Location.getLocation(defaultSpace + "/" + moduleName); //$NON-NLS-1$
                module = moduleManager.getModule(project, loc);
                if (module != null && !module.isUnresolvable()) {
                    space = defaultSpace;
                }
            }
            if (revision != null) {
                module = (IModule) trackerService.getDataService().getVersionedInstance(module.getObjectId(), revision);
            }
        } else {
            ILocation loc = Location.getLocation(space + "/" + moduleName); //$NON-NLS-1$
            module = moduleManager.getModule(project, loc);
            if (revision != null) {
                module = (IModule) trackerService.getDataService().getVersionedInstance(module.getObjectId(), revision);
            }

        }
    }

    public static String getEscapedModuleName(String name) {
        // XXX ugly hack for space encoding (we need %20, not + in url)
        String space = "space0870984651023150789456space"; //$NON-NLS-1$
        name = name.replaceAll(" ", space); //$NON-NLS-1$
        name = EscapeChars.forURL(name);
        name = name.replaceAll(space, "%20"); //$NON-NLS-1$
        return name;
    }

}
