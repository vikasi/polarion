/*
 * Copyright (C) 2004-2011 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2011 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.Map;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.google.inject.Inject;
import com.polarion.alm.tracker.ITestManagementPolicy;
import com.polarion.alm.tracker.ITestManagementService;
import com.polarion.alm.ui.server.wiki.macro.MacroContext;
import com.polarion.alm.ui.server.wiki.macro.impl.PlainMacroImpl;
import com.polarion.alm.ui.server.wiki.testrecords.TestRecordsMacroRenderer;
import com.polarion.alm.ui.server.wiki.testrecords.TestRecordsParameters;
import com.polarion.platform.guice.internal.GuicePlatform;
import com.polarion.wiki.integration.utils.MacroParameterValidationContextXWikiImpl;
import com.polarion.wiki.integration.utils.MacroRenderer;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.xpn.xwiki.XWikiContext;

public class TestRecordsMacro extends BaseLocaleMacro {

    private static final String MACRO_ID = "macro.testrecords"; //$NON-NLS-1$
    private static final String MACRO_STRING = "testrecords"; //$NON-NLS-1$

    private static final MacroRenderer renderer = MacroRenderer.getInstance();
    private ITestManagementPolicy policy;

    private static class Data {
        public MacroContext context;
        public MacroParameter params;
        public TestRecordsParameters testRecordsParameters;
    }

    @SuppressWarnings("deprecation")
    public TestRecordsMacro() {
        super();
        GuicePlatform.getGlobalInjector().injectMembers(this);
    }

    @Inject
    public void setTestingService(ITestManagementService testingService) {
        policy = testingService.getPolicy();
    }

    @Override
    public String getLocaleKey() {
        return MACRO_ID;
    }

    @Override
    public void execute(final Writer writer, final MacroParameter params) throws IllegalArgumentException, IOException {
        Data data = new Data();
        if (!policy.canUseTestManagement()) {
            writer.write(renderer.renderInaccessibleMessage(true, false));
            return;
        }
        data.params = params;
        XWikiContext xWikiContext = MacroUtils.getInstance().getXWikiContext(params);
        data.context = new MacroParameterValidationContextXWikiImpl(xWikiContext);
        data.testRecordsParameters = new TestRecordsParameters(data.context, new PlainMacroImpl(getMacroText(data)));
        if (!data.testRecordsParameters.hasPermissions()) {
            writer.write(renderer.renderInaccessibleMessage(false, true));
            return;
        }

        Map<String, String> errors = data.testRecordsParameters.validate();
        if (!errors.isEmpty()) {
            writer.write(renderer.renderErrors(errors, getMacroTextForErrors(data), MacroUtils.getInstance().isPdfExport(xWikiContext)));
            return;
        }

        writer.write(MacroUtils.getInstance().escapeValue(new TestRecordsMacroRenderer(data.testRecordsParameters).render()));
    }

    private String getMacroText(Data data) {
        return MacroUtils.getInstance().buildMacroTextFromParametersSimple(MACRO_STRING, MacroUtils.getInstance().getParameters(data.params));
    }

    private String getMacroTextForErrors(Data data) {
        return MacroUtils.getInstance().buildMacroTextFromParameters2(MACRO_STRING, data.params);
    }

}
