package com.polarion.wiki.integration.utils;

import java.util.Collection;

import com.xpn.xwiki.XWikiContext;

public interface IMacroParser {

    public String parse(Collection<String> col, String macroText, boolean forPdf);

    public XWikiContext getContext();
}
