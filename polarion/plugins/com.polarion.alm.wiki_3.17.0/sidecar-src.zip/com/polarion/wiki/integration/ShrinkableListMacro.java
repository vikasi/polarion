package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.wiki.integration.utils.MacroRenderer;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.xpn.xwiki.XWikiContext;

public class ShrinkableListMacro extends BaseLocaleMacro {

    @Override
    public void execute(Writer writer, MacroParameter parameters)
            throws IllegalArgumentException, IOException {
        String content = parameters.getContent();
        if (content == null) {
            content = "No Content.";
        }

        //width
        String width = parameters.get("width");
        if (isEmpty(width)) {
            width = "100%"; //default value
        }

        //width
        String height = parameters.get("height");
        if (isEmpty(height)) {
            height = "100%"; //default value
        }

        //title
        String title = parameters.get("title");
        if (isEmpty(title)) {
            title = "No Title"; //default value
        }

        //expand
        boolean expanded = true;
        String expand = parameters.get("expand");
        if (!isEmpty(expand)) {
            if (expand.matches("(\\s)no(\\s)")) {
                expanded = false;
            }
        }

        XWikiContext context = MacroUtils.getInstance().getXWikiContext(parameters);
        String pdf = (String) context.get("pdf_generate");

        String result;
        if (pdf == null || pdf.equalsIgnoreCase("0")) {
            result = MacroRenderer.getInstance().renderShrinkableList(title, content, expanded, width, height, false);
        } else {
            result = MacroRenderer.getInstance().renderShrinkableList(title, content, expanded, width, height, true);
        }
        writer.write(result);

    }

    @Override
    public String getLocaleKey() {
        return "macro.polarionshrinkablelist";
    }

    private boolean isEmpty(String s) {
        return (s == null) || ("".equals(s.trim()));
    }

}
