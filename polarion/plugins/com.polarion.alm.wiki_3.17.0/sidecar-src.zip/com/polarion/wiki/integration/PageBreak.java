/*
 * Copyright (C) 2004-2009 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2009 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.wiki.integration.utils.MacroRenderer;
import com.polarion.wiki.integration.utils.MacroUtils;

/**
 * break a page in PDF, the allowed values are: 'page', 'even-page' or 'odd-page' 
 * 
 * @author <a href="mailto:dev@polarion.com">Michal Antolik</a>, Polarion Software
 *
 */
public class PageBreak extends BaseLocaleMacro {

    private MacroUtils utils = MacroUtils.getInstance();

    /* (non-Javadoc)
     * @see org.radeox.macro.BaseMacro#execute(java.io.Writer, org.radeox.macro.parameter.MacroParameter)
     */
    @Override
    public void execute(Writer writer, MacroParameter parameters)
            throws IllegalArgumentException, IOException {

        ArrayList<String> col = (ArrayList<String>) utils.getParameters(parameters);
        boolean forPdf = utils.isPdfOutput(parameters.getContext());

        String content = parameters.getContent();

        String value = null;

        //validate parameter
        if (col.size() == 1) {
            //if there is more than 1 parameter, ignore the others
            value = col.get(0);
            if (!value.matches("page|even-page|odd-page")) {
                value = null;
            }
        }

        if (value == null) {
            Map<String, String> errors = new HashMap<String, String>();
            errors.put("parameter", "the allowed value is: 'page', 'even-page' or 'odd-page'");

            String macroText = utils.buildMacroTextFromParameters("page-break", col);
            writer.write(MacroRenderer.getInstance().renderErrors(errors, macroText, forPdf));
            return;
        }
        String tagValue = "";
        //macro is applicable only to PDF
        if (forPdf) {
            if ("even-page".equals(value)) {
                tagValue = " next=\"even\"";
            } else if ("odd-page".equals(value)) {
                tagValue = " next=\"odd\"";
            }
            writer.write("<pd4ml:page.break " + tagValue + "/>");
        }
        if (content != null) {
            writer.write(content);
            if (forPdf) {
                writer.write("<pd4ml:page.break " + tagValue + "/>");
            }
        }
    }

    /* (non-Javadoc)
     * @see org.radeox.macro.LocaleMacro#getLocaleKey()
     */
    @Override
    public String getLocaleKey() {
        return "macro.polarionpagebreak";
    }

}
