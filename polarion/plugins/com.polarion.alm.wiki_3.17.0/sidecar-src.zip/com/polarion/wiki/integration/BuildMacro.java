package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.builder.IBuilderService;
import com.polarion.alm.builder.model.IBuild;
import com.polarion.alm.builder.model.IBuildArtifact;
import com.polarion.alm.builder.model.IBuildStatus.BuildStatusType;
import com.polarion.alm.tracker.model.ITrackerProject;
import com.polarion.core.util.collection.CollectionsUtil;
import com.polarion.core.util.logging.Logger;
import com.polarion.platform.core.PlatformContext;
import com.polarion.platform.persistence.IDataService;
import com.polarion.platform.persistence.model.IRevision;
import com.polarion.reina.web.shared.localization.Localization;
import com.polarion.wiki.integration.utils.MacroRenderer;
import com.polarion.wiki.integration.utils.MacroUtils;

/**
 * Renders build properties - artifacts, author, timestamp<p>
 *   
 * Examples:
 * <pre>
 *   {builds}
 * </pre> 
 */
public class BuildMacro extends BaseLocaleMacro {

    private static final Logger log = Logger.getLogger(BuildMacro.class);

    private static final String NO_BUILDS = "<div class='hint'>" +
            Localization.getString("macro.build.noBuildsForTheProject") + "<br />" +
            Localization.getString("macro.build.createOneInTheBuildsTopic") + "</div>";

    private static final String NO_ARTIFACTS = "<div class='hint'>" +
            Localization.getString("macro.build.buildProcessNotConfigured") + "<br />" +
            Localization.getString("macro.build.hintHowToSetUpBuildProcess") + "</div>";

//    private static final String DATE_FORMAT = "EEE MMM d HH:mm:ss z yyyy";
//    private static final DateFormat dateFormat = new ThreadSafeDateFormatWrapper(new SimpleDateFormat(DATE_FORMAT));

    final private MacroUtils utils = MacroUtils.getInstance();
    final private MacroRenderer renderer = MacroRenderer.getInstance();

    private final static IBuilderService builderService = (IBuilderService) PlatformContext.getPlatform().lookupService(IBuilderService.class);
    private final static IDataService dataService = (IDataService) PlatformContext.getPlatform().lookupService(IDataService.class);

    private String macroText;
    private boolean forPdf;
    private Map<String, String> errors;

    private void init(MacroParameter params) {
        macroText = utils.buildMacroTextFromParameters2("builds", params);
        forPdf = utils.isPdfExport(utils.getXWikiContext(params));
        errors = new HashMap<String, String>();

//        if (params.getLength() > 0) {
//        	errors.put("Bad parameters", "This macro doesn't need any parameters.");
//        }
    }

    @Override
    @SuppressWarnings("unchecked")
    public void execute(Writer writer, MacroParameter params) throws IllegalArgumentException, IOException {
        try {
            init(params);

            String content = NO_ARTIFACTS;
            ITrackerProject project = utils.getCurrentProject(params.getContext());
            if (project == null) {
                errors.put("context", "This macro can be used only at project context.");
                writer.write(renderer.renderErrors(errors, macroText, forPdf));
                return;
            }

            IBuildArtifact buildArtifact = (IBuildArtifact) CollectionsUtil.getFirst(builderService.getBuildArtifactsForProject(project));
            if (buildArtifact != null) {
                IBuild build = null;
                Collection all = builderService.queryBuilds(project, "(buildStatus.type:" + BuildStatusType.STATUS_TYPE_OK + " OR buildStatus.type:" + BuildStatusType.STATUS_TYPE_OK_WITH_FAILURES + ") " +
                        "AND HAS_VALUE:finishTime AND HAS_VALUE:buildDescriptorName", "~" + IBuild.CREATION_TIME);
                long now = System.currentTimeMillis();
                String baseline = dataService.getCurrentBaselineRevision();
                if (baseline != null) {
                    // find date corresponding to baseline revision and set it as 'now'
                    IRevision revision = dataService.getRevision(project.getContextId(), baseline);
                    if (!revision.isUnresolvable()) {
                        now = revision.getCreated().getTime();
                    }
                }

                for (Iterator i = all.iterator(); i.hasNext();) {
                    IBuild b = (IBuild) i.next();
                    if (!b.isUnresolvable() && (b.getBuildDescriptorName() != null) && (b.getCreationTime().getTime() <= now)) {
                        build = b;
                        break;
                    }
                }

                if (build != null) {
                    String artifactLabel = build.getBuildArtifact().getLabel();
                    String buildTag = build.getBuildTag();
                    String createdOn = build.getFinishTime().toString();
                    String author;
                    if (build.getAuthor().isUnresolvable()) {
                        author = "<i>" + build.getAuthor().getId() + "</i>";
                    } else {
                        author = build.getAuthor().getName();
                    }
                    String baseDirUrl = "/polarion/bir" + build.getBIRLocation().getLocationPath();

                    StringBuilder sb = new StringBuilder();
                    sb.append("<table class=\"wiki-table-no-border\" style=\"width:100%;border: 0px;\">");
                    sb.append("<col style=\"width:30%;column-width:30%;\" />");
                    sb.append("<col style=\"width:70%;column-width:70%;\" />");

                    sb.append(
                            "<tr><td style=\"border: 0px;\"  rowspan=\"1\" colspan=\"1\"><b>" + Localization.getString("macro.build.label.artifact") + Localization.getString("definition.colon")
                                    + "</b></td><td style=\"border: 0px;\" rowspan=\"1\" colspan=\"1\">").append(artifactLabel).append("</td></tr>");
                    sb.append(
                            "<tr><td style=\"border: 0px;\" rowspan=\"1\" colspan=\"1\"><b>" + Localization.getString("macro.build.label.tag") + Localization.getString("definition.colon")
                                    + "</b></td><td style=\"border: 0px;\" rowspan=\"1\" colspan=\"1\">").append(buildTag).append("</td></tr>");
                    sb.append(
                            "<tr><td style=\"border: 0px;\" rowspan=\"1\" colspan=\"1\"><b>" + Localization.getString("macro.build.label.createdOn") + Localization.getString("definition.colon")
                                    + "</b></td><td style=\"border: 0px;\" rowspan=\"1\" colspan=\"1\">").append(createdOn).append("</td></tr>");
                    sb.append(
                            "<tr><td style=\"border: 0px;\" rowspan=\"1\" colspan=\"1\"><b>" + Localization.getString("macro.build.label.author") + Localization.getString("definition.colon")
                                    + "</b></td><td style=\"border: 0px;\" rowspan=\"1\" colspan=\"1\">").append(author).append("</td></tr>");
                    sb.append("</table><br />");

                    sb.append("<table class=\"buildMacro-downloadButton\" onclick=\"window.open('" + baseDirUrl + "; return false;')\">");
                    sb.append("<tr><td class=\"buildMacro-downloadButton-left\"></td>");
                    sb.append("<td class=\"buildMacro-downloadButton-center\">" + Localization.getString("definition.download").toUpperCase()
                            + "<img class=\"buildMacro-downloadButton-icon\" src=\"/polarion/wiki/skins/sidecar/download_arrow.png\"/></td>");
                    sb.append("<td class=\"buildMacro-downloadButton-right\"></td></tr>");
                    sb.append("</table>");

                    content = sb.toString();
                } else {
                    content = NO_BUILDS;
                }
            }

            writer.write(content);
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            errors.put("Error", "Parsing unknown exception, cause:" + e.getLocalizedMessage());
            writer.write(renderer.renderErrors(errors, macroText, forPdf));
        }
    }

    @Override
    public String getLocaleKey() {
        return "macro.polarionbuilds";
    }

}
