package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.Collection;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.integration.utils.RecentlyModifiedWorkitemsMacroParser;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.util.Util;

/**
 * {recently-modified-workitems:project=@current}
 * {recently-modified-workitems:project=@current|groupby=module}
 * {recently-modified-workitems:project=@current|groupby=module|top=112}
 * 
 * @author Michal Antolik
 *
 */
public class RecentlyModifiedWorkitemsMacro extends BaseLocaleMacro {

    final private MacroUtils utils = MacroUtils.getInstance();

    @Override
    public void execute(Writer writer, MacroParameter parameters)
            throws IllegalArgumentException, IOException {

        String result = null;
        XWikiContext context = utils.getXWikiContext(parameters);

        Collection<String> col = utils.getParameters(parameters);
        utils.addParameterNameToValue("project", col);

        RecentlyModifiedWorkitemsMacroParser parser = new RecentlyModifiedWorkitemsMacroParser(context);
        String macroText = utils.buildMacroTextFromParameters("recently-modified-workitems", col);

        String pdf = (String) context.get("pdf_generate");
        if (pdf == null || pdf.equalsIgnoreCase("0")) {
//    		String ajaxLink = utils.getAjaxLink(col, context, "workitemsmacroaction");
//    		writer.write(ajaxLink);
            result = parser.parse(col, macroText, false);
        } else {
            result = parser.parse(col, macroText, true);
        }

        result = Util.contentEncode(result);
        writer.write(result);

    }

    @Override
    public String getLocaleKey() {
        return "macro.polarionrecentlymodifiedworkitems";
    }

}
