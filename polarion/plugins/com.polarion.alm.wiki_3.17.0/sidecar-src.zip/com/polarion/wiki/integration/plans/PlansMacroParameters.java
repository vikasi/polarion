/*
 * Copyright (C) 2004-2013 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2013 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.polarion.wiki.integration.plans;

import java.util.Map;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import com.polarion.alm.tracker.model.IPlan;
import com.polarion.alm.ui.server.wiki.macro.AbstractMacroParameters;
import com.polarion.alm.ui.server.wiki.macro.MacroContext;
import com.polarion.alm.ui.server.wiki.macro.PlainMacro;
import com.polarion.alm.ui.server.wiki.macro.parameters.MacroParameter;
import com.polarion.alm.ui.server.wiki.macro.parameters.PlanParameter;
import com.polarion.alm.ui.server.wiki.macro.parameters.ProjectGroupParameter;
import com.polarion.alm.ui.server.wiki.macro.parameters.ProjectParameter;
import com.polarion.alm.ui.server.wiki.plan.PlanTemplateValidator;
import com.polarion.alm.ui.shared.wiki.ParameterNames;

public class PlansMacroParameters extends AbstractMacroParameters {

    @NotNull
    private final PlanParameter planParameter;

    @NotNull
    private final MacroParameter<String> queryParameter;

    @NotNull
    private final MacroParameter<String> sqlQueryParameter;

    @NotNull
    private final ProjectParameter projectParameter;

    @NotNull
    private final ProjectGroupParameter groupParameter;

    @NotNull
    private final PlanParameter childTemplateParameter;

    @NotNull
    private final MacroParameter<Boolean> createButtonParameter;

    @NotNull
    private final MacroParameter[] queryParameters;

    @NotNull
    private final PlanTemplateValidator templateValidator = new PlanTemplateValidator(ParameterNames.CHILD_TEMPLATE, localization());

    public PlansMacroParameters(@NotNull MacroContext context, @NotNull PlainMacro plainMacro) {
        super(context, plainMacro);

        parameters.add(planParameter = parameterFactory.planParameter(parametersAccessor.getDefaultParameter(ParameterNames.PLAN), true));

        parameters.add(queryParameter = parameterFactory.stringParameter(parametersAccessor.getParameter(ParameterNames.QUERY), null));
        parameters.add(sqlQueryParameter = parameterFactory.stringParameter(parametersAccessor.getParameter(ParameterNames.SQL_QUERY), null));

        parameters.add(projectParameter = parameterFactory.projectParameter(parametersAccessor.getParameter(ParameterNames.PROJECT)));
        parameters.add(groupParameter = parameterFactory.projectGroupParameter(parametersAccessor.getParameter(ParameterNames.GROUP)));

        parameters.add(childTemplateParameter = parameterFactory.planParameter(parametersAccessor.getParameter(ParameterNames.CHILD_TEMPLATE), false));
        parameters.add(createButtonParameter = parameterFactory.booleanParameter(parametersAccessor.getParameter(ParameterNames.CREATE_BUTTON), true));

        queryParameters = new MacroParameter[] { planParameter, queryParameter, sqlQueryParameter, projectParameter, groupParameter };
    }

    @Override
    @NotNull
    public Map<String, String> validate() {
        Map<String, String> errors = super.validate();
        if (!errors.containsKey(ParameterNames.CHILD_TEMPLATE)) {
            String error = validateChildTemplate();
            if (error != null) {
                errors.put(ParameterNames.CHILD_TEMPLATE, error);
            }
        }
        if (!containsQueryError(errors)) {
            String error = validateSingleQuery();
            if (error != null) {
                errors.put(ParameterNames.QUERY, error);
            }
        }
        return errors;
    }

    private boolean containsQueryError(@NotNull Map<String, String> errors) {
        return errors.containsKey(ParameterNames.PLAN) || errors.containsKey(getDefaultParameterLabel()) ||
                errors.containsKey(ParameterNames.QUERY) || errors.containsKey(ParameterNames.SQL_QUERY) ||
                errors.containsKey(ParameterNames.PROJECT) || errors.containsKey(ParameterNames.GROUP);
    }

    @Nullable
    private String validateSingleQuery() {
        switch (getSpecifiefQueryParametersCount()) {
        case 0:
            return planParameter.getPlan() == null ? localization().getString("macro.plans.validation.noQuery") : null; //$NON-NLS-1$
        case 1:
            return null;
        case 2:
            if (queryParameter.getStringValue() != null &&
                    (projectParameter.getStringValue() != null || groupParameter.getStringValue() != null)) {
                return null;// query and (project or group) are valid combinations
            }
            return localization().getString("macro.plans.validation.ambiguousQuery"); //$NON-NLS-1$
        default:
            return localization().getString("macro.plans.validation.ambiguousQuery"); //$NON-NLS-1$
        }
    }

    private int getSpecifiefQueryParametersCount() {
        int k = 0;
        for (MacroParameter parameter : queryParameters) {
            if (parameter.getStringValue() != null) {
                ++k;
            }
        }
        return k;
    }

    @Nullable
    private String validateChildTemplate() {
        IPlan plan = childTemplateParameter.getPlan();
        return plan != null ? templateValidator.validate(plan) : null;
    }

    @Nullable
    public IPlan getPlan() {
        return planParameter.getPlan();
    }

    @Nullable
    public IPlan getChildTemplate() {
        return childTemplateParameter.getPlan();
    }

    public boolean getCreateButton() {
        return createButtonParameter.getRequiredValue();
    }

    @Nullable
    public String getProjectId() {
        return projectParameter.getProjectId();
    }

}
