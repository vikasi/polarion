package com.polarion.wiki.integration.link;

import java.util.Calendar;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.Vector;

import org.apache.velocity.VelocityContext;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.projects.model.IUser;
import com.polarion.wiki.integration.IntegrationPlugin;
import com.polarion.wiki.svn.ISvnProvider;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.api.PUser;

public class UserLink implements ILink
{
    static final int NUMBER_ITEM_FIELDS = 4;
    public static final String FIELD_ROLES = "roles";

    protected void initItemFields()
    {
        allFields = new String[NUMBER_ITEM_FIELDS];
        allFields[0] = IUser.KEY_ID;
        allFields[1] = IUser.KEY_NAME;
        allFields[2] = IUser.KEY_DESCRIPTION;
        allFields[3] = IUser.KEY_EMAIL;
    }

    protected String item;
    protected String project;
    protected String alias;
    protected String query_project;
    protected String urlParam = "";

    protected int top = 0;
    protected String fields = null;
    protected String query = null;
    protected String sortBy = null;
    protected String outputType = null;
    protected String tableWidth = "100%";
    protected String tableHeight = "100%";
    protected String expand = null;
    protected Vector<WorkItemField> fieldsMap = new Vector<WorkItemField>();
    protected String[] allFields;

    protected XWikiContext context;
    protected String defaultSelector = "project";
    protected String selector = "";

    public UserLink()
    {
    }

    /**
     * constructor for macros
     * initial when rendering page
     */
    public UserLink(XWikiContext context) {
        this.context = context;

        initItemFields();
    }

    /**
     * Use when rendering page
     * @parameter request parameter Map
     */
    public UserLink(Map parameter, XWikiContext context)
    {
        this(context);
        LinkedList<String> ls = new LinkedList<String>();
        Set ms = parameter.entrySet();
        Iterator itr = ms.iterator();
        while (itr.hasNext())
        {
            Map.Entry me = (Map.Entry) itr.next();
            if (me != null)
            {
                String fld = (String) me.getKey();
                String[] val = (String[]) me.getValue();
                ls.add((fld + "=" + val[0]).replaceAll("p_r", "%"));
            }
        }
        parseItemParameters(ls);
        setup();
    }

    /**
     * Use durig macro processing
     * @param parameter
     * @param context
     */

    public UserLink(MacroParameter parameter, XWikiContext context) {
        this(context);
        LinkedList<String> ls = new LinkedList<String>();
        for (int i = 0; i < parameter.getLength(); i++)
        {
            String data = parameter.get(i);
            ls.add((data));
        }
        parseItemParameters(ls);
        setup();
    }

    /**
     * Setup default values to fields that have'nt been specified
     * @param parameter
     */
    protected void setup() {
        if ((project == null) || (project.equals(""))) {
            project = context.getDoc().getProject();
        }
        if (project.equals("/") || project.equals("")) {
            project = ISvnProvider.REPO_ROOT_AS_PROJECT_NAME;
        }

        if (outputType == null || outputType.equals("")) {
            outputType = ILink.FIELD_OUTPUT_TABLE;
        }

        if (expand == null || expand.equals("")) {
            if (outputType.equalsIgnoreCase(ILink.FIELD_OUTPUT_TABLE)) {
                expand = ILink.EXPAND_YES;
            } else {
                expand = ILink.EXPAND_NO;
            }
        }
        if (getQuery() == null)
        {
            //String item = (String)parameter.get(0);

            String item = getItem();

            if (item == null) {
                return;
            }

            if (isMixedItem(item)) {
                setProject(parseProject(item));
                setItem(parseItem(item));
            } else {
                setItem(item);
                if (context != null) {
                    setProject(context.getDoc().getProject());
                }
            }
            setAlias(getItem());
        }
        else
        {
            setItem(ITEM_QUERY);
        }
    }

    /**
     * @param item, the item part from macro params, e.g.: {wi:alias|project/item}
     * @return true if item contians project and item item splited by /
     */
    protected boolean isMixedItem(String item) {
        return item.indexOf('/') == -1 ? false : true;
    }

    /**
     * 
     * @param mixedItem
     * @return return project part of mixedItem
     */
    protected String parseProject(String mixedItem) {
        int index = mixedItem.indexOf("/");
        if (index == -1) {
            return null;
        }
        return mixedItem.substring(0, index);
    }

    /**
     * 
     * @param mixedItem
     * @return item part of mixedItem
     */
    protected String parseItem(String mixedItem) {
        int index = mixedItem.indexOf("/");
        if (index == -1) {
            return null;
        }
        return mixedItem.substring((index + 1), mixedItem.length());
    }

    /**
     * If project is null this method will set the current project, nothing otherwise
     * @param currentProject
     */
    public void setCurrentProject(String currentProject) {
        if (getProject() == null) {
            setProject(currentProject);
            if (query_project != null && query_project.equalsIgnoreCase("")) {
                setQueryProject(currentProject);
            }
        }
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    @Override
    public String getProject() {

        return project; // != null ? project : "";
    }

    /**
     * @return project from query 
     */
    public String getQueryProject() {
        return query_project;// != null ? project : "";
    }

    public void setQueryProject(String project) {
        query_project = project;
    }

    public void setProject(String project) {
        this.project = project;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getFields()
    {
        return fields;
    }

    @Override
    public String getQuery()
    {
        return query;
    }

    public String getSortBy()
    {
        if (sortBy == null || sortBy.equals("")) {
            return null;
        } else {
            return sortBy;
        }
    }

    public String getTableWidth()
    {
        return tableWidth;
    }

    public String getTableHeight()
    {
        return tableHeight;
    }

    public boolean getExpand()
    {
        if (expand != null && expand.equalsIgnoreCase("yes")) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public String getOutputType()
    {
        if (outputType != null && !outputType.equalsIgnoreCase("")) {
            return outputType;
        } else {
            return FIELD_OUTPUT_TABLE;
        }
    }

    public Vector getFieldsMap()
    {
        return fieldsMap;
    }

    public int getTop()
    {
        return top;
    }

    public void setTop(String topCount)
    {
        top = Integer.parseInt(topCount);
    }

    /**
     * @return fields array 
    */
    public String[] getFieldsArray()
    {
        String[] res = new String[fieldsMap.size()];

        for (int i = 0; i < fieldsMap.size(); i++)
        {
            String val = fieldsMap.get(i).getName();
            res[i] = val;
        }

        if (res.length == 0) {
            return allFields;
        }

        return res;
    }

    /**
     * 
     * @param valueField string with fields
     */
    protected void parseFields(String valueField)
    {
        StringTokenizer st = new StringTokenizer(valueField, FIELD_SEPARATOR);
        while (st.hasMoreTokens())
        {
            String data = st.nextToken().trim();
            if (data.indexOf(FIELD_TYPE_SEPARATOR) > 0) {
                fieldsMap.add(new WorkItemField(data.substring(0, data.indexOf(FIELD_TYPE_SEPARATOR)).trim().toLowerCase(), data.substring(data.indexOf(FIELD_TYPE_SEPARATOR) + 3, data.length())));
            } else if (data != null && !data.equalsIgnoreCase("")) {
                fieldsMap.add(new WorkItemField(data.trim().toLowerCase(), new String(FIELD_TYPE_IMGTXT)));
            }
        }
    }

    /**
     * 
     * @return parameters as URL parameters
     */
    public String createURLParam()
    {
        return urlParam.replaceAll(" = ", "=").replaceAll(" =", "=").replaceAll("= ", "=").replaceAll("%", "p_r");
    }

    public String getSelector() {
        return selector;
    }

    public int getCollCount()
    {
        return getFieldsArray().length;
    }

    protected void parseItemParameters(LinkedList parameter)
    {
        for (int i = 0; i < parameter.size(); i++)
        {
            String data = (String) parameter.get(i);
            if (data != null)
            {
                int index1 = data.indexOf("=");
                if (index1 == -1)
                {
                    data = defaultSelector + "=" + data;
                }

                urlParam += data.trim() + ((i != parameter.size() - 1) ? "&" : "");

                int index = data.indexOf("=");
                if (index > 0 && index != data.length())
                {
                    String nameField = data.substring(0, index).trim();
                    String valueField = data.substring(index + 1, data.length()).trim();

                    if (nameField.equalsIgnoreCase(ITEM_QUERY) || isMixedItem(nameField))
                    {
                        if (isMixedItem(nameField)) {
                            setQueryProject(parseProject(nameField));
                        }
                        query = valueField;
                        selector = ITEM_QUERY;
                    }
                    else if (nameField.equalsIgnoreCase(ITEM_PROJECT)) {
                        project = valueField;
                        selector = ITEM_PROJECT;
                    }
                    else if (nameField.equalsIgnoreCase(ITEM_FIELDS))
                    {
                        fields = valueField;
                        parseFields(valueField);
                    }
                    else if (nameField.equalsIgnoreCase(ITEM_EXPAND)) {
                        expand = valueField;
                    } else if (nameField.equalsIgnoreCase(ITEM_SORTBY)) {
                        sortBy = valueField;
                    } else if (nameField.equalsIgnoreCase(ITEM_TABLEWIDTH)) {
                        tableWidth = valueField;
                    } else if (nameField.equalsIgnoreCase(ITEM_TABLEHEIGTH)) {
                        tableHeight = valueField;
                    } else if (nameField.equalsIgnoreCase(ITEM_OUTPUT)) {
                        outputType = valueField;
                    }
                    if (outputType == null || outputType.equalsIgnoreCase("")) {
                        outputType = ILink.FIELD_OUTPUT_TABLE;
                    }
                    else if (nameField.equalsIgnoreCase(ITEM_ID)) {
                        setItem(valueField);
                    } else if (nameField.equalsIgnoreCase(ITEM_TOP)) {
                        setTop(valueField);
                    }

                }
            }
        }
    }

    public String getHTML() {
        String pdf = (String) context.get("pdf_generate");

        String url = context.getURL().getPath();
        url = url.substring(0, url.indexOf("bin/") + 4) + "loaduser" + url.substring(url.indexOf("/", url.indexOf("bin/") + 4), url.length());
        // generate unique name(id) for tables
        String uniqName = IntegrationPlugin.getUniqName();

        String ajaxHTML = "<img id=\"img_" + uniqName + "\" alt=\"progress\" src=\"" + context.getWiki().getSkinFile("progress_small.gif", context) + "\"/>" +
                "<div style=\"visibility: hidden;\" id=\"" + uniqName + "\">" +
                "<script type=\"text/javascript\">" +
                "function " + uniqName + "(){" +
                "loadUsersList('" + url + "','" + createURLParam() + "','" + uniqName + "');" +
                "}" +
                "runItem.push('" + uniqName + "');" +
                "</script></div>" +
                "<div id=\"wi_hd_" + uniqName + "\" style=\"display: none;\">" +
                "loadUsersList('" + url + "','" + createURLParam() + "','" + uniqName + "');" +
                "</div>";
        if (pdf == null || pdf.equals("0")) {
            return ajaxHTML;
        } else {
            return getContentForPdf();
        }
    }

    private String getContentForPdf()
    {
        StringBuffer buff = new StringBuffer();

        Calendar cl = Calendar.getInstance();
        long id = cl.getTimeInMillis();

        VelocityContext vcontext = (VelocityContext) context.get("vcontext");

        context.put("puser", new PUser(this, context, id));
        vcontext.put("puser", new PUser(this, context, id));

        buff.append(context.getWiki().parseTemplate("xuserviewpdf.vm", context));
        return buff.toString();
    }

}