/*
 * Copyright (C) 2004-2011 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2011 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.projects.model.IProject;
import com.polarion.alm.tracker.ITestManagementService;
import com.polarion.alm.tracker.ITrackerService;
import com.polarion.alm.tracker.model.ITestRun;
import com.polarion.alm.tracker.model.IWorkItem;
import com.polarion.alm.ui.shared.wiki.ParameterNames;
import com.polarion.core.util.ObjectUtils;
import com.polarion.platform.guice.internal.GuicePlatform;
import com.polarion.portal.server.HTMLBuilder;
import com.polarion.reina.web.shared.html.HTMLConst;
import com.polarion.reina.web.shared.html.IHTMLBuilder;
import com.polarion.reina.web.shared.localization.Localization;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.util.Constants;
import com.xpn.xwiki.XWikiContext;

/**
 * @author Jiri Banszel
 */
public class ImportTestResultsMacro extends BaseLocaleMacro {

    private ITrackerService trackerService;
    private ITestManagementService service;

    final private MacroUtils utils = MacroUtils.getInstance();

    @SuppressWarnings("deprecation")
    public ImportTestResultsMacro() {
        GuicePlatform.getGlobalInjector().injectMembers(this);
    }

    @Inject
    public void setTrackerService(ITrackerService trackerService) {
        this.trackerService = trackerService;
    }

    @Inject
    public void setService(ITestManagementService service) {
        this.service = service;
    }

    @Override
    public String getLocaleKey() {
        return "macro.import-test-results"; //$NON-NLS-1$
    }

    @Override
    public void execute(Writer writer, MacroParameter params) throws IllegalArgumentException, IOException {
        @SuppressWarnings("unchecked")
        Map<String, String> map = params.getParams();

        String testRunProjectAndId = map.get(ParameterNames.TESTRUN1);
        String templateDefectId = map.get(ParameterNames.TEMPLATE_DEFECT);
        String label = map.get(ParameterNames.LABEL);

        @SuppressWarnings("rawtypes")
        XWikiContext context = MacroUtils.getInstance().getXWikiContext(params);

        if (ObjectUtils.emptyString(testRunProjectAndId) && !Constants.TEST_RUNS.equals(context.getDoc().getSpaceName())) {
            utils.renderError(Localization.getString("macro.import-test-results.pleaseSpecifyTestRun"), writer); //$NON-NLS-1$
            return;
        }
        ITestRun testRun = TestRunPropertyMacro.getTestRun(testRunProjectAndId, context);
        if (testRun.isUnresolvable()) {
            utils.renderError(Localization.getString("macro.import-test-results.testRunDoesNotExist"), writer); //$NON-NLS-1$
            return;
        }

        if (templateDefectId != null) {
            IWorkItem templateDefect = getWorkItem(trackerService, templateDefectId, testRun.getProject());
            if (templateDefect == null || templateDefect.isUnresolvable()) {
                utils.renderError(Localization.getString("macro.import-test-results.templateDefectDoesNotExist"), writer); //$NON-NLS-1$
                return;
            }
        }

        if (label == null) {
            label = Localization.getString("macro.import-test-results.label"); //$NON-NLS-1$
        }

        renderLink(testRun, templateDefectId, label, writer, disabledReason(testRun, context));
    }

    @SuppressWarnings("rawtypes")
    private String disabledReason(ITestRun testRun, XWikiContext context) {
        if (!service.getPolicy().canExecuteTestsUsingExcel()) {
            return Localization.getString("permission.denied.executeTestRun.excelRoundTrip"); //$NON-NLS-1$
        }
        if (!service.getPolicy().canExecuteTestRun(testRun)) {
            return service.getPolicy().getCannotExecuteTestRunReason(testRun);
        }
        if (isInHistoryMode(context)) {
            return Localization.getString("macro.import-test-results.macroCannotBeUsedInHistoryMode"); //$NON-NLS-1$
        }
        return null;
    }

    @SuppressWarnings("rawtypes")
    private boolean isInHistoryMode(XWikiContext context) {
        return (String) context.get("revision") != null || "1".equals(context.get("compareMode")) || trackerService.getDataService().getCurrentBaselineRevision() != null; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    }

    public static IWorkItem getWorkItem(ITrackerService trackerService, String templateDefectId, IProject project) {
        String projectId = project.getId();
        String workItemId = templateDefectId;

        int idx = templateDefectId.indexOf("/"); //$NON-NLS-1$
        if (idx >= 0) {
            projectId = templateDefectId.substring(0, idx);
            workItemId = templateDefectId.substring(idx + 1);
        }
        return trackerService.getWorkItem(projectId, workItemId);
    }

    private void renderLink(ITestRun testRun, String templateDefectId, String label, Writer writer, String disabledReason) throws IOException {
        IHTMLBuilder builder = new HTMLBuilder(true);

        if (disabledReason == null) {
            List<String> args = Arrays.asList(
                    testRun.getProject().getId(),
                    testRun.getId(),
                    templateDefectId);
            String onclick = utils.buildJSCall("top.importTestResults", args); //$NON-NLS-1$
            builder.appendHyperlinkStart((String) null, null, null, "cursor: pointer;", "onclick=\"" + utils.escapeValue(builder.escapeForAttribute(onclick)) + "\""); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
            builder.appendText(utils.escapeValue(label));
            builder.appendElementEnd(HTMLConst.A);
        } else {
            String tooltip = disabledReason;
            builder.appendElementStart(HTMLConst.SPAN, null, "color: gray;", " title=\"" + utils.escapeValue(builder.escapeForAttribute(tooltip)) + "\""); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
            builder.appendText(utils.escapeValue(label));
            builder.appendElementEnd(HTMLConst.SPAN);
        }
        writer.write(builder.toString());
    }

}
