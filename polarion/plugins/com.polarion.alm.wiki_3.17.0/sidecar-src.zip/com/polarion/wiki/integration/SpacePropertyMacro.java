/*
 * $Id$
 *
 * Copyright (C) 2004-2008 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2008 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;

import javax.validation.constraints.NotNull;

import org.radeox.api.engine.context.RenderContext;
import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.tracker.ITrackerService;
import com.polarion.core.util.EscapeChars;
import com.polarion.core.util.StringUtils;
import com.polarion.platform.core.PlatformContext;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.util.SpaceParser;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.render.XWikiRadeoxRenderEngine;

/**
 *
 * @author Jiri Banszel
 * @version $Revision$ $Date$
 *
 */
public class SpacePropertyMacro extends BaseLocaleMacro {

    private static final String PROP_NAME = "name"; //$NON-NLS-1$
    private static final String PROP_TITLE = "title"; //$NON-NLS-1$

    @Override
    public String getLocaleKey() {
        return "macro.space-property"; //$NON-NLS-1$
    }

    @Override
    public void execute(Writer writer, MacroParameter params) throws IllegalArgumentException, IOException {
        RenderContext rcontext = params.getContext();
        XWikiRadeoxRenderEngine eg = (XWikiRadeoxRenderEngine) rcontext.getRenderEngine();
        XWikiContext context = eg.getContext();
        MacroUtils utils = MacroUtils.getInstance();
        String property = params.get(0);
        Object value;
        if (PROP_TITLE.equals(property)) {
            ITrackerService trackerService = PlatformContext.getPlatform().lookupService(ITrackerService.class);
            String space = SpaceParser.getSpace(context.getDoc().getSpace());
            value = trackerService.getFolderManager().getFolder(StringUtils.getNullIfEmpty(context.getDoc().getProject()), space).getTitleOrName();
        } else {
            value = SpaceParser.getSpace(context.getDoc().getSpace());
        }

        writer.write(escapeText(utils.format(value)));
    }

    @NotNull
    public String escapeText(String text) {
        return new MacroUtils().escapeValue(EscapeChars.forHTMLTag(text));
    }

}
