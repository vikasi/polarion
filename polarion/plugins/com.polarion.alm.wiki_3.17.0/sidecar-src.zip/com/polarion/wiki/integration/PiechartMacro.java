package com.polarion.wiki.integration;

import com.polarion.alm.reports.server.ReportsProvider;
import com.polarion.alm.reports.shared.ReportData;
import com.polarion.portal.shared.navigation.IScope;
import com.polarion.wiki.web.BaselineServlet;

/**
 * {piechart:data=/default/.reports/charts/repo-statistics-Pie3D.xml|width=200|height=200}
 * @author Michal Antolik
 *
 */
public final class PiechartMacro extends AbstractReportMacro {

    private static final String MACRO_NAME = "piechart";

    private static final String PARAM_DATA = "data";

    private static final String ID = "PieChart";

    @Override
    public String getName() {
        return MACRO_NAME;
    }

    @Override
    public String getLocaleKey() {
        return "macro.polarionpiechart";
    }

    public String getData() {
        String reportPath = getReportPath();
        if (reportPath == null || "".equals(reportPath)) {
            return getParameters().get(PARAM_DATA);
        } // else {
        return reportPath;
    }

    @Override
    public boolean getReportData(IScope scope) throws Exception {
        ReportsProvider.getReportData(scope, getData(), null, new String[0], getCallBack());
        return true;
    }

    @Override
    public String getReportContent(ReportData data, String width, String height, String action) {
        String uniqName = IntegrationPlugin.getUniqName();
        StringBuilder sb = new StringBuilder();

        boolean inBaseline = BaselineServlet.getCurrentBaselineRevision() != null;
        boolean noData = (data.noDataMessage != null) || inBaseline;
        if (noData) {
            sb.append("<div width='200px' height='200px' style=\"text-align:center;vertical-align:middle\" >");
            sb.append("<span style=\"font-weight:bold\">No data available.</span><br />");
            if (!inBaseline) {
                sb.append("<span style=\"font-size:smaller\">Press update button below to perform calculation</span>");
            }
            sb.append("</div>");
            return sb.toString();
        }

        if (isForPdf()) {
            sb.append("<div width='200px' height='200px' style=\"text-align:center;vertical-align:middle\" >");
            sb.append("<img src='/polarion/ria/images/unexportable_content.png'/>");
            sb.append("</div>");
            return sb.toString();
        }

        sb.append("\n<div align='center'").append(" id=\"").append(ID).append("_").append(uniqName).append("\">")
                .append("<object codebase='http://fpdownload.macromedia.com/get/flashplayer/current/swflash.cab' ")
                .append("height='").append(height).append("' ")
                .append("width='").append(width).append("' ")
                .append("id='").append(ID).append("_").append(uniqName).append("' ")
                .append("classid='clsid:D27CDB6E-AE6D-11cf-96B8-444553540000'>")
                .append("<param name='movie' value='/polarion/ria/charts/PieChart.swf'>")
                .append("<param name='quality' value='high'>")
                .append("<param name='bgcolor' value='#ffffff'>")
                .append("print".equals(action) ? "" : "<param name='wmode' value='transparent'>")
                .append("<param name='allowScriptAccess' value='always'>")
                .append("<param name='flashVars' value='sDataPath=").append(data.reportUrl).append("'>")
                .append("<embed flashVars='sDataPath=").append(data.reportUrl).append("' ")
                .append("pluginspage='http://www.adobe.com/go/getflashplayer' ")
                .append("type='application/x-shockwave-flash' ")
                .append("allowScriptAccess='always' loop='false' play='true' align='middle' name='Subsytem' ")
                .append("print".equals(action) ? "" : " wmode='transparent' ")
                .append("height='").append(height).append("' ")
                .append("width='").append(width).append("' ")
                .append("bgcolor='#ffffff' quality='high' src='/polarion/ria/charts/PieChart.swf'>")
                .append("</object></div>\n");
        return sb.toString();
    }

    @Override
    protected void checkRequiredParameters(String reportPath, String width, String height) {
        if (isEmpty(getData())) {
            errors.put("data", "Data have to be set.");
        }
        if (isEmpty(width)) {
            errors.put("width", "Width of chart have to be set.");
        }
        if (isEmpty(height)) {
            errors.put("height", "Height of chart have to be set.");
        }
    }

}
