package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.Collection;

import org.apache.velocity.VelocityContext;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.ui.server.wiki.IPageParameters;
import com.polarion.alm.ui.server.wiki.PageParameters;
import com.polarion.portal.server.HTMLBuilder;
import com.polarion.portal.shared.wiki.WikiEditHelper;
import com.polarion.portal.shared.wiki.WikiMacro;
import com.polarion.reina.web.shared.JSSharedUtil;
import com.polarion.reina.web.shared.html.HTMLConst;
import com.polarion.reina.web.shared.localization.Localization;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.xpn.xwiki.XWikiContext;

public class ParameterEditorMacro extends XWikiGwtMacro {

    @Override
    @NotNull
    protected String getMacroId() {
        return "parameter-editor"; //$NON-NLS-1$
    }

    @SuppressWarnings("rawtypes")
    @Override
    public void execute(Writer writer, MacroParameter parameters) throws IllegalArgumentException, IOException {
        XWikiContext context = MacroUtils.getInstance().getXWikiContext(parameters);
        String pdf = (String) context.get("pdf_generate"); //$NON-NLS-1$
        boolean isPDF = "1".equals(pdf) || "print".equals(context.getAction()) || "1".equals(context.get("documentLikeEditor")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
        HTMLBuilder builder = new HTMLBuilder(false, isPDF);
        try {
            String compare = (String) context.get("compareMode"); //$NON-NLS-1$

            boolean isCompare = "1".equals(compare); //$NON-NLS-1$

            String editorWidth = null;

            Collection<String> col = MacroUtils.getInstance().getParameters(parameters);
            String id = null;
            if (!col.isEmpty()) {
                id = col.iterator().next();
                if (id != null && id.startsWith("id=")) { //$NON-NLS-1$
                    id = id.substring(3);
                }
            }
            for (String param : col) {
                if (param.startsWith("width=")) { //$NON-NLS-1$
                    editorWidth = param.substring(6);
                }
            }

            String macroText = reconstructMacroText(parameters, "parameter-editor"); //$NON-NLS-1$
            if (isPDF) {
                VelocityContext vcontext = (VelocityContext) context.get("vcontext"); //$NON-NLS-1$
                IPageParameters pageParameters = (IPageParameters) vcontext.get("pageParameters"); //$NON-NLS-1$

                if (id != null) {
                    builder.appendHTML(pageParameters.render(id));
                }

            } else if (isCompare) {
                renderPlaceholder(builder, macroText);
            } else {

                WikiMacro macro = reconstructMacro(macroText);

                String projectId = MacroUtils.getInstance().getCurrentProjectId(context);
                VelocityContext vcontext = (VelocityContext) context.get("vcontext"); //$NON-NLS-1$
                PageParameters pageParameters = (PageParameters) vcontext.get("pageParameters"); //$NON-NLS-1$

                if (id != null) {
                    if (JSSharedUtil.isEmptyString(id)) {
                        renderError(builder, Localization.getString("macro.parameter-editor.emptyId")); //$NON-NLS-1$
                    } else if (!pageParameters.definitionExist(id)) {
                        renderError(builder, Localization.getString("macro.parameter-editor.undefinedConf", id)); //$NON-NLS-1$
                    } else if (pageParameters.isInvalidDefinition(id)) {
                        renderError(builder, Localization.getString("macro.parameter-editor.invalidConf", id)); //$NON-NLS-1$
                    } else {
                        String requestValue = pageParameters.getRequestValue(id);
                        renderMacro(builder, pageParameters.reconstructMacroText(id), requestValue, macro, projectId, editorWidth, context);
                    }
                } else {
                    renderError(builder, Localization.getString("macro.parameter-editor.emptyId")); //$NON-NLS-1$
                }

            }
        } catch (Exception e) {
            renderError(builder, e);
        }
        writer.write(builder.toString());
    }

    @SuppressWarnings({ "nls", "rawtypes" })
    private void renderMacro(@NotNull HTMLBuilder builder, @NotNull String macroText, @Nullable String requestValue,
            @NotNull WikiMacro macro, @Nullable String projectId, @Nullable String editorWidth, XWikiContext context) {
        String agent = context.getRequest().getHeader("user-agent");
        boolean isMSIE = agent.contains("MSIE");
        String verticalAlign = isMSIE ? "middle" : "baseline";
        HTMLBuilder b = new HTMLBuilder();
        MacroUtils utils = new MacroUtils();
        String projectIdParam = projectId != null ? " projectId=\"" + projectId + "\"" : "";
        String editorWidthParam = editorWidth != null ? " editorWidth=\"" + editorWidth + "\"" : "";
        String requestValueParam = requestValue != null ? " requestValue=\"" + b.escapeForAttribute(utils.escapeParameterMacro(requestValue)) + "\"" : "";
        String displayParam = isMSIE ? "display:inline-block;" : "";
        String macroParam = " macro=\"" + b.escapeForAttribute(utils.escapeParameterMacro(macroText)) + "\"";
        String macroId = WikiEditHelper.createIDParamStr(builder, WikiMacro.NODE_NAME, macro.createParamsMap());
        macroId = macroId.replace("|", "&#124;");
        //builder.appendElementStart(HTMLConst.SPAN, "parameter_editor", "zoom: 1;display:inline;vertical-align:"+verticalAlign+";",  macroId + macroParam + projectIdParam + editorWidthParam + requestValueParam);
        builder.appendElementStart(HTMLConst.SPAN, "parameter_editor", displayParam + "vertical-align:" + verticalAlign + ";line-height:normal;", macroId + macroParam + projectIdParam + editorWidthParam + requestValueParam);
        builder.appendImage(context.getWiki().getSkinFile("progress_small.gif", context), null, null, null);
        builder.appendHTML(HTMLConst.HTML_ESPAN);
    }

}
