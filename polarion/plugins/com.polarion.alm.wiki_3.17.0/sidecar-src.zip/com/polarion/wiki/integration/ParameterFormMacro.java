package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.shared.util.StringUtils;
import com.polarion.portal.server.HTMLBuilder;
import com.polarion.reina.web.shared.html.HTMLConst;
import com.polarion.reina.web.shared.html.IHTMLBuilder;
import com.polarion.wiki.integration.utils.MP;
import com.polarion.wiki.integration.utils.MacroRenderer;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.xpn.xwiki.XWikiContext;

public class ParameterFormMacro extends BaseLocaleMacro {

    private static final String PARAM_METHOD = "method"; //$NON-NLS-1$

    @Override
    public String getLocaleKey() {
        return "macro.parameter.form"; //$NON-NLS-1$
    }

    @Override
    public void execute(Writer writer, MacroParameter params)
            throws IllegalArgumentException, IOException {

        Map<String, String> errors = new HashMap<String, String>();
        XWikiContext context = MacroUtils.getInstance().getXWikiContext(params);
        String compare = (String) context.get("compareMode"); //$NON-NLS-1$
        boolean isCompare = "1".equals(compare); //$NON-NLS-1$
        String action = context.getAction();
        boolean isPreview = "preview".equals(action); //$NON-NLS-1$

        String content = params.getContent();
        if (content == null) {
            content = ""; //$NON-NLS-1$
        }

        MacroUtils utils = MacroUtils.getInstance();
        Collection<String> col = utils.getParameters(params);
        String macroText = utils.buildMacroTextFromParameters("column", col); //$NON-NLS-1$
        boolean forPdf = utils.isPdfOutput(params.getContext());

        Map<String, String> fixedParams = utils.getParameterMap(params);

        String method = setupMethodParameter(fixedParams.get(PARAM_METHOD), errors);

        if (!errors.isEmpty()) {
            writer.write(MacroRenderer.getInstance().renderErrors(errors, macroText, forPdf));
            return;
        }

        String url = context.getDoc().getURL("view", null, context); //$NON-NLS-1$
        boolean isRev = "viewrev".equals(context.getAction()); //$NON-NLS-1$
        String queryString = context.getRequest().getQueryString();
        if (isRev) {
            url = context.getDoc().getURL("viewrev", queryString, context); //$NON-NLS-1$
        }
        //boolean inBaseline = BaselineServlet.getCurrentBaselineRevision() != null;

        IHTMLBuilder builder = new HTMLBuilder();
        if (!isPreview && !isCompare) {
            builder.appendFormStart(method, "multipart/form-data", url, null, "test"); //$NON-NLS-1$//$NON-NLS-2$
        }

        if (isRev && !isCompare) {
            builder.appendInput(null, "origDocName", "hidden", null, null, context //$NON-NLS-1$ //$NON-NLS-2$
                    .getRequest().getParameter("origDocName"), null, null); //$NON-NLS-1$
            builder.appendInput(null, "origDocSpace", "hidden", null, null, context //$NON-NLS-1$ //$NON-NLS-2$
                    .getRequest().getParameter("origDocSpace"), null, null); //$NON-NLS-1$
            builder.appendInput(null, "tab", "hidden", null, null, context //$NON-NLS-1$//$NON-NLS-2$
                    .getRequest().getParameter("tab"), null, null); //$NON-NLS-1$
            builder.appendInput(null, "rev", "hidden", null, null, context //$NON-NLS-1$ //$NON-NLS-2$
                    .getRequest().getParameter("rev"), null, null); //$NON-NLS-1$
        }

        builder.appendHTML(content);

        if (!isPreview && !isCompare) {
            builder.appendElementEnd(HTMLConst.FORM);
        }
        writer.write(builder.toString());
    }

    @NotNull
    private static String setupMethodParameter(@Nullable String method, @NotNull Map<String, String> errors) {
        String result = "get"; //$NON-NLS-1$
        if (!StringUtils.isEmptyTrimmed(method)) {
            if (StringUtils.areEqualTrimmed("post", method) || StringUtils.areEqualTrimmed("get", method)) { //$NON-NLS-1$ //$NON-NLS-2$
                result = StringUtils.trimNotNull(method);
            } else {
                errors.put(method, MP.Const.ERR_MSG_METHOD.replaceFirst("%value%", method)); //$NON-NLS-1$
            }
        }
        return result;
    }
}
