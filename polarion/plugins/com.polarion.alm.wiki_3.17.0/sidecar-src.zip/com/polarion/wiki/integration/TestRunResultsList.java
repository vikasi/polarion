package com.polarion.wiki.integration;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import com.polarion.alm.tracker.model.ITestRun;
import com.polarion.alm.tracker.model.ITrackerProject;
import com.polarion.alm.ui.shared.EasyURL;
import com.polarion.platform.persistence.IEnumOption;
import com.polarion.portal.shared.navigation.IPage;
import com.polarion.portal.shared.navigation.PortalService;
import com.polarion.reina.web.shared.JSSharedUtil;
import com.polarion.wiki.integration.utils.MacroRenderer;
import com.polarion.wiki.integration.utils.MacroUtils;

public class TestRunResultsList {

    private static final MessageFormat QUERY_FORMAT = new MessageFormat("comments.title:\"Test {0} in test run:{1}\""); //$NON-NLS-1$
    private static final MessageFormat EXECUTED_QUERY_FORMAT = new MessageFormat("comments.title:\" in test run:{0}\""); //$NON-NLS-1$

    public class TestRunResults {

        private MacroUtils utils = MacroUtils.getInstance();
        private MacroRenderer renderer = MacroRenderer.getInstance();

        private String testRunId;
        private final ITestRun testRun;

        public TestRunResults(String testRunId, ITestRun testRun) {
            this.testRunId = testRunId;
            this.testRun = testRun;
        }

        public Collection<String> getResultIds() {
            return possibleResults.keySet();
        }

        public String getResultName(String resultId) {
            return possibleResults.get(resultId).getName();
        }

        public String getResultIcon(String resultId) {
            return possibleResults.get(resultId).getProperty(IEnumOption.PROPERTY_KEY_ICON_URL);
        }

        public String renderResult(String resultId, boolean forPdf) {
            if (testRun != null) {
                return renderResultNew(resultId, forPdf);
            }
            return renderResultForQuery(getResultQuery(resultId), forPdf);
        }

        public String renderExecuted(boolean forPdf) {
            if (testRun != null) {
                return renderResultNew(null, forPdf);
            }
            return renderResultForQuery(getExecutedQuery(), forPdf);
        }

        private String renderResultNew(String resultId, boolean forPdf) {
            EasyURL url = PortalService.getPortal().createTestRunUrl(project.getId(), testRun.getId(), IPage.TAB_RECORDS);
            if (resultId != null) {
                url.getAnchorPart().setQueryParam(IPage.RESULT, resultId);
            }
            int count = resultId != null ? testRun.getRecordsCount(resultId) : testRun.getRecordsCount();

            return renderer.getRenderedCount(count, forPdf, serverUrl + url.toEncodedURL());
        }

        public boolean showNotExcecuted() {
            return query != null;
        }

        @SuppressWarnings("nls")
        public String renderNotExecuted(boolean forPdf) {
            return renderResultForQuery("(" + query + ") AND NOT (" + getExecutedQuery() + ")", forPdf);
        }

        private String renderResultForQuery(String query, boolean forPdf) {
            int count = project.queryWorkItems(query, null).size();

            String link = utils.getProjectQueryLink(project.getId(), query, "id", null); //$NON-NLS-1$
            return renderer.getRenderedCount(count, forPdf, serverUrl + '/' + link);
        }

        private String getResultQuery(String resultId) {
            return QUERY_FORMAT.format(new Object[] { resultId, testRunId });
        }

        private String getExecutedQuery() {
            if (testRun != null) {
                return testRun.createQueryForAllExecutedTestCases();
            }
            return EXECUTED_QUERY_FORMAT.format(new Object[] { testRunId });
        }

    }

    private ITrackerProject project;

    private Map<String, IEnumOption> possibleResults;

    private String serverUrl;

    private String query;

    private List<TestRunResults> resultsList = new ArrayList<TestRunResults>();

    public TestRunResultsList(Map<String, IEnumOption> results, ITrackerProject project, String serverUrl, String query) {
        possibleResults = results;
        this.project = project;
        this.serverUrl = JSSharedUtil.removeSlashes(serverUrl);
        this.query = query;
    }

    public TestRunResults addTestRun(String testRunId, ITestRun testRun) {
        TestRunResults testRunResults = new TestRunResults(testRunId, testRun);
        resultsList.add(testRunResults);
        return testRunResults;
    }

    public TestRunResults getTestRunResults(int index) {
        return resultsList.get(index);
    }

    public Collection<String> getResultIds() {
        return possibleResults.keySet();
    }

    public String getResultName(String resultId) {
        return possibleResults.get(resultId).getName();
    }

    public String getResultIcon(String resultId) {
        return possibleResults.get(resultId).getProperty(IEnumOption.PROPERTY_KEY_ICON_URL);
    }

}
