package com.polarion.wiki.integration;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.velocity.context.Context;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.tracker.ITrackerService;
import com.polarion.platform.core.PlatformContext;
import com.polarion.portal.internal.shared.navigation.Portal;
import com.polarion.portal.internal.shared.navigation.ProjectGroupScope;
import com.polarion.portal.internal.shared.navigation.ProjectScope;
import com.polarion.portal.server.HTMLBuilder;
import com.polarion.portal.shared.navigation.IPage;
import com.polarion.portal.shared.navigation.IScope;
import com.polarion.portal.shared.navigation.PortalService;
import com.polarion.portal.shared.navigation.PortalSiteContext;
import com.polarion.wiki.integration.utils.MP;
import com.polarion.wiki.integration.utils.ModuleHelper;
import com.xpn.xwiki.XWikiContext;

public class ExecuteTestsButtonMacro extends VelocityBasedMacro {
    private static final String MACRO_NAME = "execute-tests-button"; //$NON-NLS-1$

    private static class AutoFillField {
        private String field;
        private String value;

        public AutoFillField(String field, String value) {
            super();
            this.field = field;
            this.value = value;
        }

        public String getField() {
            return field;
        }

        public String getValue() {
            return value;
        }

    }

    private static class ExecuteTestButtonMacroParser extends
            ExtendedMacroParser {

        private static final MP[] RULE1 = new MP[] { MP.TEST_RUN, MP.QUERY,
                MP.PROJECT, MP.SORTBY, MP.TEST_RUN_FIELD, MP.ADDITIONAL_FIELDS };

        private static final MP[] RULE2 = new MP[] { MP.TEST_RUN,
                MP.DOCUMENT_NAME2, MP.PROJECT, MP.TEST_RUN_FIELD,
                MP.ADDITIONAL_FIELDS };

        private static final MP[] RULE3 = new MP[] { MP.TEST_RUN, MP.QUERY,
                MP.DOCUMENT_NAME2, MP.PROJECT, MP.TEST_RUN_FIELD,
                MP.ADDITIONAL_FIELDS };

        private static List<MP[]> RULES = new ArrayList<MP[]>();
        static {
            RULES.add(RULE1);
            RULES.add(RULE2);
            RULES.add(RULE3);
        }

        private static Set<MP> UNIQUE_PARAMETERS = getUniqueParameters(RULES);

        private Collection<AutoFillField> autoFillFields;

        public ExecuteTestButtonMacroParser(
                @SuppressWarnings("rawtypes") XWikiContext context,
                MacroParameter parameter) {
            super(context, parameter, RULES, UNIQUE_PARAMETERS,
                    MACRO_NAME);

            String projectId = utils.getCurrentProjectId(context);
            if (projectId != null) {
                utils.addDefaultParameter(MP.PROJECT2.getName(), projectId, col);
            }

            utils.addDefaultParameter(MP.TEST_RUN_FIELD.getName(), "testRun",
                    col);
        }

        @Override
        public String parseParameters() {
            String error = super.parseParameters();
            if (error == null && getParameter(MP.PROJECT) == null) {
                error = renderer
                        .renderError(
                                MP.PROJECT.getName(),
                                "The parameter is required when macro is used in global wiki.",
                                macroText, forPdf);
            }
            if (error == null) {
                error = loadAutoFillFields(error);
            }
            return error;
        }

        private String loadAutoFillFields(String error) {
            autoFillFields = new LinkedList<ExecuteTestsButtonMacro.AutoFillField>();

            autoFillFields
                    .add(new AutoFillField(getParameter(MP.TEST_RUN_FIELD),
                            getParameter(MP.TEST_RUN)));

            String additionalFieldsString = getParameter(MP.ADDITIONAL_FIELDS);
            if (additionalFieldsString != null) {
                String[] additionalFieldStrings = additionalFieldsString
                        .split(",");
                for (String additionalFieldString : additionalFieldStrings) {
                    String[] additionalFieldParts = additionalFieldString
                            .split(":", 2);
                    if (additionalFieldParts.length == 2) {
                        autoFillFields.add(new AutoFillField(
                                additionalFieldParts[0],
                                additionalFieldParts[1]));
                    } else {
                        error = renderer.renderError(
                                MP.ADDITIONAL_FIELDS.getName(),
                                "Invalid content.", macroText, forPdf);
                        break;
                    }

                }
            }
            return error;
        }

        public Collection<AutoFillField> getAutoFillFields() {
            return autoFillFields;

        }

    }

    private ITrackerService trackerService = (ITrackerService) PlatformContext
            .getPlatform().lookupService(ITrackerService.class);

    @Override
    protected String getMacroName() {
        return MACRO_NAME;
    }

    @Override
    public String getLocaleKey() {
        return "macro.execute-tests-button";
    }

    @Override
    protected String getTemplateName() {
        return "execute-tests-button.vm";
    }

    @Override
    protected ExtendedMacroParser loadParser(MacroParameter param,
            XWikiContext<?, ?> context) {
        return new ExecuteTestButtonMacroParser(context, param);
    }

    @Override
    protected void initializeContext(Context vcontext,
            XWikiContext<?, ?> context, ExtendedMacroParser parser) {

        ExecuteTestButtonMacroParser myParser = (ExecuteTestButtonMacroParser) parser;

        Map<String, String> parameters = new HashMap<String, String>();
        parameters.put(IPage.QUERY, parser.getParameter(MP.QUERY));

        Collection<AutoFillField> autoFillFields = myParser.getAutoFillFields();
        for (AutoFillField autoFillField : autoFillFields) {
            parameters.put(IPage.FORM_FIELD_PREFIX + autoFillField.getField(),
                    autoFillField.getValue());
        }

        String projectId = parser.getParameter(MP.PROJECT);

        String link;

        String fullDocumentName = parser.getParameter(MP.DOCUMENT_NAME2);
        if (fullDocumentName == null) {
            parameters.put(IPage.SORTING, parser.getParameter(MP.SORTBY));

            link = "/polarion/#" //$NON-NLS-1$
                    + PortalService.getPortal().createUrlHash(
                            getPortalSiteContext(projectId),
                            Portal.PAGE_PATH_WORKITEMS, parameters);
        } else {
            ModuleHelper moduleHelper = new ModuleHelper(trackerService, trackerService.getTrackerProject(projectId), fullDocumentName, null);

            parameters.put(IPage.TAB, IPage.TAB_TREE);
            parameters.put(IPage.TREE_DEPTH, "0"); //$NON-NLS-1$

            link = moduleHelper.getModuleLink(parameters);
        }

        vcontext.put("link", new HTMLBuilder().escapeForAttribute(link)); //$NON-NLS-1$
    }

    private PortalSiteContext getPortalSiteContext(String projectId) {
        IScope scope;
        if (projectId == null) {
            scope = new ProjectGroupScope("");
        } else {
            scope = new ProjectScope(projectId);
        }

        PortalSiteContext portalSiteContext = new PortalSiteContext(false,
                null, null, null, scope, null);
        return portalSiteContext;
    }
}
