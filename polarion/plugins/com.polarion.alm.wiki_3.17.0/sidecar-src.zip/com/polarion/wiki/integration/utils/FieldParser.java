package com.polarion.wiki.integration.utils;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import com.polarion.alm.projects.model.IProject;
import com.polarion.alm.projects.model.IUniqueObject;
import com.polarion.alm.projects.model.IUser;
import com.polarion.alm.tracker.model.IWorkItem;
import com.polarion.alm.tracker.model.IWorkflowObject;
import com.polarion.alm.ui.shared.FieldRenderType;
import com.polarion.reina.web.shared.localization.Localization;
import com.polarion.wiki.integration.utils.MacroUtils.FieldProperty;

public class FieldParser {

    private static final MacroUtils utils = MacroUtils.getInstance();
    private static FieldParser instance;

    private String fieldName = ""; //$NON-NLS-1$
    private String fieldRenderType = null;
    private Integer fieldColumnWidth = null;

    public synchronized Map<String, FieldProperty> parseFields(String fieldsGroup, Map<String, String> errors, boolean moduleWorkItems) {
        Map<String, FieldProperty> result = new LinkedHashMap<String, FieldProperty>();

        String[] fields = fieldsGroup.split("[,]");//(\\s)*[,](\\s)* //$NON-NLS-1$

        for (String field : fields) {
            fieldName = ""; //$NON-NLS-1$
            fieldRenderType = null;
            fieldColumnWidth = null;

            if (field.trim().equals("")) { //$NON-NLS-1$
                emptyFieldNameError(errors);
                continue;
            }

            String[] partsAs = field.split(" as "); //$NON-NLS-1$
            String[] partsWidth = field.split(" width "); //$NON-NLS-1$

            if (partsAs.length == 1) {
                //we do not have 'as', but may have 'width'
                parseIdWidthPart(partsAs[0], errors);
            } else if (partsAs.length == 2) {
                //we have s1 as s2 (width can be in s1 as well as in s2)
                fieldName = partsAs[0].trim();
                parseAsWidthPart(partsAs[1], errors);
            }

            if (fieldName.trim().equals("")) { //$NON-NLS-1$
                emptyFieldNameError(errors);
            }

            if (partsAs.length > 2) {
                tooMuchParamsError(errors, "as"); //$NON-NLS-1$
                continue;
            }

            if (partsWidth.length > 2) {
                tooMuchParamsError(errors, "width"); //$NON-NLS-1$
            }

            FieldRenderType frt;
            if (fieldRenderType == null) {
                frt = getDefaultWorkitemFieldProperty(fieldName, moduleWorkItems).renderType;
                fieldRenderType = frt.getValue();
            } else {
                frt = FieldRenderType.getFieldType(fieldRenderType);
                if (frt == null) {
                    badValueError(errors, "", fieldRenderType, FieldRenderType.getUserOptions()); //$NON-NLS-1$
                }
            }

            if (!errors.isEmpty()) {
                continue;
            }

            FieldProperty fp = utils.new FieldProperty();
            fp.renderType = frt;
            if (fieldColumnWidth != null) {
                fp.width = fieldColumnWidth;
                fp.defaultWidth = false;
            } else {
                Integer width = getDefaultWorkItemFieldPercentualWidth(fieldName);
                if (width == null) {
                    fp.proportionWidth = getDefaultWorkItemFieldProportion(fieldName);
                } else {
                    fp.width = width;
                }
            }

            result.put(fieldName.trim(), fp);
//        	//TODO render errors
//        	if(fields[i].matches(".+[\\s]+(as)[\\s]+.+[\\s]+(width)[\\s]+.+")){
//        		//we have sth like: id as text width 10%
//        		String[] tmp = fields[i].split("[\\s]*(as)[\\s]*");
//        		fieldName = tmp[0];
//        		tmp = tmp[1].split("[\\s]*(width)[\\s]*");
//        		fieldRenderType = tmp[0];
//        		if(tmp[1].matches("[0-9][0-9]?[%]")){
//        			fieldColumnWidth = new Integer(tmp[1].split("[%]")[0]);
//        		}
//        	} else if(fields[i].matches(".+[\\s]+(as)[\\s]+.+")){
//        		//we have sth like: id as text
//    			String[] tmp = fields[i].split("[\\s]*(as)[\\s]*");
//    			fieldName = tmp[0];
//        		fieldRenderType = tmp[1];
//    		} else if(fields[i].matches(".+[\\s]+(width)[\\s]+.+")){
//    			//we have sth like: id width 10%
//    			String[] tmp = fields[i].split("[\\s]*(width)[\\s]*");
//    			fieldName = tmp[0];
//    			if(tmp[1].matches("[0-9][0-9]?[%]")){
//        			fieldColumnWidth = new Integer(tmp[1].split("[%]")[0]);
//        		}
//    		} else {
//    			//we have only field name without render type and width of column, e.g. title,
//    			fieldName = fields[i].trim();
//    		}

        }

        return result;
    }

    private void emptyFieldNameError(Map<String, String> errors) {
        errors.put(MP.FIELDS.getName(), Localization.getString("macro.general.missingFieldNameOrCommaTwice")); //$NON-NLS-1$
    }

    private void tooMuchParamsError(Map<String, String> errors, String param) {
        errors.put(MP.FIELDS.getName() + " - " + fieldName, Localization.getString("macro.general.youSetMoreThanOnce", param)); //$NON-NLS-1$//$NON-NLS-2$
    }

    private void badValueError(Map<String, String> errors, String param, String value, String validValues) {

        errors.put(MP.FIELDS.getName() + " - " + fieldName, Localization.getString("macro.general.valueIsNotValid", value, validValues)); //$NON-NLS-1$//$NON-NLS-2$
    }

    private void parseIdWidthPart(String part, Map<String, String> errors) {
        String[] parts = part.split("width"); //$NON-NLS-1$
        if (parts.length == 1) {
            //we have only field name
            fieldName = parts[0].trim();
        } else if (parts.length == 2) {
            fieldName = parts[0].trim();
            if (parts[1].matches("(\\s)*[0-9][0-9]?(\\s)*[%](\\s)*")) { //$NON-NLS-1$
                fieldColumnWidth = new Integer(parts[1].split("[%]")[0].trim()); //$NON-NLS-1$
            } else {
                badValueError(errors, "", parts[1], "NUM %, where NUM is positive number"); //$NON-NLS-1$
            }
        }
    }

    private void parseAsWidthPart(String part, Map<String, String> errors) {
        String[] parts = part.split("width"); //$NON-NLS-1$
        if (parts.length == 1) {
            //we have only field name
            fieldRenderType = parts[0].trim();
        } else if (parts.length == 2) {
            fieldRenderType = parts[0].trim();
            if (parts[1].matches("(\\s)*[0-9][0-9]?(\\s)*[%](\\s)*")) { //$NON-NLS-1$
                fieldColumnWidth = new Integer(parts[1].split("[%]")[0].trim()); //$NON-NLS-1$
            } else {
                badValueError(errors, "", parts[1], "NUM %, where NUM is positive number");
            }
        }
    }

    public Map<String, FieldProperty> getWorkItemFields(Map<MP, String> map, Map<String, String> errors, boolean module_defaults, boolean moduleWorkItems) {
        if (map.containsKey(MP.FIELDS)) {
            return parseFields(map.get(MP.FIELDS), errors, moduleWorkItems);
        } else {
            return getDefaultWorkItemFields(module_defaults, moduleWorkItems);
        }
    }

    public Map<String, FieldProperty> getUserFields(Map<MP, String> map, Map<String, String> errors) {
        if (map.containsKey(MP.FIELDS)) {
            return parseFields(map.get(MP.FIELDS), errors, false);
        }
        return getDefaultUserFields();
    }

    public Map<String, FieldProperty> getPageFields(Map<MP, String> map, Map<String, String> errors) {
        if (map.containsKey(MP.FIELDS)) {
            return parseFields(map.get(MP.FIELDS), errors, false);
        }
        if (map.containsKey(MP.DISPLAY_PAGES)) {
            String display = map.get(MP.DISPLAY_PAGES);
            if ("table".equalsIgnoreCase(display)) { //$NON-NLS-1$
                return getDefaultPageTableFields();
            } else {
                return getDefaultPageListFields();
            }
        } else {
            return getDefaultPageListFields();
        }
    }

    public Map<String, FieldProperty> getProjectFields(Map<MP, String> map, Map<String, String> errors) {
        if (map.containsKey(MP.FIELDS)) {
            return parseFields(map.get(MP.FIELDS), errors, false);
        }
        return getDefaultProjectFields();
    }

    public static Integer getDefaultWorkItemFieldPercentualWidth(String fieldName) {
        return getWorkItemPercentualWidthHashMap().get(fieldName);
    }

    public static Map<String, Integer> getWorkItemPercentualWidthHashMap() {
        Map<String, Integer> map = new HashMap<String, Integer>();

        map.put(IUniqueObject.KEY_ID, 15);

        return map;
    }

    public static int getDefaultWorkItemFieldProportion(String fieldName) {
        Integer proportion = getWorkItemProportionHashMap().get(fieldName);
        if (proportion == null) {
            proportion = 2; //default
        }

        return proportion;
    }

    public static Map<String, Integer> getWorkItemProportionHashMap() {
        Map<String, Integer> map = new HashMap<String, Integer>();

        map.put(IWorkflowObject.KEY_STATUS, 1);
        map.put(IUniqueObject.KEY_ID, 1);
        map.put(IWorkflowObject.KEY_TYPE, 1);
        map.put(IWorkItem.KEY_DESCRIPTION, 4);
        map.put(IWorkItem.KEY_TITLE, 2);
        map.put(IWorkItem.KEY_RESOLUTION, 1);
        map.put(IWorkItem.KEY_LINKED_REVISIONS, 3);
        map.put(IWorkItem.KEY_ATTACHMENTS, 3);
        map.put(IWorkItem.KEY_LINKED_WORK_ITEMS, 3);
        map.put(IWorkItem.KEY_HYPERLINKS, 3);
        map.put(IWorkItem.KEY_SEVERITY, 1);
        map.put(IWorkItem.KEY_PRIORITY, 1);
        map.put(IWorkItem.KEY_INITIAL_ESTIMATE, 1);
        map.put(IWorkItem.KEY_TIME_SPENT, 1);
        map.put(IWorkItem.KEY_REMAINING_ESTIMATE, 1);
        map.put(IWorkItem.KEY_PLANNED_START, 1);
        map.put(IWorkItem.KEY_PLANNED_END, 1);
        map.put(IWorkItem.KEY_RESOLVED_ON, 1);

        return map;
    }

    public static FieldParser getInstance() {
        if (instance == null) {
            instance = new FieldParser();
        }
        return instance;
    }

    private FieldParser() {
        super();
    }

    public static FieldProperty getDefaultWorkitemFieldProperty(String fieldName, boolean moduleWorkItems) {
        if (fieldName.equals(IUniqueObject.KEY_ID)) {
            return utils.new FieldProperty(FieldRenderType.IMGSTXT, getDefaultWorkItemFieldPercentualWidth(IUniqueObject.KEY_ID), null, null);
        } else if (fieldName.equals(IWorkItem.KEY_TITLE)) {
            FieldRenderType renderType = moduleWorkItems ? FieldRenderType.DEFAULT : FieldRenderType.TEXT;
            return utils.new FieldProperty(renderType, null, getDefaultWorkItemFieldProportion(IWorkItem.KEY_TITLE), null);
        } else if (fieldName.equals(IWorkItem.KEY_DESCRIPTION)) {
            return utils.new FieldProperty(FieldRenderType.TEXT, null, getDefaultWorkItemFieldProportion(IWorkItem.KEY_DESCRIPTION), null);
        } else if (fieldName.equals(IWorkflowObject.KEY_TYPE)) {
            return utils.new FieldProperty(FieldRenderType.IMGTXT, null, getDefaultWorkItemFieldProportion(IWorkflowObject.KEY_TYPE), null);
        } else if (fieldName.equals(IWorkflowObject.KEY_STATUS)) {
            return utils.new FieldProperty(FieldRenderType.IMGTXT, null, getDefaultWorkItemFieldProportion(IWorkflowObject.KEY_STATUS), null);
        } else if (fieldName.equals(IWorkItem.KEY_SEVERITY)) {
            return utils.new FieldProperty(FieldRenderType.IMAGE, null, getDefaultWorkItemFieldProportion(IWorkItem.KEY_SEVERITY), null);
        }

        return utils.new FieldProperty(FieldRenderType.TEXT, null, getDefaultWorkItemFieldProportion("unknown"), null); //$NON-NLS-1$
    }

    public static Map<String, FieldProperty> getDefaultWorkItemFields(boolean module_defaults, boolean moduleWorkItems) {
        Map<String, FieldProperty> map = new LinkedHashMap<String, FieldProperty>();

        map.put(IUniqueObject.KEY_ID, getDefaultWorkitemFieldProperty(IUniqueObject.KEY_ID, moduleWorkItems));
        map.put(IWorkItem.KEY_TITLE, getDefaultWorkitemFieldProperty(IWorkItem.KEY_TITLE, moduleWorkItems));
        if (module_defaults) {
            //map.put(IWorkItem.KEY_DESCRIPTION, getDefaultWorkitemFieldProperty(IWorkItem.KEY_DESCRIPTION));
        } else {
            map.put(IWorkflowObject.KEY_TYPE, getDefaultWorkitemFieldProperty(IWorkflowObject.KEY_TYPE, moduleWorkItems));
            map.put(IWorkflowObject.KEY_STATUS, getDefaultWorkitemFieldProperty(IWorkflowObject.KEY_STATUS, moduleWorkItems));
            map.put(IWorkItem.KEY_SEVERITY, getDefaultWorkitemFieldProperty(IWorkItem.KEY_SEVERITY, moduleWorkItems));
        }

        return map;
    }

    public static Map<String, FieldProperty> getDefaultUserFields() {
        Map<String, FieldProperty> map = new LinkedHashMap<String, FieldProperty>();
        map.put(IUser.KEY_ID, utils.new FieldProperty(FieldRenderType.TEXT, null, 2, null));
        map.put(IUser.KEY_NAME, utils.new FieldProperty(FieldRenderType.TEXT, null, 2, null));
        map.put(IUser.KEY_DESCRIPTION, utils.new FieldProperty(FieldRenderType.TEXT, null, 2, null));
        map.put(IUser.KEY_EMAIL, utils.new FieldProperty(FieldRenderType.TEXT, null, 2, null));
        map.put("roles", utils.new FieldProperty(FieldRenderType.TEXT, null, 2, null)); //$NON-NLS-1$
        return map;
    }

    public static Map<String, FieldProperty> getDefaultPageTableFields() {
        Map<String, FieldProperty> map = new LinkedHashMap<String, FieldProperty>();
        map.put("title", utils.new FieldProperty(FieldRenderType.TEXT, null, 2, null)); //$NON-NLS-1$
        map.put("updatedBy", utils.new FieldProperty(FieldRenderType.TEXT, null, 2, null)); //$NON-NLS-1$
        map.put("updated", utils.new FieldProperty(FieldRenderType.TEXT, null, 2, null)); //$NON-NLS-1$
        return map;
    }

    public static Map<String, FieldProperty> getDefaultPageListFields() {
        Map<String, FieldProperty> map = new LinkedHashMap<String, FieldProperty>();
        map.put("pageLink", utils.new FieldProperty(FieldRenderType.TEXT, null, 2, null)); //$NON-NLS-1$
        map.put("updated", utils.new FieldProperty(FieldRenderType.TEXT, null, 2, null)); //$NON-NLS-1$
        return map;
    }

    public static Map<String, FieldProperty> getDefaultProjectFields() {
        Map<String, FieldProperty> map = new LinkedHashMap<String, FieldProperty>();
        map.put(IProject.KEY_ID, utils.new FieldProperty(FieldRenderType.TEXT, null, 2, null));
        map.put(IProject.KEY_NAME, utils.new FieldProperty(FieldRenderType.TEXT, null, 2, null));
        map.put(IProject.KEY_DESCRIPTION, utils.new FieldProperty(FieldRenderType.TEXT, null, 2, null));
        map.put(IProject.KEY_LEAD, utils.new FieldProperty(FieldRenderType.TEXT, null, 2, null));
        map.put(IProject.KEY_ACTIVE, utils.new FieldProperty(FieldRenderType.IMAGE, null, 2, null));
        map.put("roles", utils.new FieldProperty(FieldRenderType.TEXT, null, 2, null)); //$NON-NLS-1$
        return map;
    }

    public static Map<String, FieldProperty> getDefaultPagesFields() {
        Map<String, FieldProperty> map = new LinkedHashMap<String, FieldProperty>();
        map.put("pagename", utils.new FieldProperty(FieldRenderType.TEXT, null, 2, null)); //$NON-NLS-1$
        map.put("updatedby", utils.new FieldProperty(FieldRenderType.TEXT, null, 2, null)); //$NON-NLS-1$
        map.put("update", utils.new FieldProperty(FieldRenderType.TEXT, null, 2, null)); //$NON-NLS-1$
        map.put("created", utils.new FieldProperty(FieldRenderType.TEXT, null, 2, null)); //$NON-NLS-1$
        return map;
    }

}
