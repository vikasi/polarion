package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.administration.web.server.security.IAdministrationPolicy;
import com.polarion.core.util.logging.Logger;
import com.polarion.platform.core.PlatformContext;
import com.polarion.wiki.web.BaselineServlet;

public class CreateProjectButtonMacro extends BaseLocaleMacro {

    private static IAdministrationPolicy administrationPolicy = (IAdministrationPolicy) PlatformContext.getPlatform().lookupService(IAdministrationPolicy.class);

    private static final String VISIBLE_BUTTON = "<a style=\"border:0px; font-size: 25mm;\" " + //$NON-NLS-1$
            "onclick=\"" + // fix for DPP-9509 - Ugly page reload when creating new project from the portal Home //$NON-NLS-1$
            "if(top!=null && top.navigateFromFrame!=null){" + //$NON-NLS-1$
            "top.navigateFromFrame('#action:create:Project');" + //$NON-NLS-1$
            "return false;" + //$NON-NLS-1$
            "}" + //$NON-NLS-1$
            "\" href=\"/polarion/#action:create:Project\" target=\"_top\">" + //$NON-NLS-1$
            "<img style=\"border:0px\" src=\"/polarion/ria/images/wiki/CreateProjectVisibleButton.png\" title=\"Create New Project\" alt=\"Create New Project\" />" + //$NON-NLS-1$
            "</a>"; //$NON-NLS-1$

    private static final String NO_PERMS_MESSAGE = "You do not have the necessary permissions to create new projects. Please contact your Polarion administrator."; //$NON-NLS-1$
    private static final String BASELINE_MESSAGE = "You cannot create projects in baseline."; //$NON-NLS-1$

    private static String getUnvisibleButton(String message) {
        return "<img src=\"/polarion/ria/images/wiki/CreateProjectUnvisibleButton.png\" title=\"" + message + "\" alt=\"" + message + "\"/>"; //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
    }

    private static final Logger log = Logger.getLogger(CreateProjectButtonMacro.class);

    @Override
    public void execute(Writer writer, MacroParameter params) throws IllegalArgumentException, IOException {
        try {
            String message = null;
            if (BaselineServlet.getCurrentBaselineRevision() != null) {
                message = BASELINE_MESSAGE;
            } else if (!administrationPolicy.canCreateProject()) {
                message = NO_PERMS_MESSAGE;
            }

            writer.write(message != null ? getUnvisibleButton(message) : VISIBLE_BUTTON);
        } catch (Exception e) {
            log.error(e);
        }
    }

    @Override
    public String getLocaleKey() {
        return "macro.polarioncreateprojectbutton";
    }

}
