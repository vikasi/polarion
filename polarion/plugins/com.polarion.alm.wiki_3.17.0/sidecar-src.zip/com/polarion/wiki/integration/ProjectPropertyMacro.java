package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.radeox.api.engine.context.RenderContext;
import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.projects.IProjectService;
import com.polarion.alm.projects.model.IGroupEntity;
import com.polarion.alm.projects.model.IProject;
import com.polarion.alm.tracker.model.ITrackerProject;
import com.polarion.core.util.logging.Logger;
import com.polarion.platform.core.PlatformContext;
import com.polarion.platform.service.repository.IRepositoryService;
import com.polarion.reina.web.shared.localization.Localization;
import com.polarion.subterra.base.location.ILocation;
import com.polarion.wiki.integration.utils.MacroRenderer;
import com.polarion.wiki.integration.utils.MacroUtils;

/**
 * Renders project property - count of project members, repository url, or any project field.<p>
 * 
 * Syntax: <code>{project-property:<i>Project</i>|<i>Property</i>}</code><br/>
 * In a wiki page from a project the project need not be specified; 
 * the current project is taken as default.<p>
 *   
 * Examples:
 * <pre>
 *   {project-property:users}
 *   {project-property:location}
 *   {project-property:name}
 *   {project-property:description}
 *   {project-property:lead}
 *   {project-property:active}
 *   {project-property:start}
 *   {project-property:finish}
 *   {project-property:id}
 *   {project-property:MyProject|users}
 * </pre> 
 */
public class ProjectPropertyMacro extends BaseLocaleMacro {

    private static final Logger log = Logger.getLogger(ProjectPropertyMacro.class);

    @Override
    public String getLocaleKey() {
        return "macro.project-property"; //$NON-NLS-1$
    }

    private static class Renderer {

        private static final String PROP_USERS = "users"; //$NON-NLS-1$
        private static final String LABEL_NO_DATE = "--"; //$NON-NLS-1$

        @NotNull
        private final MacroUtils utils = MacroUtils.getInstance();

        @NotNull
        private final MacroRenderer renderer = MacroRenderer.getInstance();

        @NotNull
        private final RenderContext context;

        @Nullable
        private final String projectId;

        //@Nullable
        private final String property;

        @NotNull
        private final String macroText;

        private final boolean forPdf;

        @NotNull
        private final Map<String, String> errors = new HashMap<String, String>();

        private Renderer(@NotNull MacroParameter params) {

            context = params.getContext();
            macroText = utils.buildMacroTextFromParameters2("project-property", params); //$NON-NLS-1$
            forPdf = utils.isPdfExport(utils.getXWikiContext(params));

            switch (params.getLength()) {
            case 2:
                projectId = params.get(0).trim();
                property = params.get(1).trim();
                break;
            case 1:
                projectId = null;
                property = params.get(0).trim();
                break;
            case 0:
                errors.put(Localization.getString("macro.project-property.badParameter"), //$NON-NLS-1$
                        Localization.getString("macro.project-property.validParameterValues1")); //$NON-NLS-1$
                // fallthrough
            default:
                projectId = null;
                property = null;
            }
        }

        void render(@NotNull Writer writer) throws IllegalArgumentException, IOException {
            try {

                ITrackerProject project = getProject();

                if ((property == null) || !property.matches("(id|location|users|name|description|lead|active|start|finish)")) { //$NON-NLS-1$
                    errors.put(Localization.getString("macro.project-property.badParameter"), //$NON-NLS-1$
                            Localization.getString("macro.project-property.validParameterValues2")); //$NON-NLS-1$
                }

                if (project == null || !errors.isEmpty()) {
                    writer.write(renderer.renderErrors(errors, macroText, forPdf));
                    return;
                }

                Object value = null;
                if (IGroupEntity.KEY_LOCATION.equals(property)) {
                    // WARNING: This is currently NOT the same as project.getValue("location")
                    value = project.getLocation();
                } else if (PROP_USERS.equals(property)) {
                    IProjectService projectService = PlatformContext.getPlatform().lookupService(IProjectService.class);
                    value = projectService.getProjectUsers(project).size();
                } else if (project.getPrototype().getKeyNames().contains(property)) {
                    value = project.getValue(property);
                }

                if (property.equals(IProject.KEY_DESCRIPTION)) {
                    if (value == null) {
                        writer.write(""); //$NON-NLS-1$
                        return;
                    }
                }

                if (property.equals(ITrackerProject.KEY_START) || property.equals(ITrackerProject.KEY_FINISH)) {
                    if (value == null) {
                        writer.write(LABEL_NO_DATE);
                        return;
                    }
                }

                if (property.equals(IGroupEntity.KEY_LOCATION) && (value instanceof ILocation)) {
                    IRepositoryService repositoryService = PlatformContext.getPlatform().lookupService(IRepositoryService.class);
                    ILocation location = (ILocation) value;
                    URI uri = repositoryService.getAccessibleURLForLocation(location);
                    writer.write("<a href=\"/polarion/#/project/" + project.getId() + "/repository/browser\" target=\"_top\">" + uri.toString() + "</a>"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
                    return;
                }
                writer.write(utils.format(value));
            } catch (Exception e) {
                log.error(e.getLocalizedMessage(), e);
                errors.put(Localization.getString("definition.error"), //$NON-NLS-1$
                        Localization.getString("macro.project-property.renderingException") + " " + e.getLocalizedMessage()); //$NON-NLS-1$ //$NON-NLS-2$
                writer.write(renderer.renderErrors(errors, macroText, forPdf));
            }
        }

        @Nullable
        private ITrackerProject getProject() {
            ITrackerProject project;
            if (projectId == null) {
                project = utils.getCurrentProject(context);
                if (project == null) {
                    // you are in bad context
                    errors.put(Localization.getString("macro.project-property.context"), //$NON-NLS-1$
                            Localization.getString("macro.project-property.inProjectContext")); //$NON-NLS-1$
                }
            } else {
                project = utils.getTrackerProject(projectId, errors);
            }
            return project;
        }

    }

    @Override
    public void execute(Writer writer, MacroParameter params) throws IllegalArgumentException, IOException {
        new Renderer(params).render(writer);
    }

}
