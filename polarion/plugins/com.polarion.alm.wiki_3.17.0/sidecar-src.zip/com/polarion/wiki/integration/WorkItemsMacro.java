package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.Collection;
import java.util.Map;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.portal.server.HTMLBuilder;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.integration.utils.WorkItemsMacroParser;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.util.Util;

/**
 * {workitems:QUERY(optional)} - search in current context
 * 
 * parameters:
 * 
 * Query:
 * first parameter is a query, without query will be fetched all in scope
 * queryName=name  - saved query in current context or on repository
 * queryName=project/name - saved query in other project
 * 
 * Scope:
 * project=
 * group=
 * {workitems: status:open|project=PolarionSVN)}
 * {workitems: status:open|group=/PolarionDPP/Components)}
 * {workitems| queryName=PolarionSVN/unresolved | group=/PolarionDPP}   unresolved saved query from project PolarionSVN executed in contex of PolarionDPP project group
 * 
 * For global (repository) scope use group "/".
 * 
 * Presentation:
 * display=list|table(default)
 * expand=yes(default)|no
 * top=count(50=default)
 * fields
 * sortby
 * width and height
 * 
 * @author Administrator
 *
 */
public class WorkItemsMacro extends BaseLocaleMacro {

    final private MacroUtils utils = MacroUtils.getInstance();

    @Override
    public void execute(Writer writer, MacroParameter parameters)
            throws IllegalArgumentException, IOException {

        XWikiContext context = utils.getXWikiContext(parameters);
        Collection<String> col = utils.getParameters(parameters);
        utils.addParameterNameToValue("query", col);

        Map<String, String> params = utils.getParameterMap(parameters);
        String displayMethod = params.get("display");

        String compare = (String) context.get("compareMode");
        String pdf = (String) context.get("pdf_generate");
        String noAjax = (String) context.get("no_ajax");

        if ((compare != null && compare.equalsIgnoreCase("1"))) {
            String macroText = utils.buildMacroTextFromParametersSimple("workitems", col);
            if (macroText != null) {
                macroText = Util.encodeLinkInCompare(macroText);
                macroText = new HTMLBuilder().escapeForAttribute(macroText);
            }
            macroText = "<img src=\"/polarion/ria/images/wiki/macro_workitems.gif\" title=\"" + macroText + "\"/>";
            writer.write(macroText);
        } else if ((pdf == null || pdf.equalsIgnoreCase("0")) && !"count".equals(displayMethod) && noAjax == null) {
            String ajaxLink = utils.getAjaxLink(col, context, "workitemsmacroaction");
            writer.write(ajaxLink);
        } else {
            String macroText = utils.buildMacroTextFromParameters("workitems", col);
            WorkItemsMacroParser parser = new WorkItemsMacroParser(context);

            String result = parser.parse(col, macroText, true);
            result = Util.contentEncode(result);
            writer.write(result);
        }

    }

    @Override
    public String getLocaleKey() {
        return "macro.polarionworkitems";
    }

}
