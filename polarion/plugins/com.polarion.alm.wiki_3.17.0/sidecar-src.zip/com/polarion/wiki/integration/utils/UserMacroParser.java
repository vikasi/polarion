package com.polarion.wiki.integration.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.polarion.alm.projects.model.IProject;
import com.polarion.alm.projects.model.IUser;
import com.polarion.core.util.logging.Logger;
import com.polarion.reina.web.shared.localization.Localization;
import com.polarion.subterra.base.data.identification.IContextId;
import com.polarion.wiki.integration.utils.MacroUtils.FieldProperty;
import com.xpn.xwiki.XWikiContext;

public class UserMacroParser extends MacroParser {

    private static final Logger log = Logger.getLogger(UserMacroParser.class);

    final static private MP[] rule1 = {
            MP.USER_ID, MP.DISPLAY_SHORT_LONG, MP.EXPAND_YES_NO, MP.FIELDS, MP.LABEL, MP.PROJECT, MP.LINK
    };
    final static private MP[] rule2 = {
            MP.USER_ID, MP.DISPLAY_SHORT_LONG, MP.EXPAND_YES_NO, MP.FIELDS, MP.LABEL, MP.GROUP, MP.LINK
    };

    static final private List<MP[]> rules = new ArrayList<MP[]>();

    static {
        rules.add(rule1);
        rules.add(rule2);
    }

    static final private Set<MP> uniqueParameters = getUniqueParameters(rules);

    public UserMacroParser(XWikiContext context) {
        super(context, rules, uniqueParameters);
    }

    @Override
    public String parse(Collection<String> col, String macroText, boolean forPdf) {
        this.col = col;
        this.macroText = macroText;
        this.forPdf = forPdf;

        IContextId contextId = null;

        try {
            utils.addParameterNameToValue("id", col); //$NON-NLS-1$
            utils.addDefaultParameter(MP.DISPLAY_SHORT_LONG.getName(), "short", col); //$NON-NLS-1$

            String err = parseParameters();
            if (err != null) {
                return err;
            }

            boolean withLink = utils.showLink(map);

            IUser user = null;
            String userId = map.get(MP.USER_ID);
            if (!userId.matches("(\\s)*@current(\\s)*")) { //$NON-NLS-1$
                user = projectService.getUser(userId);
//				if(user.isUnresolvable()){
//					errors.put(MP.USER_ID.getName(), "User with ID '" + userId + "' in doesn't exist.");
//					return renderer.renderErrors(errors, macroText, forPdf);
//				}
            } else {
                //search on current scope, but only if scope is project!
                user = projectService.getCurrentUser();
            }
            if (user == null) {
                return utils.renderError(Localization.getString("macro.general.currentUserIsPolarionServer")); //$NON-NLS-1$
            }

            if (map.containsKey(MP.PROJECT)) {
                IProject p = utils.getProject(map.get(MP.PROJECT), errors);
                if (p == null) {
                    return renderer.renderErrors(errors, macroText, forPdf);
                }
                contextId = p.getContextId();
            } else if (!map.containsKey(MP.GROUP)) {
                //set current scope' contextId
                IProject p = utils.getCurrentProject(context);
                contextId = (p != null) ? p.getContextId() : null;
            } //if we have set MP.GROUP or context is repository, then we need to have context=null what we actually have

            String fs = map.get(MP.FIELDS);
            if (fs != null) {
                //render fields behind work item id
                Map<String, FieldProperty> fields = fieldParser.getUserFields(map, errors);
                if (!errors.isEmpty()) {
                    return renderer.renderErrors(errors, macroText, forPdf);
                }
                return renderer.getRenderedFields(
                        fields,
                        user,
                        utils.getExpandMode(map),
                        utils.getLinkDisplay(map),
                        utils.getPolarionServerURL(context),
                        map.get(MP.LABEL),
                        contextId,
                        map.get(MP.WIDTH),
                        map.get(MP.HEIGHT),
                        forPdf,
                        withLink,
                        context
                        );
            } else {
                //render only work item id (+title)
                return renderer.getLink4MacroObject(
                        user,
                        macroText,
                        utils.getLinkDisplay(map),
                        map.get(MP.LABEL),
                        utils.getPolarionServerURL(context),
                        forPdf,
                        null,
                        null,
                        null,
                        withLink,
                        context
                        );
            }
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            errors.put("Error", Localization.getString("macro.general.parsingUnknownException") + e.getLocalizedMessage()); //$NON-NLS-1$//$NON-NLS-2$
            return renderer.renderErrors(errors, macroText, forPdf);
        }
    }

}
