/*
 * Copyright (C) 2004-2009 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2009 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.builder.IBuilderService;
import com.polarion.alm.builder.model.IBuild;
import com.polarion.alm.builder.model.IBuildArtifact;
import com.polarion.alm.qcentre.factbase.renderers.PercentageFormatter;
import com.polarion.alm.reports.server.ReportsPolicy;
import com.polarion.alm.tracker.ITrackerService;
import com.polarion.alm.tracker.model.ITrackerProject;
import com.polarion.core.util.collection.CollectionsUtil;
import com.polarion.platform.core.PlatformContext;
import com.polarion.wiki.integration.utils.MacroRenderer;
import com.polarion.wiki.integration.utils.MacroUtils;

/**
 * Renders Dashboard property - project, test success ratio, build success ratio
 * 
 * Syntax: <code>{dashboard-property:<i>Project</i>|<i>Property</i>}</code><br/>
 * In a wiki page from a project the project need not be specified; 
 * the current project is taken as default.<p>
 * 
 * Examples:
 * <pre>
 *  {dashboard-property:build-success-ratio}
 *  {dashboard-property:build-frequency}
 * </pre>
 * 
 * @author <a href="mailto:dev@polarion.com">Jakub Stroleny</a>, Polarion Software
 */
public final class DashboardPropertyMacro extends BaseLocaleMacro {

    private static final Logger log = Logger.getLogger(DashboardPropertyMacro.class);

    private static ITrackerService trackerService = (ITrackerService) PlatformContext.getPlatform().lookupService(ITrackerService.class);
    private static final IBuilderService builderService = (IBuilderService) PlatformContext.getPlatform().lookupService(IBuilderService.class);

    private static final MacroUtils utils = MacroUtils.getInstance();
    private static final MacroRenderer renderer = MacroRenderer.getInstance();
    private static final ReportsPolicy policy = ReportsPolicy.getPolicy();

    private ITrackerProject project;
    private String property;
    private String macroText;
    private boolean forPdf;
    private Map<String, String> errors;

    private static final String PARAM_BUILDRATIO = "build-success-ratio";
    private static final String PARAM_BUILDFREQUENCY = "build-frequency";

    @Override
    public String getLocaleKey() {
        return "macro.polariondashboard-property";
    }

    @Override
    public void execute(final Writer writer, final MacroParameter params)
            throws IllegalArgumentException, IOException {
        boolean canUseDashboards = policy.canUseDashboardMacros();
        if (!canUseDashboards) {
            writer.write(renderer.renderInaccessibleMessage(true, canUseDashboards));
            return;
        }

        init(writer, params);
        if (project != null) {
            executeInternal(writer, params);
        }
    }

    private void executeInternal(Writer writer, MacroParameter params) throws IOException {
        Object value = null;
        PercentageFormatter distributionFormatter = new PercentageFormatter();
        if (PARAM_BUILDRATIO.equals(property)) {
            IBuildArtifact buildArtifact = (IBuildArtifact) CollectionsUtil.getFirst(builderService.getBuildArtifactsForProject(project));
            if (buildArtifact != null) {
                int ok_size = builderService.queryBuilds(
                        project, "buildStatus.type:OK AND HAS_VALUE:finishTime AND HAS_VALUE:buildDescriptorName", "~" + IBuild.CREATION_TIME) //$NON-NLS-1$ //$NON-NLS-2$
                        .size();
                int all_size = builderService.queryBuilds(
                        project, "HAS_VALUE:finishTime AND HAS_VALUE:buildDescriptorName", "~" + IBuild.CREATION_TIME).size(); //$NON-NLS-1$ //$NON-NLS-2$
                if (all_size > 0) {
                    String buildURL = "/polarion/#/project/" + project.getId() + "/builds";
                    value = distributionFormatter.render(100 * (ok_size) / ((double) all_size),
                            buildURL, buildURL);
                } else {
                    value = MacroUtils.NOT_AVAILABLE;
                }
            }
        } else if (PARAM_BUILDFREQUENCY.equals(property)) {
            String lastDays = trackerService.getDataService().getQueryHelper().fromToDateOnlyQuery(new Date(System.currentTimeMillis() - 7 * 24 * 3600 * 1000), new Date());
            int lastBuilds = builderService.queryBuilds(project, "startTime:" + lastDays + " AND HAS_VALUE:buildDescriptorName", "~" + IBuild.CREATION_TIME).size(); //$NON-NLS-2$ //$NON-NLS-3$
            value = new Integer(lastBuilds);
        } else {
            // TODO
        }
        writer.write(utils.trimValue(utils.format(value)));
    }

    public void init(Writer writer, MacroParameter params) throws IOException {
        String projectId = null;
        property = null;
        macroText = utils.buildMacroTextFromParameters2("dashboard-property", params);
        forPdf = utils.isPdfExport(utils.getXWikiContext(params));
        errors = new HashMap<String, String>();

        if (params.getLength() == 2) {
            projectId = params.get(0).trim();
            property = params.get(1).trim();
        } else if (params.getLength() == 1) {
            property = params.get(0).trim();
        }
        else if (params.getLength() == 0) {
            StringBuilder sb = new StringBuilder();
            sb.append("{dashboard-property:").append(PARAM_BUILDRATIO).append("},")
                    .append("{dashboard-property:").append(PARAM_BUILDFREQUENCY).append("},");
            errors.put("Bad parameter", "The parameter should have one of these values: " + sb.toString());
        }
        if (projectId == null) {
            project = utils.getCurrentProject(params.getContext());
            if (project == null) {
                //you are on bad context
                errors.put("Context", "You should use this macro only on project context or you have to define project parameter.");
            }
        } else {
            project = utils.getTrackerProject(projectId, errors);
        }
        if ((property == null) || (!property.matches("(" + PARAM_BUILDFREQUENCY + "|" + PARAM_BUILDRATIO + ")"))) {
            StringBuilder sb = new StringBuilder();
            sb.append(PARAM_BUILDRATIO).append(",")
                    .append(PARAM_BUILDFREQUENCY);
            errors.put("Bad parameter", "The parameter should have one of these values: " + sb.toString());
        }
        if (!errors.isEmpty()) {
            writer.write(renderer.renderErrors(errors, macroText, forPdf));
            return;
        }
    }

}
