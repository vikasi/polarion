/*
 * Copyright (C) 2004-2009 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2009 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.reports.server.ReportsPolicy;
import com.polarion.alm.reports.shared.ReportData;
import com.polarion.core.util.logging.Logger;
import com.polarion.portal.internal.shared.navigation.ProjectGroupScope;
import com.polarion.portal.internal.shared.navigation.ProjectScope;
import com.polarion.portal.shared.navigation.IScope;
import com.polarion.reina.web.shared.rpc.DefaultJSRPCCallback;
import com.polarion.reina.web.shared.rpc.IJSRPCCallback;
import com.polarion.wiki.integration.utils.MacroRenderer;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.util.RequestParser;
import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;

/**
 * @author <a href="mailto:dev@polarion.com">Jakub Stroleny</a>, Polarion Software
 */
public abstract class AbstractReportMacro extends BaseLocaleMacro {

    private static final Logger log = Logger.getLogger(AbstractReportMacro.class);

    private static final MacroUtils utils = MacroUtils.getInstance();
    private static final MacroRenderer renderer = MacroRenderer.getInstance();
    private static final ReportsPolicy policy = ReportsPolicy.getPolicy();

    private String currentProject;
    private String currentProjectGroup;
    private String reportPath;
    private String width;
    private String height;
    private Writer writer;
    private MacroParameter params;
    private String macroText;
    private boolean forPdf;
    protected Map<String, String> errors;
    protected static int div_id_counter;

    private ReportData reportData = null;

    private static final String NO_REPORT_DATA = "No report data";

    private IJSRPCCallback<ReportData> callback = new ReportJSRPCCallback();

    @Override
    public abstract String getName();

    @Override
    public abstract String getLocaleKey();

    public abstract boolean getReportData(IScope scope) throws Exception;

    public abstract String getReportContent(ReportData reportData, String width, String height, String action);

    public final String getCurrentProject() {
        return currentProject;
    }

    public final String getCurrentProjectGroup() {
        return currentProjectGroup;
    }

    public final String getReportPath() {
        return reportPath;
    }

    public final String getWidth() {
        return width;
    }

    public final String getHeight() {
        return height;
    }

    public final Writer getWriter() {
        return writer;
    }

    public final MacroParameter getParameters() {
        return params;
    }

    public IJSRPCCallback<ReportData> getCallBack() {
        return callback;
    }

    public final MacroUtils getMacroUtils() {
        return utils;
    }

    public final MacroRenderer getMacroRenderer() {
        return renderer;
    }

    public final String getMacroText() {
        return macroText;
    }

    public final Map<String, String> getErrors() {
        return errors;
    }

    public final boolean isForPdf() {
        return forPdf;
    }

    @Override
    public void execute(Writer writer, MacroParameter params)
            throws IllegalArgumentException, IOException {

        String action = "view";

        try {
            String action2 = getXWikiContext(params).getAction();
            if ("print".equals(action2)) {
                action = action2;
            }
        } catch (Exception e) {
            //
        }

        boolean canUse = true;
        if ("live-plan".equals(getName())) {
            canUse = policy.canUseLiveplan();
        }
        if ("line-chart".equals(getName()) || "report".equals(getName())) {
            canUse = policy.canUseDashboardMacros();
        }
        if (!canUse) {
            writer.write(renderer.renderInaccessibleMessage(true, canUse));
            return;
        }

        if (!init(writer, params)) {
            return;
        }

        IScope scope = null;
        if (!isEmpty(getCurrentProject())) {
            scope = new ProjectScope(getCurrentProject());
        } else if (!isEmpty(getCurrentProjectGroup())) {
            scope = new ProjectGroupScope(getCurrentProjectGroup());
        } else {
            scope = new ProjectGroupScope(""); //repository scope
        }

        try {
            if (getReportData(scope)) {
                String content = getReportContent(reportData, width, height, action);
                writer.append(content != null ? content : NO_REPORT_DATA);
            }
        } catch (Exception ex) {
            log.error("Failed to retrieve data for macro " + getName(), ex);
            writer.append(renderer.renderError("Data unavailable", "Error when retrieving data.", macroText, forPdf));
        }
    }

    protected XWikiContext getXWikiContext(MacroParameter params) {
        return (XWikiContext) params.getContext().get("xcontext");
    }

    @SuppressWarnings("unchecked")
    private boolean init(Writer writer, MacroParameter params) throws IOException {
        this.writer = writer;
        this.params = params;
        Collection<String> parameters = new ArrayList<String>();
        parameters.add("report-path");
        parameters.add("width");
        parameters.add("height");
        macroText = utils.buildMacroTextFromParameters2(getName(), params);
        forPdf = utils.isPdfExport(utils.getXWikiContext(params));
        errors = new HashMap<String, String>();
        XWikiContext xcontext = utils.getXWikiContext(params);
        Map requestParams = null;

        try {
            requestParams = RequestParser.parseQuery(XWiki.getRequestURL(xcontext.getRequest()).toString(), xcontext);
        } catch (XWikiException ex) {
            log.error(ex.getLocalizedMessage(), ex);
            errors.put("Error", "Parsing unknown exception, cause:" + ex.getLocalizedMessage());
            writer.write(renderer.renderErrors(errors, macroText, forPdf));
        }

        currentProject = (String) requestParams.get("project");
        currentProjectGroup = (String) requestParams.get("projectGroup");
        reportPath = params.get("report-path");
        width = params.get("width");
        height = params.get("height");

        checkRequiredParameters(reportPath, width, height);
        if (!errors.isEmpty()) {
            writer.write(renderer.renderErrors(errors, macroText, forPdf));
        }
        return errors.isEmpty();
    }

    protected void checkRequiredParameters(String reportPath, String width, String height) {
        if (isEmpty(reportPath)) {
            errors.put("report-path", "Report path have to be set.");
        }
        if (isEmpty(width)) {
            errors.put("width", "Width of chart have to be set.");
        }
        if (isEmpty(height)) {
            errors.put("height", "Height of chart have to be set.");
        }
    }

    public boolean isEmpty(String s) {
        return (s == null) || (s.trim().length() == 0);
    }

    public boolean isEmpty(String[] s) {
        return s == null || s.length == 0;
    }

    class ReportJSRPCCallback extends DefaultJSRPCCallback<ReportData> {

        @Override
        public void callback(ReportData data) {
            reportData = data;
        }

    }

}
