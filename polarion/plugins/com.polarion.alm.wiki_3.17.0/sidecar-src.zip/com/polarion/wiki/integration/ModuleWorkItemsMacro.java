package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.Collection;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.wiki.integration.utils.MP;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.integration.utils.ModuleWorkItemsMacroParser;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.doc.XWikiDocument;

public class ModuleWorkItemsMacro extends BaseLocaleMacro {

    final private MacroUtils utils = MacroUtils.getInstance();

    @Override
    public void execute(Writer writer, MacroParameter parameters)
            throws IllegalArgumentException, IOException {

        Collection<String> col = utils.getParameters(parameters);
        utils.renameModuleNameToName(col);
        XWikiContext context = utils.getXWikiContext(parameters);
        String compare = (String) context.get("compareMode");
        String compareDLE = (String) context.get("compareModeDLE");
        boolean isCompareDLE = compareDLE != null && "1".equals(compareDLE);

        XWikiDocument o = context.getDoc();
        String rev = (String) context.get("revision");
        if (o != null && rev != null) {
            rev = o.getVersion();
            col.add(MP.REVISION.getName() + "=" + rev);
        }
        String result = null;

        utils.addParameterNameToValue(MP.MODULE_NAME.getName(), col);

        String pdf = (String) context.get("pdf_generate");
//        if ( (compare != null && compare.equalsIgnoreCase("1")) )
//        {
//        	String macroText = utils.buildMacroTextFromParameters("module-workitems", col);
//            ModuleWorkItemsMacroParser parser = new ModuleWorkItemsMacroParser(utils.getXWikiContext(parameters));
//
//        	result = parser.parse(col, macroText, true);
//        }
        if (!isCompareDLE && (pdf == null || pdf.equalsIgnoreCase("0"))) {
            String ajaxLink = utils.getAjaxLink(col, context, "moduleworkitemsmacroaction");
            result = ajaxLink;
        } else {
            String macroText = utils.buildMacroTextFromParameters("module-workitems", col);
            ModuleWorkItemsMacroParser parser = new ModuleWorkItemsMacroParser(context);

            result = parser.parse(col, macroText, true);
        }
        writer.write(result);

    }

    @Override
    public String getLocaleKey() {
        return "macro.polarionmoduleworkitems";
    }

}
