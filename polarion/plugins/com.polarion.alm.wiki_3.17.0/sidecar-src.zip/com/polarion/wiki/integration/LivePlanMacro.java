/*
 * Copyright (C) 2004-2009 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2009 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.polarion.wiki.integration;

import java.util.HashMap;
import java.util.HashSet;

import com.polarion.alm.reports.shared.ReportData;
import com.polarion.core.util.logging.Logger;
import com.polarion.portal.shared.navigation.IScope;
import com.polarion.portal.shared.portlet.JSPortletConfig;
import com.polarion.portal.shared.portlet.JSPortletPreferences;

/**
 * @author <a href="mailto:dev@polarion.com">Jakub Stroleny</a>, Polarion Software
 */
public class LivePlanMacro extends AbstractReportMacro {

    private static final String jsClassName = "com.polarion.alm.tracker.web.js.internal.liveplan.LivePlanPortlet";
    private static final String mode = "view";

    private static final String ID = "LivePlan";

    private static final Logger log = Logger.getLogger(LivePlanMacro.class);

    @Override
    public String getLocaleKey() {
        return "macro.polarionliveplan";
    }

    @Override
    public String getName() {
        return "live-plan";
    }

    @Override
    public String getReportContent(ReportData reportData, String width, String height, String action) {
        String id = IntegrationPlugin.getUniqName();
        ;

//		StringBuilder js = new StringBuilder();
//        js.append("function livePlan(e) {");
//       
//        js.append("var dom = top.renderLivePlan();");
//        js.append("document.getElementById(\"");
//        js.append(ID).append("_").append(id);
//        js.append("\").innerHTML=\"\";");
//        js.append("document.getElementById(\"");
//        js.append(ID).append("_").append(id);
//        js.append("\").appendChild(dom);");
//        js.append("}");
//        String jsText = js.toString().replaceAll("\n", ""); // for wiki page compare

        StringBuilder sb = new StringBuilder();
        sb.append("\n<div id=\"").append(ID).append("_").append(id);
        sb.append("\" style='" + (width != null ? "width:" + width + ";" : "width:100%;") + (height != null ? "height:" + height + ";" : "") + "'>");
        sb.append("<img src=\"/polarion/ria/images/wiki/macro.gif\" alt=\"Macro\" title=\"Macro\"/>");
        sb.append("</div>");
//TODO gwt        
//        sb.append("<style>@import \"/polarion/ria/ria/ria_"+RIAServlet.getCssTimestamp()+".css\";</style>");
//        sb.append("<script type=\"text/javascript\" src=\"/polarion/ria/ria/out_"+RIAServlet.getOutJsTimestamp()+".js\"></script>");
//        sb.append("<script type=\"text/javascript\" id=\"scriptmacro_"); // id=scriptmacro will be evaluated in AJAX requests
//        sb.append(id).append("\">");
//        sb.append(jsText);
//        sb.append("livePlan();");
//        sb.append("</script>\n");
        return sb.toString();
    }

    public JSPortletPreferences getPreferences() {
        // LivePlan has no parameters
        return new JSPortletPreferences(new HashMap<String, String[]>(0), new HashSet<String>(0), "");
    }

    public JSPortletConfig getConfiguration() {
        return new JSPortletConfig(getName(), new HashMap<String, String>(0));
    }

    @Override
    public boolean getReportData(IScope scope) throws Exception {
        return true;
    }

    @Override
    protected void checkRequiredParameters(String reportPath, String width, String height) {
        // nothing to do
    }

}
