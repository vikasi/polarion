package com.polarion.wiki.integration;

import java.io.Writer;
import java.util.Map;

import org.radeox.api.engine.RenderEngine;
import org.radeox.api.engine.context.RenderContext;
import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.core.util.logging.Logger;
import com.polarion.wiki.integration.link.ILink;
import com.polarion.wiki.integration.link.UserLink;
import com.polarion.wiki.util.RequestParser;
import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.api.PUser;
import com.xpn.xwiki.render.XWikiRadeoxRenderEngine;

public class UserLinkMacro extends BaseLocaleMacro
{
    static Logger log = Logger.getLogger(UserLinkMacro.class);

    @Override
    public void execute(Writer writer, MacroParameter mp)
    {
        try {
            RenderContext context = mp.getContext();
            RenderEngine engine = context.getRenderEngine();
            XWikiContext xcontext = ((XWikiRadeoxRenderEngine) engine).getContext();

            Map requestParams = RequestParser.parseQuery(XWiki.getRequestURL(xcontext.getRequest()).toString(), xcontext);
            String currentProject = (String) requestParams.get("project");

            UserLink userLink = new UserLink(mp, xcontext);
            userLink.setProject(currentProject);

            if (userLink.getOutputType().equalsIgnoreCase(ILink.FIELD_OUTPUT_COUNT)) {
                PUser user = new PUser(userLink, xcontext, 0);
                writer.write(String.valueOf(user.getUserCount()));
                return;
            }

            writer.write(userLink.getHTML());

        } catch (Exception e) {
            log.error(e);
        }
    }

    @Override
    public String getLocaleKey() {
        return "macro.polarionuserlink";
    }

}
