package com.polarion.wiki.integration.utils;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import com.polarion.alm.projects.model.IProject;
import com.polarion.alm.projects.model.IUniqueObject;
import com.polarion.alm.projects.model.IUser;
import com.polarion.alm.projects.web.server.HatService;
import com.polarion.alm.projects.web.shared.JSHat;
import com.polarion.alm.server.ServerUiContext;
import com.polarion.alm.tracker.IModuleManager;
import com.polarion.alm.tracker.ITrackerService;
import com.polarion.alm.tracker.ModuleUtils;
import com.polarion.alm.tracker.internal.importer.ModulePageTool;
import com.polarion.alm.tracker.model.IModule;
import com.polarion.alm.tracker.model.IWikiPage;
import com.polarion.alm.tracker.model.IWorkItem;
import com.polarion.alm.tracker.model.IWorkflowObject;
import com.polarion.alm.tracker.web.internal.server.tree.TreeNode;
import com.polarion.alm.tracker.web.internal.shared.JSComment;
import com.polarion.alm.tracker.web.internal.shared.JSWorkItem;
import com.polarion.alm.tracker.web.internal.shared.JSWorkflowObject;
import com.polarion.alm.ui.shared.FieldRenderType;
import com.polarion.alm.wiki.WikiPlugin;
import com.polarion.core.util.EscapeChars;
import com.polarion.core.util.types.Text;
import com.polarion.platform.core.PlatformContext;
import com.polarion.platform.persistence.ICustomFieldsService;
import com.polarion.platform.persistence.model.IPObject;
import com.polarion.platform.security.ISecurityService;
import com.polarion.portal.internal.server.rpc.UICustomizationDataProvider;
import com.polarion.portal.internal.shared.navigation.BaselineHelper;
import com.polarion.portal.server.PObjectDataProvider;
import com.polarion.portal.shared.IJSUIObject;
import com.polarion.portal.shared.navigation.IPage;
import com.polarion.portal.shared.navigation.PortalService;
import com.polarion.reina.web.shared.JSSharedUtil;
import com.polarion.reina.web.shared.html.HTMLConst;
import com.polarion.reina.web.shared.html.IHTMLBuilder;
import com.polarion.reina.web.shared.localization.Localization;
import com.polarion.reina.web.shared.renderers.JSRendererFactory;
import com.polarion.subterra.base.data.identification.IContextId;
import com.polarion.subterra.base.data.identification.ILocalId;
import com.polarion.subterra.base.data.model.ICustomField;
import com.polarion.wiki.integration.IntegrationPlugin;
import com.polarion.wiki.integration.utils.MacroUtils.ExpandMode;
import com.polarion.wiki.integration.utils.MacroUtils.FieldProperty;
import com.polarion.wiki.integration.utils.MacroUtils.ShortLongDisplay;
import com.polarion.wiki.svn.ISvnProvider;
import com.polarion.wiki.util.Constants;
import com.polarion.wiki.web.BaselineServlet;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.doc.XWikiDocument;

public class MacroRenderer {

    static private MacroRenderer instance = null;
    private ISecurityService securityService;
    private ITrackerService trackerService;
    private MacroUtils utils;
    private ICustomFieldsService cfs;

    public abstract class BaseTableModel implements ItemTableModel {
        private final Map<String, FieldProperty> fields;

        public BaseTableModel(Map<String, FieldProperty> fields) {
            this.fields = fields;
        }

        protected Map<String, FieldProperty> getFields() {
            return fields;
        }

        @Override
        public boolean isColumnWidthSet() {
            return utils.isWidthOfFieldsSet(fields);
        }

        @Override
        public String getRowStyle(int rowIndex, boolean forPDF) {
            return ""; //$NON-NLS-1$
        }

        @Override
        public boolean isRowValid(int rowIndex) {
            return true;
        }

        @Override
        public String getInvalidRowContent(int rowIndex) {
            return null;
        }

        @Override
        public FieldProperty getFieldProperty(String columnId) {
            return fields.get(columnId);
        }

        @Override
        public List<String> getColumnIds() {
            return new ArrayList<String>(fields.keySet());
        }

        @Override
        public String getAdditionalCellStyle(int rowIndex, boolean isFirstCell, boolean forPDF) {
            return ""; //$NON-NLS-1$
        }

        @Override
        public void releaseRow(int rowIndex) {
        }
    }

    private static Map<String, FieldProperty> lowerCaseKeys(Map<String, FieldProperty> map) {
        Map<String, FieldProperty> result = new LinkedHashMap<String, MacroUtils.FieldProperty>();
        for (Entry<String, FieldProperty> entry : map.entrySet()) {
            result.put(entry.getKey().toLowerCase(), entry.getValue());
        }
        return result;
    }

    public class PageTableModel extends BaseTableModel {
        private static final String DEFAULT_SPACE = "_default"; //$NON-NLS-1$
        @SuppressWarnings("rawtypes")
        private final XWikiContext context;
        private final String title;
        private final List<?> col;
        private final int realSize;

        public PageTableModel(Map<String, FieldProperty> fields, @SuppressWarnings("rawtypes") XWikiContext context, String title, List<?> col, int realSize) {
            super(fields);
            this.context = context;
            this.title = title;
            this.col = col;
            this.realSize = realSize;
        }

        @Override
        public int getNumRows() {
            return col.size();
        }

        @Override
        public String getTitle(boolean forPdf) {
            return title;
        }

        @Override
        public String getFieldName(String columnId) {
            return Localization.keyExists("page.table.field." + columnId + ".label") ? //$NON-NLS-1$ //$NON-NLS-2$
                    Localization.getString("page.table.field." + columnId + ".label") //$NON-NLS-1$//$NON-NLS-2$
                    : context.getMessageTool().get(columnId.toLowerCase());
        }

        @Override
        public String getCellContent(int rowIndex, String columnId, boolean forPdf) {
            String content = ""; //$NON-NLS-1$

            Object rowElement = getRowElement(rowIndex);

            String key = columnId;

            if (rowElement instanceof XWikiDocument) {
                XWikiDocument doc = (XWikiDocument) rowElement;

                if ("name".equalsIgnoreCase(key)) { //$NON-NLS-1$
                    content = "<a title=\"" + getLinkTitle(doc) //$NON-NLS-1$
                            + "\" href=\"" + doc.getURL("view", context) + "\">" //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
                            + doc.getName() + "</a>"; //$NON-NLS-1$

                } else if ("project".equalsIgnoreCase(key)) { //$NON-NLS-1$

                    if (doc.getProject() == null || "".equals(doc.getProject())) { //$NON-NLS-1$
                        content = "<i>" + Constants.ROOT_REPO_LEVEL + "</i>"; //$NON-NLS-1$ //$NON-NLS-2$
                    } else {
                        content = doc.getProjectName();
                    }
                } else if ("space".equalsIgnoreCase(key)) { //$NON-NLS-1$

                    if (!DEFAULT_SPACE.equalsIgnoreCase(doc.getSpaceName())) {
                        content = doc.getSpaceName();
                    } else {
                        content = "<i>" + Localization.getString("definition.defaultSpace") + "</i>"; //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$
                    }
                } else if ("created".equalsIgnoreCase(key)) { //$NON-NLS-1$
                    Date creationDate = doc.getCreationDate();
                    content = formatDate(creationDate);
                } else if ("updated".equalsIgnoreCase(key)) { //$NON-NLS-1$
                    content = formatDate(doc.getContentUpdateDate());
                } else if ("createdby".equalsIgnoreCase(key)) { //$NON-NLS-1$
                    content = doc.getCreatorName();
                } else if ("updatedby".equalsIgnoreCase(key)) { //$NON-NLS-1$
                    content = doc.getAuthorName();
                }
            } else if ((rowElement instanceof IModule) || (rowElement instanceof IWikiPage)) {
                String projectId = ((IUniqueObject) rowElement).getProjectId();
                String projectName = (projectId != null) ? ((IUniqueObject) rowElement).getProject().getName() : ""; //$NON-NLS-1$
                String id = ((IUniqueObject) rowElement).getId();
                String space = (rowElement instanceof IModule) ? ((IModule) rowElement).getModuleFolder() : ((IWikiPage) rowElement).getSpaceId();
                if (space == null) {
                    space = DEFAULT_SPACE;
                }
                String spaceTitle = (rowElement instanceof IModule) ? ((IModule) rowElement).getFolder().getTitleOrName() : ((IWikiPage) rowElement).getFolder().getTitleOrName();
                Date updated = (rowElement instanceof IModule) ? ((IModule) rowElement).getUpdated() : ((IWikiPage) rowElement).getUpdated();
                Date created = (rowElement instanceof IModule) ? ((IModule) rowElement).getCreated() : ((IWikiPage) rowElement).getCreated();
                IUser updatedBy = (rowElement instanceof IModule) ? ((IModule) rowElement).getUpdatedBy() : ((IWikiPage) rowElement).getUpdatedBy();
                IUser author = (rowElement instanceof IModule) ? ((IModule) rowElement).getAuthor() : ((IWikiPage) rowElement).getAuthor();
                if ("name".equalsIgnoreCase(key)) { //$NON-NLS-1$
                    String name = (rowElement instanceof IModule) ? ((IModule) rowElement).getModuleName() : ((IWikiPage) rowElement).getPageName();
                    content = createPageLink(projectId, id, space, name);
                } else if ("title".equalsIgnoreCase(key)) { //$NON-NLS-1$
                    String titleOrName = (rowElement instanceof IModule) ? ((IModule) rowElement).getTitleOrName() : ((IWikiPage) rowElement).getTitleOrName();
                    content = createPageLink(projectId, id, space, titleOrName);
                    content += appendHome(id);
                } else if ("project".equalsIgnoreCase(key)) { //$NON-NLS-1$
                    content = projectName;
                } else if ("space".equalsIgnoreCase(key)) { //$NON-NLS-1$
                    if (DEFAULT_SPACE.equalsIgnoreCase(space)) {
                        content = "<i>" + escapeValue(spaceTitle) + "</i>"; //$NON-NLS-1$//$NON-NLS-2$
                    } else {
                        content = escapeValue(spaceTitle);
                    }
                } else if ("created".equalsIgnoreCase(key)) { //$NON-NLS-1$
                    content = formatDate(created);
                } else if ("updated".equalsIgnoreCase(key)) { //$NON-NLS-1$
                    content = formatDate(updated);
                } else if ("createdby".equalsIgnoreCase(key)) { //$NON-NLS-1$
                    content = getUserName(author);
                } else if ("updatedby".equalsIgnoreCase(key)) { //$NON-NLS-1$
                    content = getUserName(updatedBy);
                }
            }

            return content;
        }

        @NotNull
        private String createPageLink(String projectId, String id, String space, String text) {
            String hash = PortalService.getPortal().createProjectWikiUrlHash(projectId, space, id, BaselineServlet.getCurrentBaselineRevision(), null);
            hash = utils.escapeValue(hash);

            text = escapeValue(text);
            return "<a  target=\"_top\" title=\"" + text + "\" href=\"/polarion/#" + hash + "\">" + //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
                    text + "</a>"; //$NON-NLS-1$
        }

        private String formatDate(Date date) {
            return context.getWiki().formatDate(date, "yyyy-MM-dd HH:mm", context); //$NON-NLS-1$
        }

        protected Object getRowElement(int rowIndex) {
            return col.get(rowIndex);
        }

        @Override
        public String getAdditionalCellStyle(int rowIndex, boolean isFirstCell, boolean forPDF) {
            return ""; //$NON-NLS-1$
        }

        private String getLinkTitle(XWikiDocument doc) {
            return (!(doc.getProject()).equalsIgnoreCase(ISvnProvider.REPO_ROOT_AS_PROJECT_NAME) ? doc.getProjectName() : "") + "/" + doc.getSpaceName() + "." + doc.getName(); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
        }

        @Override
        public int getOriginalSize() {
            return realSize;
        }

        @Override
        public String getItemName() {
            return "page"; //$NON-NLS-1$
        }
    }

    public interface ItemTableModel {
        String getTitle(boolean forPdf);

        int getNumRows();

        int getOriginalSize();

        String getItemName();

        List<String> getColumnIds();

        FieldProperty getFieldProperty(String columnId);

        boolean isColumnWidthSet();

        boolean isRowValid(int rowIndex);

        String getCellContent(int rowIndex, String columnId, boolean forPdf);

        String getAdditionalCellStyle(int rowIndex, boolean isFirstCell, boolean forPDF);

        String getRowStyle(int rowIndex, boolean forPDF);

        void releaseRow(int rowIndex);

        String getInvalidRowContent(int rowIndex);

        String getFieldName(String columnId);
    }

    private MacroRenderer() {
        super();
        securityService = PlatformContext.getPlatform().lookupService(ISecurityService.class);
        trackerService = PlatformContext.getPlatform().lookupService(ITrackerService.class);
        cfs = PlatformContext.getPlatform().lookupService(ICustomFieldsService.class);
        utils = MacroUtils.getInstance();
    }

    public static MacroRenderer getInstance() {
        if (instance == null) {
            instance = new MacroRenderer();
        }
        return instance;
    }

    private boolean isTargetDLE(XWikiContext context) {
        return "1".equals(context.get(WikiPlugin.TARGET)); //$NON-NLS-1$
    }

    private String getTableStyle(boolean pdf) {
        if (pdf) {
            return "style=\"padding: 9px 14px 9px 4px; border-bottom: 1px solid #F0F0F0; width:100%;\" class=\"polarion-WorkItemsMacro-table\""; //$NON-NLS-1$
        } else {
            String compactUI = (String) UICustomizationDataProvider.getUserDataValue(IPage.COMPACT_UI);
            return "class=\"" + (IPage.YES.equals(compactUI) ? "itemsTableCompact" : "itemsTable") + "\""; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
        }
    }

    public String renderPanel(String uniqueId, String body, String footer, boolean expand, String width, String height, boolean forPdf, XWikiContext context) {
        IHTMLBuilder builder = createHtmlBuilder();
        if (forPdf) {
            builder.appendElementStart(HTMLConst.DIV, "panel", "margin:0px;padding:0px;width:" + (width == null ? "100%" : width) + ";", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

            //body
            builder.appendElementStart(HTMLConst.DIV, null, "width:100%;" + (expand ? "" : "display:none"), null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
            builder.appendHTML(body);
            builder.appendElementEnd(HTMLConst.DIV);

            //footer
            if (expand) {
                builder.appendHTML(footer);
            } else {
                builder.appendElementStart(HTMLConst.DIV, null, "background-color: #f8f8f8;border-bottom: 1px solid #d5d5d5;border-top: 1px solid #d5d5d5;", null); //$NON-NLS-1$
                builder.appendHTML(footer);
                builder.appendElementEnd(HTMLConst.DIV);
            }

            builder.appendHTML("<div class=\"cb\"></div>"); //$NON-NLS-1$
            builder.appendElementEnd(HTMLConst.DIV);
        } else {

            builder.appendHTML("<div class=\"workitemsTableDiv\">"); //$NON-NLS-1$
            builder.appendTable("0", "0", expand ? "workitemsTablePanel" : "workitemsTablePanelCollapsed", (width != null ? ("width:" + width + ";") : null)); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$

            String compare = (String) context.get("compareMode"); //$NON-NLS-1$

            //body
            if ((body != null) && !body.equals("")) { //$NON-NLS-1$
                builder.appendHTML(HTMLConst.HTML_TR);
                builder.appendHTML(HTMLConst.HTML_TD);
                String clazz = (expand) ? "expandedPanel" : "collapsedPanel"; //$NON-NLS-1$ //$NON-NLS-2$
                String style = ""; //$NON-NLS-1$
                if (height != null && height.trim().length() > 0) {
                    style += "overflow:auto;height:" + height + ";"; //$NON-NLS-1$ //$NON-NLS-2$
                }
                if (compare != null && compare.equalsIgnoreCase("1")) { //$NON-NLS-1$
                    builder.appendHTML("<div class=\"" + clazz + "\" style=\"" + style + "\">"); //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$
                } else {
                    builder.appendHTML("<div class=\"" + clazz + "\" style=\"" + style + "\" id='" + uniqueId + "'" + ">"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
                }

                builder.appendHTML(body);
                builder.appendHTML("</div>"); //$NON-NLS-1$
                builder.appendHTML(HTMLConst.HTML_ETD);
                builder.appendHTML(HTMLConst.HTML_ETR);
            }

            //footer
            if (footer != null) {
                builder.appendHTML(HTMLConst.HTML_TR);
                builder.appendElementStart(HTMLConst.TD, null, "vertical-align:middle;", null); //$NON-NLS-1$
                builder.appendHTML("<div class=\"panelFooter\" style=\"width:100%;\">"); //$NON-NLS-1$
                builder.appendHTML(footer);
                builder.appendHTML("</div>"); //$NON-NLS-1$
                builder.appendHTML(HTMLConst.HTML_ETD);
                builder.appendHTML(HTMLConst.HTML_ETR);
            }

            builder.appendHTML("</table>"); //$NON-NLS-1$
            builder.appendHTML("</div>"); //$NON-NLS-1$
        }

        return builder.toString();
    }

    public String renderFooter(String title, String uniqueId, String moreLink, String leftText, String rightText, int tableColumnsCount, boolean forPdf, boolean expand, String compare) {
        boolean hasRightText = (rightText != null);
        IHTMLBuilder builder = createHtmlBuilder();

        if (forPdf) {
            builder.appendHTML("<div style=\"color:#1D5696;width:100%;text-align:center;\">"); //$NON-NLS-1$
            if (moreLink != null) {
                builder.appendHyperlinkStart(moreLink, "_top", null, "color:#1D5696;"); //$NON-NLS-1$ //$NON-NLS-2$
            }
            builder.appendHTML(leftText);
            if (moreLink != null) {
                builder.appendElementEnd(HTMLConst.A);
            }
            if (hasRightText) {
                builder.appendHTML("&nbsp;"); //$NON-NLS-1$
                builder.appendHTML(rightText);
            }
            builder.appendHTML("</div>"); //$NON-NLS-1$
        } else {
            builder.appendElementStart(HTMLConst.TABLE, "panelFooter", null, null);//"border:1px solid #bed8e8;height: 12px;", "bordercolor=#bed8e8 border=\"1\"");  //$NON-NLS-1$
            builder.appendElementStart(HTMLConst.TR, null, null, null);

            builder.appendElementStart(HTMLConst.TD, null, "width:100%; text-align:center;vertical-align:middle;font-style: italic;", null); //$NON-NLS-1$
            builder.appendHTML("<span class=\"panelFooterLeftPart\">"); //$NON-NLS-1$
            if (moreLink != null) {
                builder.appendHyperlinkStart(moreLink, "_top", null, "color:#1D5696;"); //$NON-NLS-1$ //$NON-NLS-2$
            }
            builder.appendHTML(leftText);
            if (moreLink != null) {
                builder.appendElementEnd(HTMLConst.A);
            }
            builder.appendHTML("</span>"); //$NON-NLS-1$

            if (hasRightText) {
                builder.appendHTML("<span class=\"panelFooterRightPart\">"); //$NON-NLS-1$
                builder.appendHTML(rightText);
                builder.appendHTML("</span>"); //$NON-NLS-1$
            }

            String onclick = isCompareMode(compare) ? "" : "onclick=\"switchQueryContainerDivVisibility('" + uniqueId + "_info" + "');\""; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
            builder.appendHTML("<span " + onclick + " class=\"panelShowQueryIconPart\">"); //$NON-NLS-1$ //$NON-NLS-2$
            builder.appendImage("/polarion/ria/images/portlet/info.png", null, "cursor:pointer;vertical-align:baseline;", Localization.getString("macro.general.showQuery")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
            builder.appendHTML("</span>"); //$NON-NLS-1$
            builder.appendElementEnd(HTMLConst.TD);
            builder.appendElementStart(HTMLConst.TD, null, "cursor:pointer;", "valign=\"top\""); //$NON-NLS-1$ //$NON-NLS-2$

            //       appendExpandCollapseTable(uniqueId, builder, "expandTableContainer", Localization.getString("definition.expand"), "/polarion/ria/images/portlet/expand.png", !expand, isCompareMode(compare)); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
            appendExpandCollapseTable(uniqueId, builder, Localization.getString("definition.expand"), "/polarion/ria/images/portlet/expand.png", expand, isCompareMode(compare)); //$NON-NLS-1$ //$NON-NLS-2$

            builder.appendElementEnd(HTMLConst.TD);

            builder.appendElementEnd(HTMLConst.TR);

            builder.appendElementStart(HTMLConst.TR, null, null, null);
            builder.appendElementStart(HTMLConst.TD, null, "width:100%; text-align:center;vertical-align:middle;", null); //$NON-NLS-1$

            builder.appendHTML("<div style=\"display:none;\" id=\"" + uniqueId + "_info" + "\" class=\"queryContainerDivElement\">"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
            builder.appendText(title);
            builder.appendHTML("</div>"); //$NON-NLS-1$
            builder.appendElementEnd(HTMLConst.TD);
            builder.appendElementEnd(HTMLConst.TR);

            builder.appendElementEnd(HTMLConst.TABLE);
            //builder.appendHTML("<div class=\"cb\" />"); //$NON-NLS-1$
        }
        return builder.toString();
    }

    private boolean isCompareMode(String compare) {
        return compare != null && compare.equalsIgnoreCase("1"); //$NON-NLS-1$
    }

    private void appendExpandCollapseTable(String uniqueId, IHTMLBuilder builder, String label, String imgUrl, boolean visible, boolean isCompareMode) {
        String toggle = isCompareMode ? "" : "onclick=\"expandPanel('" + uniqueId + "');\""; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
        builder.appendHTML("<table " + toggle + " id=\"" + uniqueId + "_button" + "\" style=\"position:relative;margin-left:-80px;margin-top:0px;display:" + (visible ? "none" : "table") + "\" class=\"expandCollapseTable\">"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$
        builder.appendHTML(HTMLConst.HTML_TR);
        builder.appendElementStart(HTMLConst.TD, null, "vertical-align:bottom;padding-bottom:0px;", null); //$NON-NLS-1$
        builder.appendCellStart(null, null, null, "middle", null, null); //$NON-NLS-1$
        builder.appendHTML(label);
        builder.appendHTML(HTMLConst.HTML_ETD);
        builder.appendCellStart(null, null, null, "middle", null, null); //$NON-NLS-1$
        builder.appendImage(imgUrl, null, "margin-left:5px;margin-right:10px;vertical-align:middle;", null); //$NON-NLS-1$
        builder.appendHTML(HTMLConst.HTML_ETD);
        builder.appendHTML(HTMLConst.HTML_ETR);
        builder.appendElementEnd(HTMLConst.TABLE);
    }

    @SuppressWarnings("unchecked")
    public String getPanelFooterShowingText(int listSize, int originalSize, XWikiContext context, String typeText) {
        // don't write text there use context.getMessageTool()
        if (typeText == null) {
            typeText = "item"; //$NON-NLS-1$
        }
        if (originalSize == listSize) {
            if (listSize == 1) {
                return Localization.getString("form.modules.label.showSingle." + typeText); //$NON-NLS-1$
            }

            return Localization.getString("form.modules.label.showMulti." + typeText, "" + listSize); //$NON-NLS-1$ //$NON-NLS-2$
        }

        if (listSize == 1) {
            return Localization.getString("form.modules.label.showSingleOf." + typeText, "" + originalSize); //$NON-NLS-1$ //$NON-NLS-2$
        }

        return Localization.getString("form.modules.label.showMultiOf." + typeText, "" + listSize, "" + originalSize); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    }

    public String getMoreHtmlLink(String link) {
        link = link.replaceAll("\"", "&#34;"); //$NON-NLS-1$ //$NON-NLS-2$
        return "<span class=\"panelFooterMoreLink\"><a class=\"panelFooterMoreLink\" href=\"" + link + "\" target=\"_blank\">" + Localization.getString("form.modules.label.more") + "</a></span>"; //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$
    }

    public String getIconWithLink(String link, String imageUrl, String title) {
        link = link.replaceAll("\"", "&#34;"); //$NON-NLS-1$ //$NON-NLS-2$
        return "<a class=\"panelFooterMoreLink\" href=\"" + link + "\" target=\"_blank\"><img style=\"vertical-align:baseline;\" src=\"" + imageUrl + "\" title=\"" + title + "\"/></a>"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    }

    private String getTitle(String query, boolean forPdf) {
        String title;
        title = query;
        if (title.equals("")) { //$NON-NLS-1$
            title = Localization.getString("form.modules.label.showingAllItems"); //$NON-NLS-1$
        }
        return title;
    }

    public String getRenderedDocument(Map<String, FieldProperty> fields, String macroText, List<IPObject> pObjectList, List<TreeNode> pObjectTree, Set<IPObject> objectsLeftDueHierarchy, int originalListSize, String query, String moreLink, XWikiContext context, IContextId contextId, ExpandMode expandMode, String width, String height, boolean forPdf, boolean withLink, IModule module) {

        String title = getTitle(query, forPdf);

        String footerLeftText;
        if (pObjectTree == null) {
            footerLeftText = getPanelFooterShowingText(pObjectList.size(), originalListSize, context, null);
        } else {
            footerLeftText = getPanelFooterShowingText(pObjectList.size(), originalListSize, context, null);
        }

        IHTMLBuilder builder = createHtmlBuilder();
        int columnsCount = fields.keySet().size();
        if (!pObjectList.isEmpty()) {
            int numberOfColumns = 0;
            builder.appendHTML("<table " + getTableStyle(forPdf) + ">"); //$NON-NLS-1$ //$NON-NLS-2$

            List<String> descriptionFields = new LinkedList<String>();
            for (String fieldName : fields.keySet()) {
                FieldProperty property = fields.get(fieldName);
                if (property.renderType == FieldRenderType.TEXT_DESC || IWorkItem.KEY_COMMENTS.equals(fieldName)) {
                    columnsCount--;
                    descriptionFields.add(fieldName);
                }
            }

            //RENDER columns width
            boolean manualColumnWidth = forPdf || utils.isWidthOfFieldsSet(fields);
            if (manualColumnWidth) {
                int columnId = 0;
                Iterator<String> it = fields.keySet().iterator();
                while (it.hasNext()) {
                    String fieldName = it.next();
                    if (descriptionFields.contains(fieldName)) {
                        continue;
                    } else {
                        columnId++;
                    }
                    StringBuilder sb = new StringBuilder();

                    sb.append("<col style=\"width:"). //$NON-NLS-1$
                            append(fields.get(fieldName).width).append("%;column-width:"). //$NON-NLS-1$
                            append(fields.get(fieldName).width).append("%;column-number:"). //$NON-NLS-1$
                            append(columnId).append("\">"); //column-width and column-number are for PDF //$NON-NLS-1$

                    builder.appendHTML(sb.toString());
                }
            }

            //RENDER header
            builder.appendHTML("<thead>"); //$NON-NLS-1$
            builder.appendHTML("<tr>"); //$NON-NLS-1$

            List<String> normalFields = new ArrayList<String>(fields.keySet());
            normalFields.removeAll(descriptionFields);

            String style = "border-bottom: 1px solid #D2D7DA;color: #757575;font-weight: normal;height: 28px;text-align: left;padding: 0 4px;"; //$NON-NLS-1$

            for (Iterator<String> it = normalFields.iterator(); it.hasNext();) {
                String fieldId = it.next();
                String fieldName = getFieldTitle(fieldId, pObjectList, fields);

                if (IWorkItem.KEY_TITLE.equalsIgnoreCase(fieldId)) {
                    StringBuilder sb = new StringBuilder();
                    for (String fid : descriptionFields) {
                        sb.append(" / ").append(JSSharedUtil.getFieldLabel(fid)).append(" "); //$NON-NLS-1$ //$NON-NLS-2$
                    }
                    fieldName = fieldName + sb.toString();
                }
                String colspan = ""; //$NON-NLS-1$
                if (forPdf && (normalFields.size() == 1) && !it.hasNext()) {
                    colspan = " colspan=\"2\""; //$NON-NLS-1$
                }
                builder.appendHTML("<th" + colspan + " class=\"" + (it.hasNext() ? "" : "last") + "\" style=\"" + ((forPdf ? style : "") + (!manualColumnWidth && IWorkItem.KEY_TITLE.equalsIgnoreCase(fieldId) ? "width:100%;" : "")) + "\">"); //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$
                builder.appendHTML(fieldName);
                builder.appendHTML("</th>"); //$NON-NLS-1$
                numberOfColumns++;
            }
            builder.appendHTML("</tr>"); //$NON-NLS-1$
            builder.appendHTML("</thead>"); //$NON-NLS-1$

            builder.appendHTML("<tbody>"); //$NON-NLS-1$
            if (pObjectTree == null) {
                builder.appendHTML(renderUnstructuredDocument(fields, pObjectList, numberOfColumns, context, contextId, forPdf, withLink, macroText, module));
            } else {
                builder.appendHTML(renderStructuredDocument(fields, pObjectTree, objectsLeftDueHierarchy, macroText, numberOfColumns, context, contextId, forPdf, withLink, module));
            }
            builder.appendHTML("</tbody>"); //$NON-NLS-1$
            builder.appendHTML("</table>"); //$NON-NLS-1$
        }
        String uniqueId = IntegrationPlugin.getUniqName();
        String compare = (String) context.get("compareMode"); //$NON-NLS-1$
        String footer = renderFooter(title, uniqueId, moreLink, footerLeftText,
                (moreLink != null) ? getIconWithLink(moreLink, getOpenInTableIcon(), Localization.getString("macro.general.openInTable")) : null, Math.max(columnsCount, 2), forPdf, expandMode.getValue(), compare); //$NON-NLS-1$
        return renderPanel(uniqueId, builder.toString(), footer, expandMode.getValue(), width, height, forPdf, context);
    }

    private String renderStructuredDocument(final Map<String, FieldProperty> fields, final List<TreeNode> pObjectTree, final Set<IPObject> objectsLeftDueHierarchy, final String macroText, final int numberOfColumns, final XWikiContext context, final IContextId contextId, final boolean forPdf, final boolean withLink, final IModule module) {
        final StringBuilder sb = new StringBuilder();
        for (TreeNode node : pObjectTree) {
            node.accept(new TreeNode.IVisitor() {
                @Override
                public boolean visit(TreeNode node, int depth) {
                    List<String> fieldsList = new ArrayList<String>();
                    fieldsList.addAll(fields.keySet());
                    IJSUIObject jObject = transformInstance(node.getObject(), fieldsList);

                    final Map<String, String> fieldValueMap = getRenderedValues(fields, node.getObject(), jObject, contextId, withLink, context);
                    boolean dueHierarchy = (objectsLeftDueHierarchy != null) ? (objectsLeftDueHierarchy.contains(node.getObject())) : false;
                    sb.append(renderFieldsInDocument(node.getObject(), module, fields, fieldValueMap, numberOfColumns, context, contextId, forPdf, depth, withLink, dueHierarchy, macroText));
                    return true;
                }
            });
        }
        return sb.toString();
    }

    private String renderUnstructuredDocument(Map<String, FieldProperty> fields, List<IPObject> pObjectList, int numberOfColumns, XWikiContext context, IContextId contextId, boolean forPdf, final boolean withLink, String macroText, final IModule module) {
        StringBuilder sb = new StringBuilder();
        for (IPObject pObject : pObjectList) {
            List<String> fieldsList = new ArrayList<String>();
            fieldsList.addAll(fields.keySet());
            IJSUIObject jObject = transformInstance(pObject, fieldsList);

            Map<String, String> fieldValueMap = getRenderedValues(fields, pObject, jObject, contextId, withLink, null);
            sb.append(renderFieldsInDocument(pObject, module, fields, fieldValueMap, numberOfColumns, context, contextId, forPdf, -1, withLink, false, macroText));
        }
        return sb.toString();
    }

    private String renderFieldsInDocument(IPObject o, IModule module, Map<String, FieldProperty> fields, Map<String, String> fieldValueMap, int numberOfColumns, XWikiContext context, IContextId contextId, boolean forPdf, int depth, boolean withLink, boolean dueHierarchy, String macroText) {
        IHTMLBuilder builder = createHtmlBuilder();

        String cellStyle = "padding:5px;"; //$NON-NLS-1$
        String pdf_td_style = "padding: 9px 14px 9px 4px;border-bottom: 1px solid #F0F0F0;background: #fff;"; //$NON-NLS-1$
        String pdf_fst_td_style = "padding: 9px 14px 9px 4px;border-bottom: 1px solid #F0F0F0;background: #fff;"; //$NON-NLS-1$

        if (fieldValueMap == null) {
            //object is unresolvable
            builder.appendHTML("<tr>"); //$NON-NLS-1$
            builder.appendHTML("<td valign=\"top\" class=\"" + (forPdf ? "pdf_td_style" : "") + "\" colspan=\"" + (numberOfColumns - 1) + "\">"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
            builder.appendHTML(utils.format(o));
            builder.appendHTML("</td>"); //$NON-NLS-1$
            builder.appendHTML("</tr>"); //$NON-NLS-1$
            return builder.toString();
        }
        String polarionServer = utils.getPolarionServerURL(context);
        int fontSize = (21 - depth * 2) <= 6 ? 6 : 21 - depth * 2;
        if (depth == -1) {
            fontSize = 17;
        }

        if (forPdf) {
            fontSize -= 2;
        }

        int treeLeftPadding = depth * 16;
        if (depth == -1) {
            treeLeftPadding = 0;
        }
        treeLeftPadding += 2;

        List<String> descriptionFields = new LinkedList<String>();
        for (String fieldName : fields.keySet()) {
            FieldProperty property = fields.get(fieldName);
            boolean isDescriptionField = false;
            if (property.renderType == FieldRenderType.TEXT_DESC) {
                String value = fieldValueMap.get(fieldName);
                if (value != null && value.trim().length() > 0) {
                    isDescriptionField = true;
                }

            }
            if (IWorkItem.KEY_COMMENTS.equals(fieldName)) {
                String value = fieldValueMap.get(fieldName);
                if (value != null && value.trim().length() > 0) {
                    isDescriptionField = true;
                }
            }
            if (isDescriptionField) {
                descriptionFields.add(fieldName);
            }
        }

        boolean idHandled = false;
        boolean titleHandled = false;
        if (fields.containsKey(IUniqueObject.KEY_ID) && fields.containsKey(IWorkItem.KEY_TITLE) && forPdf) {

            idHandled = true;
            titleHandled = true;
            String value = ""; //$NON-NLS-1$
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("<tr style=\""); //$NON-NLS-1$
            stringBuilder.append((dueHierarchy ? (forPdf ? "color:#cacaca;" : "filter:alpha(opacity=30);opacity:0.3;") : "")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
            stringBuilder.append("\">"); //$NON-NLS-1$
            builder.appendHTML(stringBuilder.toString());
            builder.appendHTML("<td valign=\"top\" style=\"" + (forPdf ? pdf_fst_td_style : cellStyle) + "\" " + "rowspan=" + (descriptionFields.size() + (numberOfColumns <= 2 ? 1 : 2)) + ">"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
            value = fieldValueMap.get(IUniqueObject.KEY_ID);
            value = getLink4MacroObject(o, macroText, ShortLongDisplay.SHORT, value, polarionServer, forPdf, null, null, "_top", withLink, context); //$NON-NLS-1$

            if (forPdf) {
                value = value.replaceAll("src=\"/polarion/", "src=\"" + polarionServer + "polarion/"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
            } else {
                value = value.replaceAll("href=\"#/", "href=\"" + polarionServer + "polarion/#/"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
            }
            builder.appendHTML(utils.escapeValue(value));
            builder.appendHTML("</td>"); //$NON-NLS-1$

            String padding = "padding-left:" + treeLeftPadding + "px;"; //$NON-NLS-1$ //$NON-NLS-2$

            builder.appendHTML("<td valign=\"top\" class=\"last\" style=\"" + padding + (forPdf ? pdf_td_style : cellStyle) + "\" " + "colspan=" + (numberOfColumns - 1) + ">"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

            value = fieldValueMap.get(IWorkItem.KEY_TITLE);
            value = "<div style=\"font-weight: bold;line-height: 1.1em; font-size: " + fontSize + "px; \">" + value + "</div>"; //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$

            if (forPdf) {
                value = value.replaceAll("src=\"/polarion/", "src=\"" + polarionServer + "polarion/"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
            } else {
                value = value.replaceAll("href=\"#/", "href=\"" + polarionServer + "polarion/#/"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
            }
            builder.appendHTML(utils.escapeValue(value));
            builder.appendHTML("</td></tr>"); //$NON-NLS-1$

        }

        boolean fst = true;
        boolean rowTagAdded = false;
        Iterator<String> it = fields.keySet().iterator();
        boolean idFound = false;
        int columnIdx = -1;
        while (it.hasNext()) {
            String fieldName = it.next();
            FieldProperty property = fields.get(fieldName);
            if (property.renderType == FieldRenderType.TEXT_DESC) {
                continue;
            }
            if (fieldName.equals(IUniqueObject.KEY_ID) && idHandled) {
                continue;
            }
            if (fieldName.equals(IWorkItem.KEY_TITLE) && titleHandled && numberOfColumns <= 2) {
                continue;
            }
            if (fieldName.equals(IWorkItem.KEY_COMMENTS)) {
                continue;
            }
            columnIdx++;

            if (!rowTagAdded) {
                builder.appendHTML("<tr style=\"" + (dueHierarchy ? (forPdf ? "color:#cacaca;" : "filter:alpha(opacity=30);opacity:0.3;") : "") + "\">"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
                rowTagAdded = true;
            }

            String value = fieldValueMap.get(fieldName);
            if (value != null) {
                value = value.trim();
            }
            String indent = (IWorkItem.KEY_TITLE.equalsIgnoreCase(fieldName)) ? "padding-left:" + treeLeftPadding + "px;" : ""; //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$

            //  if(forPdf){
            if (fst) {
                cellStyle = forPdf ? pdf_fst_td_style + indent : cellStyle + indent;
                fst = false;
            } else {
                cellStyle = forPdf ? pdf_td_style + indent : cellStyle + indent;
            }

            if (fieldName.equals(IUniqueObject.KEY_ID)) {
                cellStyle += "white-space:nowrap;"; //$NON-NLS-1$
            }

            // }
            String fName = null;
            if (property.props != null) {
                fName = property.props.get(IUniqueObject.KEY_ID);
                if (fName == null) {
                    fName = IUniqueObject.KEY_ID;
                }
                idFound = true;
            }

            boolean lastColumn = (columnIdx == numberOfColumns - 1);
            String colspanParam = getColspan(lastColumn && (numberOfColumns < 2) ? 2 : 1);

            builder.appendHTML("<td" + colspanParam + " valign=\"top\" class=\"" + (it.hasNext() ? "" : "last") + "\" style=\"" + cellStyle + "\" " //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$//$NON-NLS-4$//$NON-NLS-5$//$NON-NLS-6$
                    + (fName != null && fName.equalsIgnoreCase(fieldName) ? "rowspan=" + (descriptionFields.size() + 1) : "") + ">"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

            if (fName != null && fName.equalsIgnoreCase(fieldName)) {
                value = getLink4MacroObject(o, macroText, ShortLongDisplay.SHORT, value, polarionServer, forPdf, null, null, "_top", withLink, context); //$NON-NLS-1$
            }
            if (IWorkItem.KEY_TITLE.equalsIgnoreCase(fieldName)) {
                if (idFound) {
                    value = "<div style=\"font-weight: bold;line-height: 1.1em; font-size: " + fontSize + "px;\">" + value + "</div>"; //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
                } else {
                    value = getModuleLink(o, module, context, macroText, fontSize);
                }
            }
            if (forPdf) {
                value = value.replaceAll("src=\"/polarion/", "src=\"" + polarionServer + "polarion/"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
            } else {
                value = value.replaceAll("href=\"#/", "href=\"" + polarionServer + "polarion/#/"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
            }
            if (fieldName.equals(IWorkItem.KEY_TITLE)) {
                if (!titleHandled) {
                    builder.appendHTML(utils.escapeValue(value));
                }
            } else {
                builder.appendHTML("".equals(value) ? "&nbsp;" : utils.escapeValue(value)); //$NON-NLS-1$ //$NON-NLS-2$
            }
            builder.appendHTML("</td>"); //$NON-NLS-1$
        }
        if (rowTagAdded) {
            builder.appendHTML("</tr>"); //$NON-NLS-1$
        }

        boolean commentsRemoved = descriptionFields.remove(IWorkItem.KEY_COMMENTS);
        for (String descriptionField : descriptionFields) {
            String value = fieldValueMap.get(descriptionField);
            if (value != null && value.trim().length() > 0) {
                value = value.trim();

                builder.appendHTML("<tr style=\"" + (dueHierarchy ? (forPdf ? "color:#cacaca;" : "filter:alpha(opacity=30);opacity:0.3;") : "") + "\">"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$

                int colspan = (idFound || idHandled ? numberOfColumns - 1 : numberOfColumns);
                String colspanParam = getColspan(Math.max(colspan, 2));
                builder.appendHTML("<td valign=\"top\" class=\"last\" style=\"" //$NON-NLS-1$
                        + ((forPdf ? (idFound ? pdf_td_style : pdf_fst_td_style) : "") + ("".equals(value) ? " height:" + (forPdf ? 10 : 30) + "px;" : "") + "padding-left:" + treeLeftPadding + "px;") + "\"" + colspanParam + ">"); //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$
                builder.appendHTML(utils.escapeValue(value));
                builder.appendHTML("</td>"); //$NON-NLS-1$

                builder.appendHTML("</tr>"); //$NON-NLS-1$
            }
        }
        if (commentsRemoved) {
            String value = fieldValueMap.get(IWorkItem.KEY_COMMENTS);
            if (value != null && value.trim().length() > 0) {
                value = value.trim();

                builder.appendHTML("<tr style=\"" + (dueHierarchy ? (forPdf ? "color:#cacaca;" : "filter:alpha(opacity=30);opacity:0.3;") : "") + "\">"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
                builder.appendHTML("<td valign=\"top\" class=\"last\" style=\"" //$NON-NLS-1$
                        + ((forPdf ? (idFound ? pdf_td_style : pdf_fst_td_style) : "") + ("".equals(value) ? " height:" + (forPdf ? 10 : 30) + "px;" : "") + "padding-left:" + treeLeftPadding + "px;") + "\" colspan=" //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$//$NON-NLS-4$//$NON-NLS-5$//$NON-NLS-6$//$NON-NLS-7$//$NON-NLS-8$
                        + (idFound || idHandled ? numberOfColumns - 1 : numberOfColumns) + ">"); //$NON-NLS-1$
                builder.appendHTML(utils.escapeValue(value));
                builder.appendHTML("</td>"); //$NON-NLS-1$
                builder.appendHTML("</tr>"); //$NON-NLS-1$
            }
        }

        if (o != null) {
            o.forget();
        }
        return builder.toString();
    }

    private String getColspan(int colspan) {
        return (colspan > 1) ? " colspan=\"" + colspan + "\"" : ""; //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
    }

    private class PObjectTableModel extends BaseTableModel {
        private final IContextId contextId;
        private final String query;
        private final int originalListSize;
        private final String macroText;
        private final XWikiContext context;
        private final boolean withLink;
        protected List<IPObject> objects;
        private Map<Integer, Map<String, String>> fieldValueCache = new HashMap<Integer, Map<String, String>>();
        private boolean isHierarchic;

        private PObjectTableModel(Map<String, FieldProperty> fields, IContextId contextId, String query, int originalListSize, String macroText, XWikiContext context, boolean withLink, List<IPObject> pObjectList) {
            super(fields);
            this.contextId = contextId;
            this.query = query;
            this.originalListSize = originalListSize;
            this.macroText = macroText;
            this.context = context;
            this.withLink = withLink;
            objects = pObjectList;

        }

        @Override
        public String getTitle(boolean forPdf) {
            return MacroRenderer.this.getTitle(query, forPdf);
        }

        @Override
        public int getNumRows() {
            return objects.size();
        }

        @Override
        public boolean isRowValid(int rowNumber) {
            return !objects.get(rowNumber).isUnresolvable();
        }

        @Override
        public String getCellContent(int rowIndex, String columnId, boolean forPdf) {
            Map<String, String> fieldValueMap = fieldValueCache.get(rowIndex);
            if (fieldValueMap == null) {
                IPObject object = objects.get(rowIndex);
                IJSUIObject jObject = transformInstance(object, getColumnIds());
                fieldValueMap = getRenderedValues(
                        getFields(), object, jObject, contextId, withLink, null);
            }
            String value = fieldValueMap.get(columnId);

            String fName = null;
            FieldProperty property = getFieldProperty(columnId);
            if (property.props != null) {
                fName = property.props.get(IUniqueObject.KEY_ID);
            }

            if (fName != null && fName.equalsIgnoreCase(columnId)) {
                String polarionServer = utils.getPolarionServerURL(context);
                IPObject object = objects.get(rowIndex);
                value = getLink4MacroObject(object, macroText,
                        ShortLongDisplay.SHORT, value, polarionServer, forPdf,
                        null, null, (isHierarchic ? "_top" : null), //$NON-NLS-1$
                        withLink, context);
            }

            return value;
        }

        @Override
        public void releaseRow(int rowIndex) {
            fieldValueCache.remove(rowIndex);
            IPObject object = objects.get(rowIndex);
            object.forget();
        }

        @Override
        public String getInvalidRowContent(int rowIndex) {
            return utils.format(objects.get(rowIndex));
        }

        @Override
        public String getFieldName(String columnId) {
            String name = null;
            for (IPObject pObject : objects) {
                if (pObject.isUnresolvable()) {
                    continue;
                }
                ICustomField customField = cfs.getCustomField(pObject, columnId);
                String cfn = customField.getName();
                if ((cfn != null) && (cfn.length() > 0)) {
                    name = cfn;
                    break;
                }
            }
            if (name != null) {
                return name;
            } else {
                return JSSharedUtil.getFieldLabel("WorkItem", columnId); //$NON-NLS-1$
            }
        }

        @Override
        public int getOriginalSize() {
            return originalListSize;
        }

        @Override
        public String getItemName() {
            return null;
        }
    }

    private class HierarchicPObjectTableModel extends PObjectTableModel {

        private List<Integer> depthList;
        private final Set<IPObject> objectsLeftDueHierarchy;

        public HierarchicPObjectTableModel(Map<String, FieldProperty> fields, IContextId contextId, final List<TreeNode> pObjectTree, String query, int originalListSize, Set<IPObject> objectsLeftDueHierarchy, String macroText, XWikiContext context, boolean withLink) {
            super(fields, contextId, query, originalListSize,
                    macroText, context, withLink, null);

            this.objectsLeftDueHierarchy = objectsLeftDueHierarchy;

            depthList = new ArrayList<Integer>();
            objects = new ArrayList<IPObject>();
            for (TreeNode node : pObjectTree) {
                node.accept(new TreeNode.IVisitor() {
                    @Override
                    public boolean visit(TreeNode node, int depth) {
                        depthList.add(depth);
                        objects.add(node.getObject());
                        return true;
                    }
                });
            }
        }

        @Override
        public String getAdditionalCellStyle(int rowIndex, boolean isFirstCell, boolean forPDF) {

            boolean isIdColumn = IUniqueObject.KEY_ID.equals(getColumnIds().get(0));
            int depth = depthList == null ? 0 : depthList.get(rowIndex);

            if (isFirstCell && isIdColumn && depth != 0) {
                return "padding-left:" + (depth * 16) + "px;"; //$NON-NLS-1$ //$NON-NLS-2$
            } else {
                return ""; //$NON-NLS-1$
            }
        }

        @Override
        public String getRowStyle(int cellIndex, boolean forPDF) {
            IPObject item = objects.get(cellIndex);
            boolean isLeftDueHierarchy = objectsLeftDueHierarchy != null && objectsLeftDueHierarchy.contains(item);
            return isLeftDueHierarchy ? (forPDF ? "color:#cacaca;" : "filter:alpha(opacity=30);opacity:0.3;") //$NON-NLS-1$ //$NON-NLS-2$
                    : ""; //$NON-NLS-1$
        }

    }

    public String renderFlatTable(final Map<String, FieldProperty> fields, final String macroText, final List<IPObject> pObjectList, final int originalListSize, final String query, final String moreLink, final XWikiContext context, final IContextId contextId, ExpandMode expandMode, String width, String height, final boolean forPdf, final boolean withLink) {

        ItemTableModel model = new PObjectTableModel(fields, contextId, query, originalListSize,
                macroText, context, withLink, pObjectList);

        return renderTable(moreLink, context, expandMode, width, height,
                forPdf, model);

    }

    public String renderHierarchicTable(final Map<String, FieldProperty> fields, final String macroText, final List<TreeNode> pObjectTree, final Set<IPObject> objectsLeftDueHierarchy, final int originalListSize, final String query, final String moreLink, final XWikiContext context, final IContextId contextId, ExpandMode expandMode, String width, String height, final boolean forPdf, final boolean withLink) {

        ItemTableModel model = new HierarchicPObjectTableModel(fields, contextId, pObjectTree, query,
                originalListSize, objectsLeftDueHierarchy, macroText, context,
                withLink);

        return renderTable(moreLink, context, expandMode, width, height,
                forPdf, model);

    }

    public String renderTable(final String moreLink, final XWikiContext context, ExpandMode expandMode, String width, String height, boolean forPdf, ItemTableModel model) {

        StringBuilder sb = new StringBuilder();
        if (model.getColumnIds().size() > 0) {

            sb.append("<table " + getTableStyle(forPdf) + ">"); //$NON-NLS-1$ //$NON-NLS-2$

            {

                // RENDER columns width
                boolean manualColumnWidth = model.isColumnWidthSet();

                if (manualColumnWidth) {
                    sb.append("<colgroup>"); //$NON-NLS-1$

                    int columnNumber = 0;
                    for (String fieldId : model.getColumnIds()) {
                        columnNumber++;

                        FieldProperty fieldProperty = model.getFieldProperty(fieldId);
                        int colWidth = fieldProperty.width;

                        sb.append("<col style=\"width:").append(colWidth) //$NON-NLS-1$
                                .append("%;column-width:").append(colWidth) //$NON-NLS-1$
                                .append("%;column-number:") //$NON-NLS-1$
                                .append(columnNumber).append("\">\n"); //$NON-NLS-1$
                        // column-width and column-number are for PDF
                        // XXX Do we really need these properties?
                    }
                    sb.append("</colgroup>\n"); //$NON-NLS-1$
                }
                sb.append("<thead>\n"); //$NON-NLS-1$
                sb.append("<tr>\n"); //$NON-NLS-1$

                boolean first = true;
                for (Iterator<String> it2 = model.getColumnIds().iterator(); it2
                        .hasNext();) {

                    String fieldId = it2.next();

                    sb.append("<th " //$NON-NLS-1$
                            + (forPdf && (model.getColumnIds().size() == 1) ? " colspan=\"2\"" : "") //$NON-NLS-1$ //$NON-NLS-2$
                            + (forPdf ? " style=\"border-bottom: 1px solid #D2D7DA;color: #757575;font-weight: normal;height: 28px;text-align: left;padding: 0 4px;\"" : "") //$NON-NLS-1$ //$NON-NLS-2$
                            + ((it2.hasNext()) ? "" : " class=\"last\"") //$NON-NLS-1$//$NON-NLS-2$
                            + ">" //$NON-NLS-1$
                            + EscapeChars.forHTMLTag(model.getFieldName(fieldId)) + "</th>\n"); //$NON-NLS-1$
                    first = false;
                }
                sb.append("</tr>\n"); //$NON-NLS-1$
                sb.append("</thead>\n"); //$NON-NLS-1$

                sb.append("<tbody>"); //$NON-NLS-1$
                for (int rowIndex = 0; rowIndex < model.getNumRows(); rowIndex++) {
                    appendTableRow(model, rowIndex, forPdf, context, sb);
                }
                sb.append("</tbody>"); //$NON-NLS-1$

            }

            sb.append("</table>"); //$NON-NLS-1$
        }

        String footerLeftText = getPanelFooterShowingText(
                model.getNumRows(), model.getOriginalSize(), context, model.getItemName());

        String uniqueId = IntegrationPlugin.getUniqName();
        String compare = (String) context.get("compareMode"); //$NON-NLS-1$
        String footer = renderFooter(model.getTitle(forPdf), uniqueId, moreLink, footerLeftText,
                (moreLink != null) ? getIconWithLink(moreLink, getOpenInTableIcon(), Localization.getString("macro.general.openInTable")) : null, //$NON-NLS-1$
                        model.getColumnIds().size(), forPdf, expandMode.getValue(), compare);
        return renderPanel(uniqueId, sb.toString(), footer, expandMode.getValue(),
                width, height, forPdf, context);
    }

    private String getOpenInTableIcon() {
        return "/polarion/ria/images/portlet/portletOpenInTable.png"; //$NON-NLS-1$
    }

    private String appendTableRow(ItemTableModel tableModel, int rowIndex, boolean forPdf, XWikiContext context, StringBuilder sb) {

        if (!tableModel.isRowValid(rowIndex)) {
            int colspan = tableModel.getColumnIds().size();
            if (forPdf && (tableModel.getColumnIds().size() == 1)) {
                colspan = 2;
            }
            sb.append("<tr>"); //$NON-NLS-1$
            sb.append("<td valign=\"top\" colspan=" + colspan + "\">"); //$NON-NLS-1$ //$NON-NLS-2$
            sb.append(tableModel.getInvalidRowContent(rowIndex));
            sb.append("</td>"); //$NON-NLS-1$
            sb.append("</tr>"); //$NON-NLS-1$

            return sb.toString();
        }

        String polarionServer = utils.getPolarionServerURL(context);

        sb.append("<tr style=\"" + tableModel.getRowStyle(rowIndex, forPdf) + "\">"); //$NON-NLS-1$ //$NON-NLS-2$

        boolean isFirstCell = true;
        int colspanLastCell = forPdf && (tableModel.getColumnIds().size() == 1) ? 2 : 1;
        for (Iterator<String> iter = tableModel.getColumnIds().iterator(); iter.hasNext();) {
            String fieldId = iter.next();
            String value = tableModel.getCellContent(rowIndex, fieldId, forPdf);
            value = value.replaceAll("ref=\"#/", "ref=\"" + polarionServer + "polarion/#/"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

            String compare = (String) context.get("compareMode"); //$NON-NLS-1$
            if ("1".equalsIgnoreCase(compare) && value != null) { //$NON-NLS-1$
                value = value.trim();
            }

            String style = tableModel.getAdditionalCellStyle(rowIndex, isFirstCell, forPdf);

            boolean addNoWrap = JSWorkflowObject.KEY_TYPE.equals(fieldId) || JSWorkItem.KEY_ID.equals(fieldId) ||
                    JSWorkItem.KEY_SEVERITY.equals(fieldId) || JSWorkItem.KEY_PRIORITY.equals(fieldId) ||
                    JSWorkItem.KEY_UPDATED.equals(fieldId) || JSWorkItem.KEY_CREATED.equals(fieldId);
            if (addNoWrap) {
                style += "white-space:nowrap;"; //$NON-NLS-1$
            }

            if (forPdf) {
                style += "padding: 9px 14px 9px 4px;border-bottom: 1px solid #F0F0F0;background: #fff;"; //$NON-NLS-1$
            }

            boolean isLastCell = !iter.hasNext();
            sb.append("<td valign=\"top\" style=\"" + style + "\"" + (isLastCell && (colspanLastCell > 1) ? " colspan=\"" + colspanLastCell + "\"" : "") + ">"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
            sb.append(utils.escapeValue(value));
            sb.append("</td>"); //$NON-NLS-1$

            isFirstCell = false;
        }
        sb.append("</tr>"); //$NON-NLS-1$

        tableModel.releaseRow(rowIndex);

        return sb.toString();
    }

    public String getRenderedCount(int number, boolean forPdf, String moreLink) {
        StringBuilder sb = new StringBuilder();

        sb.append("<span>"); //$NON-NLS-1$
        if (moreLink != null) {
            sb.append("<a class='graylinks' target='_top' href='"); //$NON-NLS-1$
            sb.append(moreLink);
            sb.append("'>"); //$NON-NLS-1$

            sb.append(number);

            sb.append("</a>"); //$NON-NLS-1$
        } else {
            sb.append(number);
        }

        sb.append("</span>"); //$NON-NLS-1$

        return sb.toString();
    }

    public static IJSUIObject transformInstance(IPObject o, List<String> fieldsList) {
        if (fieldsList == null) {
            fieldsList = new ArrayList<String>();
        }
        if (o instanceof IWorkItem) {
            if (!fieldsList.contains(IUniqueObject.KEY_ID)) {
                fieldsList.add(IUniqueObject.KEY_ID);
            }
            if (!fieldsList.contains(IWorkflowObject.KEY_TYPE)) {
                fieldsList.add(IWorkflowObject.KEY_TYPE);
            }
            if (!fieldsList.contains(IWorkItem.KEY_TITLE)) {
                fieldsList.add(IWorkItem.KEY_TITLE);
            }
            if (!fieldsList.contains(IWorkItem.KEY_RESOLUTION)) {
                fieldsList.add(IWorkItem.KEY_RESOLUTION);
            }
            if (!fieldsList.contains(IWorkItem.KEY_SEVERITY)) {
                fieldsList.add(IWorkItem.KEY_SEVERITY);
            }
            if (!fieldsList.contains(IUniqueObject.KEY_PROJECT)) {
                fieldsList.add(IUniqueObject.KEY_PROJECT);
            }
        } else if (o instanceof IUser) {
            if (!fieldsList.contains(IUser.KEY_ID)) {
                fieldsList.add(IUser.KEY_ID);
            }
            if (!fieldsList.contains(IUser.KEY_NAME)) {
                fieldsList.add(IUser.KEY_NAME);
            }
            fieldsList.remove("roles"); //$NON-NLS-1$
        } else if (o instanceof IProject) {
            if (!fieldsList.contains(IProject.KEY_ID)) {
                fieldsList.add(IProject.KEY_ID);
            }
            if (!fieldsList.contains(IProject.KEY_NAME)) {
                fieldsList.add(IProject.KEY_NAME);
            }
        }

        return PObjectDataProvider.transformInstance(o, fieldsList, false, null, null, true, false, null);
    }

    @SuppressWarnings("unchecked")
    public Map<String, String> renderWorkItemFields(Map<String, FieldProperty> fieldsMap, IWorkItem pObject, IJSUIObject jObject, boolean withLink, XWikiContext wikiContext) {
        Map<String, String> result = new HashMap<String, String>();

        if (pObject.isUnresolvable()) {
            for (String fieldName : fieldsMap.keySet()) {
                result.put(fieldName, ""); //$NON-NLS-1$
            }
            pObject.forget();
            return result;
        }

        for (String fieldName : fieldsMap.keySet()) {
            Object fieldValue = null;
            FieldRenderType fieldType = fieldsMap.get(fieldName).renderType;
            fieldValue = jObject.getValue(fieldName);

            if ((fieldValue == null) || ((fieldValue instanceof Collection) && ((Collection) fieldValue).isEmpty())) {
                result.put(fieldName, ""); //$NON-NLS-1$
                continue;
            } else if (fieldValue instanceof Collection) {
                if (((Collection) fieldValue).toArray()[0] instanceof JSComment) {
                    Iterator comments = ((Collection) fieldValue).iterator();
                    List hats = HatService.getHatsAvailableToCurrentUser(pObject.getContextId());
                    List<JSComment> comments2remove = new ArrayList();

                    while (comments.hasNext()) {
                        JSComment comment = (JSComment) comments.next();
                        List visible2 = comment.getVisibleToParsed();
                        if (visible2 == null || visible2.size() == 0) {
                            continue;
                        }
                        boolean found = false;
                        for (Iterator iter = hats.iterator(); iter.hasNext();) {
                            JSHat definedHat = (JSHat) iter.next();
                            if (visible2.contains(definedHat.getId() + "")) { //$NON-NLS-1$
                                found = true;
                                break;
                            }
                        }
                        if (!found) {
                            comments2remove.add(comment);
                        }
                    }
                    ((Collection) fieldValue).removeAll(comments2remove);
                }
            }

            String res;
            if (fieldName.equals("id")) { //$NON-NLS-1$
                //id field without link, cause later special link will be assigned
                switch (fieldType) {
                case TEXT:
                case SHORT_TEXT:
                    res = renderField(jObject, fieldName, fieldType, false, false, pObject, null);
                    break;
                default:
                    res = renderField(jObject, fieldName, FieldRenderType.IMGSTXT, false, false, pObject, null);
                }

            } else {
                res = renderField(jObject, fieldName, fieldType, withLink, false, pObject, wikiContext);
            }
            if (res != null && res.contains(ModulePageTool.COMMENT_ID_PREFIX)) {
                res = res.replaceAll("<[Ii][Mm][Gg][^>]+?[Ii][Dd]=\"" + ModulePageTool.COMMENT_ID_PREFIX + "(.*?)\"*>", ""); // comment markers are not displayes in HTML Blocks //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
                res = res.replaceAll("<[Ii][Mm][Gg][^>]+?[Ii][Dd]=\"" + ModulePageTool.COMMENT_ID_PREFIX + "(.*?)\"*/>", ""); // comment markers are not displayes in HTML Blocks  //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$
            }
            res = utils.escapeValue(res);

            result.put(fieldName, res);
        }
        pObject.forget();
        return result;
    }

    @SuppressWarnings("unchecked")
    public Map<String, String> renderUserFields(Map<String, FieldProperty> fieldsMap, IUser pObject, IJSUIObject jObject, IContextId context, boolean withLink) {
        Map<String, String> result = new HashMap<String, String>();

        if (pObject.isUnresolvable()) {
            for (String fieldName : fieldsMap.keySet()) {
                result.put(fieldName, ""); //$NON-NLS-1$
            }
            pObject.forget();
            return result;
        }

        List<String> fieldsList = new ArrayList<String>();
        fieldsList.addAll(fieldsMap.keySet());
        String roles = null;
        Collection<String> col = null;

        for (String s : fieldsList) { //workaround for unknown field (but only for roles)
            if (s.equalsIgnoreCase("roles")) { //$NON-NLS-1$
                roles = s;
            }
        }
        if (roles != null) {
            fieldsList.remove(roles);
            col = securityService.getRolesForUser(pObject.getId(), context);
        }

        for (String fieldName : fieldsMap.keySet()) {
            Object fieldValue = null;
            FieldRenderType fieldType = fieldsMap.get(fieldName).renderType;
            fieldValue = jObject.getValue(fieldName);

            if ((fieldValue == null) || ((fieldValue instanceof Collection) && ((Collection) fieldValue).isEmpty())) {
                if (fieldName.equalsIgnoreCase("roles")) { //$NON-NLS-1$
                    StringBuilder sb = new StringBuilder();
                    Iterator<String> it = col.iterator();
                    while (it.hasNext()) {
                        sb.append(it.next());
                        sb.append(it.hasNext() ? ", " : ""); //$NON-NLS-1$ //$NON-NLS-2$
                    }
                    result.put(fieldName, sb.toString());
                } else {
                    result.put(fieldName, ""); //$NON-NLS-1$
                }
                continue;
            }

            String res = renderField(jObject, fieldName, fieldType, withLink, false, null, null);
            res = utils.escapeValue(res);

            result.put(fieldName, res);
        }
        pObject.forget();
        return result;
    }

    @SuppressWarnings("unchecked")
    public Map<String, String> renderProjectFields(Map<String, FieldProperty> fieldsMap, IProject pObject, IJSUIObject jObject, boolean withLink) {
        Map<String, String> result = new HashMap<String, String>();

        if (pObject.isUnresolvable()) {
            pObject.forget();
            return null;
        }

        List<String> fieldsList = new ArrayList<String>();
        fieldsList.addAll(fieldsMap.keySet());

        for (String fieldName : fieldsMap.keySet()) {
            Object fieldValue = null;
            FieldRenderType fieldType = fieldsMap.get(fieldName).renderType;
            fieldValue = jObject.getValue(fieldName);

            if ((fieldValue == null) || ((fieldValue instanceof Collection) && ((Collection) fieldValue).isEmpty())) {
                result.put(fieldName, ""); //$NON-NLS-1$
                continue;
            }

            String res = renderField(jObject, fieldName, fieldType, withLink, false, null, null);
            res = utils.escapeValue(res);

            result.put(fieldName, res);
        }
        pObject.forget();
        return result;
    }

    public Map<String, String> getRenderedValues(Map<String, FieldProperty> fieldsMap, IPObject pObject, IJSUIObject jObject, IContextId context, boolean withLink, XWikiContext wikiContext) {

        if (pObject instanceof IWorkItem) {
            return renderWorkItemFields(fieldsMap, (IWorkItem) pObject, jObject, withLink, wikiContext);
        } else if (pObject instanceof IUser) {
            return renderUserFields(fieldsMap, (IUser) pObject, jObject, context, withLink);
        } else if (pObject instanceof IProject) {
            return renderProjectFields(fieldsMap, (IProject) pObject, jObject, withLink);
        }

        return null;
    }

    @SuppressWarnings("unchecked")
    public static String renderField(IJSUIObject o, String fieldName, FieldRenderType fieldType, boolean withLink, boolean targetBlank, IPObject pObject, XWikiContext wikiContext) {
        IHTMLBuilder b = createHtmlBuilder();

        Object object2render;
        if (fieldName == null) {
            object2render = o;
        } else {
            object2render = o.getValue(fieldName);
        }
        if (o instanceof JSWorkItem) {
            boolean isCompareDLE = false;
            if (wikiContext != null) {
                String compareDLE = (String) wikiContext.get("compareModeDLE"); //$NON-NLS-1$
                isCompareDLE = compareDLE != null && "1".equals(compareDLE); //$NON-NLS-1$
            }

            JSWorkItem wi = (JSWorkItem) o;
            if (IUniqueObject.KEY_ID.equals(fieldName)) {
                wi.renderIconAndGlobalId(b, withLink, true, false);

            } else if (JSWorkItem.KEY_OUTLINE_NUMBER.equals(fieldName)) {
                wi.renderIconAndOutlineNumber(b, false, false);

            } else if (JSWorkItem.KEY_TITLE.equals(fieldName)) {
                if (wi.getOutlineNumber() != null && (fieldType == FieldRenderType.IMGTXT || fieldType == FieldRenderType.DEFAULT)) {
                    wi.renderIconOutlineNumberAndTitle(b, false, false);
                } else {
                    wi.renderOutlineNumberAndTitle(b, false, false);
                }

            } else if (JSWorkItem.KEY_COMMENTS.equals(fieldName)) {
                ArrayList<JSComment> comments = (ArrayList<JSComment>) object2render;
                boolean first = true;
                for (Iterator iterator = comments.iterator(); iterator.hasNext();) {
                    JSComment comment = (JSComment) iterator.next();
                    if (first) {
                        first = false;
                        comment.renderTableStart(b);
                    }
                    comment.renderTableDataRow(b, pObject != null ? HatService.getHatsAvailableToCurrentUser(pObject.getContextId()) : null, null, true);

                    if (!iterator.hasNext()) {
                        comment.renderTableEnd(b);
                    }
                }
            } else if (JSWorkItem.KEY_DESCRIPTION.equals(fieldName) && isCompareDLE) {
                b.appendHTML(((IWorkItem) pObject).renderDescription((Text) pObject.getValue(IWorkItem.KEY_DESCRIPTION), null).getContent());
            } else {
                JSRendererFactory.getInstance().render(b, object2render, withLink, false, fieldType.getRenderStyle());
            }
        } else {
            JSRendererFactory.getInstance().render(b, object2render, withLink, false, fieldType.getRenderStyle());
        }
        return MacroUtils.getInstance().escapeValue(b.toString());
    }

    public String renderJSUIObject(IJSUIObject o) {
        IHTMLBuilder b = createHtmlBuilder();
        JSRendererFactory.getInstance().render(b, o, false, true);
        return b.toString();
    }

    private String getModuleLink(IPObject o, IModule module, XWikiContext context, String macroText, int fontSize) {
        IWorkItem wi = (IWorkItem) o;
        JSWorkItem jsWorkItem = (JSWorkItem) transformInstance(o, new ArrayList<String>());
        String url;
        module = module == null ? wi.getModule() : module;
        String target = getTargetForModule(module);
        boolean linkTargetIsDLE = target.contains("/wiki/"); //$NON-NLS-1$
        String baseline = BaselineHelper.getBaselineURLPart(BaselineServlet.getCurrentBaselineRevision(), true, false);
        String selectionId = !wi.getProjectId().equals(module.getProjectId()) ? wi.getProjectId() + "/" + wi.getId() : wi.getId(); //$NON-NLS-1$
        if (isTargetDLE(context) && macroText != null && (macroText.contains("module-workitems") || macroText.contains("document-workitems")) && //$NON-NLS-1$ //$NON-NLS-2$
                linkTargetIsDLE) {
            url = "/polarion/#" + baseline + "/project/" + wi.getProject().getId() + getTargetForModule(module) + "?" + IPage.SELECTION + "=" + selectionId; //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
        } else {
            url = "/polarion/#" + baseline + "/project/" + wi.getProject().getId() + getTargetForModule(module) + "?" + IPage.SELECTION + "=" + selectionId + "&amp;tab=" + IPage.TAB_MULTIEDIT; //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
        }
        if (jsWorkItem.revision != null) {
            url += "&amp;revision=" + jsWorkItem.revision; //$NON-NLS-1$
        }
        IHTMLBuilder b = createHtmlBuilder();
        b.appendHyperlinkStart(url, isTargetDLE(context) ? "_blank" : "_top", null, "font-weight: bold; text-decoration: none; font-size: " + fontSize + "px;color:#000;"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$
        jsWorkItem.renderIconOutlineNumberAndTitle(b, false, false);
        b.appendHTML(HTMLConst.HTML_EA);
        return b.toString();
    }

    public String getLink4MacroObject(IPObject renderedItem, String macroText, ShortLongDisplay display, String label, String polarionServer, boolean forPdf, String linkStyle, String linkStyleClass, String anchorTarget, boolean withLink, XWikiContext context) {

        if (renderedItem.isUnresolvable()) {
            return utils.format(renderedItem);
        }

        if (label == null) {
            List<String> fieldsList = new ArrayList<String>();

            IJSUIObject jo = transformInstance(renderedItem, fieldsList);
            if (display == ShortLongDisplay.SHORT) {
                label = renderField(jo, utils.getLongDisplayField(renderedItem), FieldRenderType.IMGSTXT, false, false, null, null);
            } else {
                label = renderField(jo, null, FieldRenderType.IMGSTXT, false, false, null, null);
                if (renderedItem instanceof IWorkItem) {
                    label += " - " + utils.escapeTitle(((IWorkItem) renderedItem).getTitle()); //$NON-NLS-1$
                }
            }
        }
        if (withLink) {
            return getLink4MacroObjectPhase2(renderedItem, macroText, label, polarionServer, forPdf, linkStyle, linkStyleClass, anchorTarget, context);
        } else {
            return label;
        }
    }

    public String getLink4MacroObjectPhase2(IPObject pObject, String macroText, String label, String polarionServer, boolean forPdf, String linkStyle, String linkStyleClass, String anchorTarget, XWikiContext context) {

        if (pObject.isUnresolvable()) {
            return utils.format(pObject);
        }

        String url = null;

        String b = BaselineServlet.getCurrentBaselineRevision();
        String baseline = BaselineHelper.getBaselineURLPart(b, true, false);
        if (pObject instanceof IWorkItem) {
            IWorkItem wi = (IWorkItem) pObject;
            if (wi.getModule() != null) {
                if (macroText != null && macroText.toLowerCase().contains("document-workitems") && wi.getRevision() == null) { //$NON-NLS-1$
                    url = "polarion/#" + baseline + "/project/" + wi.getProject().getId() + getTargetForModule(wi.getModule()) + "?" + IPage.SELECTION + "=" + wi.getId(); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
                } else if (macroText != null && macroText.toLowerCase().contains("module-workitems") && wi.getRevision() == null) { //$NON-NLS-1$
                    url = "polarion/#" + baseline + "/project/" + wi.getProject().getId() + getTargetForModule(wi.getModule()) + "?" + IPage.SELECTION + "=" + wi.getId() + "&amp;tab=" + IPage.TAB_MULTIEDIT; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
                } else {
                    url = "polarion/#" + baseline + "/project/" + wi.getProject().getId() + "/workitem?id=" + wi.getId(); //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$
                    String rev = wi.getRevision();
                    if ((rev != null) && !rev.equals(b)) {
                        url += "&amp;" + IPage.REVISION + "=" + rev; //$NON-NLS-1$ //$NON-NLS-2$
                    }
                }
            } else {
                url = "polarion/#" + baseline + "/project/" + wi.getProject().getId() + "/workitem?id=" + wi.getId(); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
            }
        } else if (pObject instanceof IUser) {
            IUser user = (IUser) pObject;
            url = "polarion/#" + baseline + "/user?id=" + user.getId(); //$NON-NLS-1$ //$NON-NLS-2$
        } else if (pObject instanceof IProject) {
            IProject project = (IProject) pObject;
            url = "polarion/#" + baseline + "/project/" + project.getId(); //$NON-NLS-1$ //$NON-NLS-2$
        }

        if (url == null) {
            //we don't know how to generate link, find another way, hehe
            return null;
        }

        if (linkStyleClass == null) {
            linkStyleClass = "wiItem"; //$NON-NLS-1$
        }
        if (linkStyle == null) {
            linkStyle = ""; //$NON-NLS-1$
        }
        if (anchorTarget == null) {
            anchorTarget = "_blank"; //$NON-NLS-1$
        }
        label = MacroUtils.getInstance().escapeValue(label);
        if (forPdf) {
            return "<a style='text-decoration: none;padding-left: 2px;padding-right: 2px;color: #000000;" + linkStyle + "' href='" + ((polarionServer != null) ? polarionServer : "") + url + "'  target='_top'>" + label + "</a>"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
        } else {
            return "<a class='" + "" + "' style='" + linkStyle + "' href='" + ((polarionServer != null) ? polarionServer : "") + url + "'  target='" + anchorTarget + "'>" + label + "</a>"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$
        }
    }

    public String renderShrinkableList(String title, String body, boolean expand, String width, String height, boolean forPdf) {
        IHTMLBuilder builder = createHtmlBuilder();

        if (forPdf) {
            builder.appendElementStart(HTMLConst.DIV, null, null, null);

            //header
            builder.appendElementStart(HTMLConst.DIV, null, "padding-left: 9px;margin-bottom:3px;margin-top:3px;width: 100%;vertical-align:middle;background-position: center left;", null); //$NON-NLS-1$
            builder.appendHTML(title);
            builder.appendElementEnd(HTMLConst.DIV);

            //body
            builder.appendElementStart(HTMLConst.DIV, null, "width:100%;", null); //$NON-NLS-1$
            builder.appendElementStart(HTMLConst.DIV, null, "padding:2px;border: 1px solid #BED8E8;", null); //$NON-NLS-1$
            builder.appendHTML(body);
            builder.appendElementEnd(HTMLConst.DIV);
            builder.appendElementEnd(HTMLConst.DIV);

            builder.appendElementEnd(HTMLConst.DIV);
        } else {
            String uniqueId = IntegrationPlugin.getUniqName();

            builder.appendElementStart(HTMLConst.DIV, null, null, null);

            builder.appendElementStart(
                    HTMLConst.SPAN,
                    (expand) ? "expand_open" : "expand_close", "padding-left: 9px;margin-bottom:3px;margin-top:3px;width: 10px;height:15px;vertical-align:middle;background-position: center left;", "id='head_" + uniqueId //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$//$NON-NLS-4$
                            + "' onclick=\"togglePanelVisibilityStyle2(document.getElementById('" + uniqueId + "'),'expandedPanel','collapsedPanel',document.getElementById('head_" + uniqueId + "'),'expand_open','expand_close');\""); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
            builder.appendHTML("&nbsp;"); //$NON-NLS-1$
            builder.appendElementEnd(HTMLConst.SPAN);
            builder.appendHTML(title);

            //body
            builder.appendElementStart(HTMLConst.DIV, (expand) ? "expandedPanel" : "collapsedPanel", "width:98%; overflow:auto;", "id='" + uniqueId + "'"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$//$NON-NLS-4$//$NON-NLS-5$
            builder.appendElementStart(HTMLConst.DIV, null, "padding:2px;border: 1px solid #BED8E8;height:" + height + ";", null); //$NON-NLS-1$//$NON-NLS-2$
            builder.appendHTML(body);
            builder.appendElementEnd(HTMLConst.DIV);
            builder.appendElementEnd(HTMLConst.DIV);

            builder.appendElementEnd(HTMLConst.DIV);

            builder.appendElementStart(HTMLConst.TABLE, null, "width:98%; height:1px;", null); //$NON-NLS-1$
            builder.appendElementStart(HTMLConst.TR, null, null, null);
            builder.appendElementStart(HTMLConst.TD, null, null, null);
            builder.appendElementEnd(HTMLConst.TD);
            builder.appendElementEnd(HTMLConst.TR);
            builder.appendElementEnd(HTMLConst.TABLE);
        }

        return builder.toString();
    }

    public String getPObjectLabel(String fieldName, IPObject object) {
        ICustomField cf = object.getCustomFieldPrototype(fieldName);
        if ((cf == null) || (cf.getName().equals(""))) { //$NON-NLS-1$
            return JSSharedUtil.getFieldLabel(object.getPrototype().getName(), fieldName);
        } else {
            return cf.getName();
        }
    }

    public String renderListOfPObjects(List<IPObject> list, Map<String, FieldProperty> fields, ExpandMode expandMode, String polarionServer, IContextId context, String width, String height, boolean forPdf, boolean withLink, XWikiContext wikicontext) {

        if (list.isEmpty()) {
            return "<div>" + Localization.getString("form.modules.label.noItemsFound") + "</div>"; //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$
        }

        IHTMLBuilder builder = createHtmlBuilder();

        builder.appendElementStart(HTMLConst.DIV, null, null, null);
        for (IPObject o : list) {
            String s = getRenderedFields(
                    fields,
                    o,
                    expandMode,
                    ShortLongDisplay.LONG,
                    polarionServer,
                    null,
                    context, "", //$NON-NLS-1$
                    "", //$NON-NLS-1$
                    forPdf,
                    withLink,
                    wikicontext);
            builder.appendHTML(s);
        }
        builder.appendElementEnd(HTMLConst.DIV);
        return builder.toString();
    }

    public String getRenderedFields(Map<String, FieldProperty> fields, IPObject pObject, ExpandMode expandMode, ShortLongDisplay shortLongTitle, String polarionServer, String label, IContextId context, String width, String height, boolean forPdf, boolean withLink, XWikiContext wikicontext) {
        if (pObject.isUnresolvable()) {
            return utils.format(pObject);
        }

        StringBuilder sb = new StringBuilder();

        List<String> fieldsList = new ArrayList<String>();
        fieldsList.addAll(fields.keySet());
        IJSUIObject jObject = transformInstance(pObject, fieldsList);
        Map<String, String> fieldValueMap = getRenderedValues(fields, pObject, jObject, context, withLink, null);

        if (label == null) {
            //generate some label
            label = renderField(jObject, null, FieldRenderType.IMGTXT, false, false, null, null);
            //maybe necessary to call link2macroObject
        }

        if (fieldValueMap != null) {
            sb.append("<div style='font-size:11px'>"); //TODO table width //$NON-NLS-1$
            for (String fn : fields.keySet()) {
                sb.append("<span style=\"font-weight: bold;\">"); //$NON-NLS-1$
                sb.append(getPObjectLabel(fn, pObject));
                sb.append(": </span>"); //$NON-NLS-1$
                String value = fieldValueMap.get(fn);
                sb.append(utils.escapeValue(value));
                sb.append("<br />"); //$NON-NLS-1$
            }
            sb.append("</div>"); //$NON-NLS-1$
        }

        String output = renderShrinkableList(getLink4MacroObject(pObject, null, shortLongTitle, label, polarionServer, forPdf, null, null, null, withLink, wikicontext), sb.toString(), expandMode.getValue(), width, height, forPdf);
        pObject.forget();
        return output;
    }

    public String renderInaccessibleMessage(boolean hasPermission, boolean hasLicense) {
        String inaccessibleMsg = MacroUtils.NOT_AVAILABLE;
        if (!hasPermission) {
            inaccessibleMsg = Localization.getString("security.cannotShowMacro"); // TODO //$NON-NLS-1$
        }
        if (!hasLicense) {
            inaccessibleMsg = Localization.getString("license.featureNotAvailable"); //$NON-NLS-1$
        }
        return inaccessibleMsg.replaceAll("\n", " "); //$NON-NLS-1$//$NON-NLS-2$
    }

    public String renderErrors(Map<String, String> errors, String macroText, boolean forPdf, List<MP[]> rulesList) {
        StringBuilder sb = new StringBuilder();
        sb.append("<div style=\"font-size:11px\" >"); //$NON-NLS-1$
        sb.append(Localization.getString("macro.general.thereAreSeveralProblemsWithMacro") + "<br />"); //$NON-NLS-1$ //$NON-NLS-2$
        sb.append("<ol>"); //$NON-NLS-1$
        Iterator<String> it = errors.keySet().iterator();
        while (it.hasNext()) {
            String paramName = it.next();
            sb.append("<li>"); //$NON-NLS-1$
            sb.append("<b>"); //$NON-NLS-1$
            sb.append(paramName);
            sb.append("</b>: "); //$NON-NLS-1$
            sb.append(utils.escapeValue(errors.get(paramName)));
            sb.append("</li>"); //$NON-NLS-1$
        }
        sb.append("</ol>"); //$NON-NLS-1$

        if (rulesList != null) {
            sb.append("<br />"); //$NON-NLS-1$
            sb.append(Localization.getString("macro.general.checkMacroParameters") + "<br />"); //$NON-NLS-1$ //$NON-NLS-2$
            sb.append(renderListOfRules(rulesList));
        }
        sb.append("</div>"); //$NON-NLS-1$
        return renderShrinkableList(
                "<span style=\"font-size: 11px; color: red; font-weight: bold\">" + Localization.getString("macro.general.errorsInMacro") + " \"" + macroText + "\"</span>", sb.toString(), false, "auto", "auto", forPdf); //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    }

    public String renderErrors(Map<String, String> errors, String macroText, boolean forPdf) {
        return renderErrors(errors, macroText, forPdf, null);
    }

    public String renderError(String errorTitle, String errorMsg, String macroText, boolean forPdf) {
        StringBuilder sb = new StringBuilder();
        sb.append("<div style=\"font-size:11px\" >"); //$NON-NLS-1$
        sb.append(Localization.getString("macro.general.thereAreSeveralProblemsWithMacro") + "<br />"); //$NON-NLS-1$ //$NON-NLS-2$
        sb.append("<ol>"); //$NON-NLS-1$
        sb.append("<li>"); //$NON-NLS-1$
        sb.append("<b>"); //$NON-NLS-1$
        sb.append(errorTitle);
        sb.append("</b>: "); //$NON-NLS-1$
        sb.append(utils.escapeValue(errorMsg));
        sb.append("</li>"); //$NON-NLS-1$
        sb.append("</ol>"); //$NON-NLS-1$
        sb.append("</div>"); //$NON-NLS-1$
        return renderShrinkableList(
                "<span style=\"font-size: 11px; color: red; font-weight: bold\">" + Localization.getString("macro.general.errorsInMacro") + " \"" + macroText + "\"</span>", sb.toString(), false, "auto", "auto", forPdf); //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    }

    public String renderRecentlyModiefiedWorkItems(List<IPObject> list, String groupby, String polarionServer, boolean forPdf, boolean withLink, XWikiContext wikicontext) {
        StringBuilder sb = new StringBuilder();
        IModuleManager moduleManager = trackerService.getModuleManager();
        DateFormat df = MacroUtils.getInstance().getDateFormat();
        List<IPObject> notInModules;

        Map<IModule, Date> updatedModulesMap = new HashMap<IModule, Date>();
        Map<IModule, List<IWorkItem>> modulesMap = new HashMap<IModule, List<IWorkItem>>();

        boolean groupByModules = (groupby != null) && (groupby.equals("module")); //$NON-NLS-1$

        if (groupByModules) {
            notInModules = new ArrayList<IPObject>();
            for (IPObject o : list) {
                IWorkItem wi = (IWorkItem) o;
                if (wi.isUnresolvable()) {
                    continue;
                }
                if (moduleManager.isModuleItem(wi)) {
                    IModule mod = moduleManager.getContainingModule(wi);
                    List<IWorkItem> l = modulesMap.get(mod);
                    if (l == null) {
                        l = new ArrayList<IWorkItem>();
                        modulesMap.put(mod, l);
                    }
                    l.add(wi);
                    if (!updatedModulesMap.containsKey(mod)) {
                        updatedModulesMap.put(mod, wi.getUpdated());
                    }
                } else {
                    if (!updatedModulesMap.containsKey(null)) {
                        updatedModulesMap.put(null, wi.getUpdated());
                    }
                    notInModules.add(wi);
                }
            }
        } else {
            updatedModulesMap.put(null, new Date());
            notInModules = list;
        }
        List<IModule> sortedModules = utils.getKeysSortedByValue(updatedModulesMap, true);

        String baseline = BaselineHelper.getBaselineURLPart(BaselineServlet.getCurrentBaselineRevision(), true, false);
        for (IModule m : sortedModules) {
            if (m != null) {
                String escapedModuleName = ModuleHelper.getEscapedModuleName(m.getModuleName());
                sb.append("<span>"); //$NON-NLS-1$
                sb.append("<img src='" + (forPdf ? polarionServer : "/") + "polarion/ria/images/details/document.png' style='vertical-align: middle; margin-right:2px;' alt='module_icon' title='" + m.getModuleName() + "' />"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

                String escapedModuleTitle = utils.escapeTitle(m.getTitleOrName());
                if (withLink) {
                    sb.append("<a href=\"/polarion/#" + baseline + "/project/"). //$NON-NLS-1$ //$NON-NLS-2$
                            append(m.getProject().getId()).append("/"). //$NON-NLS-1$
                            append(IPage.MODULE).append("/"). //$NON-NLS-1$
                            append(escapedModuleName).append("\" target=\"_top\"" + (forPdf ? " style=\"text-decoration: none;padding-left: 2px;padding-right: 2px;color: #336699;font-size:12px\"" : "") + ">"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
                    sb.append(escapedModuleTitle);
                    sb.append("</a>"); //$NON-NLS-1$
                } else {
                    sb.append(escapedModuleTitle);
                }

                sb.append("</span>"); //$NON-NLS-1$
                sb.append("<span class='smallerGrayFont' " + (forPdf ? "style=\"color:gray;font-size:11px;\"" : "") + ">"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
                sb.append("</span>"); //$NON-NLS-1$
            } else {
                if (groupByModules) {
                    sb.append("<i>" + Localization.getString("form.modules.label.notInModules") + Localization.getString("definition.colon") + "</i>"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
                }
            }
            sb.append("<ul class='workitemsModuleList' " + (forPdf ? "style=\"margin-top:0px;\"" : "") + ">"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$//$NON-NLS-4$
            for (IPObject wi : m != null ? modulesMap.get(m) : notInModules) {
                sb.append("<li" + (forPdf ? " style=\"padding-left:2.5em;\"" : "") + ">"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
                if (wi.isUnresolvable()) {
                    String contextName = wi.getContextId().getContextName();
                    String objectName = wi.getLocalId().getObjectName();
                    if (withLink) {
                        sb.append("<i><a href=\"/polarion/#" + baseline + "/project/" + contextName + "/workitem/?id=" + objectName + "\" target=\"_top\">" + objectName + "</a></i>"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
                    } else {
                        sb.append("<i>" + objectName + "</i>"); //$NON-NLS-1$//$NON-NLS-2$
                    }
                } else {
                    sb.append(getLink4MacroObject(wi, null, ShortLongDisplay.LONG, null, "/", forPdf, forPdf ? "color: #336699" : "", "", "_top", withLink, wikicontext)); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
                    sb.append(":<br /><span class='smallerGrayFont' " + (forPdf ? "style=\"color:gray;font-size:11px;\"" : "") + "> "); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$//$NON-NLS-4$
                    IUser user = utils.getWorkItemUpdatedUser((IWorkItem) wi);
                    sb.append(user == null ? "" : (user.isUnresolvable() ? user.getLocalId().getObjectName() : user.getName())); //$NON-NLS-1$
                    sb.append(" "); //$NON-NLS-1$
                    sb.append(df.format(((IWorkItem) wi).getUpdated()));
                    sb.append("</span>"); //$NON-NLS-1$
                }
                sb.append("</li>"); //$NON-NLS-1$
            }
            sb.append("</ul>"); //$NON-NLS-1$
        }

        if (modulesMap.isEmpty() && notInModules.isEmpty()) {
            sb.append(Localization.getString("form.modules.label.noWIMatched")); //$NON-NLS-1$
        }
        for (IPObject o : list) {
            o.forget();
        }
        return sb.toString();
    }

    private String renderListOfRules(List<MP[]> rulesList) {
        StringBuilder sb = new StringBuilder();
        sb.append("<ol>"); //$NON-NLS-1$
        Iterator<MP[]> it = rulesList.iterator();
        while (it.hasNext()) {
            MP[] params = it.next();
            sb.append("<li>"); //$NON-NLS-1$
            for (MP mp : params) {
                sb.append("<b>"); //$NON-NLS-1$
                sb.append(mp.getName());
                sb.append("</b>(<i>"); //$NON-NLS-1$
                sb.append(mp.isOptionalForUser() ? "O" : "R"); //$NON-NLS-1$ //$NON-NLS-2$
                sb.append("</i>"); //$NON-NLS-1$
                if (mp.getValueForUser() != null) {
                    sb.append(","); //$NON-NLS-1$
                    sb.append(mp.getValueForUser());
                }
                sb.append(")"); //$NON-NLS-1$
                sb.append(", "); //$NON-NLS-1$
            }
            sb.append("</li>"); //$NON-NLS-1$
        }

        sb.append(Localization.getString("macro.general.whereRMeansRequiredAndOMeansOptional", "R", "O")); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
        sb.append("</ol>"); //$NON-NLS-1$

        return sb.toString();
    }

    public String renderAcceptableMacroParameters(List<MP[]> rulesList, String macroText, boolean forPdf) {
        StringBuilder sb = new StringBuilder();
        sb.append("<div style=\"font-size:11px\" >"); //$NON-NLS-1$
        sb.append(Localization.getString("macro.general.youHaveSetWrongParametersForYourMacro") + "<br />"); //$NON-NLS-1$ //$NON-NLS-2$
        sb.append(renderListOfRules(rulesList));
        sb.append("</div>"); //$NON-NLS-1$
        return renderShrinkableList(
                "<span style=\"font-size: 11px; color: red; font-weight: bold\">" + Localization.getString("macro.general.errorsInMacro") + " \"" + macroText + "\"</span>", sb.toString(), false, "auto", "auto", forPdf); //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    }

    @SuppressWarnings("unchecked")
    public String getFieldTitle(String field, List<IPObject> items, Map<String, FieldProperty> fields) {
        String name = null;
        for (IPObject pObject : items) {
            if (pObject.isUnresolvable()) {
                continue;
            }
            ICustomField customField = cfs.getCustomField(pObject, field);
            String cfn = customField.getName();
            if ((cfn != null) && (cfn.length() > 0)) {
                name = cfn;
                break;
            }
        }
        if (name != null) {
            return name;
        } else {
            return JSSharedUtil.getFieldLabel(field);
        }
    }

    public String renderRecentlyModiefiedPagesList(List col, Map<String, FieldProperty> fields, XWikiContext context, boolean isProject) {

        StringBuilder sb = new StringBuilder();
        sb.append("<table>"); //$NON-NLS-1$
        Iterator it2 = col.iterator();
        while (it2.hasNext()) {
            Object object = it2.next();

            if (object instanceof XWikiDocument) {
                XWikiDocument doc = (XWikiDocument) object;

                sb.append("<tr><td>"); //$NON-NLS-1$

                for (Object element : fields.keySet()) {
                    String key = (String) element;
                    if ("pageLink".equalsIgnoreCase(key)) { //$NON-NLS-1$
                        sb.append("<span class=\"panelitem\" style=\"padding-bottom:3px;\" >"); //$NON-NLS-1$

                        sb.append("<a title=\"" + getTitle(doc) + "\" href=\"" + doc.getURL("view", context) + "\">"); //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
                        sb.append("<img src='/polarion/ria/images/details/wiki_svn.gif' style='vertical-align:middle;margin-right:2px;border:0px;'>"); //$NON-NLS-1$
                        sb.append(utils.escapeValue(doc.getName()));
                        sb.append("</a>&nbsp;"); //$NON-NLS-1$
                        boolean renderedProject = false;
                        boolean renderedSpace = false;
                        if (!doc.getProject().equalsIgnoreCase("") && !isProject) { //$NON-NLS-1$
                            renderedProject = true;
                            sb.append("<span  style=\"color:gray;font-size:11px;\" >("); //$NON-NLS-1$
                            sb.append(utils.escapeValue(doc.getProjectName()));
                        }
                        if (!doc.getSpaceName().equals("_default")) { //$NON-NLS-1$
                            renderedSpace = true;
                            if (!renderedProject) {
                                sb.append("<span  style=\"color:gray;font-size:11px;\" >("); //$NON-NLS-1$
                            } else {
                                sb.append(" / "); //$NON-NLS-1$
                            }
                            sb.append(utils.escapeValue(doc.getSpaceName()));
                        }
                        if (renderedProject || renderedSpace) {
                            sb.append(")</span>&nbsp;"); //$NON-NLS-1$
                        }

                    } else if ("updated".equalsIgnoreCase(key)) { //$NON-NLS-1$
                        sb.append("<span  style=\"color:gray;font-size:11px;\" >"); //$NON-NLS-1$
                        sb.append(context.getWiki().formatDate(doc.getContentUpdateDate(), "yyyy-MM-dd HH:mm", context)); //$NON-NLS-1$
                        sb.append("</span>&nbsp;"); //$NON-NLS-1$
                    } else if ("created".equalsIgnoreCase(key)) { //$NON-NLS-1$
                        sb.append("&nbsp;<span  style=\"color:gray;font-size:11px;\" >"); //$NON-NLS-1$
                        sb.append(context.getWiki().formatDate(doc.getCreationDate(), "yyyy-MM-dd HH:mm", context)); //$NON-NLS-1$
                        sb.append("</span>&nbsp;"); //$NON-NLS-1$
                    } else if ("updatedBy".equalsIgnoreCase(key)) { //$NON-NLS-1$
                        sb.append("<span  style=\"color:gray;font-size:11px;\" >"); //$NON-NLS-1$
                        sb.append(utils.escapeValue(doc.getAuthorName()));
                        sb.append("</span>&nbsp;"); //$NON-NLS-1$
                    } else if ("createdBy".equalsIgnoreCase(key)) { //$NON-NLS-1$
                        sb.append("<span  style=\"color:gray;font-size:11px;\" >"); //$NON-NLS-1$
                        sb.append(utils.escapeValue(doc.getCreatorName()));
                        sb.append("</span>&nbsp;"); //$NON-NLS-1$
                    }
                }
                sb.append("</span></td></tr>"); //$NON-NLS-1$
            } else if ((object instanceof IModule) || (object instanceof IWikiPage)) {
                String projectId = ((IUniqueObject) object).getProjectId();
                String projectName = (projectId != null) ? ((IUniqueObject) object).getProject().getName() : ""; //$NON-NLS-1$
                String id = ((IUniqueObject) object).getId();
                String space = (object instanceof IModule) ? ((IModule) object).getModuleFolder() : ((IWikiPage) object).getSpaceId();
                if (space == null) {
                    space = "_default"; //$NON-NLS-1$
                }
                String spaceTitle = (object instanceof IModule) ? ((IModule) object).getFolder().getTitleOrName() : ((IWikiPage) object).getFolder().getTitleOrName();
                String titleOrName = (object instanceof IModule) ? ((IModule) object).getTitleOrName() : ((IWikiPage) object).getTitleOrName();
                titleOrName = escapeValue(titleOrName);
                Date updated = (object instanceof IModule) ? ((IModule) object).getUpdated() : ((IWikiPage) object).getUpdated();
                Date created = (object instanceof IModule) ? ((IModule) object).getCreated() : ((IWikiPage) object).getCreated();
                IUser updatedBy = (object instanceof IModule) ? ((IModule) object).getUpdatedBy() : ((IWikiPage) object).getUpdatedBy();
                IUser author = (object instanceof IModule) ? ((IModule) object).getAuthor() : ((IWikiPage) object).getAuthor();
                String image = (object instanceof IModule) ? "/polarion/ria/images/details/document.png" : "/polarion/ria/images/details/wiki_svn.gif"; //$NON-NLS-1$ //$NON-NLS-2$
                sb.append("<tr><td>"); //$NON-NLS-1$

                for (Object element : fields.keySet()) {
                    String key = (String) element;
                    if ("pageLink".equalsIgnoreCase(key)) { //$NON-NLS-1$
                        sb.append("<span class=\"panelitem\" style=\"padding-bottom:3px;\" >"); //$NON-NLS-1$
                        String hash = PortalService.getPortal().createProjectWikiUrlHash(projectId, space, id, BaselineServlet.getCurrentBaselineRevision(), null);
                        hash = utils.escapeValue(hash);
                        sb.append("<a title=\"" + titleOrName + "\" target=\"_top\" href=\"/polarion/#" + hash + "\">"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
                        sb.append("<img src='" + image + "' style='vertical-align:middle;margin-right:2px;border:0px;'>"); //$NON-NLS-1$ //$NON-NLS-2$
                        sb.append(titleOrName);
                        sb.append("</a>" + appendHome(id) + "&nbsp;"); //$NON-NLS-1$ //$NON-NLS-2$
                        boolean renderedProject = false;
                        boolean renderedSpace = false;
                        if (!projectName.equalsIgnoreCase("") && !isProject) { //$NON-NLS-1$
                            renderedProject = true;
                            sb.append("<span  style=\"color:gray;font-size:11px;\" >("); //$NON-NLS-1$
                            sb.append(utils.escapeValue(projectName));
                        }
                        if (!space.equals("_default")) { //$NON-NLS-1$
                            renderedSpace = true;
                            if (!renderedProject) {
                                sb.append("<span  style=\"color:gray;font-size:11px;\" >("); //$NON-NLS-1$
                            } else {
                                sb.append(" / "); //$NON-NLS-1$
                            }
                            sb.append(escapeValue(spaceTitle));
                        }
                        if (renderedProject || renderedSpace) {
                            sb.append(")</span>&nbsp;"); //$NON-NLS-1$
                        }

                    } else if ("updated".equalsIgnoreCase(key)) { //$NON-NLS-1$
                        sb.append("<span  style=\"color:gray;font-size:11px;\" >"); //$NON-NLS-1$
                        sb.append(context.getWiki().formatDate(updated, "yyyy-MM-dd HH:mm", context)); //$NON-NLS-1$
                        sb.append("</span>&nbsp;"); //$NON-NLS-1$
                    } else if ("created".equalsIgnoreCase(key)) { //$NON-NLS-1$
                        sb.append("&nbsp;<span  style=\"color:gray;font-size:11px;\" >"); //$NON-NLS-1$
                        sb.append(context.getWiki().formatDate(created, "yyyy-MM-dd HH:mm", context)); //$NON-NLS-1$
                        sb.append("</span>&nbsp;"); //$NON-NLS-1$
                    } else if ("updatedBy".equalsIgnoreCase(key)) { //$NON-NLS-1$
                        sb.append("<span  style=\"color:gray;font-size:11px;\" >"); //$NON-NLS-1$
                        sb.append(utils.escapeValue(getUserName(updatedBy)));
                        sb.append("</span>&nbsp;"); //$NON-NLS-1$
                    } else if ("createdBy".equalsIgnoreCase(key)) { //$NON-NLS-1$
                        sb.append("<span  style=\"color:gray;font-size:11px;\" >"); //$NON-NLS-1$
                        sb.append(utils.escapeValue(getUserName(author)));
                        sb.append("</span>&nbsp;"); //$NON-NLS-1$
                    }
                }
                sb.append("</span></td></tr>"); //$NON-NLS-1$
            }

        }
        sb.append("</table>"); //$NON-NLS-1$

        return sb.toString();
    }

    @NotNull
    private String escapeValue(@Nullable String text) {
        text = EscapeChars.forHTMLTag(text);
        text = utils.escapeValue(text);
        return text;
    }

    private String getUserName(IUser user) {
        if (user.isUnresolvable()) {
            return "<i>" + user.getLocalId().getObjectName() + "</i>"; //$NON-NLS-1$ //$NON-NLS-2$
        }
        return user.getName();
    }

    private String getTitle(XWikiDocument doc) {
        return (!(doc.getProject()).equalsIgnoreCase(ISvnProvider.REPO_ROOT_AS_PROJECT_NAME) ? doc.getProjectName() : "") + "/" + doc.getSpaceName() + "." + doc.getName(); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    }

    public String renderRecentlyModifiedPagesTable(final List col, final String title, final int realSize, final Map<String, FieldProperty> fields, String polarionServer, boolean forPdf, final XWikiContext context, boolean isProject) {
        return renderTable(null, context, ExpandMode.YES, null, null, forPdf, new PageTableModel(fields, context, title, col, realSize));
    }

    private String getTargetForModule(IModule module) {
        ILocalId moduleId = module.getLocalId();
        String s = ModuleUtils.getModuleNameWithSpace(moduleId);
        return (moduleId.getContainerId() != null) ? "/wiki/" + s : "/modules/" + s; //$NON-NLS-1$//$NON-NLS-2$
    }

    private static IHTMLBuilder createHtmlBuilder() {
        return (IHTMLBuilder) ServerUiContext.getInstance().createHtmlBuilderFor().oldWiki();
    }

    private static String appendHome(String id) {
        if ("Home".equals(id)) { //$NON-NLS-1$
            return " <i>" + Localization.getString("definition.openBracket") + Localization.getString("definition.home") + Localization.getString("definition.closeBracket") + "</i>"; //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$//$NON-NLS-4$//$NON-NLS-5$
        }
        return ""; //$NON-NLS-1$
    }

}
