package com.polarion.wiki.integration;

import org.radeox.macro.parameter.MacroParameter;

@Deprecated
public final class PiechartFooterMacro extends UpdateReportFooterMacro {

    // Just delegate to generic ChartFooterMacro

    private static final String PARAM_DATA = "data";

    @Override
    public String getLocaleKey() {
        return "macro.polarionpiechartfooter";
    }

    @Override
    public String getName() {
        return "piechartfooter";
    }

    @Override
    public String getReportPath(MacroParameter params) {
        return params.get(PARAM_DATA);
    }

}
