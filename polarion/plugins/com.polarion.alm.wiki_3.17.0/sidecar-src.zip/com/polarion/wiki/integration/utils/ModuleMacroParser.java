package com.polarion.wiki.integration.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.polarion.alm.projects.model.IProject;
import com.polarion.alm.tracker.model.IModule;
import com.polarion.core.util.ObjectUtils;
import com.polarion.core.util.logging.Logger;
import com.polarion.portal.shared.navigation.IPage;
import com.polarion.reina.web.shared.localization.Localization;
import com.xpn.xwiki.XWikiContext;

public class ModuleMacroParser extends MacroParser {

    private static final Logger log = Logger.getLogger(ModuleMacroParser.class);

    enum Page {
        HOME("home"), TABLE("table"), MULTIEDIT("multiedit");

        private String title;

        private Page(String title) {
            this.title = title;
        }

        public String getTitle() {
            return title;
        }
    }

    final static private MP[] rule1 = {
            MP.NAME, MP.DOCUMENT_QUERY, MP.PAGE, MP.PROJECT, MP.LINK
    };

    static final private List<MP[]> rules = new ArrayList<MP[]>();

    static {
        rules.add(rule1);
    }
    static final private Set<MP> uniqueParameters = getUniqueParameters(rules);

    public ModuleMacroParser(XWikiContext context) {
        super(context, rules, uniqueParameters);
    }

    @Override
    public String parse(Collection<String> col, String macroText, boolean forPdf) {
        this.col = col;
        this.macroText = macroText;
        this.forPdf = forPdf;

        try {
            utils.addParameterNameToValue(MP.NAME.getName(), col);
            utils.addDefaultParameter(MP.PAGE.getName(), "home", col); //$NON-NLS-1$

            String err = parseParameters();
            if (err != null) {
                return err;
            }

            String name = map.get(MP.NAME);
            if (name.matches("(\\s)*@current(\\s)*")) { //$NON-NLS-1$
                name = context.getDoc().getName();
                map.put(MP.NAME, name);
            }

            IProject project = null;
            if (map.containsKey(MP.PROJECT)) {
                project = utils.getProject(map.get(MP.PROJECT), errors);
            }

            if (project == null) {
                project = utils.getCurrentProject(context);
                if (project == null) {
                    return renderer.renderError(MP.PROJECT_ID.getName(), Localization.getString("macro.general.parameterProjectIsNotSet"), macroText, forPdf); //$NON-NLS-1$
                }
            }

            return renderModuleLink(map, project, forPdf);
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            String put = errors.put("Error", Localization.getString("macro.general.parsingUnknownException") + e.getLocalizedMessage()); //$NON-NLS-1$ //$NON-NLS-2$
            return renderer.renderErrors(errors, macroText, forPdf);
        }
    }

    private String renderModuleLink(Map<MP, String> map, IProject project, boolean forPdf) {
        StringBuilder result = new StringBuilder();
        String moduleName = map.get(MP.NAME);

        ModuleHelper moduleHelper = new ModuleHelper(trackerService, project, moduleName, null);

        IModule module = moduleHelper.getModule();

        if (module == null) {
            return "<i>" + moduleName + "</i>"; //$NON-NLS-1$//$NON-NLS-2$
        } else if (module.isUnresolvable()) {
            return utils.format(module);
        }
        String title = module.getTitleOrName();
        String titleWithSpace = module.getTitleWithSpace();
        boolean withLink = utils.showLink(map);

        String vAlign = forPdf ? "top" : "middle";

        result.append("<span title=\"" + titleWithSpace + "\">") //$NON-NLS-1$ //$NON-NLS-2$
                .append("<img src='/polarion/ria/images/details/document.png' style='vertical-align: " + vAlign + "; margin-right:2px;' alt='module_icon' title='") //$NON-NLS-1$
                .append(titleWithSpace)
                .append("' />"); //$NON-NLS-1$

        if (withLink) {
            result.append("<a href=\""); //$NON-NLS-1$
            result.append(moduleHelper.getModuleLink());

            String page = map.get(MP.PAGE);
            String query = map.get(MP.DOCUMENT_QUERY);
            String queryParam = null;
            if (!ObjectUtils.emptyString(query)) {
                String query2 = query.replaceAll("&#042;", "%2A"); //$NON-NLS-1$ //$NON-NLS-2$
                query2 = query2.replaceAll("#", "%23"); //$NON-NLS-1$//$NON-NLS-2$
                query2 = query2.replaceAll("\"", "&#34;"); //$NON-NLS-1$ //$NON-NLS-2$
                query2 = MacroUtils.getInstance().escapeValue(query2);
                queryParam = "&query=" + query2; //$NON-NLS-1$
            }
            if (Page.TABLE.getTitle().equals(page)) {
                result.append("?tab=") //$NON-NLS-1$
                        .append(IPage.TAB_TABLE + (queryParam != null ? queryParam : "")) //$NON-NLS-1$
                        .append("\" target=\"_top\">"); //$NON-NLS-1$
            } else if (Page.MULTIEDIT.getTitle().equals(page)) {
                result.append("?tab=") //$NON-NLS-1$
                        .append(IPage.TAB_MULTIEDIT + (queryParam != null ? queryParam : "")) //$NON-NLS-1$
                        .append("\" target=\"_top\">"); //$NON-NLS-1$
            } else if (!ObjectUtils.emptyString(query)) {
                query = query.replaceAll("&#042;", "%2A"); //$NON-NLS-1$//$NON-NLS-2$
                query = query.replaceAll("#", "%23"); //$NON-NLS-1$ //$NON-NLS-2$
                query = query.replaceAll("\"", "&#34;"); //$NON-NLS-1$ //$NON-NLS-2$
                query = MacroUtils.getInstance().escapeValue(query);
                result.append("?query=") //$NON-NLS-1$
                        .append(query)
                        .append("\" target=\"_top\">"); //$NON-NLS-1$
            } else {
                result.append("\" target=\"_top\">"); //$NON-NLS-1$
            }
        }

        result.append(title);
        if (withLink) {
            result.append("</a>"); //$NON-NLS-1$
        }
        result.append("</span>"); //$NON-NLS-1$

        return result.toString();
    }

}
