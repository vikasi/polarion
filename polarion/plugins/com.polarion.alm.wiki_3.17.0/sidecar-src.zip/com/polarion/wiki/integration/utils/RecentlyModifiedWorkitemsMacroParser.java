package com.polarion.wiki.integration.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;

import com.polarion.alm.projects.model.IProject;
import com.polarion.core.util.logging.Logger;
import com.polarion.platform.persistence.model.IPObject;
import com.polarion.platform.persistence.model.IPObjectList;
import com.polarion.reina.web.shared.localization.Localization;
import com.xpn.xwiki.XWikiContext;

public class RecentlyModifiedWorkitemsMacroParser extends MacroParser {

    private static final Logger log = Logger.getLogger(RecentlyModifiedWorkitemsMacroParser.class);

    final static private MP[] rule1 = {
            MP.PROJECT2, MP.GROUPBY, MP.TOP, MP.LINK
    };

    static final private List<MP[]> rules = new ArrayList<MP[]>();

    static {
        rules.add(rule1);
    }

    static final private Set<MP> uniqueParameters = getUniqueParameters(rules);

    public RecentlyModifiedWorkitemsMacroParser(XWikiContext context) {
        super(context, rules, uniqueParameters);

    }

    @Override
    @SuppressWarnings("unchecked")
    public String parse(Collection<String> col, String macroText, boolean forPdf) {
        this.col = col;
        this.macroText = macroText;
        this.forPdf = forPdf;

        try {
            IProject project = null;

            String err = parseParameters();
            if (err != null) {
                return err;
            }

            boolean withLink = utils.showLink(map);

            String projectId = map.get(MP.PROJECT2);
            if (!projectId.matches("(\\s)*@current(\\s)*")) { //$NON-NLS-1$
                project = utils.getProject(map.get(MP.PROJECT2), errors);
                if (project == null) {
                    return renderer.renderErrors(errors, macroText, forPdf);
                }
            } else {
                //search on current scope, but only if scope is project!
                project = utils.getCurrentProject(context);
            }
            if (project == null) {
                return renderer.renderError(MP.PROJECT.getName(), Localization.getString("macro.general.parameterProjectIsNotSet"), macroText, forPdf); //$NON-NLS-1$
            }

            IPObjectList list = trackerService.queryWorkItems(project, "", "~updated"); //$NON-NLS-1$ //$NON-NLS-2$
            List<IPObject> final_list = utils.getTopItems(list, map.get(MP.TOP), 10);
            return MacroRenderer.getInstance().renderRecentlyModiefiedWorkItems(final_list, map.get(MP.GROUPBY), utils.getPolarionServerURL(context), forPdf, withLink, context);
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            errors.put("Error", Localization.getString("macro.general.parsingUnknownException") + e.getLocalizedMessage()); //$NON-NLS-1$//$NON-NLS-2$
            return renderer.renderErrors(errors, macroText, forPdf);
        }
    }

}
