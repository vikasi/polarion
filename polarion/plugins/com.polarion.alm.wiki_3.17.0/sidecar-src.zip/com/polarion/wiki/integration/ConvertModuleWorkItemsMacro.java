package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.tracker.model.IWorkItem;
import com.polarion.alm.tracker.web.internal.server.tree.TreeNode;
import com.polarion.platform.persistence.model.IPObject;
import com.polarion.wiki.integration.utils.MP;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.integration.utils.ModuleWorkItemsMacroParser;
import com.xpn.xwiki.XWikiContext;

public class ConvertModuleWorkItemsMacro extends BaseLocaleMacro {

    @Override
    public String getLocaleKey() {
        return "macro.convert.module.workitems";
    }

    @Override
    public void execute(Writer writer, MacroParameter param)
            throws IllegalArgumentException, IOException {
        MacroUtils utils = MacroUtils.getInstance();
        XWikiContext<?, ?> context = utils.getXWikiContext(param);
        ModuleWorkItemsMacroParser parser = new ModuleWorkItemsMacroParser(
                context);

        Collection<String> parameters = utils.getParameters(param);
        utils.addDefaultParameter(MP.DISPLAY_DOCUMENT.getName(), "document", parameters);
        String error = parser.parseParameters(parameters);
        if (error != null) {
            writer.write(error);
        } else {
            List<TreeNode> tree = parser
                    .getStructuredTreeForModule(new HashSet<IPObject>());
            writeTree(writer, tree);
        }

    }

    @SuppressWarnings("unchecked")
    private void writeTree(Writer writer, List<TreeNode> tree)
            throws IOException {
        for (TreeNode treeNode : tree) {
            IWorkItem workitem = (IWorkItem) treeNode.getObject();
            writer.write(String.format("<div id=\"polarion_wiki macro name=module-workitem;params=id=%s|level=%d\"></div>"
                    , workitem.getId(), treeNode.getLevel()));
            writeTree(writer, treeNode.getChildNodes());
        }
    }

}
