package com.polarion.wiki.integration;

import java.util.LinkedHashMap;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import com.google.inject.Inject;
import com.polarion.alm.tracker.ITestManagementPolicy;
import com.polarion.alm.tracker.ITestManagementService;
import com.polarion.alm.tracker.model.ITestRun;
import com.polarion.alm.ui.shared.wiki.status.StatusData.Type;
import com.polarion.platform.guice.internal.GuicePlatform;
import com.polarion.reina.web.shared.localization.Localization;
import com.xpn.xwiki.XWikiContext;

/**
 * This is server side representation of TestRun Status Button Macro
 */
public class TestRunStatusButtonMacro extends StatusButtonMacro {

    public static final String MACRO_ID = "testrun-status-button"; //$NON-NLS-1$

    private static ITestManagementPolicy policy;

    @SuppressWarnings("deprecation")
    public TestRunStatusButtonMacro() {
        super(MACRO_ID);
        GuicePlatform.getGlobalInjector().injectMembers(this);
    }

    @Inject
    public void setTestingService(ITestManagementService testingService) {
        policy = testingService.getPolicy();
    }

    @Override
    @Nullable
    protected Scope getScope(@NotNull String name, @NotNull LinkedHashMap<String, String> parameters, @NotNull XWikiContext context) {

        ITestRun testRun = TestRunPropertyMacro.getTestRun(null, context);

        if (testRun != null && !testRun.isUnresolvable()) {
            parameters.put(Type.TestRun.projectIdParameterName, testRun.getProjectId());
            parameters.put(Type.TestRun.targetIdParameterName, testRun.getId());

            return new Scope(name, parameters, testRun.getStatus(), testRun.getFinishedOn());
        }

        return null;
    }

    @Override
    protected boolean hasLicense() {
        return policy.canUseTestManagement();
    }

    @Override
    @NotNull
    protected String getTargetNotAvailableMessage() {
        return Localization.getString("macro.status-button.testRunContextRequired", getMacroId()); //$NON-NLS-1$
    }

}
