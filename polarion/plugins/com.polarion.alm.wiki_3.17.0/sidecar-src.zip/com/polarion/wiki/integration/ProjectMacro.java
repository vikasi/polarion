package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.Collection;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.integration.utils.ProjectMacroParser;
import com.xpn.xwiki.XWikiContext;

public class ProjectMacro extends BaseLocaleMacro {

    final private MacroUtils utils = MacroUtils.getInstance();

    @Override
    public void execute(Writer writer, MacroParameter parameters)
            throws IllegalArgumentException, IOException {

        Collection<String> col = utils.getParameters(parameters);
        String macroText = utils.buildMacroTextFromParameters("project", col);

        XWikiContext context = utils.getXWikiContext(parameters);
        ProjectMacroParser parser = new ProjectMacroParser(utils.getXWikiContext(parameters));
        String result = null;

        String pdf = (String) context.get("pdf_generate");
        if (pdf == null || pdf.equalsIgnoreCase("0")) {
            result = parser.parse(col, macroText, false);
        } else {
            result = parser.parse(col, macroText, true);
        }
        writer.write(result);

    }

    @Override
    public String getLocaleKey() {
        return "macro.polarionproject";
    }

}
