/*
 * Copyright (C) 2004-2013 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2013 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.polarion.wiki.integration.plans;

import java.io.IOException;
import java.io.Writer;
import java.util.Map;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.tracker.ITrackerService;
import com.polarion.alm.tracker.model.IPlan;
import com.polarion.alm.ui.server.plans.PlansMacroDataProvider;
import com.polarion.alm.ui.server.wiki.macro.impl.PlainMacroImpl;
import com.polarion.alm.ui.shared.wiki.ParameterNames;
import com.polarion.platform.core.PlatformContext;
import com.polarion.portal.server.HTMLBuilder;
import com.polarion.portal.shared.wiki.SharedMacroContextImpl;
import com.polarion.subterra.base.data.identification.IContextId;
import com.polarion.wiki.integration.XWikiGwtMacro;

public class PlansMacro extends XWikiGwtMacro {

    @NotNull
    private static final String MACRO_ID = "plans"; //$NON-NLS-1$

    @NotNull
    private static final ITrackerService trackerService = PlatformContext.getPlatform().lookupService(ITrackerService.class);

    @Override
    @NotNull
    protected String getMacroId() {
        return MACRO_ID;
    }

    @Override
    public boolean hasLicense() {
        return trackerService.getTrackerPolicy().canUsePlans();
    }

    @Override
    public void execute(Writer writer, MacroParameter parameters) throws IllegalArgumentException, IOException {
        new DataRenderer(new Data(parameters)).render(writer);
    }

    private class Data extends MacroData {

        @NotNull
        final PlansMacroParameters parameters;

        Data(@NotNull MacroParameter inputParameters) {
            super(inputParameters);
            parameters = new PlansMacroParameters(macroContext, new PlainMacroImpl(getMacroText(inputParameters)));
        }

        @Override
        @NotNull
        public Map<String, String> getErrors() {
            return parameters.validate();
        }

        @Override
        @NotNull
        public Map<String, String> getParameters() {
            Map<String, String> map = parameters.getMap();
            SharedMacroContextImpl.persist(macroContext, map);
            IPlan plan = parameters.getPlan();
            map.put(ParameterNames.PLAN, toString(plan));
            boolean canCreatePlan = checkCreatePermission() && (plan == null || !plan.isTemplate());
            map.put(ParameterNames.CREATE_BUTTON, String.valueOf(parameters.getCreateButton() && canCreatePlan));
            map.put(ParameterNames.CHILD_TEMPLATE, toString(parameters.getChildTemplate()));
            return map;
        }

        private boolean checkCreatePermission() {
            String projectId = parameters.getProjectId();
            if (projectId == null) {
                return false;
            }
            IContextId contextId = trackerService.getProjectsService().getProject(projectId).getContextId();
            return trackerService.getDataService().getPersistencePolicy().canCreateInstances(IPlan.PROTO, contextId);
        }

        @Nullable
        private String toString(@Nullable IPlan plan) {
            return plan != null ? plan.getProjectId() + "/" + plan.getId() : null; //$NON-NLS-1$
        }
    }

    class DataRenderer extends MacroDataRenderer<Data> {

        DataRenderer(@NotNull final Data data) {
            super(data);
        }

        @Override
        protected void renderStatical(@NotNull HTMLBuilder builder) throws Exception {
            if (data.wikiContext.isInCompareMode()) {
                super.renderStatical(builder);
            } else {
                Map<String, String> parameterMap = data.getParameters();
                String html = new PlansMacroDataProvider(data.macroContext, parameterMap).renderPlans(false);
                builder.appendHTML(html);
            }
        }

    }

}
