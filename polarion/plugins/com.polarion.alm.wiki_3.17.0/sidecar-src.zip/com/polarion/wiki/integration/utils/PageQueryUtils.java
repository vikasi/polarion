package com.polarion.wiki.integration.utils;

import com.polarion.alm.tracker.model.IWikiPage;
import com.polarion.wiki.integration.link.ILink;

public class PageQueryUtils {

    public static String modifyQueryFields(String query) {
        if (query != null) {
            query = query.replaceAll("page:", "pageName:"); //$NON-NLS-1$ //$NON-NLS-2$
            query = query.replaceAll("project:", "project.id:"); //$NON-NLS-1$ //$NON-NLS-2$
            query = query.replaceAll("space:", "space.id:"); //$NON-NLS-1$ //$NON-NLS-2$
            query = query.replaceAll("updated:", "updated:"); //$NON-NLS-1$ //$NON-NLS-2$
            query = query.replaceAll("created:", "created:"); //$NON-NLS-1$ //$NON-NLS-2$
            query = query.replaceAll("updatedby:", "updatedBy.id:"); //$NON-NLS-1$ //$NON-NLS-2$
            query = query.replaceAll("createdby:", "author.id:"); //$NON-NLS-1$ //$NON-NLS-2$
        }
        return query;
    }

    public static String modifySortFields(String sortBy) {
        if (sortBy != null)
        {
            if (sortBy.equalsIgnoreCase(ILink.PAGE_NAME)) {
                sortBy = IWikiPage.KEY_PAGENAME;
            } else if (sortBy.equalsIgnoreCase(ILink.PAGE_TITLE)) {
                sortBy = IWikiPage.KEY_TITLE;
            } else if (sortBy.equalsIgnoreCase(ILink.PAGE_UPDATED)) {
                sortBy = IWikiPage.KEY_UPDATED;
            } else if (sortBy.equalsIgnoreCase(ILink.PAGE_CREATED)) {
                sortBy = IWikiPage.KEY_CREATED;
            } else if (sortBy.equalsIgnoreCase("~" + ILink.PAGE_NAME)) { //$NON-NLS-1$
                sortBy = "~" + IWikiPage.KEY_PAGENAME; //$NON-NLS-1$
            } else if (sortBy.equalsIgnoreCase("~" + ILink.PAGE_TITLE)) { //$NON-NLS-1$
                sortBy = "~" + IWikiPage.KEY_TITLE; //$NON-NLS-1$
            } else if (sortBy.equalsIgnoreCase("~" + ILink.PAGE_UPDATED)) { //$NON-NLS-1$
                sortBy = "~" + IWikiPage.KEY_UPDATED; //$NON-NLS-1$
            } else if (sortBy.equalsIgnoreCase("~" + ILink.PAGE_CREATED)) { //$NON-NLS-1$
                sortBy = "~" + IWikiPage.KEY_CREATED; //$NON-NLS-1$
            }
        }
        return sortBy;
    }

}
