package com.polarion.wiki.integration.link;

/**
 * Structure for save field from macros and value 
 */
public class WorkItemField
{
    private String name = "";
    private String value = "";

    public WorkItemField(String name, String value)
    {
        this.name = name;
        this.value = value;
    }

    public String getName()
    {
        return name;
    }

    public String getValue()
    {
        return value;
    }
}
