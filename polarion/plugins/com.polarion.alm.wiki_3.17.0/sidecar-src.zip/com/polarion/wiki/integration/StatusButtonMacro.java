/*
 * Copyright (C) 2004-2013 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2013 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.Date;
import java.util.LinkedHashMap;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.tracker.model.IStatusOpt;
import com.polarion.portal.server.HTMLBuilder;
import com.polarion.portal.shared.wiki.WikiMacro;
import com.polarion.reina.web.shared.JSSharedUtil;
import com.xpn.xwiki.XWikiContext;

public abstract class StatusButtonMacro extends XWikiGwtMacro {

    @NotNull
    private final String macroId;

    public StatusButtonMacro(@NotNull String macroId) {
        super();
        this.macroId = macroId;
    }

    @Override
    @NotNull
    protected String getMacroId() {
        return macroId;
    }

    private class Data extends MacroData {

        //@Nullable
        final Scope scope;

        Data(@NotNull MacroParameter inputParameters) {
            super(inputParameters);
            WikiMacro macro = reconstructMacro(macroText);
            scope = getScope(macro.getName(), getParsedParameters(macro), wikiContext);
        }
    }

    @Override
    public void execute(Writer writer, MacroParameter parameters) throws IllegalArgumentException, IOException {
        new DataRenderer(new Data(parameters)).render(writer);
    }

    class DataRenderer extends MacroDataRenderer<Data> {
        DataRenderer(final Data data) {
            super(data);
        }

        @Override
        protected boolean hasErrors() {
            return data.scope == null;
        }

        @Override
        protected void renderErrors(@NotNull HTMLBuilder builder) {
            renderTargetNotAvailable(builder);
        }

        @Override
        protected void renderStatical(@NotNull HTMLBuilder builder) {
            builder.appendHTML(renderState(data.scope));
        }

        @Override
        protected void renderDynamical(@NotNull HTMLBuilder builder) {
            renderMacro(builder, data.scope.macro);
        }

    }

    private static String renderState(@NotNull Scope scope) {
        return "<table width=\"100%\" border=\"0\"><tr><td  align=\"center\"><div class=\"polarion-StatusButtonExtension-buttons polarion-StatusButtonExtension-buttons-isFirst polarion-StatusButtonExtension-buttons-isLast\" style=\"cursor: Auto; color: rgb(94, 94, 94); text-shadow: 1px 1px rgb(255, 244, 204); border-color: rgb(94, 94, 94); background: rgb(250, 250, 250); width: 100px;\"><table cellspacing=\"0\" cellpadding=\"0\" style=\"width: 100%; height: 100%; table-layout:fixed;\"><tbody><tr><td align=\"center\" height=\"65%\" style=\"vertical-align: bottom;\"><div class=\"polarion-StatusButtonExtension-buttons-labelText\" style=\"font-size: 12px; color: rgb(94, 94, 94); text-shadow: 1px 1px rgb(255, 244, 204);\">" //$NON-NLS-1$
                + scope.statusName
                + "</div></td></tr><tr><td align=\"center\" style=\"vertical-align: middle;\"><div class=\"polarion-StatusButtonExtension-buttons-dateText\" style=\"color: rgb(94, 94, 94); text-shadow: 1px 1px rgb(255, 244, 204);\">" //$NON-NLS-1$
                + JSSharedUtil.formatDateAndTime(scope.finishedOn)
                + "</div></td></tr></tbody></table></div></td></tr></table>"; //$NON-NLS-1$
    }

    public class Scope {
        @NotNull
        private final WikiMacro macro;
        @NotNull
        private final String statusName;
        @Nullable
        private final Date finishedOn;

        public Scope(@NotNull String name, @NotNull LinkedHashMap<String, String> parameters, @Nullable IStatusOpt status, @Nullable Date finishedOn) {
            macro = new WikiMacro(name, parameters);
            statusName = status == null ? "" : status.getName(); //$NON-NLS-1$
            this.finishedOn = finishedOn;
        }
    }

    @Nullable
    protected abstract Scope getScope(@NotNull String name, @NotNull LinkedHashMap<String, String> parameters, @NotNull XWikiContext context);

    private void renderTargetNotAvailable(@NotNull HTMLBuilder builder) {
        builder.clear();
        renderError(builder, getTargetNotAvailableMessage());
    }

    @NotNull
    protected abstract String getTargetNotAvailableMessage();

}
