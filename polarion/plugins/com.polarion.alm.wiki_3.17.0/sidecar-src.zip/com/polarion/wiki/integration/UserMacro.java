package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.Collection;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.integration.utils.UserMacroParser;
import com.xpn.xwiki.XWikiContext;

/**
 * {user: username}
 * username =  username or @logged_user
 * other parameters: (In future, not for v.1)
 * display=short(default)|long
 * expand=yes|no(default)
 * fields
 * 
 * @author Michal Antolik
 *
 */
public class UserMacro extends BaseLocaleMacro {

    final private MacroUtils utils = MacroUtils.getInstance();

    @Override
    public void execute(Writer writer, MacroParameter parameters)
            throws IllegalArgumentException, IOException {

        Collection<String> col = utils.getParameters(parameters);
        String macroText = utils.buildMacroTextFromParameters("user", col);

        XWikiContext context = utils.getXWikiContext(parameters);
        UserMacroParser parser = new UserMacroParser(utils.getXWikiContext(parameters));
        String result = null;

        String pdf = (String) context.get("pdf_generate");
        if (pdf == null || pdf.equalsIgnoreCase("0")) {
            result = parser.parse(col, macroText, false);
        } else {
            result = parser.parse(col, macroText, true);
        }
        writer.write(result);

    }

    @Override
    public String getLocaleKey() {
        return "macro.polarionuser";
    }

}
