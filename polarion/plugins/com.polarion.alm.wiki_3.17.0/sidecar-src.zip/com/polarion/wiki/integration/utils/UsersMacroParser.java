package com.polarion.wiki.integration.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.polarion.alm.projects.model.IProject;
import com.polarion.alm.projects.model.IUser;
import com.polarion.core.util.logging.Logger;
import com.polarion.platform.core.PlatformContext;
import com.polarion.platform.persistence.model.IPObject;
import com.polarion.platform.security.ISecurityService;
import com.polarion.reina.web.shared.localization.Localization;
import com.polarion.subterra.base.data.identification.IContextId;
import com.polarion.wiki.integration.utils.MacroUtils.FieldProperty;
import com.xpn.xwiki.XWikiContext;

public class UsersMacroParser extends MacroParser {

    private static final Logger log = Logger.getLogger(UsersMacroParser.class);

    final static private MP[] rule1 = {
            MP.QUERY, MP.PROJECT, MP.ROLES, MP.DISPLAY_LIST, MP.EXPAND_YES_NO, MP.FIELDS, MP.TOP, MP.SORTBY, MP.WIDTH, MP.HEIGHT, MP.LINK
    };
    final static private MP[] rule2 = {
            MP.QUERY, MP.PROJECT, MP.ROLES, MP.DISPLAY_TABLE, MP.EXPAND_YES_NO, MP.FIELDS, MP.TOP, MP.SORTBY, MP.WIDTH, MP.HEIGHT, MP.LINK
    };
    final static private MP[] rule3 = {
            MP.QUERY, MP.PROJECT, MP.ROLES, MP.DISPLAY_COUNT, MP.LINK
    };
    final static private MP[] rule4 = {
            MP.QUERY, MP.GROUP, MP.ROLES, MP.DISPLAY_LIST, MP.EXPAND_YES_NO, MP.FIELDS, MP.TOP, MP.SORTBY, MP.WIDTH, MP.HEIGHT, MP.LINK
    };
    final static private MP[] rule5 = {
            MP.QUERY, MP.GROUP, MP.ROLES, MP.DISPLAY_TABLE, MP.EXPAND_YES_NO, MP.FIELDS, MP.TOP, MP.SORTBY, MP.WIDTH, MP.HEIGHT, MP.LINK
    };
    final static private MP[] rule6 = {
            MP.QUERY, MP.GROUP, MP.ROLES, MP.DISPLAY_COUNT, MP.LINK
    };

    static final private List<MP[]> rules = new ArrayList<MP[]>();
    static final ISecurityService securityService = (ISecurityService) PlatformContext.getPlatform().lookupService(ISecurityService.class);

    static {
        rules.add(rule1);
        rules.add(rule2);
        rules.add(rule3);
        rules.add(rule4);
        rules.add(rule5);
        rules.add(rule6);
    }

    static final private Set<MP> uniqueParameters = getUniqueParameters(rules);

    public UsersMacroParser(XWikiContext context) {
        super(context, rules, uniqueParameters);
    }

    @Override
    @SuppressWarnings("unchecked")
    public String parse(Collection<String> col, String macroText, boolean forPdf) {
        this.col = col;
        this.macroText = macroText;
        this.forPdf = forPdf;

        try {
            utils.addDefaultParameter(MP.DISPLAY_TABLE.getName(), "table", col); //$NON-NLS-1$

            String err = parseParameters();
            if (err != null) {
                return err;
            }

            boolean withLink = utils.showLink(map);

            String query = map.get(MP.QUERY);
            if (query.matches("(\\s)*@all(\\s)*")) { //$NON-NLS-1$
                query = ""; //$NON-NLS-1$
            }

            List<IPObject> tmp = null;
            List<IPObject> list = null;
            IProject project = null;
            IContextId contextId = null;

            if (map.containsKey(MP.PROJECT)) {
                String projectId = map.get(MP.PROJECT);
                project = utils.getProject(projectId, errors);
                if (project == null) {
                    return renderer.renderErrors(errors, macroText, forPdf);
                }
                tmp = projectService.searchProjectUsers(project, query, map.get(MP.SORTBY));
                contextId = project.getContextId();
            } else if (map.containsKey(MP.GROUP)) {
                if (!map.get(MP.GROUP).equals("/")) { //$NON-NLS-1$
                    return renderer.renderError(Localization.getString("macro.general.notSupportedGroupParameter"), Localization.getString("macro.general.searchingUsersInProjectGroup", "group=/"), macroText, forPdf); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
                }
                tmp = projectService.searchUsers(query, map.get(MP.SORTBY));
            } else if ((project = utils.getCurrentProject(context)) != null) {
                tmp = projectService.searchProjectUsers(project, query, map.get(MP.SORTBY));
                contextId = project.getContextId();
            } else {
                //search all system users
                tmp = projectService.searchUsers(query, map.get(MP.SORTBY));
            }

            if (map.containsKey(MP.ROLES)) {
                list = filterRoles(tmp, contextId, map.get(MP.ROLES));
            } else {
                list = tmp;
            }

            int originalListSize = list.size();
            if (!map.containsKey(MP.DISPLAY_COUNT)) {
                list = utils.getTopItems(list, map.get(MP.TOP), 50);
            }

            Map<String, FieldProperty> fields = fieldParser.getUserFields(map, errors);
            if (!errors.isEmpty()) {
                return renderer.renderErrors(errors, macroText, forPdf);
            }

            if (map.containsKey(MP.DISPLAY_LIST)) {
                return renderer.renderListOfPObjects(list,
                        fields,
                        utils.getExpandMode(map),
                        utils.getPolarionServerURL(context),
                        contextId,
                        utils.getWidth(map),
                        utils.getHeight(map),
                        forPdf,
                        withLink,
                        context
                        );
            } else if (map.containsKey(MP.DISPLAY_COUNT)) {
                return renderer.getRenderedCount(originalListSize, forPdf, null);
            } else if (map.containsKey(MP.DISPLAY_TABLE)) {
                return renderer.renderFlatTable(
                        fields,
                        macroText,
                        list,
                        originalListSize,
                        query,
                        null,
                        context,
                        contextId,
                        utils.getExpandMode(map),
                        utils.getWidth(map),
                        utils.getHeight(map),
                        forPdf,
                        withLink
                        );
            } else {
                return Localization.getString("macro.general.noDisplayParameter"); //shouldn't happen //$NON-NLS-1$
            }
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            errors.put("Error", Localization.getString("macro.general.parsingUnknownException") + e.getLocalizedMessage()); //$NON-NLS-1$ //$NON-NLS-2$
            return renderer.renderErrors(errors, macroText, forPdf);
        }
    }

    @SuppressWarnings("unchecked")
    private List<IPObject> filterRoles(List<IPObject> tmp, IContextId contextId, String strRoles)
    {
        List<IPObject> list = new ArrayList<IPObject>();
        String[] roles = strRoles.split("(\\s)*,(\\s)*"); //$NON-NLS-1$
        Arrays.sort(roles);
        for (IPObject obj : tmp) {
            IUser user = (IUser) obj;
            Collection<String> userRoles = securityService.getRolesForUser(user.getId(), contextId != null ? contextId : user.getContextId());
            boolean found = false;
            for (String role : userRoles) {
                found = (Arrays.binarySearch(roles, role) >= 0);
                if (found) {
                    break;
                }
            }
            if (found) {
                list.add(obj);
            }
        }

        return list;
    }
}
