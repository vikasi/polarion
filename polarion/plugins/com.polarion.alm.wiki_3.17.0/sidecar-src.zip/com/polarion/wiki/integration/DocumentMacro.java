package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.Collection;
import java.util.Iterator;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.integration.utils.ModuleMacroParser;
import com.xpn.xwiki.XWikiContext;

public class DocumentMacro extends BaseLocaleMacro {

    final private MacroUtils utils = MacroUtils.getInstance();

    @Override
    public void execute(Writer writer, MacroParameter parameters)
            throws IllegalArgumentException, IOException {

        XWikiContext context = utils.getXWikiContext(parameters);
        String name = utils.getDefaultParameter("name", parameters);
        Collection<String> col = utils.getParameters(parameters);
        ;
        if (name != null && !name.contains("/")) {
            String space = context.getDoc().getSpaceName();
            String toAdd = null;
            for (Iterator iterator = col.iterator(); iterator.hasNext();) {
                String param = (String) iterator.next();
                if (param != null && (param.startsWith("name=") || !param.contains("="))) {
                    toAdd = param.replaceAll(name, space + "/" + name);
                    iterator.remove();
                }
            }
            if (toAdd != null) {
                col.add(toAdd);
            }
        }

        String macroText = utils.buildMacroTextFromParameters("document", col);

        ModuleMacroParser parser = new ModuleMacroParser(context);
        String result = null;

        String pdf = (String) context.get("pdf_generate");
        if (pdf == null || pdf.equalsIgnoreCase("0")) {
            result = parser.parse(col, macroText, false);
        } else {
            result = parser.parse(col, macroText, true);
        }
        writer.write(result);

    }

    @Override
    public String getLocaleKey() {
        return "macro.polariondocument";
    }
}
