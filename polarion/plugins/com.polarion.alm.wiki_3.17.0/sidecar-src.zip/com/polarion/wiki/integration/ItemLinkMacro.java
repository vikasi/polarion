package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.Calendar;
import java.util.Map;

import org.apache.velocity.VelocityContext;
import org.radeox.api.engine.RenderEngine;
import org.radeox.api.engine.context.RenderContext;
import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.core.util.logging.Logger;
import com.polarion.wiki.integration.link.ILink;
import com.polarion.wiki.integration.link.WorkItemLink;
import com.polarion.wiki.util.RequestParser;
import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.api.WorkItem;
import com.xpn.xwiki.render.XWikiRadeoxRenderEngine;

public class ItemLinkMacro extends BaseLocaleMacro {
    static Logger log = Logger.getLogger(ItemLinkMacro.class);

    /**
     * {wi:WI-246} Link to WI in the same project like Wiki space
     * 
     * {wi:My WorkItem|WI-246} Link to WI in the same project like Wiki space
     * 
     * {wi:project1/WI-246} Link to WI in different project then the Wiki space
     * 
     * {wi:My WorkItem|project1/WI-246}
     */
    @Override
    public void execute(Writer writer, MacroParameter params) throws IllegalArgumentException, IOException {
        try {

            RenderContext context = params.getContext();
            RenderEngine engine = context.getRenderEngine();
            XWikiContext xcontext = ((XWikiRadeoxRenderEngine) engine).getContext();

            WorkItemLink workItemLink = new WorkItemLink(params, xcontext);
            Map requestParams = RequestParser.parseQuery(XWiki.getRequestURL(xcontext.getRequest()).toString(), xcontext);
            String currentProject = (String) requestParams.get("project");

            workItemLink.setCurrentProject(currentProject);

            try {
                writer.write(getLinkItem(workItemLink, xcontext));
            } catch (Exception e) {
                log.error("Exception in ItemLinkMacro while write plugin answer: " + e.getMessage());
            }
        } catch (Exception e) {
            log.error("Exception in ItemLinkMacro: " + e.getMessage());
        }

        return;
    }

    /**
     * 
     * @param workItemLink
     * @return HTML code for page and this code load workitems use ajax
     * @throws Exception
     */
    public String getLinkItem(WorkItemLink workItemLink, XWikiContext context) throws Exception {

        if (workItemLink.getOutputType().equalsIgnoreCase(ILink.FIELD_OUTPUT_COUNT)) {
            return getCountLink(workItemLink, context);
        }

        String pdf = (String) context.get("pdf_generate");
        if (pdf == null || pdf.equalsIgnoreCase("0")) {
            return getAjaxLink(workItemLink, context);
        }
        else
        {
            return getPdfLink(workItemLink, context);
        }
    }

    private String getAjaxLink(WorkItemLink workItemLink, XWikiContext context) {
        //PBO modify to ajax
        String url = context.getURL().getPath();
        url = url.substring(0, url.indexOf("bin/") + 4) + "loadwi" + url.substring(url.indexOf("/", url.indexOf("bin/") + 4), url.length());
        // generate unik name(id) for tables
        String unic_name = IntegrationPlugin.getUniqName();
        String display = workItemLink.getDisplay();

        String res = (!display.equalsIgnoreCase("link") ? "<p></p>" : "") + "<img alt=\"\" src=\"" + context.getWiki().getSkinFile("progress_small.gif", context) + "\"/><" + (!display.equalsIgnoreCase("link") ? "div" : "font")
                + " style=\"visibility: hidden;\" id=\"" + unic_name + "\"><script type=\"text/javascript\">" +
                "function " + unic_name + "() " +
                "{" +
                "loadWorkItemsList('" + url + "','" + workItemLink.createURLParam().replaceAll("&#35;", "#") + "','" + unic_name + "');" +
                "}" +
                "runItem.push('" + unic_name + "');" +
                "</script></" + (!display.equalsIgnoreCase("link") ? "div" : "font") + ">" +
                "<" + (!display.equalsIgnoreCase("link") ? "div" : "font") + " id=\"wi_hd_" + unic_name + "\" style=\"display: none;\">" +
                "loadWorkItemsList('" + url + "','" + workItemLink.createURLParam() + "','" + unic_name + "');" +
                "</" + (!display.equalsIgnoreCase("link") ? "div" : "font") + ">";
        return res;
    }

    private String getPdfLink(WorkItemLink workItemLink, XWikiContext context) {
        StringBuffer buff = new StringBuffer();

        Calendar cl = Calendar.getInstance();
        long id = cl.getTimeInMillis() + IntegrationPlugin.getUniqID();

        WorkItem item = new WorkItem(workItemLink, context, id);
        item.setId(id);

        VelocityContext vcontext = (VelocityContext) context.get("vcontext");
        context.put("workitem", item);
        vcontext.put("workitem", item.newItem(workItemLink, context, id));

        buff.append(context.getWiki().parseTemplate("xworkitemviewpdf.vm", context));
        return buff.toString();
    }

    private String getCountLink(WorkItemLink workItemLink, XWikiContext context) {
        int count = -1;
        String href = "";
        StringBuffer sbuf = new StringBuffer();
        WorkItem wi = new WorkItem(workItemLink, context, 0);
        try
        {
            count = wi.getWorkItemsCount();
            href = wi.getWorkItemMore();
        } catch (Exception e)
        {
            log.error(e);
        }

        sbuf.append("<a target=\"_blank\" title=\"");
        if (count >= 0) {
            sbuf.append(wi.getQueryProject());
            sbuf.append(workItemLink.getQuery());
        } else {
            sbuf.append("Error: Invalid project/query");
        }
        sbuf.append("\" href=\"");
        sbuf.append(href);
        sbuf.append("\">");
        if (count >= 0) {
            sbuf.append(count);
        } else {
            sbuf.append("<span style=\"color: red\">0</span>");
        }
        sbuf.append("</a>");

        return sbuf.toString();
    }

    @Override
    public String getLocaleKey() {
        return "macro.polarionitemlink";
    }

}
