/*
 * Copyright (C) 2004-2011 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2011 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.Map;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.google.inject.Inject;
import com.polarion.alm.tracker.ITestManagementPolicy;
import com.polarion.alm.tracker.ITestManagementService;
import com.polarion.alm.ui.server.wiki.macro.MacroContext;
import com.polarion.alm.ui.server.wiki.macro.impl.PlainMacroImpl;
import com.polarion.alm.ui.server.wiki.testrunlabel.TestrunLabelParameters;
import com.polarion.alm.ui.server.wiki.testrunlabel.TestrunLabelParametersRenderer;
import com.polarion.core.util.logging.Logger;
import com.polarion.platform.guice.internal.GuicePlatform;
import com.polarion.reina.web.shared.localization.Localization;
import com.polarion.wiki.integration.utils.MacroParameterValidationContextXWikiImpl;
import com.polarion.wiki.integration.utils.MacroRenderer;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.xpn.xwiki.XWikiContext;

public class TestrunLabelMacro extends BaseLocaleMacro {
    private static final String MACRO_ID = "macro.testrun-label"; //$NON-NLS-1$
    private static final String MACRO_STRING = "testrun-label"; //$NON-NLS-1$

    private static final MacroRenderer renderer = MacroRenderer.getInstance();
    private ITestManagementPolicy policy;

    private static class Data {
        public MacroContext context;
        public MacroParameter params;
        public TestrunLabelParameters parameters;
    }

    @SuppressWarnings("deprecation")
    public TestrunLabelMacro() {
        super();
        GuicePlatform.getGlobalInjector().injectMembers(this);
    }

    @Inject
    public void setTestingService(ITestManagementService testingService) {
        policy = testingService.getPolicy();
    }

    @Override
    public String getLocaleKey() {
        return getMacroId();
    }

    protected String getMacroId() {
        return MACRO_ID;
    }

    @Override
    public void execute(final Writer writer, final MacroParameter params) throws IllegalArgumentException, IOException {
        XWikiContext<?, ?> xWikiContext = null;
        Data data = new Data();
        try {
            if (!policy.canUseTestManagement()) {
                writer.write(renderer.renderInaccessibleMessage(true, false));
                return;
            }
            data.params = params;
            xWikiContext = MacroUtils.getInstance().getXWikiContext(params);
            data.context = new MacroParameterValidationContextXWikiImpl(xWikiContext);
            data.parameters = new TestrunLabelParameters(data.context, new PlainMacroImpl(getMacroText(data)));
            if (!data.parameters.hasPermissions()) {
                writer.write(renderer.renderInaccessibleMessage(false, true));
                return;
            }

            Map<String, String> errors = data.parameters.validate();
            if (!errors.isEmpty()) {
                writer.write(renderer.renderErrors(errors, getMacroTextForErrors(data), MacroUtils.getInstance().isPdfExport(xWikiContext)));
                return;
            }

            writer.write(MacroUtils.getInstance().escapeValue(new TestrunLabelParametersRenderer(data.parameters).render()));
        } catch (Exception e) {
            Logger.getLogger(this).error("Exception in rendering the testrun-label macro: ", e); //$NON-NLS-1$
            boolean pdfExport = xWikiContext == null ? false : MacroUtils.getInstance().isPdfExport(xWikiContext);
            writer.write(renderer.renderError("Error", Localization.getString("macro.exception", MACRO_STRING), getMacroTextForErrors(data), pdfExport)); //$NON-NLS-1$//$NON-NLS-2$
        }
    }

    private String getMacroText(Data data) {
        return MacroUtils.getInstance().buildMacroTextFromParametersSimple(MACRO_STRING, MacroUtils.getInstance().getParameters(data.params));
    }

    private String getMacroTextForErrors(Data data) {
        return MacroUtils.getInstance().buildMacroTextFromParameters2(MACRO_STRING, data.params);
    }
}
