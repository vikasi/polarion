package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.tracker.model.ITestRun;
import com.polarion.alm.ui.server.tracker.AbstractModulePageLayouter;
import com.polarion.alm.ui.server.wiki.macro.MacroContext;
import com.polarion.alm.ui.server.wiki.macro.MacroValidationResults;
import com.polarion.alm.ui.server.wiki.macro.impl.PlainMacroParameterImpl;
import com.polarion.alm.ui.server.wiki.macro.parameters.MacroParameterFactory;
import com.polarion.alm.ui.server.wiki.macro.parameters.TestRunParameter;
import com.polarion.alm.ui.shared.FieldRenderType;
import com.polarion.alm.ui.shared.wiki.ParameterNames;
import com.polarion.core.util.ObjectUtils;
import com.polarion.portal.server.HTMLBuilder;
import com.polarion.portal.server.PObjectDataProvider;
import com.polarion.portal.shared.IJSUIObject;
import com.polarion.reina.web.shared.html.IHTMLBuilder;
import com.polarion.reina.web.shared.localization.Localization;
import com.polarion.reina.web.shared.renderers.JSRendererFactory;
import com.polarion.wiki.integration.utils.MacroParameterValidationContextXWikiImpl;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.util.Constants;
import com.xpn.xwiki.XWikiContext;

public class TestRunPropertyMacro extends BaseLocaleMacro {

    private MacroUtils utils = MacroUtils.getInstance();

    @Override
    public String getLocaleKey() {
        return "macro.testrun.property"; //$NON-NLS-1$
    }

    @Override
    public void execute(Writer writer, MacroParameter params) throws IllegalArgumentException, IOException {
        String property = null;
        String projectAndId = null;
        if (params.getLength() == 0) {
            utils.renderError(Localization.getString("macro.testrun-property.wrongParameters"), writer); //$NON-NLS-1$
            return;

        } else if (params.getLength() == 1) {
            property = params.get(0);
        } else {
            projectAndId = params.get(0);
            property = params.get(1);
            Map<String, String> map = params.getParams();
            if (map.containsKey(ParameterNames.TESTRUN1)) {
                projectAndId = map.get(ParameterNames.TESTRUN1);
            }
            if (map.containsKey(ParameterNames.PROPERTY)) {
                property = map.get(ParameterNames.PROPERTY);
            }
            if (ParameterNames.VALUE_CURRENT.equals(projectAndId)) {
                projectAndId = null;
            }
        }
        if (property != null) {
            XWikiContext context = MacroUtils.getInstance().getXWikiContext(params);
            renderProperty(projectAndId, property, writer, context);
        } else {
            utils.renderError(Localization.getString("macro.testrun-property.wrongParameters"), writer); //$NON-NLS-1$
            return;
        }
    }

    public static ITestRun getTestRun(String projectAndId, XWikiContext context) {
        return getTestRun(projectAndId, new MacroParameterValidationContextXWikiImpl(context));
    }

    private static ITestRun getTestRun(String projectAndId, MacroContext context) {
        MacroParameterFactory parameterFactory = new MacroParameterFactory(context);
        TestRunParameter testRunParameter = parameterFactory.testRunParameterRequired(new PlainMacroParameterImpl("", projectAndId)); //$NON-NLS-1$
        MacroValidationResults validate = testRunParameter.validate();
        if (!validate.isOK()) {
            return null;
        } else {
            return testRunParameter.getValue();
        }
    }

    private void renderProperty(String projectAndId, String property, Writer writer, XWikiContext context) throws IOException {
        if (ObjectUtils.emptyString(projectAndId) && !Constants.TEST_RUNS.equals(context.getDoc().getSpaceName())) {
            utils.renderError(Localization.getString("macro.testrun-property.pleaseSpecifyTestRun"), writer); //$NON-NLS-1$
            return;
        }
        ITestRun testRun = getTestRun(projectAndId, context);
        if (testRun.isUnresolvable()) {
            utils.renderError(Localization.getString("macro.testrun-property.testRunDoesNotExist"), writer); //$NON-NLS-1$
            return;
        }
        FieldRenderType type = AbstractModulePageLayouter.resolveFieldRenderType(property);
        property = AbstractModulePageLayouter.resolveIdWithoutRenderType(property);

        if (testRun.getValue(property) == null) {
            return;
        }
        List<String> fields = new ArrayList<String>();
        fields.add(property);
        IJSUIObject transformed = PObjectDataProvider.transformInstance(testRun, fields, false, null, null, true, false, null);

        IHTMLBuilder builder = new HTMLBuilder(true);
        Object value = transformed.getValue(property);
        if (type != null) {
            JSRendererFactory.getInstance().render(builder, value, true, false, type.getRenderStyle());
        } else {
            JSRendererFactory.getInstance().render(builder, value, true, false);
        }
        writer.write(builder.toString().trim());
    }
}
