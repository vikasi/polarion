/*
 * Copyright (C) 2004-2011 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2011 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.tracker.ITestManagementService;
import com.polarion.alm.tracker.ITrackerService;
import com.polarion.alm.tracker.model.ITestRun;
import com.polarion.alm.tracker.model.IWorkItem;
import com.polarion.alm.ui.shared.wiki.ParameterNames;
import com.polarion.core.util.ObjectUtils;
import com.polarion.platform.guice.internal.GuicePlatform;
import com.polarion.portal.server.HTMLBuilder;
import com.polarion.reina.web.shared.html.HTMLConst;
import com.polarion.reina.web.shared.html.IHTMLBuilder;
import com.polarion.reina.web.shared.localization.Localization;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.util.Constants;
import com.xpn.xwiki.XWikiContext;

/**
 * @author Jiri Banszel
 */
public class ImportAutomatedTestResultsMacro extends BaseLocaleMacro {

    private static final String PARAMETER_MAX_CREATED_DEFECTS = "max-created-defects"; //$NON-NLS-1$
    private static final String PARAMETER_MAX_CREATED_DEFECTS_PERCENT = "max-created-defects-percent"; //$NON-NLS-1$
    private static final String PARAMETER_TEMPLATE_TEST_CASE_ID = "template-testcase"; //$NON-NLS-1$
    private static final String PARAMETER_TEMPLATE_DEFECT_ID = "template-defect"; //$NON-NLS-1$

    private ITrackerService trackerService;
    private ITestManagementService service;

    final private MacroUtils utils = MacroUtils.getInstance();

    @SuppressWarnings("deprecation")
    public ImportAutomatedTestResultsMacro() {
        GuicePlatform.getGlobalInjector().injectMembers(this);
    }

    @Inject
    public void setTrackerService(ITrackerService trackerService) {
        this.trackerService = trackerService;
    }

    @Inject
    public void setService(ITestManagementService service) {
        this.service = service;
    }

    @Override
    public String getLocaleKey() {
        return "macro.import-automated-test-results"; //$NON-NLS-1$
    }

    @Override
    public void execute(Writer writer, MacroParameter params) throws IllegalArgumentException, IOException {
        @SuppressWarnings("unchecked")
        Map<String, String> map = params.getParams();

        String testRunProjectAndId = map.get(ParameterNames.TESTRUN1);
        String templateDefectId = map.get(PARAMETER_TEMPLATE_DEFECT_ID);
        String templateTestCaseId = map.get(PARAMETER_TEMPLATE_TEST_CASE_ID);
        String maxCreatedDefects = map.get(PARAMETER_MAX_CREATED_DEFECTS);
        String maxCreatedDefectsPercent = map.get(PARAMETER_MAX_CREATED_DEFECTS_PERCENT);

        @SuppressWarnings("rawtypes")
        XWikiContext context = MacroUtils.getInstance().getXWikiContext(params);

        if (ObjectUtils.emptyString(testRunProjectAndId) && !Constants.TEST_RUNS.equals(context.getDoc().getSpaceName())) {
            utils.renderError(Localization.getString("macro.import-automated-test-results.pleaseSpecifyTestRun"), writer); //$NON-NLS-1$
            return;
        }
        ITestRun testRun = TestRunPropertyMacro.getTestRun(testRunProjectAndId, context);
        if (testRun.isUnresolvable()) {
            utils.renderError(Localization.getString("macro.import-automated-test-results.testRunDoesNotExist"), writer); //$NON-NLS-1$
            return;
        }

        if (templateDefectId != null) {
            IWorkItem templateDefect = ImportTestResultsMacro.getWorkItem(trackerService, templateDefectId, testRun.getProject());
            if (templateDefect == null || templateDefect.isUnresolvable()) {
                utils.renderError(Localization.getString("macro.import-automated-test-results.templateDefectDoesNotExist"), writer); //$NON-NLS-1$
                return;
            }
        }

        if (templateTestCaseId != null) {
            IWorkItem templateTestCase = ImportTestResultsMacro.getWorkItem(trackerService, templateTestCaseId, testRun.getProject());
            if (templateTestCase == null || templateTestCase.isUnresolvable()) {
                utils.renderError(Localization.getString("macro.import-automated-test-results.templateTestCaseDoesNotExist"), writer); //$NON-NLS-1$
                return;
            }
        }

        if (maxCreatedDefects != null) {
            try {
                Integer.parseInt(maxCreatedDefects);
            } catch (NumberFormatException e) {
                utils.renderError(Localization.getString("macro.import-automated-test-results.invalidParameter", PARAMETER_MAX_CREATED_DEFECTS), writer); //$NON-NLS-1$
                return;
            }
        }

        if (maxCreatedDefectsPercent != null) {
            try {
                Integer.parseInt(maxCreatedDefectsPercent);
            } catch (NumberFormatException e) {
                utils.renderError(Localization.getString("macro.import-automated-test-results.invalidParameter", PARAMETER_MAX_CREATED_DEFECTS_PERCENT), writer); //$NON-NLS-1$
                return;
            }
        }

        String projectAndTestRunId = testRun.getProject().getId() + "/" + testRun.getId(); //$NON-NLS-1$
        writer.write(createImportButton(disabledReason(testRun, context), projectAndTestRunId, templateDefectId, templateTestCaseId, maxCreatedDefects, maxCreatedDefectsPercent));
    }

    private String createImportButton(String disabledReason, String projectAndTestRunId, String templateDefectId, String templateTestCaseId, String maxCreatedDefects, String maxCreatedDefectsPercent) {
        IHTMLBuilder builder = new HTMLBuilder();

        String params;
        String textColor;
        if (disabledReason == null) {
            List<String> args = Arrays.asList(projectAndTestRunId, templateDefectId, templateTestCaseId, maxCreatedDefects, maxCreatedDefectsPercent);
            String onclick = utils.buildJSCall("top.importAutomatedTestResults", args); //$NON-NLS-1$
            params = "onclick=\"" + utils.escapeValue(builder.escapeForAttribute(onclick)) + "\""; //$NON-NLS-1$ //$NON-NLS-2$
            textColor = "rgb(67, 161, 52)"; //$NON-NLS-1$
        } else {
            params = "title=\"" + utils.escapeValue(builder.escapeForAttribute(disabledReason)) + "\""; //$NON-NLS-1$ //$NON-NLS-2$
            textColor = "gray"; //$NON-NLS-1$
        }

        String buttonStyle = "cursor: pointer; display:inline-block; height: 71px; border-radius: 5px; border-style: solid; border-color: #C0C0C0; border-width: 1px; background-repeat:background-repeat:repeat-x; background-image:url('/polarion/ria/images/backgrounds/btn_big.png'); text-align:center;"; //$NON-NLS-1$
        builder.appendElementStart(HTMLConst.TABLE, null, buttonStyle, params);
        builder.appendElementStart(HTMLConst.TR, null, null, null);
        builder.appendElementStart(HTMLConst.TD, null, null, null);
        String textStyle = "white-space:nowrap;padding: 20px 20px 0px 20px; font-size: 26px; font-weight: bold; color: " + textColor + "; font-family: Arial; text-align: center; text-shadow: 1px 1px 0pt white;"; //$NON-NLS-1$ //$NON-NLS-2$
        builder.appendElementStart(HTMLConst.DIV, null, textStyle, null);
        builder.appendText(utils.escapeValue(Localization.getString("macro.import-automated-test-results.label"))); //$NON-NLS-1$
        builder.appendElementEnd(HTMLConst.DIV);

        builder.appendElementStart(HTMLConst.DIV, null, "white-space:nowrap; padding: 10px 20px 0px 20px; font-size: 11px; color: rgb(95, 95, 95); font-family: Arial; text-align: center; text-shadow: 1px 1px 0pt white;", null); //$NON-NLS-1$
        builder.appendText(utils.escapeValue(Localization.getString("macro.import-automated-test-results.sublabel"))); //$NON-NLS-1$
        builder.appendElementEnd(HTMLConst.DIV);

        builder.appendElementEnd(HTMLConst.TD);
        builder.appendElementEnd(HTMLConst.TR);
        builder.appendElementEnd(HTMLConst.TABLE);
        return builder.toString();
    }

    @SuppressWarnings("rawtypes")
    private String disabledReason(ITestRun testRun, XWikiContext context) {
        if (!service.getPolicy().canImportTestResultsFromXUnit()) {
            return Localization.getString("permission.denied.executeTestRun.importXUnit"); //$NON-NLS-1$
        }
        if (!service.getPolicy().canExecuteTestRun(testRun)) {
            return service.getPolicy().getCannotExecuteTestRunReason(testRun);
        }
        if (isCompareOrRevisionView(context)) {
            return Localization.getString("macro.import-test-results.macroCannotBeUsedInHistoryMode"); //$NON-NLS-1$
        }
        return null;
    }

    @SuppressWarnings("rawtypes")
    protected boolean isCompareOrRevisionView(XWikiContext context) {
        String compare = (String) context.get("compareMode"); //$NON-NLS-1$
        String rev = (String) context.get("revision"); //$NON-NLS-1$

        boolean isCompare = "1".equals(compare); //$NON-NLS-1$
        boolean isRevision = rev != null;
        return isCompare || isRevision;
    }

}
