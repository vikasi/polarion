package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.List;
import java.util.Set;

import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;
import org.apache.velocity.context.Context;
import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.wiki.integration.utils.MP;
import com.polarion.wiki.integration.utils.MacroParser;
import com.polarion.wiki.integration.utils.MacroRenderer;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.xpn.xwiki.XWikiContext;

public abstract class VelocityBasedMacro extends BaseLocaleMacro {

    public static class ExtendedMacroParser extends MacroParser {

        public ExtendedMacroParser(
                @SuppressWarnings("rawtypes") XWikiContext context,
                MacroParameter parameter, List<MP[]> rules,
                Set<MP> uniqueParameters, String macroName) {
            super(context, rules, uniqueParameters);

            col = utils.getParameters(parameter);
            macroText = utils.buildMacroTextFromParameters(macroName, col);
        }

        public String getMacroText() {
            return macroText;
        }

        public String getParameter(MP key) {
            return map.get(key);
        }
    }

    protected abstract String getMacroName();

    protected abstract String getTemplateName();

    protected abstract ExtendedMacroParser loadParser(MacroParameter param,
            XWikiContext<?, ?> context);

    protected abstract void initializeContext(Context vcontext,
            XWikiContext<?, ?> context, ExtendedMacroParser parser);

    protected static final MacroUtils utils = MacroUtils.getInstance();

    public VelocityBasedMacro() {
        super();
    }

    @Override
    public void execute(Writer writer, MacroParameter param)
            throws IllegalArgumentException, IOException {

        MacroRenderer renderer = MacroRenderer.getInstance();

        XWikiContext<?, ?> context = utils.getXWikiContext(param);

        ExtendedMacroParser parser = null;
        try {
            parser = loadParser(param, context);

            String parseResult = parser.parseParameters();
            if (parseResult == null) {

                Context vcontext = new VelocityContext();

                initializeContext(vcontext, context, parser);

                vcontext.put("forPdf", utils.isPdfExport(context));

                Reader template = loadTemplate();
                StringWriter resultWriter = new StringWriter();

                try {
                    Velocity.evaluate(vcontext, resultWriter, getLocaleKey(),
                            template);
                    writer.write(resultWriter.toString());
                } catch (Exception e) {
                    writer.write(renderer.renderError(
                            "Unexpected error rendering macro", e.toString(),
                            parser.getMacroText(), utils.isPdfExport(context)));
                }

            } else {
                writer.write(parseResult);
            }
        } catch (Exception e) {
            String macroText = parser != null ? parser.getMacroText() : MacroUtils.getInstance().buildMacroTextFromParameters2(getMacroName(), param);
            writer.write(renderer.renderError(
                    "Unexpected error rendering macro", e.toString(), macroText, utils.isPdfExport(context)));
        }
    }

    private Reader loadTemplate() {
        String templateName = "/velocitymacros/" + getTemplateName();
        Reader template = new InputStreamReader(
                TestRunResultsMacro.class.getResourceAsStream(templateName));
        return template;
    }

}