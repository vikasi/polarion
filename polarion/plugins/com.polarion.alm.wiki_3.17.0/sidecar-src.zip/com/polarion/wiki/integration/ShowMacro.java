/*
 * Copyright (C) 2004-2009 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2009 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.wiki.integration.utils.MacroRenderer;
import com.polarion.wiki.integration.utils.MacroUtils;

/**
 * @author <a href="mailto:dev@polarion.com">Michal Antolik</a>, Polarion Software
 */

public class ShowMacro extends BaseLocaleMacro {

    final private MacroUtils utils = MacroUtils.getInstance();
    final private MacroRenderer renderer = MacroRenderer.getInstance();

    /* (non-Javadoc)
     * @see org.radeox.macro.BaseMacro#execute(java.io.Writer, org.radeox.macro.parameter.MacroParameter)
     */
    @Override
    public void execute(Writer writer, MacroParameter params)
            throws IllegalArgumentException, IOException {
        boolean forPdf = utils.isPdfExport(utils.getXWikiContext(params));
        String content = params.getContent();

        String att = params.get(0);
        if (att != null) {
            if (att.matches("wiki")) {
                if (!forPdf) {
                    writer.write(content);
                }
            } else if (att.matches("pdf")) {
                if (forPdf) {
                    writer.write(content);
                }
            } else if (att.matches("toc") || att.matches("none")) {
                //nothing
            } else {
                writer.write(renderError(forPdf, params));
            }
        } else {
            writer.write(renderError(forPdf, params));
        }
    }

    private String renderError(boolean forPdf, MacroParameter params) {
        Map<String, String> errors = new HashMap<String, String>();
        String macroText = utils.buildMacroTextFromParameters2("show", params);

        errors.put("parameter", "No suitable parameter was used. " +
                "Possibilities are: <b>wiki</b> (visible only for wiki), " +
                "<b>pdf</b> (visible only for pdf), " +
                "<b>toc</b> (visible only for macro &#123;toc&#125;)." +
                "<b>none</b> (unvisible).");
        return renderer.renderErrors(errors, macroText, forPdf);
    }

    /* (non-Javadoc)
     * @see org.radeox.macro.LocaleMacro#getLocaleKey()
     */
    @Override
    public String getLocaleKey() {
        return "macro.show";
    }

}
