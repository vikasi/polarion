package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.projects.model.IUniqueObject;
import com.polarion.alm.tracker.ITrackerService;
import com.polarion.alm.tracker.model.IModule;
import com.polarion.alm.tracker.model.ITrackerProject;
import com.polarion.platform.core.PlatformContext;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.integration.utils.ModuleHelper;

public class ModulePropertyMacro extends BaseLocaleMacro {

//    final private static Logger log = Logger.getLogger(ModulePropertyMacro.class);

    final private static ITrackerService trackerService = (ITrackerService) PlatformContext.getPlatform().lookupService(ITrackerService.class);
    final private MacroUtils utils = MacroUtils.getInstance();

    final private static String MODULE_NAME_PREFIX = "name";
    final private static String MODULE_NAME_PREFIX_OLD = "moduleName";
    final private static String MSG_BAD_PARAMETERS = "Bad Parameters";

    @Override
    public void execute(Writer writer, MacroParameter params) throws IllegalArgumentException, IOException {
        String moduleName = null;
        String property = null;
        if (params.getLength() > 1) {
            moduleName = params.get(0);
            property = params.get(1);
        } else {
            utils.renderError(MSG_BAD_PARAMETERS, writer);
            return;
        }
        if (moduleName != null && property != null) {
            if (moduleName.startsWith(MODULE_NAME_PREFIX)) {
                moduleName = moduleName.substring(MODULE_NAME_PREFIX.length() + 1);
            }
            if (moduleName.startsWith(MODULE_NAME_PREFIX_OLD)) {
                moduleName = moduleName.substring(MODULE_NAME_PREFIX_OLD.length() + 1);
            }
            renderProperty(moduleName, property, writer, params);
        } else {
            utils.renderError(MSG_BAD_PARAMETERS, writer);
            return;
        }
    }

    private void renderProperty(String moduleName, String property, Writer writer, MacroParameter params) throws IOException {
        ITrackerProject project = utils.getCurrentProject(params.getContext());
        ModuleHelper moduleHelper = new ModuleHelper(trackerService, project, moduleName, null);
        IModule module = moduleHelper.getModule();

        String value = null;
        if (IModule.KEY_AUTHOR.equals(property)) {
            value = utils.format(module.getAuthor());
        }
        if (IModule.KEY_CREATED.equals(property)) {
            value = utils.format(module.getCreated());
        }
        if (IModule.KEY_UPDATED.equals(property)) {
            value = utils.format(module.getUpdated());
        }
        if (IModule.KEY_UPDATEDBY.equals(property)) {
            value = utils.format(module.getUpdatedBy());
        }
        if (IModule.KEY_MODULENAME.equals(property)) {
            value = utils.format(module.getModuleName());
        }
        if (IUniqueObject.KEY_PROJECT.equals(property)) {
            value = utils.format(module.getProject());
        }
        if (value == null) {
            value = utils.format(value);
        }
        writer.write(value);
        return;
    }

    @Override
    public String getLocaleKey() {
        return "macro.module-property";
    }
}
