/*
?* Copyright (C) 2004-2013 Polarion Software
?* All rights reserved.
?* Email: dev@polarion.com
?*
?*
?* Copyright (C) 2004-2013 Polarion Software
?* All Rights Reserved.? No use, copying or distribution of this
?* work may be made except in accordance with a valid license
?* agreement from Polarion Software.? This notice must be
?* included on all copies, modifications and derivatives of this
?* work.
?*
?* POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
?* ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
?* INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
?* FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
?* SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
?* OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
?*
?*/
package com.polarion.wiki.integration.plans;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import com.polarion.alm.tracker.model.IPlan;
import com.polarion.alm.ui.server.wiki.macro.MacroContext;
import com.polarion.alm.ui.server.wiki.macro.impl.PlainMacroParameterImpl;
import com.polarion.alm.ui.server.wiki.macro.parameters.MacroParameterFactory;
import com.polarion.alm.ui.server.wiki.macro.parameters.PlanParameterRequired;
import com.polarion.wiki.integration.utils.MacroParameterValidationContextXWikiImpl;
import com.xpn.xwiki.XWikiContext;

public class PlanPropertyMacro {

    @Nullable
    public static IPlan getPlan(@Nullable String projectAndId, @NotNull XWikiContext context) {
        return getPlan(projectAndId, new MacroParameterValidationContextXWikiImpl(context));
    }

    @Nullable
    private static IPlan getPlan(@Nullable String projectAndId, @NotNull MacroContext context) {
        MacroParameterFactory parameterFactory = new MacroParameterFactory(context);
        PlanParameterRequired planParameter = parameterFactory.planParameterRequired(new PlainMacroParameterImpl("", projectAndId), true); //$NON-NLS-1$
        return planParameter.validate().isOK() ? planParameter.getPlan() : null;
    }
}
