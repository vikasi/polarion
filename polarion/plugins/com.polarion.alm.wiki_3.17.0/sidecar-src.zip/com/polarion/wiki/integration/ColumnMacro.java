package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.portal.server.HTMLBuilder;
import com.polarion.reina.web.shared.html.HTMLConst;
import com.polarion.reina.web.shared.html.IHTMLBuilder;
import com.polarion.wiki.integration.utils.MP;
import com.polarion.wiki.integration.utils.MacroRenderer;
import com.polarion.wiki.integration.utils.MacroUtils;

/**
 * {column}
 * {column:width=#|padding=#} default padding is 10 px
 *
 */
public class ColumnMacro extends BaseLocaleMacro {

    final private MacroUtils utils = MacroUtils.getInstance();

    @Override
    public void execute(Writer writer, MacroParameter params) throws IllegalArgumentException, IOException {

        Map<String, String> errors = new HashMap<String, String>();
        StringBuilder cellStyle = new StringBuilder();
        StringBuilder cellAttr = new StringBuilder();

        String width = null;
        String padding = null;

        String content = params.getContent();
        if (content == null) {
            content = "";
        }

        Collection<String> col = utils.getParameters(params);
        String macroText = utils.buildMacroTextFromParameters("column", col);
        boolean forPdf = utils.isPdfOutput(params.getContext());

        for (String p : col) {
            if (p.matches("width(\\s)*=.*")) {
                String value = utils.getValueFromParameter(p);
                if (value.matches(MP.Const.VV_HTML_SIZE)) {
                    width = value;
                } else {
                    errors.put("width", MP.Const.ERR_MSG_HTML_SIZE);
                }
            } else if (p.matches("padding(\\s)*=.*")) {
                String value = utils.getValueFromParameter(p);
                if (value.matches(MP.Const.VV_HTML_PADDING)) {
                    padding = value;
                } else {
                    errors.put("padding", MP.Const.ERR_MSG_HTML_SIZE);
                }
            } else {
                //non acceptable parameter
                String[] parts = p.split("[=]");
                errors.put(parts[0], "Parameter is not suitable for this macro.");
            }
        }

        if (!errors.isEmpty()) {
            writer.write(MacroRenderer.getInstance().renderErrors(errors, macroText, forPdf));
            return;
        }

        if (padding == null) {
            padding = "0px 10px 0px 10px"; // default value;
        }
        cellStyle.append("padding:").append(padding).append(";");

        if (width != null) {
            cellAttr.append("width=\"").append(width).append("\" ");
            cellAttr.append(SectionMacro.PDF_COLUMN_WIDTH_MARK + "=\"").append(width).append("\" ");
        }

        cellStyle.append("border:0px;");

        IHTMLBuilder builder = new HTMLBuilder();
        builder.appendElementStart(HTMLConst.TD, null, cellStyle.toString(), cellAttr.toString());
        builder.appendHTML(content);
        builder.appendElementEnd(HTMLConst.TD);
        writer.write(builder.toString().endsWith("\n") ? builder.toString().substring(0, builder.toString().length() - 1) : builder.toString());
    }

    @Override
    public String getLocaleKey() {
        return "macro.column";
    }

}
