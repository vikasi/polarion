package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.projects.IProjectService;
import com.polarion.alm.projects.model.IProject;
import com.polarion.alm.tracker.ITestManagementService;
import com.polarion.alm.tracker.model.ITestRun;
import com.polarion.alm.ui.server.wiki.createtestrunbutton.CreateTestRunButtonMacroParameters;
import com.polarion.alm.ui.server.wiki.macro.impl.PlainMacroImpl;
import com.polarion.core.util.ObjectUtils;
import com.polarion.platform.guice.internal.GuicePlatform;
import com.polarion.platform.persistence.IDataService;
import com.polarion.portal.server.HTMLBuilder;
import com.polarion.reina.web.shared.localization.Localization;
import com.polarion.subterra.base.data.identification.IContextId;
import com.polarion.wiki.integration.utils.MacroRenderer;

/**
 * This is server side representation of Tests Execution Button Macro
 */
public class CreateTestRunButtonMacro extends XWikiGwtMacro {

    public static final String MACRO_ID = "create-testrun-button"; //$NON-NLS-1$

    private static final MacroRenderer renderer = MacroRenderer.getInstance();

    private IDataService dataService;
    private IProjectService projectService;
    private ITestManagementService testService;

    public CreateTestRunButtonMacro() {
        super();
        GuicePlatform.getGlobalInjector().injectMembers(this);
    }

    @Inject
    public void setProjectService(IProjectService service) {
        projectService = service;
    }

    @Inject
    public void setDataService(IDataService dataService) {
        this.dataService = dataService;
    }

    @Inject
    public void setTestService(ITestManagementService testService) {
        this.testService = testService;
    }

    private class Data extends MacroData {

        @NotNull
        final CreateTestRunButtonMacroParameters parameters;

        Data(@NotNull MacroParameter inputParameters) {
            super(inputParameters);
            parameters = new CreateTestRunButtonMacroParameters(macroContext, new PlainMacroImpl(getMacroText(inputParameters)));
        }

        @Override
        @NotNull
        public Map<String, String> getErrors() {
            return parameters.validate();
        }

        @Override
        @NotNull
        public Map<String, String> getParameters() {
            String projectId = parameters.getProjectId();
            Map<String, String> map = new HashMap<String, String>();
            map.put("query", parameters.getQuery()); //$NON-NLS-1$
            map.put("label", getLabel(parameters)); //$NON-NLS-1$
            map.put("buttonEnabled", String.valueOf(isButtonEnabled(projectId))); //$NON-NLS-1$ 
            map.put("project", projectId); //$NON-NLS-1$
            return map;
        }
    }

    @Override
    @NotNull
    protected String getMacroId() {
        return MACRO_ID;
    }

    @Override
    public void execute(Writer writer, MacroParameter parameters) throws IllegalArgumentException, IOException {
        new DataRenderer(new Data(parameters)).render(writer);
    }

    class DataRenderer extends MacroDataRenderer<Data> {
        DataRenderer(final Data data) {
            super(data);
        }

        @Override
        protected boolean hasErrors() throws Exception {
            return !data.parameters.iCanGetProjectId() || super.hasErrors();
        }

        @Override
        protected void renderErrors(@NotNull HTMLBuilder builder) throws Exception {
            if (!data.parameters.iCanGetProjectId()) {
                renderProjectError(builder);
            } else {
                super.renderErrors(builder);
            }
        }
    }

    private void renderProjectError(@NotNull HTMLBuilder builder) {
        builder.clear();
        renderError(builder, Localization.getString("macro.create-testrun-button.InvalidProject", MACRO_ID)); //$NON-NLS-1$
    }

    @NotNull
    private static String getLabel(@NotNull CreateTestRunButtonMacroParameters dataParameters) {
        String label = dataParameters.getlabel();
        if (ObjectUtils.emptyString(label)) {
            label = Localization.getString("macro.create-testrun-button.label"); //$NON-NLS-1$
        }
        return label;
    }

    private boolean isButtonEnabled(@Nullable String projectId) {

        IContextId contextId = null;
        if (projectId != null) {
            IProject project = projectService.getProject(projectId);
            if (!project.isUnresolvable()) {
                contextId = project.getContextId();
            }
        }

        return dataService.getPersistencePolicy().canCreateInstances(ITestRun.PROTO, contextId);
    }

    @Override
    protected boolean hasLicense() {
        return testService.getPolicy().canUseTestManagement();
    }

}
