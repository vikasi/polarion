package com.polarion.wiki.integration;

import com.xpn.xwiki.XWikiContext;

/**
 * @author VKO
 * All classes with functionallity to be restricted should implement this interface.
 */

public interface Restrictable {
    String RESTRICTED_MSG = "*This syntax is not available for your license type.*";
    String RESTRICTED_BANNER = "#info(\"This page uses one or more syntax constructs which are not available for your license type.\")";

    boolean isUnderRestriction(XWikiContext context);
}
