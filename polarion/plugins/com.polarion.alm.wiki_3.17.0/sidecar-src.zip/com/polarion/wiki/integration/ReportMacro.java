/*
 * Copyright (C) 2004-2009 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2009 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.polarion.wiki.integration;

import com.polarion.alm.reports.server.ReportsProvider;
import com.polarion.alm.reports.shared.ReportData;
import com.polarion.portal.server.HTMLBuilder;
import com.polarion.portal.shared.navigation.IScope;
import com.polarion.reina.web.shared.html.HTMLConst;
import com.polarion.reina.web.shared.html.IHTMLBuilder;
import com.polarion.reina.web.shared.localization.Localization;
import com.polarion.wiki.integration.utils.MacroUtils;

/**
 * @author <a href="mailto:dev@polarion.com">Jakub Stroleny</a>, Polarion Software
 */
public final class ReportMacro extends AbstractReportMacro {

    private static final String CONTENT_NOT_AVAILABLE = Localization.getString("macro.report.contentNotAvailable"); //$NON-NLS-1$

    @Override
    public String getLocaleKey() {
        return "macro.polarionreport";
    }

    @Override
    public String getName() {
        return "report";
    }

    @Override
    public String getReportContent(ReportData reportData, String width, String height, String action) {
        if (reportData.reportData != null) {
            IHTMLBuilder builder = new HTMLBuilder();
            StringBuilder styles = new StringBuilder();
            if (!"auto".equals(width)) {
                styles.append("width:").append(width).append("px;");
            }
            if (!"auto".equals(height)) {
                styles.append("height:").append(height).append("px;");
            }
            builder.appendElementStart(HTMLConst.DIV, null, styles.toString(), null);
            String content = MacroUtils.getInstance().escapeValue(reportData.reportData);
            builder.appendHTML(content);
            builder.appendElementEnd(HTMLConst.DIV);
            return builder.toString();
        } else {
            return CONTENT_NOT_AVAILABLE;
        }

    }

    @Override
    public boolean getReportData(IScope scope) throws Exception {
        ReportsProvider.getReportData(scope, getReportPath(), null, new String[0], getCallBack());
        return true;
    }

}
