package com.polarion.wiki.integration.utils;

import java.io.IOException;
import java.io.Writer;
import java.net.URI;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.velocity.VelocityContext;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.radeox.api.engine.context.RenderContext;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.projects.model.IProject;
import com.polarion.alm.projects.model.IProjectGroup;
import com.polarion.alm.projects.model.IUser;
import com.polarion.alm.server.ServerUiContext;
import com.polarion.alm.shared.api.utils.links.PortalLink;
import com.polarion.alm.tracker.ITrackerService;
import com.polarion.alm.tracker.SavedQuery;
import com.polarion.alm.tracker.model.ILinkRoleOpt;
import com.polarion.alm.tracker.model.IModule;
import com.polarion.alm.tracker.model.ITrackerProject;
import com.polarion.alm.tracker.model.IWorkItem;
import com.polarion.alm.ui.shared.FieldRenderType;
import com.polarion.alm.wiki.WikiPlugin;
import com.polarion.core.util.EscapeChars;
import com.polarion.core.util.RunnableWEx;
import com.polarion.core.util.types.DateOnly;
import com.polarion.core.util.types.Text;
import com.polarion.core.util.types.ThreadSafeDateFormatWrapper;
import com.polarion.platform.core.PlatformContext;
import com.polarion.platform.persistence.model.IPObject;
import com.polarion.platform.persistence.model.IPObjectList;
import com.polarion.platform.persistence.model.IRevision;
import com.polarion.platform.service.repository.IRepositoryService;
import com.polarion.portal.server.TransactionalExecuter;
import com.polarion.reina.web.shared.localization.Localization;
import com.polarion.subterra.base.data.identification.IContextId;
import com.polarion.subterra.base.location.ILocation;
import com.polarion.subterra.base.location.Location;
import com.polarion.wiki.integration.IntegrationPlugin;
import com.polarion.wiki.integration.link.ILink;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.render.XWikiRadeoxRenderEngine;

/**
 *
 * @author Jiri Banszel
 * @version $Revision$ $Date$
 *
 */
public class MacroUtils {

    public static final String NOT_AVAILABLE = "N/A";

    private static final String DATE_ONLY_FORMAT = "yyyy-MM-dd"; //$NON-NLS-1$
    private static final String DATE_FORMAT = "yyyy-MM-dd HH:mm"; //$NON-NLS-1$

    private static MacroUtils instance;
    public ITrackerService trackerService;
    private IRepositoryService repositoryService;
    private DateFormat dateOnlyFormat;
    private DateFormat dateFormat;
    private IContextId globalContextId;

    public MacroUtils() {
        trackerService = PlatformContext.getPlatform().lookupService(ITrackerService.class);
        repositoryService = PlatformContext.getPlatform().lookupService(IRepositoryService.class);
        dateOnlyFormat = new ThreadSafeDateFormatWrapper(new SimpleDateFormat(DATE_ONLY_FORMAT));
        dateFormat = new ThreadSafeDateFormatWrapper(new SimpleDateFormat(DATE_FORMAT));
        globalContextId = trackerService.getProjectsService().getProjectGroupAtLocation(Location.getLocation(IRepositoryService.DEFAULT, "/", null)).getContextId(); //$NON-NLS-1$
    }

    public static MacroUtils getInstance() {
        if (instance == null) {
            instance = new MacroUtils();
        }
        return instance;
    }

    public DateFormat getDateFormat() {
        return dateFormat;
    }

    public DateFormat getDateOnlyFormat() {
        return dateOnlyFormat;
    }

    public ITrackerProject getCurrentProject(RenderContext rcontext) {
        return getProject(getCurrentProjectId(rcontext));
    }

    public ITrackerProject getCurrentProject(XWikiContext context) {
        return getProject(getCurrentProjectId(context));
    }

    public IProjectGroup getCurrentProjectGroup(XWikiContext context) {
        return getProjectGroup(getCurrentProjectGroupId(context));
    }

    public XWikiContext getXWikiContext(MacroParameter parameters) {
        XWikiRadeoxRenderEngine eg = (XWikiRadeoxRenderEngine) parameters.getContext().getRenderEngine();
        return eg.getContext();
    }

    public void renameModuleNameToName(Collection<String> col) {
        String toAdd = null;
        for (Iterator iterator = col.iterator(); iterator.hasNext();) {
            String param = (String) iterator.next();
            if (param != null && param.startsWith("moduleName=")) { //$NON-NLS-1$
                toAdd = param.replaceAll("moduleName=", "name="); //$NON-NLS-1$//$NON-NLS-2$
                iterator.remove();
            }
        }
        if (toAdd != null) {
            col.add(toAdd);
        }
    }

    public void renderError(String msg, Writer writer) throws IOException {
        if (msg == null) {
            msg = Localization.getString("macro.general.errorUppercase"); //$NON-NLS-1$
        }
        writer.write("<span style=\"color: red\">" + escapeValue(msg) + "</span>"); //$NON-NLS-1$//$NON-NLS-2$
    }

    public String renderError(String msg) {
        if (msg == null) {
            return Localization.getString("macro.general.errorUppercase"); //$NON-NLS-1$
        }
        return "<span style=\"color: red\">" + msg + "</span>"; //$NON-NLS-1$//$NON-NLS-2$
    }

    public String format(Object value) {
        if (value == null) {
            return NOT_AVAILABLE;
        }
        if (value instanceof IPObject) {
            IPObject pobj = (IPObject) value;
            if (pobj.isUnresolvable()) {
                String objectName = pobj.getLocalId().getObjectName();
                if (pobj instanceof IWorkItem) {
                    return "<i><img src='/polarion/ria/images/enums/type_generic.gif' style='vertical-align: middle; margin-right:2px;'/>" + objectName + "</i>"; //$NON-NLS-1$ //$NON-NLS-2$
                }
                if (pobj instanceof IUser) {
                    return "<i>" + objectName + "</i>"; //$NON-NLS-1$//$NON-NLS-2$
                }
                if (pobj instanceof IProject) {
                    return "<i>" + objectName + "</i>"; //$NON-NLS-1$ //$NON-NLS-2$
                }
                if (pobj instanceof IModule) {
                    return "<i><img src='/polarion/ria/images/details/document.png' style='vertical-align: middle; margin-right:2px;'/>" + objectName + "</i>"; //$NON-NLS-1$ //$NON-NLS-2$
                }
                return "<i>" + objectName + "</i>"; //$NON-NLS-1$//$NON-NLS-2$
            }
        }
        if (value instanceof ILinkRoleOpt) {
            String linkRole = ((ILinkRoleOpt) value).getName();
            return linkRole;
        }
        if (value instanceof IProject) {
            String projectName = ((IProject) value).getName();
            return projectName;
        }
        if (value instanceof DateOnly) {
            DateOnly dateOnly = (DateOnly) value;
            return dateOnlyFormat.format(dateOnly.getDate());
        }
        if (value instanceof Date) {
            Date date = (Date) value;
            return dateFormat.format(date);
        }
        if (value instanceof Text) {
            // TODO pictures
            return ((Text) value).getContent();
        }
        if (value instanceof IUser) {
            return ((IUser) value).getName();
        }
        if (value instanceof Boolean) {
            String checked = ((Boolean) value).booleanValue() ? "checked=\"" + ((Boolean) value).toString() + "\"" : ""; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
            return "<input type=\"checkbox\" disabled=\"true\" " + checked + " />"; //$NON-NLS-1$//$NON-NLS-2$
        }
        if (value instanceof ILocation) {
            ILocation location = (ILocation) value;
            URI uri = repositoryService.getAccessibleURLForLocation(location);
            if (uri != null) {
                String url = (uri != null) ? uri.toString() : location.toString();
                return "<a href=\"" + url + "\" target=\"_blank\">" + url + "</a>"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
            } else {
                return location.toString();
            }
        }
        return value.toString();
    }

    private String getCurrentProjectId(RenderContext rcontext) {
        XWikiRadeoxRenderEngine eg = (XWikiRadeoxRenderEngine) rcontext.getRenderEngine();
        XWikiContext context = eg.getContext();
        return getCurrentProjectId(context);
    }

    public String getCurrentProjectId(XWikiContext context) {
        String project = context.getWiki().getCurrentProject(context);
        if (project != null) {
            project = project.trim();
            if (project.length() > 0) {
                return project;
            }
        }
        return null;
    }

    private String getCurrentProjectGroupId(XWikiContext context) {
        String group = context.getWiki().getCurrentGroup(context);
        if (group != null) {
            group = group.trim();
            if (group.length() > 0) {
                return group;
            }
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    public String getCurrentGroupLocation(Map requestParams) {
        return (String) requestParams.get("projectGroup"); //$NON-NLS-1$
    }

    public IProject getProject(String projectId, Map<String, String> errors) {
        IProject project = null;
        try {
            project = trackerService.getProjectsService().getProject(projectId);
        } catch (Exception e) {
            errors.put(MP.PROJECT.getName(), Localization.getString("macro.general.projectDoesNotExist", projectId)); //$NON-NLS-1$
            return null;
        }
//		if(project.isUnresolvable()){
//			errors.put(MP.PROJECT.getName(), "Project with id '" + projectId + "' doesn't exist.");
//			return null;
//		}
        return project;
    }

    public ITrackerProject getTrackerProject(String projectId, Map<String, String> errors) {
        ITrackerProject project = null;
        try {
            project = trackerService.getTrackerProject(projectId);
        } catch (Exception e) {
            errors.put(MP.PROJECT.getName(), Localization.getString("macro.general.projectDoesNotExist", projectId)); //$NON-NLS-1$
            return null;
        }
//		if(project.isUnresolvable()){
//			errors.put(MP.PROJECT.getName(), "Project with id '" + projectId + "' doesn't exist.");
//			return null;
//		}
        return project;
    }

    public ITrackerProject getProject(String projectId) {
        if (projectId != null) {
            projectId = projectId.trim();
            if (projectId.length() > 0) {
                ITrackerProject project = trackerService.getTrackerProject(projectId);
                if (!project.isUnresolvable()) {
                    return project;
                }
            }
        }
        return null;
    }

    public IProjectGroup getProjectGroup(String groupLocation) {
        if (groupLocation != null) {
            groupLocation = groupLocation.trim();
            if (groupLocation.length() > 0) {
                IProjectGroup projectGroup = trackerService.getProjectsService().getProjectGroupAtLocation(Location.getLocation(IRepositoryService.DEFAULT, "/" + groupLocation, null)); //$NON-NLS-1$
                if (!projectGroup.isUnresolvable()) {
                    return projectGroup;
                }
            }
        }
        return null;
    }

    public String getProjectName(String projectId) {
        if (projectId != null) {
            projectId = projectId.trim();
            if (projectId.length() > 0) {
                IProject project = trackerService.getProjectsService().getProject(projectId);
                if (!project.isUnresolvable()) {
                    return project.getName();
                }
            }
        }
        return ""; //$NON-NLS-1$
    }

    public String getDefaultParameter(String key, MacroParameter params) {
        Pattern pattern = Pattern.compile(key + "=(.+)"); //$NON-NLS-1$
        String param = params.get(0);
        if (param != null) {
            Matcher matcher = pattern.matcher(param);
            if (matcher.find()) {
                return matcher.group(1);
            } else {
                return param;
            }
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    public boolean addDefaultParameter(String key, String value, Collection params) {
        for (Object o : params) {
            String data = (String) o;
            if (data.matches("[\\s]*" + key + "[\\s]*[\\S]+")) { //$NON-NLS-1$//$NON-NLS-2$
                return false;
            }
        }
        params.add(key + "=" + value); //$NON-NLS-1$
        return true;
    }

    @SuppressWarnings("unchecked")
    public boolean addParameterNameToValue(String key, Collection params) {
        for (Object o : params) {
            String data = (String) o;
            if (data.matches("[^=]+")) { //$NON-NLS-1$
                params.remove(o);
                params.add(key + "=" + data); //$NON-NLS-1$
                return true;
            }
        }
        return false;
    }

    @SuppressWarnings("unchecked")
    public boolean replaceParameterName(String key, String replacement, Collection params) {
        for (Object o : params) {
            String data = (String) o;
            if (data.trim().matches(key + "[\\s]*=[\\s]*.+")) { //$NON-NLS-1$
                params.remove(o);
                params.add(replacement + data);
                return true;
            }
        }
        return false;
    }

    /**
     * Escapes some characters from the url so that it is not automatically replaced
     * with a hyperlink on a wiki page.
     */
    public String escapeUrlForLabel(String url) {
        int idx = url.indexOf(':');
        if (idx > 0) {
            return url.substring(0, idx) + "&#0058" + url.substring(idx + 1, url.length()); //$NON-NLS-1$
        }
        return url;
    }

    @NotNull
    public String escapeValue(String content) {
        content = content.replaceAll("[\\{]", "&#123;"); //$NON-NLS-1$ //$NON-NLS-2$
        content = content.replaceAll("[\\}]", "&#125;"); //$NON-NLS-1$//$NON-NLS-2$
        content = content.replaceAll("[\\[]", "&#091;"); //$NON-NLS-1$ //$NON-NLS-2$
        content = content.replaceAll("[\\]]", "&#093;"); //$NON-NLS-1$//$NON-NLS-2$
        content = content.replaceAll("[\\*]", "&#042;"); //$NON-NLS-1$ //$NON-NLS-2$
        content = content.replaceAll("~~", "&#126;&#126;"); //$NON-NLS-1$//$NON-NLS-2$
        content = content.replaceAll("--", "&#045;&#045;"); //$NON-NLS-1$ //$NON-NLS-2$
        content = content.replaceAll("__", "&#095;&#095;"); //$NON-NLS-1$//$NON-NLS-2$

        //content = content.replaceAll("1", "&#049;");
        return content;
    }

    @SuppressWarnings("nls")
    public String escapeParameterMacro(String content) {
        content = escapeValue(content);
        content = content.replace("\\", "&#092;"); //$NON-NLS-1$//$NON-NLS-2$
        content = content.replace("|", "&#124;"); //$NON-NLS-1$ //$NON-NLS-2$
        return content;
    }

    public String escapeURLValue(String content) {
        int a = content.indexOf("?"); //$NON-NLS-1$
        if (a != -1 && a != content.length()) {
            content = content.substring(0, a + 1) + (content.substring(a + 1, content.length())).replaceAll("\\?", "%3f"); //$NON-NLS-1$ //$NON-NLS-2$
        }
        return content;
    }

    public String escapeURLValueLabel(String content) {
        if (content == null) {
            return ""; //$NON-NLS-1$
        }
        return content.replaceAll("http://", "http:/&#047;").replaceAll("https://", "https:/&#047;").replaceAll("ftp://", "ftp:/&#047;"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$

    }

    public String trimValue(String content) {
        content = content.replaceAll("\n", ""); //$NON-NLS-1$//$NON-NLS-2$
        content = content.replaceAll("\r", ""); //$NON-NLS-1$ //$NON-NLS-2$
        content = content.replaceAll("\t", ""); //$NON-NLS-1$//$NON-NLS-2$
        content = content.replaceAll("> +<", "><"); //$NON-NLS-1$ //$NON-NLS-2$
        return content.trim();
    }

    /**
     * c = a \ b
     * @param a
     * @param b
     * @return c
     */
    public <T> Set<T> distictionOfSets(Set<T> a, Set<T> b) {
        Set<T> copya = new HashSet<T>();
        copya.addAll(a);

        for (T o : b) {
            if (copya.contains(o)) {
                copya.remove(o);
            }
        }

        return copya;
    }

//    static <T> void fromArrayToCollection(T[] a, Collection<T> c) {
//        for (T o : a) {
//            c.add(o); // Correct
//        }
//    }

//    public Map<MP, String> parseMacroParameters(MacroParameter parameters, List<Set<MP>> allowedParameters){
//
//    	Map<MP, String> matched = new HashMap<MP, String>();
//    	for (int i=0; i<parameters.getLength(); i++) {
//    		String data = (String)parameters.get(i);
//    		for (MP mp : MP.values()){
//    			if(data.matches(mp.getRegexp())){
//    				matched.put(mp, data);
//    			}
//    		}
//    	}
//
//    	Set<MP> subset = matched.keySet();
//    	for (Set<MP> set: allowedParameters){
//    		if (set.containsAll(subset)){
//    			if(checkRequiredParameters(set, subset)){
//    				//we have all required parameters
//    				return matched;
//    			}
//    		}
//    	}
//
//    	return null;
//    }

    /**
     *
     * @param parameters
     * @param result matched parameters
     * @return list of unmatched parameters, never null
     */
    public List<String> parseInputParameters(Collection<String> parameters, HashMap<MP, String> result) {
        List<String> unmatched = new ArrayList<String>();

        for (String o : parameters) {
            boolean found = false;
            for (MP mp : MP.values()) {
                if (o.trim().matches(mp.getRegexp())) {
                    result.put(mp, o.trim().split("[\\s]*=[\\s]*")[1]); //$NON-NLS-1$
                    found = true;
                }
            }
            if (!found) {
                unmatched.add(o);
            }
        }

        return unmatched;
    }

    public Map<MP, String> findAppropriateRule(HashMap<MP, String> result, List<MP[]> rules) {
        for (MP[] rule : rules) {
            Set<MP> ps = new HashSet<MP>();
            Collections.addAll(ps, rule);

        }
        return null;
    }

    public IUser getWorkItemUpdatedUser(IWorkItem wi) {
        try {

            IPObjectList objectHistory = trackerService.getDataService().getObjectHistory(wi);
            IWorkItem object = (IWorkItem) objectHistory.get(objectHistory.size() - 1);
            IRevision revision = trackerService.getDataService().getRevision(wi.getContextId(), object.getRevision());
            String userId = revision.getStringAuthor();
            return trackerService.getProjectsService().getUser(userId);

        } catch (Exception e) {
            return null;
        }
    }

//    public Collection<String> validateMacro(Collection<String> params, Set<MP> set){
//    	Map<MP, String> matched = new HashMap<MP, String>();
//    	for (MP mp : MP.values()){
//    		for (String o: params) {
//    			if(o.trim().matches(mp.getPrefixRegexp())){
//    				if(o.matches("(.)*id(.)*") && (!set.contains(mp))){ //put only id, which is in set
//    					continue;
//    				}
//    				matched.put(mp, o.trim().split("[\\s]*=[\\s]*")[1]);
//    			}
//    		}
//    	}
//
//    	Set<MP> subset = matched.keySet();
//
//    	if (subset.isEmpty()){
//    		return null;
//    	}
//
//    	if (set.containsAll(subset)){
//			if(checkRequiredParameters(set, subset)){
//				//we have all required parameters
//				parseProjectSlashParameter(matched);
//				//return matched;
//			}
//		}
//
//    	return null;
//    }

    public Collection<String> getParameters(MacroParameter parameters) {
        Collection<String> col = new ArrayList<String>();
        for (int i = 0; i < parameters.getLength(); i++) {
            String s = parameters.get(i);
            if (s != null) {
                String v = s.trim();
                v = v.replaceAll("&#035;", "#"); //$NON-NLS-1$ //$NON-NLS-2$
                v = v.replaceAll("&#037;", "%"); //$NON-NLS-1$//$NON-NLS-2$
                v = v.replaceAll("&#35;", "#"); //$NON-NLS-1$ //$NON-NLS-2$
                v = v.replaceAll("&#37;", "%"); //$NON-NLS-1$//$NON-NLS-2$
                v = v.replaceAll("&#91;", "["); //$NON-NLS-1$ //$NON-NLS-2$
                v = v.replaceAll("&#93;", "]"); //$NON-NLS-1$//$NON-NLS-2$
                v = v.replaceAll("&#091;", "["); //$NON-NLS-1$ //$NON-NLS-2$
                v = v.replaceAll("&#093;", "]"); //$NON-NLS-1$//$NON-NLS-2$
                v = v.replaceAll("&#92;", "\\\\"); //$NON-NLS-1$//$NON-NLS-2$
                v = v.replaceAll("&#092;", "\\\\"); //$NON-NLS-1$ //$NON-NLS-2$
                v = v.replaceAll("&#036;", "\\$"); //$NON-NLS-1$//$NON-NLS-2$
                v = v.replaceAll("&#36;", "\\$"); //$NON-NLS-1$ //$NON-NLS-2$
                v = v.replaceAll("\n", ""); //$NON-NLS-1$//$NON-NLS-2$
                v = v.replaceAll("\r", ""); //$NON-NLS-1$ //$NON-NLS-2$
                col.add(v);
            }
        }
        return col;
    }

    @NotNull
    public Map<String, String> getParameterMap(MacroParameter parameters) {
        Map<String, String> col = new LinkedHashMap<String, String>();
        for (int i = 0; i < parameters.getLength(); i++) {
            String s = parameters.get(i);
            if (s != null) {
                String v = s.trim();
                v = v.replaceAll("&#035;", "#"); //$NON-NLS-1$//$NON-NLS-2$
                v = v.replaceAll("&#037;", "%"); //$NON-NLS-1$//$NON-NLS-2$
                v = v.replaceAll("&#35;", "#"); //$NON-NLS-1$ //$NON-NLS-2$
                v = v.replaceAll("&#37;", "%"); //$NON-NLS-1$//$NON-NLS-2$
                v = v.replaceAll("&#91;", "["); //$NON-NLS-1$ //$NON-NLS-2$
                v = v.replaceAll("&#93;", "]"); //$NON-NLS-1$//$NON-NLS-2$
                v = v.replaceAll("&#091;", "["); //$NON-NLS-1$ //$NON-NLS-2$
                v = v.replaceAll("&#093;", "]"); //$NON-NLS-1$//$NON-NLS-2$
                v = v.replaceAll("&#92;", "\\\\"); //$NON-NLS-1$ //$NON-NLS-2$
                v = v.replaceAll("&#092;", "\\\\"); //$NON-NLS-1$ //$NON-NLS-2$
                v = v.replaceAll("&#036;", "\\$"); //$NON-NLS-1$//$NON-NLS-2$
                v = v.replaceAll("&#36;", "\\$"); //$NON-NLS-1$ //$NON-NLS-2$
                v = v.replaceAll("\n", ""); //$NON-NLS-1$//$NON-NLS-2$
                v = v.replaceAll("\r", ""); //$NON-NLS-1$ //$NON-NLS-2$
                String[] parts = v.split("(\\s)*=(\\s)*"); //$NON-NLS-1$
                if (parts.length != 2) {
                    col.put(v, null);
                } else {
                    col.put(parts[0].trim(), parts[1].trim());
                }
            }
        }
        return col;
    }

    public Collection<String> getParameters(Enumeration<String> map, XWikiContext context) {
        Collection<String> col = new ArrayList<String>();

        while (map.hasMoreElements()) {
            String s = map.nextElement();
            String realParameterName = s;
            if (WikiPlugin.TARGET.equals(realParameterName)) {
                continue;
            }
            if (s.matches("amp;(.)*")) { //$NON-NLS-1$
                realParameterName = s.substring(4);
            }
            if (s != null) {
                String v = context.getRequest().getParameter(s);
                v = v.replaceAll("&#035;", "#"); //$NON-NLS-1$ //$NON-NLS-2$
                v = v.replaceAll("&#037;", "%"); //$NON-NLS-1$ //$NON-NLS-2$
                v = v.replaceAll("&#35;", "#"); //$NON-NLS-1$ //$NON-NLS-2$
                v = v.replaceAll("&#37;", "%"); //$NON-NLS-1$ //$NON-NLS-2$
                v = v.replaceAll("\n", ""); //$NON-NLS-1$ //$NON-NLS-2$

                if ((v != null) && (!v.equals(""))) { //$NON-NLS-1$
                    col.add(realParameterName + "=" + v); //$NON-NLS-1$
                }
            }
        }
        return col;
    }

    public String getPolarionServerURL(XWikiContext context) {
        return context.getURLFactory().getURL();
    }

    public ShortLongDisplay getLinkDisplay(Map<MP, String> map) {
        String value = map.get(MP.DISPLAY_SHORT_LONG);
        if ((value != null) && (value.matches("[\\s]*long[\\s]*"))) {
            return ShortLongDisplay.LONG;
        }
        return ShortLongDisplay.SHORT;
    }

    public String getWidth(Map<MP, String> map) {
        String value = map.get(MP.WIDTH);
        if ((value == null) || (value.equals(""))) { //$NON-NLS-1$
            value = null; //"100%" was before DPP-8073
        }
        return value;
    }

    public String getHeight(Map<MP, String> map) {
        String value = map.get(MP.HEIGHT);
        if ((value == null) || (value.equals(""))) { //$NON-NLS-1$
            value = ""; //$NON-NLS-1$
        }
        return value;
    }

    public ExpandMode getExpandMode(Map<MP, String> map) {
        String value = map.get(MP.EXPAND_YES_NO);
        if ((value != null) && (value.matches("[\\s]*no[\\s]*"))) {
            return ExpandMode.NO;
        }
        return ExpandMode.YES;
    }

    public boolean isPdfOutput(RenderContext rcontext) {
        XWikiRadeoxRenderEngine eg = (XWikiRadeoxRenderEngine) rcontext.getRenderEngine();
        XWikiContext context = eg.getContext();
        return isPdfExport(context);
    }

    public enum ShortLongDisplay {
        SHORT, LONG
    }

    public enum ExpandMode {
        YES {
            @Override
            boolean getValue() {
                return true;
            }

            @Override
            String getName() {
                return "yes"; //$NON-NLS-1$
            }
        },
        NO {
            @Override
            boolean getValue() {
                return false;
            }

            @Override
            String getName() {
                return "no"; //$NON-NLS-1$
            }
        };

        abstract boolean getValue();

        abstract String getName();

    }

    public class FieldProperty {
        public FieldRenderType renderType;
        public Integer width;
        public Integer proportionWidth;
        public boolean defaultWidth = true;
        public Map<String, String> props;

        public FieldProperty(FieldRenderType renderType, Integer width, Integer proportionWidth, boolean defaultWidth, Map<String, String> props) {
            this(renderType, width, proportionWidth, props);
            this.defaultWidth = defaultWidth;
        }

        public FieldProperty(FieldRenderType renderType, Integer width, Integer proportionWidth, Map<String, String> props) {
            this.renderType = renderType;
            this.width = width;
            this.proportionWidth = proportionWidth;
            this.props = props;
        }

        public FieldProperty() {
        };
    }

    /**
     *
     * @param fields
     * @return true if width of some field is set
     */
    public boolean isWidthOfFieldsSet(Map<String, FieldProperty> fields) {
        boolean result = true;

        for (String s : fields.keySet()) {
            result = fields.get(s).defaultWidth;
        }

        return !result;
    }

    public Map<String, FieldProperty> setWidthForFields(Map<String, FieldProperty> map, Set<String> exclude) {

        //first count all column % width
        int allW = 0;
        int numCol = 0; //number of columns, which has width not null
        int allP = 0; //the sum of proportions of the fields, which hasn't got width set
        for (String s : map.keySet()) {
            if ((exclude != null) && (exclude.contains(s))) {
                continue;
            }
            Integer width = map.get(s).width;
            if (width != null) {
                allW += width;
                numCol++;
            } else {
                allP += map.get(s).proportionWidth;
            }
        }

        if (allW > 100) {
            //set' widths in fields parameter are too big -> reduce it
            int diff = (numCol == 0) ? 100 : (allW - 100) / numCol;

            //repair width
            Iterator<String> it = map.keySet().iterator();
            while (it.hasNext()) {
                String fieldName = it.next();
                if ((exclude != null) && (exclude.contains(fieldName))) {
                    continue;
                }
                FieldProperty fp = map.get(fieldName);
                Integer width = fp.width;
                if (width != null) {
                    if (it.hasNext()) {
                        fp.width -= diff;
                        allW -= diff;
                    } else {
                        fp.width = allW; //the rest
                    }
                } else {
                    fp.width = 0;
                }
            }
            return map;
        } else if (allP == 0) {
            //all width are set, not necessary to set anything else
            //but maybe user set widths, which sum is not 100%, so let to expand them
            if (allW < 100) {
                //expanding
                int diff = 100 - allW;
                int addition = diff / numCol;
                //add diff to each column width
                Iterator<String> it = map.keySet().iterator();
                FieldProperty lastSetProperty = null;

                while (it.hasNext()) {
                    String fieldName = it.next();
                    if ((exclude != null) && (exclude.contains(fieldName))) {
                        if (!it.hasNext() && (diff != 0) && (lastSetProperty != null)) {
                            //set to last unset column the rest of width
                            lastSetProperty.width += diff;
                        }
                        continue;
                    }
                    if (it.hasNext()) {
                        map.get(fieldName).width += addition;
                        lastSetProperty = map.get(fieldName);
                        diff -= addition;
                    } else {
                        map.get(fieldName).width += diff;
                    }

                }
            }
            return map;
        } else {
            //set width for the rest fields
            int diff = 100 - allW;
            float onePP = new Float(diff) / new Float(allP); //the width of one proportion point

            //complete the rest widths
            Iterator<String> it = map.keySet().iterator();
            FieldProperty lastSetProperty = null;

            while (it.hasNext()) {
                String fieldName = it.next();
                if ((exclude != null) && (exclude.contains(fieldName))) {
                    if (!it.hasNext() && (diff != 0) && (lastSetProperty != null)) {
                        //set to last unset column the rest of width
                        lastSetProperty.width += diff;
                    }
                    continue;
                }
                FieldProperty fp = map.get(fieldName);
                if (fp.width != null) {
                    if (!it.hasNext() && (diff != 0) && (lastSetProperty != null)) {
                        lastSetProperty.width += diff;
                    }
                    continue;
                }

                //let to set new width
                lastSetProperty = fp;
                Integer prop = fp.proportionWidth;
                if (it.hasNext()) {
                    int newWidth = (int) (onePP * prop.floatValue());
                    fp.width = newWidth;
                    diff -= newWidth;
                } else {
                    fp.width = diff; //the rest
                }
            }
            return map;
        }

    }

    public String getQueryByName2(String queryName, String projectId, IUser user, Map<String, String> errors) {
        IProject project = getProject(projectId, errors);
        if (project == null) {
            return null;
        }
        return getQueryByName(queryName, project, user, errors);
    }

    @SuppressWarnings("unchecked")
    public String getQueryByName(String queryName, IProject project, IUser user, Map<String, String> errors) {
        try {
            List<SavedQuery> list = trackerService.getSavedQueriesManager().getSavedQueries(project, user);
            for (SavedQuery sq : list) {
                if (sq.name.equalsIgnoreCase(queryName)) {
                    return sq.query;
                }
            }
        } catch (Exception e) {
        }
        errors.put(MP.QUERY_NAME.getName(), Localization.getString("macro.general.savedQueryDoesNotExist", queryName, project.getContextId().getContextName())); //$NON-NLS-1$

        return null;
    }

    public List<IPObject> getTopItems(List<IPObject> list, String restriction, int default_top) {
        if (restriction != null) {
            int top = new Integer(restriction);
            if ((top > 0) && (top < list.size())) {
                return list.subList(0, top);
            }
        } else if (list.size() > default_top) {
            return list.subList(0, default_top);
        }
        return list;
    }

    public IContextId getGlobalContextId() {
        return globalContextId;
    }

    public String transformParametersToURL(Collection<String> parameters) {
        StringBuilder sb = new StringBuilder();

        Iterator<String> it = parameters.iterator();
        while (it.hasNext()) {
            String s = it.next();
            String[] s_arr = s.split("="); //$NON-NLS-1$
            String res_s = ""; //$NON-NLS-1$
            int valueIndex = s.indexOf('=');
            if (valueIndex != -1) {
                res_s = s.substring(valueIndex + 1);
                res_s = EscapeChars.forURL(res_s);
            }
            if (res_s.equals("")) { //$NON-NLS-1$
                res_s = "missing"; //$NON-NLS-1$
            }
            res_s = res_s.replaceAll("[*]", "%2A"); //$NON-NLS-1$ //$NON-NLS-2$
            res_s = res_s.replaceAll("[~]", "%7E"); //$NON-NLS-1$//$NON-NLS-2$
            res_s = res_s.replaceAll("[-]", "%2D"); //$NON-NLS-1$ //$NON-NLS-2$
            res_s = res_s.replaceAll("[_]", "%5F"); //$NON-NLS-1$//$NON-NLS-2$
            sb.append(s_arr[0] + "=" + res_s); //$NON-NLS-1$
            if (it.hasNext()) {
                sb.append("&"); //$NON-NLS-1$
            }
        }

        return sb.toString();
    }

    public String getAjaxLink(Collection<String> parameters, XWikiContext context, String actionName) {
        boolean compare = false;
        String url = context.getURL().getPath();

        if (url == null) {
            return ""; //$NON-NLS-1$
        }

        if (context.getAction().equals("compare")) { //$NON-NLS-1$
            compare = true;
        }
        url = url.substring(0, url.indexOf("bin/") + 4) + actionName + url.substring(url.indexOf("/", url.indexOf("bin/") + 4), url.length()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
        url += "?xpage=showstring&"; //$NON-NLS-1$
        url += transformParametersToURL(parameters);
        if (context.get("revision") != null) { //$NON-NLS-1$
            url += "&revision=" + context.get("revision"); //$NON-NLS-1$ //$NON-NLS-2$
        }
        if ("1".equals(context.get(WikiPlugin.TARGET))) { //$NON-NLS-1$
            url += "&" + WikiPlugin.TARGET + "=1"; //$NON-NLS-1$ //$NON-NLS-2$
        }

        //unique name for javascript function
//	    Integer hash = macroText.hashCode();
        String unic_name = IntegrationPlugin.getUniqName();
        String functionName = "function_" + unic_name; //$NON-NLS-1$
        String divName = "div_" + unic_name; //$NON-NLS-1$

        StringBuilder javascriptFunction = new StringBuilder();
        javascriptFunction.append("function "); //$NON-NLS-1$
        javascriptFunction.append(functionName);
        javascriptFunction.append("(e){"); //$NON-NLS-1$
        javascriptFunction.append(" if(!document.getElementById(\""); //$NON-NLS-1$
        javascriptFunction.append(divName);
        javascriptFunction.append("\") ) return;"); //$NON-NLS-1$
        javascriptFunction.append(" document.getElementById(\""); //$NON-NLS-1$
        javascriptFunction.append(divName);
        javascriptFunction.append("\").innerHTML=e;};"); //$NON-NLS-1$

//	    StringBuilder javascriptFunction2 = new StringBuilder();
//	    javascriptFunction2.append("function ");
//	    javascriptFunction2.append(functionName);
//	    javascriptFunction2.append("(e){assignAjaxResult('");
//	    javascriptFunction2.append(divName);
//	    javascriptFunction2.append("', e)};");

        StringBuilder sb = new StringBuilder();

        sb.append("<script type=\"text/javascript\">"); //$NON-NLS-1$
        sb.append(javascriptFunction);
        sb.append("</script>"); //$NON-NLS-1$

        sb.append("<div id=\""); //$NON-NLS-1$
        sb.append(divName);
        sb.append("\"><script type=\"text/javascript\">"); //$NON-NLS-1$
        sb.append("executeCommand('"); //$NON-NLS-1$
        sb.append(url.replaceAll("&#35;", "#")); //$NON-NLS-1$//$NON-NLS-2$
        sb.append("', "); //$NON-NLS-1$
        sb.append(functionName);
//    	sb.append("');runItem.push('"+functionName+"');");
        sb.append(")"); //$NON-NLS-1$
        sb.append("</script>"); //$NON-NLS-1$
        sb.append("<img alt=\"progress\" src=\""); //$NON-NLS-1$
        sb.append(context.getWiki().getSkinFile("progress_small.gif", context)); //$NON-NLS-1$
        sb.append("\"/></div>"); //$NON-NLS-1$

        if (compare) {
            sb.append("<script>"); //$NON-NLS-1$
        } else {
            sb.append("<div style=\"display: none;\" id=\"wi_hd_\">"); //$NON-NLS-1$
        }

        //sb.append("<script>");
        sb.append(javascriptFunction);
        sb.append("executeCommand('"); //$NON-NLS-1$
        sb.append(url);//.replaceAll("&#35;", "#")
        sb.append("', "); //$NON-NLS-1$
        sb.append(functionName);
        sb.append(");"); //$NON-NLS-1$
        if (compare) {
            sb.append("</script>"); //$NON-NLS-1$
        } else {
            sb.append("</div>"); //$NON-NLS-1$
        }

        return sb.toString();
    }

    public boolean performAjaxAction(final IMacroParser parser, final String macroId) {
        return TransactionalExecuter.execute(new RunnableWEx<Boolean>() {
            @Override
            public Boolean runWEx() throws Exception {
                return performAjaxActionTx(parser, macroId);
            }
        });
    }

    @SuppressWarnings("unchecked")
    private boolean performAjaxActionTx(IMacroParser parser, String macroId) {
        String result = ""; //$NON-NLS-1$
        VelocityContext vcontext = (VelocityContext) parser.getContext().get("vcontext"); //$NON-NLS-1$
        XWikiContext context = parser.getContext();

        Collection<String> col = MacroUtils.getInstance().getParameters(context.getRequest().getParameterNames(), context);
        String xpage = null;
        for (String s : col) {
            if (s.matches("xpage=showstring")) { //$NON-NLS-1$
                xpage = s;
                break;
            }
        }
        if (xpage != null) {
            col.remove(xpage);
        }

        String macroText = buildMacroTextFromParameters(macroId, col);
        result = parser.parse(col, macroText, false);

        if (result.equals("")) { //$NON-NLS-1$
            result = Localization.getString("macro.general.noResults"); //$NON-NLS-1$
        }
        context.put("result", result); //$NON-NLS-1$
        vcontext.put("result", result); //$NON-NLS-1$

        return true;
    }

    public String getProjectQueryLink(String projectId, String query, String sort, String revision) {
        PortalLink link = ServerUiContext.getInstance().createPortalLink().project(projectId).workItems().query(query).sorting(sort);
        return link.toEncodedRelativeUrl();
    }

    public String getGroupQueryLink(String groupLocation, String query, String sort, String revision) {
        PortalLink link = null;
        if (groupLocation != null && !groupLocation.isEmpty() && !"/".equals(groupLocation)) { //$NON-NLS-1$
            link = ServerUiContext.getInstance().createPortalLink().projectGroup(groupLocation).workItems().query(query).sorting(sort);
        } else {
            link = ServerUiContext.getInstance().createPortalLink().repository().workItems().query(query).sorting(sort);
        }
        return link.toEncodedRelativeUrl();
    }

    public String getWorkItemLink(String projectId, String id) {
        StringBuilder sb = new StringBuilder();
        sb.append("/polarion/#/project/"); //$NON-NLS-1$
        sb.append(projectId);
        sb.append("workitem?id="); //$NON-NLS-1$
        sb.append(id);

        return sb.toString();
    }

    public <K, V extends Comparable<? super V>> List<K> getKeysSortedByValue(final Map<K, V> map, final boolean desc) {
        final List<Map.Entry<K, V>> list = new ArrayList<Map.Entry<K, V>>(map.entrySet());
        Collections.sort(list, new Comparator<Map.Entry<K, V>>() {
            @Override
            public int compare(Map.Entry<K, V> m1, Map.Entry<K, V> m2) {
                return (desc ? m2 : m1).getValue().compareTo((desc ? m1 : m2).getValue());
            }
        });
        List<K> keys = new ArrayList<K>(list.size());
        for (Map.Entry<K, V> entry : list) {
            keys.add(entry.getKey());
        }
        return keys;
    }

    public String buildMacroTextFromParametersForCompare(String macroName, Collection<String> col) {
        StringBuilder sb = new StringBuilder();
        sb.append("&#123;"); //$NON-NLS-1$
        sb.append(macroName);
        sb.append(col.isEmpty() ? "" : ":"); //$NON-NLS-1$ //$NON-NLS-2$
        Iterator<String> it = col.iterator();
        while (it.hasNext()) {
            sb.append(it.next());
            if (it.hasNext()) {
                sb.append("&#124;"); //$NON-NLS-1$
            }
        }
        sb.append("&#125;"); //$NON-NLS-1$

        return sb.toString();
    }

    public String buildMacroTextFromParameters(String macroName, Collection<String> col) {
        StringBuilder sb = new StringBuilder();
        sb.append("&#123;"); //$NON-NLS-1$
        sb.append(macroName);
        sb.append(col.isEmpty() ? "" : ":"); //$NON-NLS-1$ //$NON-NLS-2$
        Iterator<String> it = col.iterator();
        while (it.hasNext()) {
            sb.append(it.next());
            if (it.hasNext()) {
                sb.append("|"); //$NON-NLS-1$
            }
        }
        sb.append("&#125;"); //$NON-NLS-1$

        return sb.toString();
    }

    public String buildMacroTextFromParametersSimple(String macroName, Collection<String> col) {
        StringBuilder sb = new StringBuilder();
        sb.append("{"); //$NON-NLS-1$
        sb.append(macroName);
        sb.append(col.isEmpty() ? "" : ":"); //$NON-NLS-1$ //$NON-NLS-2$
        Iterator<String> it = col.iterator();
        while (it.hasNext()) {
            sb.append(it.next());
            if (it.hasNext()) {
                sb.append("|"); //$NON-NLS-1$
            }
        }
        sb.append("}"); //$NON-NLS-1$

        return sb.toString();
    }

    public String buildMacroTextFromParameters2(String macroId, MacroParameter params) {
        StringBuilder macroText = new StringBuilder();
        macroText.append("&#123;"); //$NON-NLS-1$
        macroText.append(macroId);
        for (int i = 0, maxi = params.getLength(); i < maxi; i++) {
            String param = params.get(i);
            if (i == 0) {
                macroText.append(":"); //$NON-NLS-1$
            } else {
                if (param != null) {
                    macroText.append("|"); //$NON-NLS-1$
                }
            }
            if (param != null) {
                macroText.append(param);
            }
        }
        macroText.append("&#125;"); //$NON-NLS-1$

        return macroText.toString();
    }

    public boolean isPdfExport(@Nullable XWikiContext context) {
        if (context == null) {
            return false;
        }
        String pdf = (String) context.get("pdf_generate"); //$NON-NLS-1$
        if (pdf == null || pdf.equalsIgnoreCase("0")) { //$NON-NLS-1$
            return false;
        } else {
            return true;
        }
    }

    public String getValueFromParameter(String param) {
        String[] parts = param.split("(\\s)*=(\\s)*"); //$NON-NLS-1$
        if (parts.length != 2) {
            return ""; //$NON-NLS-1$
        }
        return parts[1].trim();
    }

    public boolean showLink(Map<MP, String> map) {
        if (!map.containsKey(MP.LINK)) {
            return true;
        }
        boolean withLink = ("no".equals(map.get(MP.LINK))) ? false : true;

        return withLink;
    }

    public String getLongDisplayField(IPObject pObject) {
        if (pObject instanceof IWorkItem) {
            return null;//IWorkItem.KEY_TITLE;
        } else if (pObject instanceof IProject) {
            return IProject.KEY_ID;
        } else if (pObject instanceof IUser) {
            return IUser.KEY_ID;
        }

        return ""; //$NON-NLS-1$
    }

    /**
     * looking in map for QUERY record, or QUERY_NAME or PROJECT/QUERY_NAME and will return query
     *
     * @param map
     * @param currentProject
     * @param errors
     * @return
     */
    public String getQuery(Map<MP, String> map, IProject currentProject, Map<String, String> errors) {
        if (map.containsKey(MP.PROJECT_SLASH_QUERY_NAME)) {
            String q = map.get(MP.QUERY_NAME); //Q, like from jb007 :)
            if (q.matches("(\\s)*@all(\\s)*")) {
                q = ""; //$NON-NLS-1$
            }
            return getQueryByName2(q, map.get(MP.PARSING_PROJECT), null, errors);
        }
        if (map.containsKey(MP.QUERY)) {
            String q = map.get(MP.QUERY);
            if (q.matches("(\\s)*@all(\\s)*")) {
                q = ""; //$NON-NLS-1$
            }
            return q;
        }
        if (map.containsKey(MP.QUERY_NAME)) {
            return getQueryByName(map.get(MP.QUERY_NAME), currentProject, null, errors);
        }

        return ""; //$NON-NLS-1$
    }

    public long randomId() {
        long x = System.nanoTime();
        x ^= (x << 21);
        x ^= (x >>> 35);
        x ^= (x << 4);
        return Math.abs(x);
    }

    public String escapeTitle(String text) {
        if (text != null) {
            return text.replaceAll("<", "&#60;").replaceAll(">", "&#62;").replace("\\", "&#92;"); //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
        } else {
            return text;
        }
    }

    public boolean isQuery(MacroParameter parameters) {
        if (parameters == null) {
            return false;
        }
        return parameters.getParams().containsKey(ILink.ITEM_QUERY_NAME) || parameters.getParams().containsKey(ILink.ITEM_QUERY_NAME_UPPER) || parameters.getParams().containsKey(ILink.ITEM_QUERY);
    }

    public String buildJSCall(String method, List<String> args) {
        String call = method + "("; //$NON-NLS-1$
        for (int i = 0; i < args.size(); i++) {
            String arg = args.get(i);
            if (i > 0) {
                call += ", "; //$NON-NLS-1$
            }

            if (arg != null) {
                call += "'" + EscapeChars.forJavascriptString(arg) + "'"; //$NON-NLS-1$//$NON-NLS-2$
            } else {
                call += "null"; //$NON-NLS-1$
            }
        }
        call += ");"; //$NON-NLS-1$
        return call;
    }

}
