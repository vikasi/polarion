/*
 * Copyright (C) 2004-2013 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2013 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.polarion.wiki.integration.plans;

import java.util.LinkedHashMap;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import com.polarion.alm.tracker.ITrackerService;
import com.polarion.alm.tracker.model.IPlan;
import com.polarion.alm.ui.shared.wiki.status.StatusData.Type;
import com.polarion.platform.core.PlatformContext;
import com.polarion.reina.web.shared.localization.Localization;
import com.polarion.wiki.integration.StatusButtonMacro;
import com.xpn.xwiki.XWikiContext;

public class PlanStatusButtonMacro extends StatusButtonMacro {

    @NotNull
    public static final String MACRO_ID = "plan-status-button"; //$NON-NLS-1$

    @NotNull
    private static final ITrackerService trackerService = PlatformContext.getPlatform().lookupService(ITrackerService.class);

    public PlanStatusButtonMacro() {
        super(MACRO_ID);
    }

    @Override
    @Nullable
    protected Scope getScope(@NotNull String name, @NotNull LinkedHashMap<String, String> parameters, @NotNull XWikiContext context) {

        IPlan plan = PlanPropertyMacro.getPlan(null, context);

        if (plan != null && !plan.isUnresolvable()) {
            parameters.put(Type.Plan.projectIdParameterName, plan.getProjectId());
            parameters.put(Type.Plan.targetIdParameterName, plan.getId());

            return new Scope(name, parameters, plan.getStatus(), plan.getFinishedOn());
        }

        return null;
    }

    @Override
    protected boolean hasLicense() {
        return trackerService.getTrackerPolicy().canUsePlans();
    }

    @Override
    @NotNull
    protected String getTargetNotAvailableMessage() {
        return Localization.getString("macro.status-button.planContextRequired", getMacroId()); //$NON-NLS-1$
    }

}
