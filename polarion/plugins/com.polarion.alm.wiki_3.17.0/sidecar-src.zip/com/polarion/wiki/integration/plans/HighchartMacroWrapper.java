/*
?* Copyright (C) 2004-2013 Polarion Software
?* All rights reserved.
?* Email: dev@polarion.com
?*
?*
?* Copyright (C) 2004-2013 Polarion Software
?* All Rights Reserved.? No use, copying or distribution of this
?* work may be made except in accordance with a valid license
?* agreement from Polarion Software.? This notice must be
?* included on all copies, modifications and derivatives of this
?* work.
?*
?* POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
?* ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
?* INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
?* FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
?* SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
?* OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
?*
?*/
package com.polarion.wiki.integration.plans;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import com.polarion.alm.server.ServerUiContext;
import com.polarion.alm.server.util.HighchartRenderer;
import com.polarion.alm.server.util.HighchartRenderer.Parameters;
import com.polarion.alm.shared.api.utils.html.HtmlTagBuilder;
import com.polarion.alm.shared.api.utils.html.impl.HtmlBuilder;
import com.polarion.alm.tracker.web.internal.server.PdfExportChartReport;
import com.polarion.alm.ui.server.wiki.macro.HighchartWikiMacro;
import com.polarion.wiki.integration.MacroRenderingProtector;
import com.polarion.wiki.integration.PolarionXWikiMacroWrapper;
import com.xpn.xwiki.XWikiContext;

public abstract class HighchartMacroWrapper<T extends HighchartWikiMacro> extends PolarionXWikiMacroWrapper<T> {
    private static final Logger logger = Logger.getLogger(HighchartMacroWrapper.class);

    @Override
    @NotNull
    protected String renderMacroContent(@NotNull XWikiContext<?, ?> xWikiContext, @NotNull T macro) {
        long currentTime = System.currentTimeMillis();

        HtmlBuilder builder = ServerUiContext.getInstance().createHtmlBuilderFor().forFrame();
        if (macro.advancedValidation(builder)) {
            String html = builder.toString();
            return html;
        }

        String options = super.renderMacroContent(xWikiContext, macro);
        String result = new JsRenderer(xWikiContext, options, getHeight(macro), getWidth(macro)).render(true);
        logger.debug("Time of chart macro rendering is " + (System.currentTimeMillis() - currentTime) + " ms."); //$NON-NLS-1$ //$NON-NLS-2$
        return result;
    }

    @Override
    protected boolean shouldBeWrapedByPre2Level() {
        // highchart renderer has own escaping
        //TODO it can be removed but all cases(also calling from highchart report, from velocity should managed)
        return false;
    }

    protected abstract int getHeight(@NotNull T macro);

    protected abstract int getWidth(@NotNull T macro);

    /**
     * public - because of old highchart report macro uses the same implementation
     */
    public static class JsRenderer {
        private static final String ID_PREFIX = "JsMacroRenderer_"; //$NON-NLS-1$
        private static int id = 0;

        @NotNull
        private final XWikiContext<?, ?> xWikiContext;
        @NotNull
        private final String content;

        private final int height;
        private final int width;

        public JsRenderer(@NotNull XWikiContext<?, ?> xWikiContext, @NotNull String content, int height, int width) {
            this.xWikiContext = xWikiContext;
            this.content = content;
            this.height = height;
            this.width = width;
        }

        @NotNull
        public String render(boolean isEscaped) {
            boolean isForPdfExport = xWikiContext.isInPdfMode();
            if (isForPdfExport || isInPreview()) {
                PdfExportChartReport report = isForPdfExport ? getPdfExportReport() : null;
                return new HighchartRenderer().generateChart(new HighchartRenderer.Parameters(content, height, width, report), getHttpServlerRequest(), isEscaped);
            } else {
                StringBuilder styles = new StringBuilder();
                styles.append("width:").append(width + "px;"); //$NON-NLS-1$ //$NON-NLS-2$
                styles.append("height:").append(height + "px;"); //$NON-NLS-1$ //$NON-NLS-2$
                HtmlBuilder builder = ServerUiContext.getInstance().createHtmlBuilderFor().oldWiki();
                final String currentId = getId();
                HtmlTagBuilder div = builder.append().div();
                HtmlTagBuilder chartDiv = div.append().tag().div();
                chartDiv.attributes().id(currentId).style(styles.toString());
                String script = "<script type=\"text/javascript\">\n" + //$NON-NLS-1$
                        HighchartRenderer.defaultFontDefinition() + //
                        Parameters.getLocalization() + // 
                        "var options = " + content + "\n" + //$NON-NLS-1$ //$NON-NLS-2$
                        HighchartRenderer.sizeDefinition(height, width) +
                        renderToDefinition(currentId) + "new Highcharts.Chart(options);\n" + //$NON-NLS-1$ 
                        "</script>"; //$NON-NLS-1$
                div.append().html(script);
                div.finished();

                // see comment in shouldBeWrapedByPre2Level()
                // protect content by {pre2} tags from Wiki rendering, it messes up spec. characters 
                return MacroRenderingProtector.protect(xWikiContext, builder.toString());

//                return builder.toString();
            }
        }

        @NotNull
        private synchronized static String getId() {
            id++;
            return ID_PREFIX + id;
        }

        private boolean isInPreview() {
            return "preview".equals(xWikiContext.getAction()); //$NON-NLS-1$
        }

        @Nullable
        private PdfExportChartReport getPdfExportReport() {
            return (PdfExportChartReport) xWikiContext.getVelocityContext().get(
                    PdfExportChartReport.KEY_PDF_EXPORT_REPORT);
        }

        @Nullable
        private HttpServletRequest getHttpServlerRequest() {
            return xWikiContext.getRequest().getHttpServletRequest();
        }

        @SuppressWarnings("nls")
        @NotNull
        private static String renderToDefinition(@NotNull String currentId) {
            return "if (options.chart == null){\n renderTo: '" + currentId + "'\n} else {\n"
                    + "options.chart.renderTo = '" + currentId + "';\n" + "}\n";
        }

    }

}
