package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.Collection;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.integration.utils.WorkItemMacroParser;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.util.Util;

/**
 * {workitem: WI-1} - only in project context otherwise error
 * {workitem: TestProject/WI-1}
 * parameters:
 * display=short(default)|long
 * expand=yes|no(default)
 * fields
 * label=LABEL use just as a link with this label
 * 
 * Like the problem with {workitem:DPP-145|label=login screen}. -> Like the problem with <a >login screen</a>
 * 
 * @author Michal Antolik
 *
 */
public class WorkItemMacro extends BaseLocaleMacro {

    final private MacroUtils utils = MacroUtils.getInstance();

    @Override
    public void execute(Writer writer, MacroParameter parameters)
            throws IllegalArgumentException, IOException {

        Collection<String> col = utils.getParameters(parameters);
        String macroText = utils.buildMacroTextFromParameters("workitem", col);

        XWikiContext context = utils.getXWikiContext(parameters);
        WorkItemMacroParser parser = new WorkItemMacroParser(utils.getXWikiContext(parameters));
        String result = null;

        String pdf = (String) context.get("pdf_generate");
        String compare = (String) context.get("compareMode");
        String rev = (String) context.get("revision");
        XWikiDocument o = context.getDoc();
        if (o != null && rev != null && compare == null) {
            rev = o.getVersion();
        }

        if ((compare != null && compare.equalsIgnoreCase("1")) || (utils.isQuery(parameters) && rev != null))
        {
            result = utils.buildMacroTextFromParametersForCompare("workitem", col);
            if (result != null) {
                result = Util.encodeLinkInCompare(result);
            }
            result = "<img src=\"/polarion/ria/images/wiki/macro_workitem.gif\" alt=\"" + result + "\"/>";
        } else if (pdf == null || pdf.equalsIgnoreCase("0")) {
            result = parser.parse(col, macroText, false);
        } else {
            result = parser.parse(col, macroText, true);
        }
        writer.write(result);

    }

//	private String getUrlParameters(Map<MP,String> map){
//		StringBuilder sb = new StringBuilder();
//		Iterator<MP> it = map.keySet().iterator();
//		while (it.hasNext()){
//			MP mp = it.next();
//			sb.append(mp.getName());
//			sb.append("=");
//			sb.append(map.get(mp));
//			if(it.hasNext()){
//				sb.append("&");
//			}
//		}
//		return sb.toString();
//	}

    @Override
    public String getLocaleKey() {
        return "macro.polarionworkitem";
    }

}
