package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.ui.server.wiki.macro.MacroContext;
import com.polarion.core.util.logging.Logger;
import com.polarion.portal.server.HTMLBuilder;
import com.polarion.portal.shared.wiki.WikiEditHelper;
import com.polarion.portal.shared.wiki.WikiMacro;
import com.polarion.portal.shared.wiki.WikiNode;
import com.polarion.portal.shared.wiki.WikiNode.IVisitor;
import com.polarion.portal.shared.wiki.WikiPage;
import com.polarion.portal.shared.wiki.WikiParser;
import com.polarion.reina.web.shared.html.HTMLConst;
import com.polarion.reina.web.shared.localization.Localization;
import com.polarion.wiki.integration.utils.MacroParameterValidationContextXWikiImpl;
import com.polarion.wiki.integration.utils.MacroRenderer;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.xpn.xwiki.XWikiContext;

public abstract class XWikiGwtMacro extends BaseLocaleMacro {

    public interface IMacroContentRenderer {
        void render(HTMLBuilder builder);
    }

    @NotNull
    protected abstract String getMacroId();

    public class MacroData {

        @NotNull
        public final MacroParameter inputParameters;

        @NotNull
        public final XWikiContext wikiContext;

        @NotNull
        public final MacroContext macroContext;

        @NotNull
        public final String macroText;

        public MacroData(@NotNull MacroParameter inputParameters) {
            this.inputParameters = inputParameters;
            wikiContext = MacroUtils.getInstance().getXWikiContext(inputParameters);
            macroContext = new MacroParameterValidationContextXWikiImpl(wikiContext);
            macroText = reconstructMacroText(inputParameters, getMacroId());
        }

        protected boolean isInReadOnlyMode() {
            return wikiContext.isInReadOnlyMode();
        }

        @NotNull
        public Map<String, String> getErrors() throws Exception {
            return new HashMap<String, String>();
        }

        @NotNull
        public Map<String, String> getParameters() {
            return new HashMap<String, String>();
        }

    }

    protected class MacroDataRenderer<T extends MacroData> {

        @NotNull
        protected final T data;

        protected MacroDataRenderer(@NotNull T data) {
            this.data = data;
        }

        private boolean isPdfRendering(@NotNull XWikiContext context) {
            return context.isInPdfMode() || context.isInPrintMode() || context.isInDocumentEditor();
        }

        public void render(@NotNull Writer writer) throws IOException {
            HTMLBuilder builder = new HTMLBuilder(false, isPdfRendering(data.wikiContext));
            try {
                render(builder);
            } catch (Exception e) {
                renderError(builder, e);
            }
            String content = postProcess(builder.toString());
            writer.write(content);
        }

        @NotNull
        protected String postProcess(@NotNull String content) {

            // protect content by {pre2} tags from Wiki rendering, it messes up spec. characters
            return MacroRenderingProtector.protect(data.wikiContext, content);
        }

        protected void render(@NotNull HTMLBuilder builder) throws Exception {

            // Security / visibility
            if (!hasLicense()) {
                renderNoLicense(builder);
            } else {
                // Validations
                if (hasErrors()) {
                    renderErrors(builder);
                } else {
                    if (data.isInReadOnlyMode()) {
                        renderStatical(builder);
                    } else {
                        renderDynamical(builder);
                    }
                }
            }
        }

        protected void renderNoLicense(@NotNull HTMLBuilder builder) throws Exception {
            renderPlaceholder(builder, data.macroText);
        }

        protected boolean hasErrors() throws Exception {
            return !data.getErrors().isEmpty();
        }

        protected void renderErrors(@NotNull HTMLBuilder builder) throws Exception {
            renderError(builder, MacroRenderer.getInstance().renderErrors(data.getErrors(), getMacroTextForErrors(data.inputParameters), isPdfRendering(data.wikiContext)));
        }

        protected void renderStatical(@NotNull HTMLBuilder builder) throws Exception {
            renderPlaceholder(builder, data.macroText);
        }

        protected void renderDynamical(@NotNull HTMLBuilder builder) throws Exception {
            WikiMacro reconstructedMacro = reconstructMacro(data.macroText);
            WikiMacro macro = new WikiMacro(reconstructedMacro.getName(), getParsedParameters(reconstructedMacro));
            renderDynamical(builder, macro);
        }

        protected void renderDynamical(@NotNull HTMLBuilder builder, @NotNull WikiMacro macro) throws Exception {
            renderMacro(builder, macro);
        }

        protected void renderMacro(@NotNull HTMLBuilder builder, @NotNull WikiMacro macro) {
            builder.appendElementStart(HTMLConst.DIV, null, null,
                    WikiEditHelper.createIDParamStr(builder, WikiMacro.NODE_NAME, macro.createParamsMap()));
            {
                builder.appendElementStart(HTMLConst.DIV, null, "margin-top:2px;", null); //$NON-NLS-1$

                getContentRenderer().render(builder);

                builder.appendHTML(HTMLConst.HTML_EDIV);
            }
            builder.appendHTML(HTMLConst.HTML_EDIV);
        }

        @NotNull
        protected IMacroContentRenderer getContentRenderer() {
            return new IMacroContentRenderer() {

                @Override
                public void render(HTMLBuilder builder) {
                    renderMacroParameters(builder, data.getParameters());
                }
            };
        }
    }

    protected WikiMacro reconstructMacro(@NotNull String macroText) {
        WikiPage page = new WikiParser(macroText).parse();
        WikiMacro macro = findMacro(page);
        return macro;
    }

    @Override
    public final String getLocaleKey() {
        return "macro." + getMacroId(); //$NON-NLS-1$
    }

    @NotNull
    protected String reconstructMacroText(@NotNull MacroParameter parameters, @NotNull String macroName) {
        Collection<String> col = MacroUtils.getInstance().getParameters(parameters);
        String macroText = MacroUtils.getInstance().buildMacroTextFromParameters(macroName, col);
        if (macroText.startsWith("&#123;")) { //$NON-NLS-1${
            macroText = "{" + macroText.substring("&#123;".length()); //$NON-NLS-1$//$NON-NLS-2$
        }
        if (macroText.endsWith("&#125;")) { //$NON-NLS-1${
            macroText = macroText.substring(0, macroText.length() - "&#125;".length()) + "}"; //$NON-NLS-1$ //$NON-NLS-2$
        }
        return macroText;
    }

    @Nullable
    protected WikiMacro findMacro(@NotNull WikiPage page) {
        final WikiMacro[] result = new WikiMacro[1];
        page.accept(new IVisitor() {
            @Override
            public boolean visit(WikiNode node) {
                if (node instanceof WikiMacro) {
                    result[0] = (WikiMacro) node;
                }
                return true;
            }
        });
        return result[0];
    }

    protected void renderPlaceholder(@NotNull HTMLBuilder builder, @NotNull String macroText) {
        builder.appendImage("/polarion/ria/images/wiki/macro.gif", null, null, macroText.substring(1, macroText.length() - 1)); //$NON-NLS-1$
    }

    protected void renderError(@NotNull HTMLBuilder builder, @NotNull Throwable e) {
        builder.clear();
        Logger.getLogger(this).error("Exception in rendering the " + getMacroId() + " macro: ", e); //$NON-NLS-1$ //$NON-NLS-2$
        renderError(builder, Localization.getString("macro.general.renderingException", getMacroId())); //$NON-NLS-1$
    }

    protected void renderError(@NotNull HTMLBuilder builder, @Nullable String validationResult) {
        builder.appendElementStart(HTMLConst.DIV, null, "color:red;font-weight:bold;", null); //$NON-NLS-1$
        builder.appendHTML(validationResult);
        builder.appendHTML(HTMLConst.HTML_EDIV);
    }

    protected static void renderMacroParameters(@NotNull HTMLBuilder builder, @NotNull Map<String, String> parameters) {
        if (!parameters.isEmpty()) {
            builder.appendFormStart(null, null, null, null, null);
            for (String key : parameters.keySet()) {
                String value = parameters.get(key);
                if (value != null) {
                    builder.appendInput(key, null, "hidden", null, null, builder.escapeForAttribute(value), null, null); //$NON-NLS-1$
                }
            }
            builder.appendElementEnd(HTMLConst.FORM);
        }
    }

    @NotNull
    protected static LinkedHashMap<String, String> getParsedParameters(@NotNull WikiMacro macro) {
        LinkedHashMap<String, String> parameters = new LinkedHashMap<String, String>();
        Map<String, String> parsedParameters = macro.parseParametersAsNamed();
        if (parsedParameters != null) {
            parameters.putAll(parsedParameters);
        }
        return parameters;
    }

    @NotNull
    protected String getMacroText(@NotNull MacroParameter inputParameters) {
        MacroUtils utils = MacroUtils.getInstance();
        return utils.buildMacroTextFromParametersSimple(getMacroId(), utils.getParameters(inputParameters));
    }

    @NotNull
    protected String getMacroTextForErrors(@NotNull MacroParameter inputParameters) {
        return MacroUtils.getInstance().buildMacroTextFromParameters2(getMacroId(), inputParameters);
    }

    @Override
    public void execute(Writer writer, MacroParameter parameters) throws IllegalArgumentException, IOException {
        new MacroDataRenderer<MacroData>(new MacroData(parameters)).render(writer);
    }

    protected boolean hasLicense() {
        return true;
    }
}
