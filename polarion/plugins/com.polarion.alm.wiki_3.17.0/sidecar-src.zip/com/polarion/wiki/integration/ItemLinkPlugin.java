/*package com.polarion.wiki.integration;

import java.security.PrivilegedExceptionAction;
import java.util.Iterator;

import com.polarion.alm.projects.IProjectService;
import com.polarion.alm.projects.model.IProject;
import com.polarion.alm.tracker.ITrackerService;
import com.polarion.alm.tracker.model.IWorkItem;
import com.polarion.core.util.logging.Logger;
import com.polarion.platform.core.PlatformContext;
import com.polarion.platform.hivemind.EclipseHiveMindPlatform;
import com.polarion.platform.persistence.model.IPObjectList;
import com.polarion.platform.security.ISecurityService;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.api.Api;
import com.xpn.xwiki.plugin.XWikiDefaultPlugin;
import com.xpn.xwiki.plugin.XWikiPluginInterface;

public class ItemLinkPlugin extends XWikiDefaultPlugin
{
	static Logger log = Logger.getLogger(ItemLinkPlugin.class);
	private ISecurityService securityService;
	private IProjectService projectService;
	private ITrackerService tracker;

	public ItemLinkPlugin ( String name, String className, XWikiContext context )
	{
		super(name, className, context);
		log.error("Constructor ItemLinkPlugin: " + name + " - " + className);
		init(context);

		platformInit();
		serviceInit();
	}

	public String getName()
	{
		return "polarionitemlink";
	}

	public void flushCache()
	{
	}

	public void init(XWikiContext context)
	{
		log.error("ItemLinkPlugin init");
		super.init(context);
	}

	public String getLinkItem(String project, String item) throws Exception
	{
		log.error("Get Link Item: " + project + " - " + item);
		// Check project and item
		String checkedproject = project.trim();
		String checkeditem = item.trim();

		String ret = checkProjectItem(checkedproject, checkeditem);

		if (ret == null)
		{
			ret = "<a target='_blank' href='/polarion/#/projects/" + checkedproject + "/workitem/" + checkeditem + "'>" + checkeditem + "</a>";
		}

		return ret;
	}

	private String checkProjectItem(String project, String item) throws Exception
	{
		log.error("Check project item: " + project + " - " + item);
		String ret = null;
		final StringBuffer bf = new StringBuffer();
		final String fproject = project;
		final String fitem = item;

		securityService.doAsSystemUser(new PrivilegedExceptionAction()
		{

			public Object run() throws Exception
			{
				// Search Project
				// IPObjectList list = projectService.searchProjects("Demo Multi
				// Project");
				IPObjectList list = projectService.searchProjects(fproject);
				if (0 == list.size())
				{
					bf.append("Project '" + fproject + "' not found");
					return null;
				}

				Iterator iter = list.iterator();
				IProject project = (IProject) iter.next();

				IPObjectList wiList = tracker.queryWorkItems(project, fitem, null);
				// IPObjectList wiList = tracker.queryWorkItems(project, null,
				// null);

				if (0 == wiList.size())
				{
					bf.append("Item '" + fitem + "' not found");
				}

				return null;
			}
		});

		if (bf.length() > 0)
			ret = bf.toString();

		return ret;
	}

	private void platformInit()
	{
		if (!PlatformContext.isInitialized())
		{
			EclipseHiveMindPlatform platform = new EclipseHiveMindPlatform();
			PlatformContext.initPlatform(platform);
		}
	}

	private void serviceInit()
	{
		securityService = (ISecurityService) PlatformContext.getPlatform().lookupService(ISecurityService.class);
		projectService = (IProjectService) PlatformContext.getPlatform().lookupService(IProjectService.class);
		tracker = (ITrackerService) PlatformContext.getPlatform().lookupService(ITrackerService.class);
	}
}*/
