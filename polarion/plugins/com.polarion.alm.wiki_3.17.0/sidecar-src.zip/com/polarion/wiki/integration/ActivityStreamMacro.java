package com.polarion.wiki.integration;

import java.io.IOException;
import java.io.Writer;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.inject.Inject;

import org.jetbrains.annotations.NotNull;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.alm.ui.server.tracker.ActivityStreamRenderer;
import com.polarion.alm.ui.shared.wiki.activity.ActivityStreamMacroConfiguration;
import com.polarion.platform.guice.internal.GuicePlatform;
import com.polarion.portal.server.HTMLBuilder;
import com.polarion.portal.shared.wiki.WikiMacro;
import com.polarion.reina.web.shared.JSSharedUtil;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.util.RequestParser;
import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;

public class ActivityStreamMacro extends XWikiGwtMacro {

    public static final String MACRO_ID = "activity-stream"; //$NON-NLS-1$

    private ActivityStreamRenderer.Factory rendererFactory;

    public ActivityStreamMacro() {
        super();
        GuicePlatform.getGlobalInjector().injectMembers(this);
    }

    public ActivityStreamRenderer.Factory getRendererFactory() {
        return rendererFactory;
    }

    @Inject
    public void setRendererFactory(ActivityStreamRenderer.Factory rendererFactory) {
        this.rendererFactory = rendererFactory;
    }

    @Override
    @NotNull
    protected String getMacroId() {
        return MACRO_ID;
    }

    @Override
    public void execute(Writer writer, MacroParameter parameters) throws IllegalArgumentException, IOException {
        new DataRenderer(new MacroData(parameters)).render(writer);
    }

    class DataRenderer extends MacroDataRenderer<MacroData> {

        DataRenderer(MacroData data) {
            super(data);
        }

        @Override
        protected void renderDynamical(@NotNull HTMLBuilder builder) throws Exception {
            WikiMacro macro = reconstructMacro(data.macroText);
            ActivityStreamMacroConfiguration configuration = new ActivityStreamMacroConfiguration(macro);
            String validationResult = configuration.validate();
            if (validationResult != null) {
                renderError(builder, validationResult);
            } else {
                if (configuration.getScope() == null) {
                    macro = handleScope(macro, data.wikiContext);
                    configuration = new ActivityStreamMacroConfiguration(macro);
                }
                renderMacro(builder, macro);
            }
        }
    }

    private static WikiMacro handleScope(@NotNull WikiMacro macro, @NotNull XWikiContext context) throws XWikiException {
        LinkedHashMap<String, String> parameters = getParsedParameters(macro);
        String projectId = MacroUtils.getInstance().getCurrentProjectId(context);
        if (!JSSharedUtil.isEmptyString(projectId)) {
            parameters.put(ActivityStreamMacroConfiguration.PROJECT, projectId);
        } else {
            Map requestParams = RequestParser.parseQuery(XWiki.getRequestURL(context.getRequest()).toString(), context);
            String groupLocation = MacroUtils.getInstance().getCurrentGroupLocation(requestParams);
            if (JSSharedUtil.isEmptyString(groupLocation)) {
                groupLocation = "/"; //$NON-NLS-1$
            } else if (!groupLocation.startsWith("/")) { //$NON-NLS-1$
                groupLocation = "/" + groupLocation; //$NON-NLS-1$
            }
            parameters.put(ActivityStreamMacroConfiguration.GROUP, groupLocation);
        }
        return new WikiMacro(macro.getName(), parameters);
    }
}
