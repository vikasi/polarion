package com.polarion.wiki.plugin;

import com.polarion.alm.projects.IProjectService;
import com.polarion.alm.tracker.ITrackerService;
import com.polarion.core.util.logging.Logger;
import com.polarion.platform.core.PlatformContext;
import com.polarion.platform.hivemind.EclipseHiveMindPlatform;
import com.polarion.platform.security.ISecurityService;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.api.Api;

public class PolarionTestPluginApi extends Api
{

    private PolarionTestPlugin plugin;
    static Logger log = Logger.getLogger(PolarionTestPluginApi.class);
    private ISecurityService securityService;
    private IProjectService projectService;
    private ITrackerService tracker;

    public PolarionTestPluginApi(PolarionTestPlugin plugin, XWikiContext context)
    {
        super(context);
        setPlugin(plugin);

        try
        {
            //platformInit();
            //serviceInit();
        } catch (Exception e)
        {
            log.error("Exception while init and setup polarion platform");
        }
    }

    public PolarionTestPlugin getPlugin()
    {
        return plugin;
    }

    public void setPlugin(PolarionTestPlugin plugin)
    {
        this.plugin = plugin;
    }

    public String pluginTest()
    {
        /*final StringBuffer bf = new StringBuffer();
        try
        {

        	securityService.doAsSystemUser(new PrivilegedExceptionAction()
        	{

        		public Object run() throws Exception
        		{
        			IPObjectList list = projectService.searchProjects(null);
        			if (list.size() > 0)
        			{
        				for (Iterator iter = list.iterator(); iter.hasNext();)
        				{
        					IProject project = (IProject) iter.next();
        					bf.append("<h2>Found project: " + project.getName() + "</h2>\n");
        					log.error("Found project: " + project.getName());
        					IPObjectList wiList = tracker.queryWorkItems(project, null, null);
        					if (wiList.size() > 0)
        					{
        						bf.append("<h3>Work items: </h3>\n");
        						bf.append("<select size='5'>");
        						for (Iterator iterator = wiList.iterator(); iterator.hasNext();)
        						{
        							IWorkItem workItem = (IWorkItem) iterator.next();

        							if (workItem.getRevision() != null)
        							{
        								continue;
        							}
        							bf.append("<option>" + workItem.getId() + "</option>\n");
        							log.error("\tFound work item: " + workItem.getId());
        						}// ADD
        						bf.append("</select>\n");
        					}
        					else
        					{
        						bf.append("<h3>Work items for this project not found</h3>");
        					}
        				}
        			}
        			else
        			{
        				bf.append("<h2>Projects not found</h2>");
        			}

        			return null;
        		}
        	});
        }
        catch (Exception e)
        {
        	log.error("Exception while working with polarion projects: " + e.getMessage());
        }

        return bf.toString();*/
        return "";
    }

    //
    // TRACKER API
    //

    private void platformInit()
    {
        if (!PlatformContext.isInitialized())
        {
            EclipseHiveMindPlatform platform = new EclipseHiveMindPlatform();
            PlatformContext.initPlatform(platform);
        }
    }

    private void serviceInit()
    {
        securityService = (ISecurityService) PlatformContext.getPlatform().lookupService(ISecurityService.class);
        projectService = (IProjectService) PlatformContext.getPlatform().lookupService(IProjectService.class);
        tracker = (ITrackerService) PlatformContext.getPlatform().lookupService(ITrackerService.class);
    }

}
