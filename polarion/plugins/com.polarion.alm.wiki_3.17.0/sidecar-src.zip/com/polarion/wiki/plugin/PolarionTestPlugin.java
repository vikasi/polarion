package com.polarion.wiki.plugin;

import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.api.Api;
import com.xpn.xwiki.plugin.XWikiDefaultPlugin;
import com.xpn.xwiki.plugin.XWikiPluginInterface;

public class PolarionTestPlugin extends XWikiDefaultPlugin
{

    public PolarionTestPlugin(String name, String className, XWikiContext context)
    {
        super(name, className, context);
        init(context);
    }

    @Override
    public String getName()
    {
        return "PolarionTestPlugin";
    }

    public void fluchCache() {
    }

    @Override
    public Api getPluginApi(XWikiPluginInterface plugin, XWikiContext context)
    {
        return new PolarionTestPluginApi((PolarionTestPlugin) plugin, context);
    }

    @Override
    public void init(XWikiContext context)
    {
        super.init(context);
    }
/*

public HelloWorldPlugin(String name, String className, XWikiContext context) { super(name,className,context); init(context); }

public String getName() { return "helloworld"; }

public Api getPluginApi(XWikiPluginInterface plugin, XWikiContext context) { return new HelloWorldPluginApi((HelloWorldPlugin) plugin, context); }

public void flushCache() { }

public void init(XWikiContext context) { super.init(context); }
 
 */
}
