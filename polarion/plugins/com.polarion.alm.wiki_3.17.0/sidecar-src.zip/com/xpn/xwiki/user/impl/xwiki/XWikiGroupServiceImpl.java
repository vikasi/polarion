/*
 * Copyright 2006, XpertNet SARL, and individual contributors as indicated
 * by the contributors.txt.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 * @author ludovic
 * @author sdumitriu
 */

package com.xpn.xwiki.user.impl.xwiki;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Vector;

import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.cache.api.XWikiCache;
import com.xpn.xwiki.cache.api.XWikiCacheNeedsRefreshException;
import com.xpn.xwiki.cache.api.XWikiCacheService;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.notify.DocChangeRule;
import com.xpn.xwiki.notify.XWikiDocChangeNotificationInterface;
import com.xpn.xwiki.notify.XWikiNotificationInterface;
import com.xpn.xwiki.notify.XWikiNotificationRule;
import com.xpn.xwiki.objects.BaseObject;
import com.xpn.xwiki.user.api.XWikiGroupService;
import com.xpn.xwiki.util.Util;

public class XWikiGroupServiceImpl implements XWikiGroupService, XWikiDocChangeNotificationInterface {
    protected XWikiCache groupCache;

    @Override
    public synchronized void init(XWiki xwiki, XWikiContext context) throws XWikiException {
        initCache(context);
        xwiki.getNotificationManager().addGeneralRule(new DocChangeRule(this));
    }

    @Override
    public synchronized void initCache(XWikiContext context) throws XWikiException {
        int iCapacity = 100;
        try {
            String capacity = context.getWiki().Param("xwiki.authentication.group.cache.capacity");
            if (capacity != null) {
                iCapacity = Integer.parseInt(capacity);
            }
        } catch (Exception e) {
        }
        initCache(iCapacity, context);
    }

    @Override
    public synchronized void initCache(int iCapacity, XWikiContext context) throws XWikiException {
        XWikiCacheService cacheService = context.getWiki().getCacheService();
        groupCache = cacheService.newCache("xwiki.authentication.group.cache", iCapacity);
    }

    @Override
    public void flushCache() {
        if (groupCache != null) {
            groupCache.flushAll();
            groupCache = null;
        }
    }

    @Override
    public Collection listGroupsForUser(String username, XWikiContext context) throws XWikiException {
        List list = null;
        String database = context.getDatabase();
        try {
            String shortname = Util.getName(username);
            String veryshortname = shortname.substring(shortname.indexOf(".") + 1);
            String key = database + ":" + shortname;
            synchronized (key) {
                if (groupCache == null) {
                    initCache(context);
                }
                try {
                    list = (List) groupCache.getFromCache(key);
                } catch (XWikiCacheNeedsRefreshException e) {
                    groupCache.cancelUpdate(key);

                    groupCache.putInCache(key, list);
                }
            }
            return list;
        } finally {
            context.setDatabase(database);
        }
    }

    /*
       Adding the user to the group cache
    */
    @Override
    public void addUserToGroup(String username, String database, String group, XWikiContext context) throws XWikiException {
        String shortname = Util.getName(username);
        List list = null;
        String key = database + ":" + shortname;
        if (groupCache == null) {
            initCache(context);
        }
        synchronized (key) {
            try {
                list = (List) groupCache.getFromCache(key);
            } catch (XWikiCacheNeedsRefreshException e) {
                groupCache.cancelUpdate(key);
                list = new ArrayList();
                groupCache.putInCache(key, list);
            }
        }
        list.add(group);
    }

    @Override
    public List listMemberForGroup(String group, XWikiContext context) throws XWikiException {
        List list = new ArrayList();
        String database = context.getDatabase();
        String sql = "";

        try {
            if (group == null) {
                return list;
            } else {
                String gshortname = Util.getName(group, context);
                XWikiDocument docgroup = context.getWiki().getDocument(gshortname, context);
                Vector v = docgroup.getObjects("XWiki.XWikiGroups");
                for (int i = 0; i < v.size(); i++) {
                    BaseObject bobj = (BaseObject) v.get(i);
                    if (bobj != null) {
                        String members = bobj.getStringValue("member");
                        if (members != null) {
                            String[] members2 = members.split(" ,");
                            for (String element : members2) {
                                list.add(members2[i]);
                            }
                        }
                    }
                }
                return list;
            }
        } catch (XWikiException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            context.setDatabase(database);
        }
        return null;
    }

    @Override
    public List listAllGroups(XWikiContext context) throws XWikiException {
        return null;
    }

    public List listAllLevels(XWikiContext context) throws XWikiException {
        List list = new ArrayList();
        String levels = "admin,view,edit,comment,delete,register,programming";
        String[] level = levels.split(",");
        for (String element : level) {
            list.add(element);
        }
        return list;
    }

    @Override
    public void notify(XWikiNotificationRule rule, XWikiDocument newdoc, XWikiDocument olddoc, int event, XWikiContext context) {
        try {
            if (event == XWikiNotificationInterface.EVENT_CHANGE) {
                boolean flushCache = false;

                if ((olddoc != null) && (olddoc.getObjects("XWiki.XWikiGroups") != null)) {
                    flushCache = true;
                }

                if ((newdoc != null) && (newdoc.getObjects("XWiki.XWikiGroups") != null)) {
                    flushCache = true;
                }

                if (flushCache) {
                    flushCache();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
