package com.xpn.xwiki.plugin.autotag;

import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.api.Api;

public class AutoTagPluginAPI extends Api
{

    private AutoTagPlugin plugin;

    public AutoTagPluginAPI(XWikiContext context)
    {
        super(context);
    }

    public AutoTagPluginAPI(AutoTagPlugin autoTagPlugin, XWikiContext context)
    {
        super(context);
        plugin = autoTagPlugin;
    }

    public TagCloud generateTagCloud(String text, int lang)
    {
        return plugin.generateTagCloud(text, lang);
    }
}
