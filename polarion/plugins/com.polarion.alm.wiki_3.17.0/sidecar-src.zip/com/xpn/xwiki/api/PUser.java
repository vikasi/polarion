package com.xpn.xwiki.api;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.catalina.util.ParameterMap;

import com.polarion.alm.projects.model.IUser;
import com.polarion.core.util.logging.Logger;
import com.polarion.wiki.integration.IntegrationPlugin;
import com.polarion.wiki.integration.link.UserLink;
import com.polarion.wiki.integration.link.Validator;
import com.xpn.xwiki.XWikiContext;

public class PUser extends Api
{
    static Logger log = Logger.getLogger(PUser.class);
    private XWikiContext context;
    private IntegrationPlugin plugin;
    private UserLink ul;
    private int itemCount = 0;
    private long id = 0;
    private static HashMap fieldNamesMap = new HashMap();
    IUser[] users = null;

    private Validator validator;

    public static String KEY_ROLE = "roles";

    public PUser(XWikiContext context, long id)
    {
        super(context);
        this.id = id;
        this.context = context;
        initFields();
        plugin = (IntegrationPlugin) context.getWiki().getPlugin("integrationplugin", context);
        validator = new Validator(fieldNamesMap.keySet());
    }

    public PUser(UserLink link, XWikiContext context, long id)
    {
        super(context);
        initFields();
        ul = link;
        this.id = id;
        plugin = (IntegrationPlugin) context.getWiki().getPlugin("integrationplugin", context);
        validator = new Validator(fieldNamesMap.keySet());
    }

    protected void initFields() {
        if (!fieldNamesMap.isEmpty()) {
            return;
        }
        fieldNamesMap.put(IUser.KEY_ID, new FieldName("ID", 1));
        fieldNamesMap.put(IUser.KEY_NAME, new FieldName("Name", 2));
        fieldNamesMap.put(IUser.KEY_DESCRIPTION, new FieldName("Description", 3));
        fieldNamesMap.put(IUser.KEY_EMAIL, new FieldName("Mail", 4));
        fieldNamesMap.put(KEY_ROLE, new FieldName("Roles", 5));
    }

    public String getRealNameField(String field)
    {
        String res = null;
        PUser.FieldName fieldName = (PUser.FieldName) fieldNamesMap.get(field);
        if (fieldName != null) {
            res = fieldName.name;
        }
        if (res != null) {
            return res;
        } else {
            return field;
        }
    }

    public IUser[] getUsers(ParameterMap m)
    {
        if (users != null) {
            return users;
        }
        if (ul == null) {
            ul = new UserLink(m, context);
        }
        try
        {
            List l = plugin.getUserList(ul);
            IUser[] ar = new IUser[l.size()];
            int i = 0;
            Iterator it = l.listIterator();
            while (it.hasNext()) {
                ar[i++] = (IUser) it.next();
            }
            itemCount = i;
            String sortby = ul.getSortBy();
            if (sortby != null && fieldNamesMap.containsKey(sortby)) {
                Comparator userComparator = new UserComparator(sortby);
                Arrays.sort(ar, userComparator);
                return ar;
            } else {
                return ar;
            }
        } catch (IllegalArgumentException iae) {
            validator.addError(iae.getMessage());
            log.error(iae.getMessage());
        } catch (Exception e)
        {
            log.error(e.getMessage());
        }
        return null;
    }

    public int getUserCount() {
        return plugin.getUserList(ul).size();
    }

    public String getValue(String field, IUser user) {
        try {
            if (field == null || user == null) {
                return "";
            }
            if (field.equalsIgnoreCase(IUser.KEY_ID)) {
                return user.getId();
            } else if (field.equalsIgnoreCase(IUser.KEY_NAME)) {
                return user.getName();
            } else if (field.equalsIgnoreCase(IUser.KEY_DESCRIPTION)) {
                return user.getDescription().getContent();
            } else if (field.equalsIgnoreCase(IUser.KEY_EMAIL)) {
                return user.getEmail();
            } else if (field.equalsIgnoreCase(UserLink.FIELD_ROLES)) {
                String res = "";
                java.util.Collection roles = plugin.getRolesForUser(user, null);
                Iterator it = roles.iterator();

                boolean first = true;
                while (it.hasNext()) {
                    String role = (String) it.next();
                    res += (first ? "" : "; ") + role;
                    first = false;
                }
                return res;
            }
        } catch (Exception e) {
        }
        return "";

    }

    public int getSize() {
        return itemCount;
    }

    public long getId() {
        return id;
    }

    public String getUserUrl(IUser user) {
        return "";
    }

    public UserLink getUserLink() {
        return ul;
    }

    public boolean validate(ParameterMap parameters) {
        return validator.validate(parameters);
    }

    public List getErrors() {
        return validator.getErrors();
    }

    class FieldName
    {
        String name = "";
        int number = 0;

        public FieldName(String name, int number)
        {
            this.name = name;
            this.number = number;
        }

    }

    class UserComparator implements Comparator {
        private String sortby;

        public UserComparator(String sortby) {
            this.sortby = sortby;
        }

        @Override
        public int compare(java.lang.Object obj1, java.lang.Object obj2)
        {
            IUser user1 = (IUser) obj1;
            IUser user2 = (IUser) obj2;
            String value1 = getValue(sortby, user1);
            String value2 = getValue(sortby, user2);
            return value1.compareToIgnoreCase(value2);
        }

    }

}
