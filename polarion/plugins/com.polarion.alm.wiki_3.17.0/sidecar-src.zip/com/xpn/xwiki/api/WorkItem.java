package com.xpn.xwiki.api;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.catalina.util.ParameterMap;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.polarion.alm.projects.model.IUniqueObject;
import com.polarion.alm.projects.model.IUser;
import com.polarion.alm.shared.util.ObjectUtils;
import com.polarion.alm.tracker.model.IApprovalStruct;
import com.polarion.alm.tracker.model.IHyperlinkStruct;
import com.polarion.alm.tracker.model.IPriorityOpt;
import com.polarion.alm.tracker.model.ISeverityOpt;
import com.polarion.alm.tracker.model.IStatusOpt;
import com.polarion.alm.tracker.model.ITypeOpt;
import com.polarion.alm.tracker.model.IWorkItem;
import com.polarion.alm.tracker.model.IWorkflowObject;
import com.polarion.alm.tracker.web.internal.shared.JSComment;
import com.polarion.alm.tracker.web.internal.shared.JSWorkItem;
import com.polarion.core.util.types.DateOnly;
import com.polarion.core.util.types.Text;
import com.polarion.core.util.types.duration.DurationTime;
import com.polarion.platform.core.PlatformContext;
import com.polarion.platform.persistence.ICustomFieldsService;
import com.polarion.platform.persistence.IEnumOption;
import com.polarion.platform.persistence.model.IPObjectList;
import com.polarion.platform.persistence.model.IRevision;
import com.polarion.platform.persistence.model.ITypedList;
import com.polarion.platform.persistence.spi.AbstractTypedList;
import com.polarion.platform.persistence.spi.CustomTypedList;
import com.polarion.platform.persistence.spi.DelegatingOption;
import com.polarion.platform.persistence.spi.PObjectList;
import com.polarion.portal.server.HTMLBuilder;
import com.polarion.portal.server.PObjectDataProvider;
import com.polarion.reina.web.shared.html.IHTMLBuilder;
import com.polarion.subterra.base.data.identification.IContextId;
import com.polarion.subterra.base.data.model.ICustomField;
import com.polarion.wiki.integration.IntegrationPlugin;
import com.polarion.wiki.integration.link.ILink;
import com.polarion.wiki.integration.link.WorkItemField;
import com.polarion.wiki.integration.link.WorkItemLink;
import com.polarion.wiki.integration.link.WorkItemValidator;
import com.polarion.wiki.util.ConvertUtil;
import com.xpn.xwiki.XWikiContext;

/**
 *
 * @author Borovik P
 * API class for use in velosity page
 * present main methods
 */

public class WorkItem extends Api {
    private XWikiContext context;
    private IntegrationPlugin plugin;
    private WorkItemLink wi;
    private int itemCount = 0;
    private long id = 0;
    private static HashMap<String, WorkItem.FieldStructure> fieldsName_map = new HashMap<String, WorkItem.FieldStructure>();
    private ICustomFieldsService cfs;
    private IWorkItem[] items = null;
    private WorkItemValidator validator;

    public WorkItem(WorkItemLink item, XWikiContext context) {
        super(context);
        this.context = context;
        cfs = PlatformContext.getPlatform().lookupService(ICustomFieldsService.class);
        initFields();
        validator = new WorkItemValidator(this, fieldsName_map.keySet());
    }

    public WorkItem(WorkItemLink item, XWikiContext context, long id) {
        super(context);
        this.context = context;
        initFields();
        wi = item;
        this.id = id;
        cfs = PlatformContext.getPlatform().lookupService(ICustomFieldsService.class);
        plugin = (IntegrationPlugin) context.getWiki().getPlugin("integrationplugin", context); //$NON-NLS-1$
        validator = new WorkItemValidator(this, fieldsName_map.keySet());
    }

    public WorkItem newItem(XWikiContext context, long id) {
        return new WorkItem(context, id);
    }

    public WorkItem newItem(WorkItemLink item, XWikiContext context, long id) {
        return new WorkItem(item, context, id);
    }

    public WorkItem(XWikiContext context, long id) {
        super(context);
        this.id = id;
        this.context = context;
        cfs = PlatformContext.getPlatform().lookupService(ICustomFieldsService.class);
        initFields();
        plugin = (IntegrationPlugin) context.getWiki().getPlugin("integrationplugin", context); //$NON-NLS-1$
        validator = new WorkItemValidator(this, fieldsName_map.keySet());
    }

    /**
     * @param m
     * request parameters
     * @return IWorkItems array
     */
    public IWorkItem[] getWorkItems(ParameterMap m) throws Exception {
        IWorkItem[] ar = null;
        try {
            wi = new WorkItemLink(m, context);
            ar = plugin.getLinkItemArray(wi);
            if (ar != null) {
                itemCount = ar.length;
            } else {
                itemCount = 0;
            }
        } catch (Exception e) {
            //Can't view com.polarion.subterra.index.QueryIndexException, so it just a workaround
            String mess = e.getMessage();
            int ind = mess.indexOf("com.polarion.subterra.index.QueryIndexException:"); //$NON-NLS-1$
            if (ind != -1) {
                mess = mess.substring(ind + "com.polarion.subterra.index.QueryIndexException:".length()); //$NON-NLS-1$
            }
            validator.addError(mess);
        }
        return ar;

    }

    /**
     * search single WorkItem
     * @return
     */
    public IWorkItem[] getSingleWorkItem(String id) throws Exception {
        if (id == null || id.equalsIgnoreCase("")) {
            return null;
        }
        return plugin.getItemFromQuery(null, "id:" + id, null, 0, wi); //$NON-NLS-1$
    }

    /**
     * @return IWorkItems array for create pdf
     */

    public IWorkItem[] getWorkItems() {
        try {
            if (items == null) {
                items = plugin.getLinkItemArray(wi);
                if (items != null) {
                    itemCount = items.length;
                } else {
                    itemCount = 0;
                }
            }
            return items;
        } catch (Exception e) {
            return null;
        }
    }

    public int getSize() {
        return itemCount;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getId() {
        return id;
    }

    public String getDisplay() {
        return wi.getDisplay().toLowerCase();
    }

    public int getCollCount() {
        return wi.getFieldsArray().length;
    }

    public String[] getFields() {
        return sortFields(wi.getFieldsArray());
    }

    public WorkItemLink getWorkItemLink() {
        return wi;
    }

    public String getQuery() {
        return wi.getQuery();
    }

    public String getItem() {
        return wi.getItem();
    }

    public String getProject() {
        String pr = wi.getProject();
        return (pr == null) || (pr.equalsIgnoreCase("")) ? "" : pr + "/"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    }

    public int getTotal() {
        return wi.getTotal();
    }

    public int getTop() {
        return wi.getTop();
    }

    public String getQueryProject() {
        String pr = wi.getQueryProject();
        return (pr == null) || (pr.equalsIgnoreCase("")) ? "" : pr + "/"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    }

    /**
     * return URL for WorkItem
    */
    public String getWorkItemURL(IWorkItem wri) {
        if (wi.getProject() != null && !wi.getItem().equalsIgnoreCase(ILink.ITEM_QUERY)) {
            return plugin.getWorkItemLink(wi.getProject(), null, wri);
        } else if (wi.getQueryProject() != null) {
            return plugin.getWorkItemLink(wi.getQueryProject(), null, wri);
        } else {
            return plugin.getWorkItemLink(null, null, wri);
        }
    }

    public String getWorkItemURLPdf(IWorkItem wri) {
        if (wi.getProject() != null && !wi.getItem().equalsIgnoreCase(ILink.ITEM_QUERY)) {
            return plugin.getWorkItemLinkPdf(wi.getProject(), null, wri);
        } else if (wi.getQueryProject() != null) {
            return plugin.getWorkItemLinkPdf(wi.getQueryProject(), null, wri);
        } else {
            return plugin.getWorkItemLinkPdf(null, null, wri);
        }
    }

    public String getWorkItemMore() {
        if (wi.getProject() != null && !wi.getItem().equalsIgnoreCase(ILink.ITEM_QUERY)) {
            if (wi.getSavedQuery() != null) {
                return plugin.getWorkItemMore(wi.getProject(), null, wi.getSavedQuery());
            } else {
                return plugin.getWorkItemSingle(wi.getProject(), null, wi.getItem());
            }
        } else if (wi.getQueryProject() != null) {
            if (wi.getSavedQuery() != null) {
                return plugin.getWorkItemMore(wi.getQueryProject(), null, wi.getSavedQuery());
            } else {
                return plugin.getWorkItemMore(wi.getQueryProject(), null, wi.getQuery());
            }
        } else if (wi.getQuery() != null) {
            return plugin.getWorkItemMore(null, null, wi.getQuery());
        } else {
            return plugin.getWorkItemMore(null, null, ""); //$NON-NLS-1$
        }

    }

    public String getWorkItemMorePdf() {
        if (wi.getProject() != null && !wi.getItem().equalsIgnoreCase(ILink.ITEM_QUERY)) {
            if (wi.getSavedQuery() != null) {
                return plugin.getWorkItemMorePdf(wi.getProject(), null, wi.getSavedQuery());
            } else {
                return plugin.getWorkItemSinglePdf(wi.getProject(), null, wi.getItem());
            }
        } else if (wi.getQueryProject() != null) {
            if (wi.getSavedQuery() != null) {
                return plugin.getWorkItemMorePdf(wi.getQueryProject(), null, wi.getSavedQuery());
            } else {
                return plugin.getWorkItemMorePdf(wi.getQueryProject(), null, wi.getQuery());
            }
        } else if (wi.getQuery() != null) {
            return plugin.getWorkItemMorePdf(null, null, wi.getQuery());
        } else {
            return plugin.getWorkItemMorePdf(null, null, ""); //$NON-NLS-1$
        }

    }

    @SuppressWarnings("unchecked")
    public String getValueComments(IWorkItem workItem, boolean pdf) {
        JSWorkItem wi = (JSWorkItem) PObjectDataProvider.transformInstance(workItem, null, false, null, null, true, false, null);
        IHTMLBuilder b = new HTMLBuilder();
        ArrayList<JSComment> comments = (ArrayList<JSComment>) wi.getValue(JSWorkItem.KEY_COMMENTS);
        boolean first = true;
        for (Iterator iterator = comments.iterator(); iterator.hasNext();) {
            JSComment comment = (JSComment) iterator.next();
            if (first) {
                first = false;
                comment.renderTableStart(b);
            }
            comment.renderTableDataRow(b, null, true, true);

            if (!iterator.hasNext()) {
                comment.renderTableEnd(b);
            }
        }
        if (pdf) {
            return com.xpn.xwiki.util.Util.contentEncode(workItem.transformDescriptionForUI(new Text(Text.TYPE_HTML, b.toString())).getContent().trim());
        } else {
            return workItem.transformDescriptionForUI(new Text(Text.TYPE_HTML, b.toString())).getContent().trim();
        }
    }

    public String getValueDescription(IWorkItem workItem) {
        if (workItem == null) {
            return ""; //$NON-NLS-1$
        }
        String res = (workItem.getDescription()) != null ? (workItem.transformDescriptionForUI(workItem.getDescription())).getContent().trim() : "";
        return res;
    }

    public String getValueDescriptionPDF(IWorkItem workItem) {
        if (workItem == null) {
            return ""; //$NON-NLS-1$
        }
        String res = (workItem.getDescription()) != null ? (workItem.transformDescriptionForUI(workItem.getDescription())).getContent().trim() : "";
//		res = prepareLiveDocURL(res);
        return com.xpn.xwiki.util.Util.contentEncode(res);
    }

    public String getValueID(IWorkItem workItem) {
        try {
            String res = workItem.getId();
            if (res == null) {
                res = ""; //$NON-NLS-1$
            }
            return res;
        } catch (Exception e) {
            return ""; //$NON-NLS-1$
        }
    }

    public String getValueIDPdf(IWorkItem workItem) {
        try {
            String name = workItem.getId();
            ITypeOpt val = (workItem.getType());
            if (val != null) {
                String id = val.getId();
                if (name == null) {
                    name = ""; //$NON-NLS-1$
                }
                return getImageField(id, name, IUniqueObject.KEY_ID, val);
            }
            return ""; //$NON-NLS-1$

        } catch (Exception e) {
            return ""; //$NON-NLS-1$
        }
    }

    /**
     *
     * @param field name
     * @param workItem current IWorkItem
     * @return
     */
    public String getValue(String field, IWorkItem workItem) {
        try {
            if (field.equals(IUniqueObject.KEY_ID)) {
                String name = workItem.getId();
                ITypeOpt val = (workItem.getType());
                if (val != null) {
                    String id = val.getId();
                    if (name == null) {
                        name = ""; //$NON-NLS-1$
                    }
                    return getImageField(id, name, IUniqueObject.KEY_ID, val);
                }
                return ""; //$NON-NLS-1$

            } else if (field.equals(IWorkItem.KEY_TITLE)) {
                return workItem.getTitle();
            } else if (field.equals(IWorkflowObject.KEY_TYPE)) {
                ITypeOpt val = (workItem.getType());

                if (val != null) {
                    String id = val.getId();
                    String name = val.getName();
                    if (name == null) {
                        name = ""; //$NON-NLS-1$
                    }
                    return getImageField(id, name, IWorkflowObject.KEY_TYPE, val);
                }
                return ""; //$NON-NLS-1$
            } else if (field.equals(IWorkItem.KEY_CREATED)) {
                return convertDate(workItem.getCreated());
            } else if (field.equals(IWorkItem.KEY_UPDATED)) {
                return convertDate(workItem.getUpdated());
            } else if (field.equals(IWorkItem.KEY_AUTHOR)) {
                return (workItem.getAuthor()) != null ? (workItem.getAuthor()).getName() : ""; //$NON-NLS-1$
            } else if (field.equals(IWorkItem.KEY_SEVERITY)) {
                ISeverityOpt val = workItem.getSeverity();
                if (val != null) {
                    String id = val.getId();
                    String name = val.getName();
                    if (name == null) {
                        name = ""; //$NON-NLS-1$
                    }
                    return getImageField(id, name, IWorkItem.KEY_SEVERITY, val);
                }
                return ""; //$NON-NLS-1$
            } else if (field.equals(IWorkItem.KEY_DESCRIPTION)) {
                String res = (workItem.getDescription()) != null ? (workItem.transformDescriptionForUI(workItem.getDescription())).getContent().trim() : ""; //$NON-NLS-1$
                try {
                    if (wi.getOutputType().equalsIgnoreCase("list")) //$NON-NLS-1$
                    {
//						res = prepareLiveDocURL(res);
                        return res;
                    } else {
//						res = prepareLiveDocURL(res);
                        res = replaceTaleContent(res);
                        return res;
                    }
                } catch (Exception e) {
                    return "Description...";
                }
            } else if (field.equals(IUniqueObject.KEY_PROJECT)) {
                return (workItem.getProject()) != null ? (workItem.getProject()).getName() : "";
            } else if (field.equalsIgnoreCase(IWorkItem.KEY_CATEGORIES)) {
                String bs_buff = ""; //$NON-NLS-1$
                IPObjectList lst = workItem.getCategories();
                if (lst != null) {
                    Iterator itr = lst.iterator();
                    while (itr.hasNext()) {
                        String cat = (String) itr.next();
                        bs_buff += (cat + " "); //$NON-NLS-1$
                    }
                }
                return bs_buff;
            } else if (field.equals(IWorkItem.KEY_INITIAL_ESTIMATE)) {
                return convertDurationDate(workItem.getInitialEstimate());
            } else if (field.equals(IWorkItem.KEY_TIME_SPENT)) {
                return convertDurationDate(workItem.getTimeSpent());
            } else if (field.equals(IWorkItem.KEY_REMAINING_ESTIMATE)) {
                return convertDurationDate(workItem.getRemainingEstimate());
            } else if (field.equals(IWorkItem.KEY_ASSIGNEE)) {
                String bs_buff = ""; //$NON-NLS-1$
                IPObjectList users = workItem.getAssignees();
                if (users != null) {
                    Iterator it3 = users.iterator();
                    while (it3.hasNext()) {
                        IUser us = (IUser) it3.next();
                        String nm = us.getName();
                        bs_buff += (nm + " "); //$NON-NLS-1$
                    }
                }
                return bs_buff;
            } else if (field.equals(IWorkflowObject.KEY_STATUS)) {
                //return ((IStatusOpt)workItem.getStatus()) != null ? ((IStatusOpt)workItem.getStatus()).getId() : "";
                IStatusOpt val = (workItem.getStatus());
                if (val != null) {
                    String id = val.getId();
                    String name = val.getName();
                    if (name == null) {
                        name = ""; //$NON-NLS-1$
                    }
                    return getImageField(id, name, IWorkflowObject.KEY_STATUS, val);
                }
                return ""; //$NON-NLS-1$
            } else if (field.equals(IWorkItem.KEY_RESOLUTION)) {
                return (workItem.getResolution()) != null ? (workItem.getResolution()).getName() : ""; //$NON-NLS-1$
            } else if (field.equals(IWorkItem.KEY_PRIORITY)) {
                IPriorityOpt val = (workItem.getPriority());
                if (val != null) {
                    String id = val.getName();
                    String name = val.getName() + " " + val.getId(); //$NON-NLS-1$
                    if (name == null) {
                        name = ""; //$NON-NLS-1$
                    }
                    return getImageField(id, name, IWorkItem.KEY_PRIORITY, val);
                }
                return ""; //$NON-NLS-1$
            } else if (field.equals(IWorkItem.KEY_DUE_DATE)) {
                return convertDueDate(workItem.getDueDate());
            } else if (field.equals(IWorkItem.KEY_TIME_POINT)) {
                return convertDueDate((workItem.getTimePoint()) != null ? (workItem.getTimePoint()).getTime() : null);
            } else if (field.equals(IWorkItem.KEY_PLANNING_CONSTRAINTS)) {
                ITypedList typeList = workItem.getPlanningConstraints();
                if (typeList != null && typeList.size() > 0) {
                    AbstractTypedList absList = (AbstractTypedList) typeList;
                    java.util.List utilList = absList.getRawData();
                    HashMap mapList = (HashMap) utilList.get(0);
                    String type = (String) mapList.get("constraint"); //$NON-NLS-1$
                    String data = convertDate((Date) mapList.get("date")); //$NON-NLS-1$
                    return type + " " + data; //$NON-NLS-1$
                }
                return ""; //$NON-NLS-1$
            } else if (field.equals(IWorkItem.KEY_PLANNED_END)) {
                return convertDate(workItem.getPlannedEnd());
            } else if (field.equals(IWorkItem.KEY_PLANNED_START)) {
                return convertDate(workItem.getPlannedStart());
            } else if (field.equals(IWorkItem.KEY_RESOLVED_ON)) {
                return convertDate(workItem.getResolvedOn());
            } else if (field.equals(IWorkItem.KEY_PREVIOUS_STATUS)) {
                IStatusOpt val = (workItem.getPreviousStatus());
                if (val != null) {
                    String id = val.getId();
                    String name = val.getName();
                    if (name == null) {
                        name = ""; //$NON-NLS-1$
                    }
                    return getImageField(id, name, IWorkItem.KEY_PREVIOUS_STATUS, val);
                }
                return ""; //$NON-NLS-1$
            } else if (field.equals(IWorkItem.KEY_APPROVALS)) {
                StringBuffer res = new StringBuffer();
                java.util.Collection approvals = workItem.getApprovals();
                for (Iterator iter = approvals.iterator(); iter.hasNext();) {
                    IApprovalStruct appStruct = (IApprovalStruct) iter.next();
                    res.append("Name: ");
                    IUser user = appStruct.getUser();
                    String userName = ""; //$NON-NLS-1$
                    try {
                        userName = user.getName();
                    } catch (Exception e) {
                        userName = ""; //$NON-NLS-1$
                    }
                    res.append(userName);
                    res.append("; Status: ");
                    res.append(appStruct.getStatus().getName());
                    res.append("<br/>"); //$NON-NLS-1$
                }
                return res.toString();
            } else if (field.equals(IWorkItem.KEY_LINKED_REVISIONS)) {

                String bs_buff = ""; //$NON-NLS-1$
                PObjectList lst = (PObjectList) workItem.getLinkedRevisions();
                ;
                if (lst != null) {
                    Iterator itr = lst.iterator();
                    while (itr.hasNext()) {
                        IRevision rv = (IRevision) itr.next();
                        bs_buff += (rv.getName() + ": " + rv.getMessage() + "<br />"); //$NON-NLS-1$ //$NON-NLS-2$
                    }
                }
                return bs_buff;
            } else if (field.equals(IWorkItem.KEY_LINKED_WORK_ITEMS)) {
                String bs_buff = ""; //$NON-NLS-1$
                PObjectList lst = (PObjectList) workItem.getLinkedWorkItems();
                if (lst != null) {
                    Iterator itr = lst.iterator();
                    while (itr.hasNext()) {
                        IWorkItem wi = (IWorkItem) itr.next();
                        bs_buff += (wi.getId() + ": " + wi.getTitle() + "<br />"); //$NON-NLS-1$ //$NON-NLS-2$
                    }
                }
                return bs_buff;

            } else if (field.equals(IWorkItem.KEY_LOCATION)) {
                return workItem.getLocation().toString();
            } else if (field.equals(IWorkItem.KEY_HYPERLINKS)) {
                String bs_buff = ""; //$NON-NLS-1$
                java.util.Collection hl = workItem.getHyperlinks();
                Iterator itr = hl.iterator();
                while (itr.hasNext()) {
                    IHyperlinkStruct hrl = (IHyperlinkStruct) itr.next();
                    bs_buff += (hrl.getRole().getName() + " - " + hrl.getUri() + "<br />"); //$NON-NLS-1$ //$NON-NLS-2$
                }
                return bs_buff;
            } else if (field.equals(IWorkItem.KEY_COMMENTS)) {
                if (wi.getOutputType().equalsIgnoreCase("list")) {
                    return getValueComments(workItem, false);
                } else {
                    return context.getMessageTool().get("commentsWI"); //$NON-NLS-1$
                }
            } else {

                String bs_buff = ""; //$NON-NLS-1$
                HashSet e = (HashSet) workItem.getCustomFieldsList();

                Iterator it = e.iterator();
                while (it.hasNext()) {
                    String ob = (String) it.next();
                    java.lang.Object val = workItem.getCustomField(ob);

                    if (!ob.equalsIgnoreCase(field)) {
                        continue;
                    }

                    if (val instanceof DelegatingOption) {
                        DelegatingOption d = (DelegatingOption) workItem.getCustomField(ob);
                        bs_buff += (d.getName() != null ? d.getName() : "" + " "); //$NON-NLS-1$ //$NON-NLS-2$
                    } else if (val instanceof Text) {
                        Text text = (Text) val;
                        if (text.isHtml()) {
                            bs_buff += workItem.transformDescriptionForUI(text).getContent().trim();
                        } else {
                            bs_buff += text.getContent();
                        }

                    } else if (val instanceof CustomTypedList) {
                        CustomTypedList ctl = (CustomTypedList) workItem.getCustomField(ob);
                        int sz = ctl.size();
                        for (int i = 0; i < sz; i++) {
                            DelegatingOption d = (DelegatingOption) ctl.get(i);
                            bs_buff += (d.getName() != null ? d.getName() : "" + " "); //$NON-NLS-1$ //$NON-NLS-2$
                        }
                    } else if (val != null) {
                        bs_buff += ((String) val + " "); //$NON-NLS-1$
                    }
                }
                return bs_buff;
            }
        } catch (Exception r) {
            return ""; //$NON-NLS-1$
        }
    }

    /**
     * Functions for convert Date to String format
     * @param date
     * @return
     */
    private String convertDurationDate(DurationTime date) {
        if (date == null) {
            return ""; //$NON-NLS-1$
        }

        return date.toString();
    }

    private String convertDate(Date date) {

        if (date == null) {
            return ""; //$NON-NLS-1$
        }
        return ConvertUtil.dateToString(date);
    }

    private String convertDueDate(DateOnly date) {
        if (date == null) {
            return ""; //$NON-NLS-1$
        }

        return date.toString();
    }

    /**
     *
     * @param field_id id value fields ("dueDate")
     * @param field_name  Full name value from id("Due Date")
     * @param name field name
     * @return
     */

    private String getImageURL(IEnumOption enum1) {
        String iconURL = enum1.getProperty(IEnumOption.PROPERTY_KEY_ICON_URL);
        if (iconURL != null && iconURL.startsWith("images/polarion/enums/")) //$NON-NLS-1$
        {
            iconURL = context.getURLFactory().getURL() + "polarion/ria/images/enums/" + iconURL.substring("images/polarion/enums/".length()); //$NON-NLS-1$ //$NON-NLS-2$
        } else if (iconURL != null && iconURL.startsWith("polarion/ria") && iconURL.trim().length() != 0) //$NON-NLS-1$
        {
            iconURL = context.getURLFactory().getURL() + iconURL;
        }

        if (iconURL == null || (iconURL != null && iconURL.trim().length() == 0)) {
            iconURL = null;
        }
        return iconURL;
    }

    private String getImageField(String field_id, String field_name, String name, IEnumOption enum1) {
        Vector mp = wi.getFieldsMap();
        if (mp.size() > 0) {
            for (int i = 0; i < mp.size(); i++) {
                String key = ((WorkItemField) mp.get(i)).getName();
                String type = ((WorkItemField) mp.get(i)).getValue().trim();
                if (name.equals(key)) {
                    return getImage(type, field_id, field_name, name, enum1);
                }
            }
            if (name.equals(IUniqueObject.KEY_ID)) {
                return getImage(ILink.FIELD_TYPE_IMGTXT, field_id, field_name, name, enum1);
            }
        } else {
            String[] arr = wi.getFieldsArray();
            for (String element : arr) {
                if (element.equals(name)) {
                    return getImage(ILink.FIELD_TYPE_IMGTXT, field_id, field_name, name, enum1);
                }
            }
        }
        return "";
    }

    /**
     * @return image from field value
     */
    private String getImage(String type, String field_id, String field_name, String name, IEnumOption enum1) {
        String img = ""; //$NON-NLS-1$
        if (name.equals(IWorkflowObject.KEY_TYPE)) {
            img = "type_" + field_id + ".gif"; //$NON-NLS-1$ //$NON-NLS-2$
        } else if (name.equals(IUniqueObject.KEY_ID)) {
            img = "type_" + field_id + ".gif";//$NON-NLS-1$ //$NON-NLS-2$
        } else if (name.equals(IWorkflowObject.KEY_STATUS)) {
            img = "status_" + field_id + ".gif";//$NON-NLS-1$ //$NON-NLS-2$
        } else if (name.equals(IWorkItem.KEY_SEVERITY)) {
            img = "severity_" + field_id + ".gif";//$NON-NLS-1$ //$NON-NLS-2$
        } else if (name.equals(IWorkItem.KEY_PRIORITY)) {
            img = "priority_" + field_id.toLowerCase() + ".gif";//$NON-NLS-1$ //$NON-NLS-2$
        } else {
            img = ""; //$NON-NLS-1$
        }

        if (img != null) {
            String imgURL = getImageURL(enum1);
            if (imgURL != null) {
                img = "<img width='16' height='16' alt=\"\" src=\"" + imgURL + "\" border=\"0\" />";//$NON-NLS-1$ //$NON-NLS-2$
            } else {
                img = ""; //$NON-NLS-1$
            }
        } else {
            img = ""; //$NON-NLS-1$
        }

        if (type.equalsIgnoreCase(ILink.FIELD_TYPE_TEXT)) {
            return field_name;
        } else if (type.equalsIgnoreCase(ILink.FIELD_TYPE_IMAGE)) {
            return img;
        } else if (type.equalsIgnoreCase(ILink.FIELD_TYPE_IMGTXT) || type.equalsIgnoreCase(ILink.FIELD_TYPE_TXTIMG)) {
            return img + " " + field_name; //$NON-NLS-1$
        } else if (type.equalsIgnoreCase(ILink.FIELD_TYPE_HIDDEN)) {
            return field_name;
        } else {
            return field_name;
        }

    }

    /**
     * init fields map
     */
    private void initFields() {
        fieldsName_map.put(IUniqueObject.KEY_ID, new WorkItem.FieldStructure("ID", 0));
        fieldsName_map.put(IWorkItem.KEY_TITLE, new WorkItem.FieldStructure("Title", 1));
        fieldsName_map.put(IWorkflowObject.KEY_TYPE, new WorkItem.FieldStructure("Type", 2));
        fieldsName_map.put(IWorkflowObject.KEY_STATUS, new WorkItem.FieldStructure("Status", 3));
        fieldsName_map.put(IWorkItem.KEY_AUTHOR, new WorkItem.FieldStructure("Author", 4));
        fieldsName_map.put(IWorkItem.KEY_ASSIGNEE, new WorkItem.FieldStructure("Assignee", 5));
        fieldsName_map.put(IWorkItem.KEY_SEVERITY, new WorkItem.FieldStructure("Severity", 6));
        fieldsName_map.put(IWorkItem.KEY_CREATED, new WorkItem.FieldStructure("Created", 7));
        fieldsName_map.put(IWorkItem.KEY_UPDATED, new WorkItem.FieldStructure("Updated", 8));
        fieldsName_map.put(IWorkItem.KEY_DESCRIPTION, new WorkItem.FieldStructure("Description", 9));
        fieldsName_map.put(IUniqueObject.KEY_PROJECT, new WorkItem.FieldStructure("Project", 10));
        fieldsName_map.put(IWorkItem.KEY_CATEGORIES, new WorkItem.FieldStructure("Categories", 11));
        fieldsName_map.put(IWorkItem.KEY_INITIAL_ESTIMATE, new WorkItem.FieldStructure("Initial Estimate", 12));
        fieldsName_map.put(IWorkItem.KEY_TIME_SPENT, new WorkItem.FieldStructure("Time Spent", 13));
        fieldsName_map.put(IWorkItem.KEY_REMAINING_ESTIMATE, new WorkItem.FieldStructure("Remaining Estimate", 14));
        fieldsName_map.put(IWorkItem.KEY_RESOLUTION, new WorkItem.FieldStructure("Resolution", 15));
        fieldsName_map.put(IWorkItem.KEY_PRIORITY, new WorkItem.FieldStructure("Priority", 16));
        fieldsName_map.put(IWorkItem.KEY_DUE_DATE, new WorkItem.FieldStructure("Due Date", 17));
        fieldsName_map.put(IWorkItem.KEY_TIME_POINT, new WorkItem.FieldStructure("Time Point", 18));
        fieldsName_map.put(IWorkItem.KEY_PLANNING_CONSTRAINTS, new WorkItem.FieldStructure("Planning Constraints", 2));
        fieldsName_map.put(IWorkItem.KEY_PLANNED_END, new WorkItem.FieldStructure("Planned End", 19));
        fieldsName_map.put(IWorkItem.KEY_PLANNED_START, new WorkItem.FieldStructure("Planned Start", 20));
        fieldsName_map.put(IWorkItem.KEY_RESOLVED_ON, new WorkItem.FieldStructure("Resolved On", 21));
        fieldsName_map.put(IWorkItem.KEY_PREVIOUS_STATUS, new WorkItem.FieldStructure("Previous Status", 22));
        fieldsName_map.put(IWorkItem.KEY_APPROVALS, new WorkItem.FieldStructure("Approvals", 23));
        fieldsName_map.put(IWorkItem.KEY_LINKED_REVISIONS, new WorkItem.FieldStructure("Linked Revisions", 24));
        fieldsName_map.put(IWorkItem.KEY_LINKED_WORK_ITEMS, new WorkItem.FieldStructure("Linked Work Items", 25));
        fieldsName_map.put(IWorkItem.KEY_LOCATION, new WorkItem.FieldStructure("Location", 26));
        fieldsName_map.put(IWorkItem.KEY_HYPERLINKS, new WorkItem.FieldStructure("Hyperlinks", 27));
        fieldsName_map.put(IWorkItem.KEY_COMMENTS, new WorkItem.FieldStructure("Comments", 28));
    }

    /**
     *
     * @param field
     * @return
     */
    public boolean isCustomField(String field) {
        if (itemCount == 0) {
            return true;
        }
        for (int i = 0; i < itemCount; i++) {
            IWorkItem item = items[i];
            java.util.Collection customFields = item.getCustomFieldsList();
            Iterator it = customFields.iterator();
            while (it.hasNext()) {
                if (field.equals(it.next())) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * @deprecated
     * @param field
     * @return real field name
     */

    @Deprecated
    public String getRealNameField(String field) {
        if (!fieldsName_map.containsKey(field)) {
            getWorkItems();
            IWorkItem item = null;
            IContextId contextId = null;
            String prototypeName = null;
            String customFieldId = null;
            boolean finded = false;
            int i = 0;
            while (i < itemCount && !finded) {
                item = items[i];
                contextId = item.getContextId();
                prototypeName = item.getPrototype().getName();
                java.util.Collection customFields = item.getCustomFieldsList();
                Iterator it = customFields.iterator();
                while (it.hasNext()) {
                    String id = (String) it.next();
                    if (field.equals(id)) {
                        customFieldId = id;
                        finded = true;
                        break;
                    }
                }
                i++;
            }
            if (customFieldId != null) {
                ICustomField customField = cfs.getCustomField(customFieldId, ObjectUtils.notNull(prototypeName), ObjectUtils.notNull(contextId));
                return customField.getName();
            } else {
                return field;
            }
        } else {
            WorkItem.FieldStructure st = fieldsName_map.get(field);
            return st.name;
        }
    }

    public boolean validate(ParameterMap parameters) {
        return validator.validate(parameters);
    }

    public List getErrors() {
        return validator.getErrors();
    }

    /**
     *
     * @param array
     * @return sort fields
     */
    private String[] sortFields(String[] array) {
        return array;
    }

    /**
     * parse description and remove <table> tags
     * @param content
     * @return
     * @throws Exception
     * @throws ParserConfigurationException
     */

    private String replaceTaleContent(String content) throws Exception, ParserConfigurationException {
        if (content.equalsIgnoreCase("")) {
            return content;
        }

        String content1 = "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?><root>" + content + "</root>"; //$NON-NLS-1$ //$NON-NLS-2$
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        InputStream xmlinputstream = new ByteArrayInputStream(content1.getBytes());
        org.w3c.dom.Document docXML = builder.parse(new InputSource(xmlinputstream));

        docXML.getDocumentElement().normalize();
        org.w3c.dom.Element node = docXML.getDocumentElement();

        String str = _replaceTaleContent(node, ""); //$NON-NLS-1$
        if (str.equalsIgnoreCase("")) {
            return content;
        } else {
            return str;
        }
    }

    private String _replaceTaleContent(org.w3c.dom.Node node, String str) {
        NodeList nl = node.getChildNodes();

        for (int i = 0; i < nl.getLength(); i++) {
            org.w3c.dom.Node childElement = nl.item(i);

            if ((childElement.getNodeType() == 1) && (childElement.getNodeName().equalsIgnoreCase("tr"))) {
                str = _replaceTaleContent(childElement, str) + "<br />"; //$NON-NLS-1$
            } else if (childElement.getNodeType() == 1) {
                str = _replaceTaleContent(childElement, str);
            } else if (childElement.getNodeType() == org.w3c.dom.Node.TEXT_NODE) {
                if (childElement.getParentNode().getNodeName().equalsIgnoreCase("td") || childElement.getParentNode().getNodeName().equalsIgnoreCase("th")) {
                    str += !childElement.getNodeValue().trim().equalsIgnoreCase("") ? " | " + childElement.getNodeValue() + "" : ""; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
                } else {
                    str += !childElement.getNodeValue().trim().equalsIgnoreCase("") ? childElement.getNodeValue() + "<br />" : ""; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
                }
            }
        }

        return str;
    }

    /**
     *
     * @author inner structure
     *
     */
    class FieldStructure {
        String name = ""; //$NON-NLS-1$
        int number = 0;

        public FieldStructure(String name, int number) {
            this.name = name;
            this.number = number;
        }
    }

    public String EncodeTextPDF(String text) {
        return com.xpn.xwiki.util.Util.contentEncode(text);
    }

    public int getWorkItemsCount() {
        return plugin.getWorkItemsCount(wi.getQueryProject(), wi.getQuery());
    }
}
