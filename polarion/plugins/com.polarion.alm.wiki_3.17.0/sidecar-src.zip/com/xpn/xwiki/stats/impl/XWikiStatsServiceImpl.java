/*
 * Copyright 2006, XpertNet SARL, and individual contributors as indicated
 * by the contributors.txt.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 * @author erwan
 * @author sdumitriu
 */

package com.xpn.xwiki.stats.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.buffer.CircularFifoBuffer;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.polarion.wiki.util.RequestParser;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.notify.XWikiActionRule;
import com.xpn.xwiki.notify.XWikiNotificationRule;
import com.xpn.xwiki.stats.api.XWikiStatsService;
import com.xpn.xwiki.store.XWikiStoreInterface;

public class XWikiStatsServiceImpl implements XWikiStatsService {

    private static final Log log = LogFactory.getLog(XWikiStatsServiceImpl.class);

    public static Date expirationDate;
    public static String[] cookieDomains;

    //action stats modification lock
    private static Object LOCK = new Object();

    /**
     * Initializes the Stats Service by inserting the notification rule
     * to be notified of all actions on documents
     * @param context
     */
    @Override
    public void init(XWikiContext context) {
        // Let's init the expirationDate for the cookie
        Calendar cal = Calendar.getInstance();
        cal.set(2030, 0, 0);
        expirationDate = cal.getTime();

        cookieDomains = StringUtils.split(context.getWiki().Param("xwiki.authentication.cookiedomains"), ",");

        // Adding the rule which will allow this module to be called on each page view
        if ("1".equals(context.getWiki().Param("xwiki.stats", "1"))) {
            context.getWiki().getNotificationManager().addGeneralRule(new XWikiActionRule(this));
        }
    }

    /**
     * Gets total statistics on a document for a specific action
     *
     * @param docname fully qualified document named
     * @param action can be "view", "edit", "save", etc..
     * @param context
     * @return DocStats - statistics object
     */
    @Override
    public DocumentStats getDocTotalStats(String docname, String action, XWikiContext context) {
        return new DocumentStats();
    }

    /**
     * Gets monthly statistics on a document for a specific action
     * @param docname
     * @param action
     * @param month
     * @param context
     * @return
     */
    @Override
    public DocumentStats getDocMonthStats(String docname, String action, Date month, XWikiContext context) {
        return null;
    }

    /**
     * Gets daily statistics on a document for a specific action
     * @param docname
     * @param action
     * @param day
     * @param context
     * @return
     */
    @Override
    public DocumentStats getDocDayStats(String docname, String action, Date day, XWikiContext context) {
        return new DocumentStats();
    }

    @Override
    public List getRefMonthStats(String docname, Date month, XWikiContext context) throws XWikiException {
        XWikiStoreInterface store = context.getWiki().getNotCacheStore();
        List solist = new ArrayList();
        return solist;
    }

    @Override
    public Collection getRecentActions(String action, int size, XWikiContext context) {
        ArrayList list = new ArrayList();
        if ((action.equals("view") || (action.equals("save")))) {
            HttpSession session = context.getRequest().getSession();
            Collection actions = (Collection) session.getAttribute("recent_" + action);

            if (actions != null) {
                Object[] actionsarray = actions.toArray();
                CollectionUtils.reverseArray(actionsarray);
                int nb = Math.min(actions.size(), size);
                for (int i = 0; i < nb; i++) {
                    list.add(actionsarray[i]);
                }
            }
        }
        return list;
    }

    /**
     * Notification rule to store usage statistics
     * @param rule
     * @param doc
     * @param action
     * @param context
     */
    @Override
    public void notify(XWikiNotificationRule rule, XWikiDocument doc, String action, XWikiContext context) {

        if (context.getWiki().isReadOnly()) {
            // the server is in read-only mode, forget about the statistics
            return;
        }
        // Unless this is a "view", "save" or "download" action, we are not interested
        if (!(action.equals("view") || action.equals("save") || action.equals("download") || action.equals("delete"))) {
            return;
        }

        // Let's save in the session the last elements view, saved
        synchronized (LOCK) {
            if (RequestParser.isDocumentPage(doc.getSpace()) == false) {
                return;
            }
            if (!action.equals("download")) {
                HttpSession session = context.getRequest().getSession();
                String actionKey = "recent_" + (action.equals("delete") ? "view" : action);
                Collection actions = (Collection) session.getAttribute(actionKey);
                if (actions == null) {
                    actions = new CircularFifoBuffer(context.getWiki().getXWikiPreferenceAsInt("recent_visits_size", 20, context));
                    session.setAttribute(actionKey, actions);
                }
                String element = doc.getFullName();
                try {
                    if (actions.contains(element)) {
                        actions.remove(element);
                    }
                } catch (Exception e) {
                    // DPP-7618 - ArrayIndexOutOfBoundsException: -1 error in console
                    // no clue how it can happen, should not, not risky code, logging exception just as debug
                    if (log.isDebugEnabled()) {
                        log.debug(e.getLocalizedMessage(), e);
                    }
                }
                if (!action.equals("delete")) {
                    actions.add(element);
                }
            }
        }

        // Let's check if this wiki should have statistics disabled
        String statsdefault = context.getWiki().Param("xwiki.stats.default");
        String statsactive = context.getWiki().getXWikiPreference("statistics", "", context);
        if ("0".equals(statsactive)) {
            return;
        }
        // If nothing is said we use the default parameter
        if (("".equals(statsactive)) && ("0".equals(statsdefault))) {
            return;
        }

        return;

    }

    protected VisitStats findVisitByCookie(String cookie, XWikiContext context) throws XWikiException {
        return null;
    }

    protected VisitStats findVisitByIPUA(String ipua, XWikiContext context) throws XWikiException {
        return null;
    }

    protected Cookie addCookie(XWikiContext context) {
        Cookie cookie = new Cookie("visitid", RandomStringUtils.randomAlphanumeric(32).toUpperCase());
        cookie.setPath("/");

        int time = (int) (expirationDate.getTime() - (new Date()).getTime()) / 1000;
        cookie.setMaxAge(time);

        String cookieDomain = null;
        if (cookieDomains != null) {
            String servername = context.getRequest().getServerName();
            for (String cookieDomain2 : cookieDomains) {
                if (servername.indexOf(cookieDomain2) != -1) {
                    cookieDomain = cookieDomain2;
                    break;
                }
            }
        }

        if (cookieDomain != null) {
            cookie.setDomain(cookieDomain);
        }

        if (log.isDebugEnabled()) {
            log.debug("Setting cookie " + cookie.getValue() + " for name " + cookie.getName()
                    + " with domain " + cookie.getDomain() + " and path " + cookie.getPath()
                    + " and maxage " + cookie.getMaxAge());
        }

        context.getResponse().addCookie(cookie);
        return cookie;
    }

}
