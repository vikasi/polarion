package com.xpn.xwiki.pdf.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.velocity.VelocityContext;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import com.polarion.alm.projects.IProjectService;
import com.polarion.alm.projects.model.IProject;
import com.polarion.alm.tracker.ITrackerService;
import com.polarion.alm.tracker.internal.FolderUtils;
import com.polarion.alm.tracker.internal.exporter.ExportProperties;
import com.polarion.alm.tracker.internal.exporter.IExportData;
import com.polarion.alm.tracker.web.internal.server.HomeServletUtil;
import com.polarion.alm.tracker.web.internal.server.PdfExportChartReport;
import com.polarion.alm.tracker.web.internal.server.pdfexport.PdfExporter;
import com.polarion.alm.ui.server.tracker.ImportExportStatusKeeper;
import com.polarion.alm.wiki.IWikiService;
import com.polarion.core.util.logging.Logger;
import com.polarion.platform.IPlatformService;
import com.polarion.platform.core.PlatformContext;
import com.polarion.platform.repository.config.IRepositoryConfigService;
import com.polarion.platform.security.ISecurityService;
import com.polarion.platform.service.repository.IRepositoryService;
import com.polarion.subterra.base.data.identification.IContextId;
import com.polarion.subterra.base.location.ILocation;
import com.polarion.wiki.util.SpaceParser;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.pdf.api.PdfExport;

public class PdfExportImpl implements PdfExport {

    private static Logger log = Logger.getLogger(PdfExportImpl.class);

    private static final IRepositoryConfigService repositoryConfigService = PlatformContext
            .getPlatform().lookupService(IRepositoryConfigService.class);
    private static IProjectService projectService = PlatformContext
            .getPlatform().lookupService(IProjectService.class);
    private static IRepositoryService repositoryService = PlatformContext
            .getPlatform().lookupService(IRepositoryService.class);
    private static ISecurityService securityService = PlatformContext
            .getPlatform().lookupService(ISecurityService.class);
    private static ITrackerService trackerService = PlatformContext
            .getPlatform().lookupService(ITrackerService.class);
    private static IPlatformService platformService = PlatformContext
            .getPlatform().lookupService(IPlatformService.class);
    private static IWikiService wikiService = PlatformContext
            .getPlatform().lookupService(IWikiService.class);

    public String validationPath = "";

    public static Object SYNCHRONIZED_OBJ = new Object();

    public enum ExportType {
        PDF, PDF_NEW;
    }

    public static final String PAPER_SIZE_A4 = "A4";
    private static final String PAPER_SIZE_A3 = "A3";
    private static final String PAPER_SIZE_LETTER = "Letter";
    private static final String PAPER_SIZE_LEGAL = "Legal";
    private static final String PAPER_SIZE_TABLOID = "Tabloid";

    public static final int PDF = 0;
    public static final int PDF_NEW = 1;
    private File tempdir = null;
    private String filename = "";
    public String tempDirName = "";
    public String link = "";

    String orientation = null;
    String paper = null;
    String headerFooter = null;
    String bookmarks = null;
    String adjustWidth = null;

    private String pdfExportId;
    private XWikiContext context;

    public PdfExportImpl() {
        super();
    }

    public PdfExportImpl(XWikiContext context) {
        this.context = context;
        String tempDirName = null;

        link = context.getURL().getPath();
        String query = this.context.getURL().getQuery();
        String[] params = query.split("[&]");
        VelocityContext vcontext = getVelocityContext();
        if (params != null) {
            for (String param : params) {
                String[] parts = param.split("[=]");
                if (parts.length == 2) {
                    if (parts[0].trim().equals("orientation")) {
                        orientation = parts[1];
                    } else if (parts[0].trim().equals("paper")) {
                        paper = parts[1];
                    } else if (parts[0].trim().equals("headerFooter")) {
                        headerFooter = parts[1];
                    } else if (parts[0].trim().equals("bookmarks")) {
                        bookmarks = parts[1];
                    } else if (parts[0].trim().equals("adjustWidth")) {
                        adjustWidth = parts[1];
                    } else if (parts[0].trim().equals(PdfExportChartReport.KEY_PDF_EXPORT_ID)) {
                        pdfExportId = parts[1];
                    } else {
                        vcontext.put(parts[0].trim(), parts[1]);
                    }
                }
            }
        }

        if (pdfExportId != null) {
            if (pdfExportId.trim().isEmpty()) {
                pdfExportId = ImportExportStatusKeeper.getInstance().generateNewId();
            }
            vcontext.put(PdfExportChartReport.KEY_PDF_EXPORT_REPORT, new PdfExportChartReport(pdfExportId));
        }

        File dir = (File) context.getEngineContext().getAttribute(
                "javax.servlet.context.tempdir");
        if ((tempDirName == null) || ("".equals(tempDirName))) {
            tempDirName = RandomStringUtils.randomAlphanumeric(8);
        }
        File tempdir = new File(dir, tempDirName);
        this.tempdir = tempdir;
        this.tempDirName = tempDirName;

        checkExistenceOfTempDir();
    }

    @NotNull
    private VelocityContext getVelocityContext() {
        return (VelocityContext) context.get("vcontext"); //$NON-NLS-1$
    }

    private void checkExistenceOfTempDir() {
        if (!tempdir.exists()) {
            tempdir.mkdirs();
        }
    }

    @Override
    public void export(XWikiDocument doc, OutputStream out, int type,
            XWikiContext context) throws XWikiException {
        // TODO Auto-generated method stub

    }

    @Override
    public void exportToPDF(XWikiDocument doc, OutputStream out,
            XWikiContext context) throws XWikiException {

        try {

            String revisionString = null;
            if (doc.getVersion() != null && !doc.getVersion().contains(".")) { //$NON-NLS-1$
                revisionString = doc.getVersion();
            }
            String name = doc.getName();
            filename = PdfExporter.createPDFFileName(SpaceParser.getSpace(doc.getSpace()) + " " + name, revisionString, doc.getProjectName()); //doc.getProject() + (SpaceParser.getSpace(doc.getSpace()).startsWith("_") ? "" : "_") + SpaceParser.getSpace(doc.getSpace()) + "_" + name + revisionString + ".pdf"; //$NON-NLS-1$ 
            out = new FileOutputStream(new File(tempdir, filename));
            createPD4ML(doc, context, out);
            if (pdfExportId != null) {
                ((PdfExportChartReport) getVelocityContext().get(PdfExportChartReport.KEY_PDF_EXPORT_REPORT)).persist(true);
            }
        } catch (IOException io) {
            log.error("Export to pdf: " + io, io);
            throw new XWikiException(XWikiException.MODULE_XWIKI_EXPORT,
                    XWikiException.ERROR_XWIKI_EXPORT_PDF_FOP_FAILED,
                    "Exception while exporting PDF", io);
        } catch (Exception e) {
            log.error("Export to pdf in the end " + e, e);
            throw new XWikiException(XWikiException.MODULE_XWIKI_EXPORT,
                    XWikiException.ERROR_XWIKI_EXPORT_PDF_FOP_FAILED,
                    "Exception while exporting PDF", e);
        }
    }

    private static IExportData getData(@NotNull final XWikiDocument doc, @Nullable final IProject project) {
        return new IExportData() {

            @Override
            @Nullable
            public String getName() {
                return doc.getName();
            }

            @Override
            @Nullable
            public String getSpace() {
                return doc.getSpaceName();
            }

            @Override
            @Nullable
            public IProject getProject() {
                return project;
            }

            @Override
            @Nullable
            public Date getCreated() {
                return doc.getCreationDate();
            }

            @Override
            @Nullable
            public Date getUpdated() {
                return doc.getDate();
            }

            @Override
            @Nullable
            public String getUpdatedBy() {
                return doc.getAuthorName();
            }

            @Override
            @Nullable
            public String getAuthor() {
                return doc.getCreatorName();
            }

            @Override
            @Nullable
            public String getRevision() {
                return doc.getRevision();
            }

            @Override
            @NotNull
            public List<String> getCustomFields() {
                return Collections.EMPTY_LIST;
            }

            @Override
            @Nullable
            public Object getCustomFieldValue(String field) {
                return null;
            }

            @Override
            @Nullable
            public IContextId getContextId() {
                return project != null ? project.getContextId() : null;
            }

            @Override
            @Nullable
            public ILocation getConfigurationLocation() {
                return null;
            }

            @Override
            @Nullable
            public String getTitleOrName() {
                return doc.getPageTitleOrName();
            }

            @Override
            @Nullable
            public String getSpaceTitleOrName() {
                return FolderUtils.getFolder(project != null ? project.getId() : null, doc.getSpace()).getTitleOrName();
            }

        };
    }

    public static String handleNull(String input) {
        if (input == null) {
            return "";
        }
        return input;
    }

    private void createPD4ML(XWikiDocument doc, XWikiContext context2, OutputStream out) throws Exception {
        boolean isLandscape = orientation != null && "Landscape".equalsIgnoreCase(orientation);
        boolean adjustWidth2 = Boolean.parseBoolean(adjustWidth);
        boolean generateBookmarks = Boolean.parseBoolean(bookmarks);
        boolean includeHeaderFooter = Boolean.parseBoolean(headerFooter);

        context.setDoc(doc);
        context.setAction("view");
        context.put("pdf_generate", "1");
        context.getWiki().prepareResources(context2);

        String renderDocument = null;
        renderDocument = context.getWiki().getRenderingEngine().renderDocument(doc, context2);
        if (renderDocument == null) {
            return;
        }
        VelocityContext vcontext = (VelocityContext) context.get("vcontext");

        IProject project = doc.getProject() != null && !"".equals(doc.getProject()) ? projectService.getProject(doc.getProject()) : null;

        ExportProperties exportProperties = new ExportProperties(getData(doc, project));

        PdfExporter pdf = new PdfExporter(exportProperties, true);

        pdf.setRepositoryConfigurationService(repositoryConfigService);
        pdf.setTrackerService(trackerService);
        pdf.setRepositoryService(repositoryService);
        pdf.setVelocityContext(vcontext);

        HomeServletUtil.processContext(context2.getRequest(), context2.getResponse(), null, pdf);

        pdf.setPageFormat(paper, isLandscape);

        if (adjustWidth2) {
            pdf.adjustWidth();
        }

        if (generateBookmarks) {
            pdf.generateOutlines(true);
        }

        pdf.render(out, renderDocument, doc.getName(), includeHeaderFooter);

        out.close();
        sendPDFResponse();
    }

    public static void saveFile(String filename, byte[] content)
            throws IOException {
        FileOutputStream fos = new FileOutputStream(new File(filename));
        fos.write(content);
        fos.close();
    }

    public void sendPNGResponce(File previewFile) throws Exception {
        context.getResponse().setContentType("image/png");
        // context.getResponse().addHeader("Content-disposition",
        // "attachment; filename=\"" + filename+"\"");

        FileInputStream fi = new FileInputStream(previewFile);
        int r;
        while ((r = fi.read()) != -1) {
            context.getResponse().getWriter().write(r);
        }
        fi.close();
        context.getResponse().getWriter().flush();
    }

    private void sendPDFResponse() throws Exception {
        context.getResponse().setContentType("application/pdf");
        context.getResponse().addHeader("Content-disposition",
                "attachment; filename=\"" + filename + "\"");

        FileInputStream fi = new FileInputStream(new File(tempdir,
                filename));
        int r;
        while ((r = fi.read()) != -1) {
            context.getResponse().getWriter().write(r);
        }
        fi.close();
        context.getResponse().getWriter().flush();
    }

    @Override
    public void exportHtml(String xhtml, OutputStream out, int type,
            XWikiContext context) throws XWikiException {
        // TODO Auto-generated method stub

    }

    @Override
    public void exportXHtml(byte[] xhtml, OutputStream out, int type,
            XWikiContext context) throws XWikiException {
        // TODO Auto-generated method stub

    }

    @Override
    public byte[] convertToStrictXHtml(byte[] input, XWikiContext context) {
        // TODO Auto-generated method stub
        return null;
    }

}