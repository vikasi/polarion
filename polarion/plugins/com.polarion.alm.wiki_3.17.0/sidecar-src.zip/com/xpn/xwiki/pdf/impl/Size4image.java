package com.xpn.xwiki.pdf.impl;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.polarion.core.util.eclipse.BundleHelper;
import com.polarion.core.util.logging.Logger;

public class Size4image {

    private static Logger log = Logger.getLogger(Size4image.class);

    public static class SizePair {
        public int width = -1;
        public int height = -1;

        public String getWidthStr() {
            return getAsStr(width);
        }

        public String getHeightStr() {
            return getAsStr(height);
        }

        public static String getAsStr(int i) {
            if (i >= 0) {
                return String.valueOf(i);
            }
            return "";
        }
    }

//	final String filename = "result.xml";
//	final String outFilename = "result.out.xml";

    final private InputStream in;
    final private OutputStream out;

    final private String java2jsPluginPath;

    private Map<String, SizePair> knownImages = new HashMap<String, SizePair>();

    public Size4image(InputStream in, OutputStream out) {
        this.in = in;
        this.out = out;

        if (File.separatorChar == '/') {
            //we have UNIX
            java2jsPluginPath = BundleHelper.getPath("com.polarion.alm.ui", "/webapp");
        } else {
            java2jsPluginPath = BundleHelper.getPath("com.polarion.alm.ui", "/webapp").substring(1);
        }
    }

    public void fetchSizes() {
        Document doc = null;

        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory
                    .newInstance();
            factory.setValidating(false);
            DocumentBuilder builder = factory.newDocumentBuilder();
            doc = builder.parse(in);

            suckSizes(doc, doc.getDocumentElement());

            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(out);

            TransformerFactory transFactory = TransformerFactory.newInstance();
            Transformer transformer = transFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.transform(source, result);

        } catch (Exception e) {
            log.error("INTERNAL ERROR", e);
        }
    }

    public void setScale(double scale, int sourceResolution) {
        Document doc = null;

        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory
                    .newInstance();
            factory.setValidating(false);
            DocumentBuilder builder = factory.newDocumentBuilder();
            doc = builder.parse(in);

            setScale(doc, doc.getDocumentElement(), scale, sourceResolution);

            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(out);

            TransformerFactory transFactory = TransformerFactory.newInstance();
            Transformer transformer = transFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.transform(source, result);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private SizePair getImageSize(String url) {
        SizePair pair = new SizePair();
        InputStream imageIn = null;

        if (knownImages.containsKey(url)) {
            return knownImages.get(url);
        }

        String origUrl = new String(url);
        url = url.replaceAll("\\\\", "/");
        url = url.replaceAll("[ ]", "%20");
        URI uri = null;

        if (url.startsWith("file:/", 0)) {
            try {
                uri = new URI(url);
            } catch (URISyntaxException e) {
//				e.printStackTrace();
//				System.out.println("bad uri for: " + url);
            }
        } else if (url.startsWith("http://", 0) || url.startsWith("https://", 0)) {
            try {
                URL urlConn = new URL(url);
                //			url = url.substring(7);
                String serverPath = urlConn.getPath();//url.substring(url.indexOf('/'));
                if (serverPath.startsWith("/polarion/ria/")) {
                    url = java2jsPluginPath + serverPath.substring(10);
                } else {
                    URLConnection conn = urlConn.openConnection();
                    imageIn = conn.getInputStream();
                }
            } catch (IOException ioe) {
                return null;
            }
        } else {
            return null;
        }
        try {
            String[] ext = url.split("[.]");
            Iterator<ImageReader> readers = ImageIO.getImageReadersBySuffix(ext[ext.length - 1]);

            ImageInputStream in;
            if (imageIn != null) {
                in = ImageIO.createImageInputStream(imageIn);
            } else if (uri != null) {
                in = ImageIO.createImageInputStream(new File(uri));
            } else {
                in = ImageIO.createImageInputStream(new File(url));
            }

            while (readers.hasNext()) {
                ImageReader r = readers.next();
                r.setInput(in, true);
                try {
                    Integer width = r.getWidth(0);
                    Integer height = r.getHeight(0);
                    if ((width != null) && (height != null)) {
                        pair.width = width;
                        pair.height = height;
                        knownImages.put(origUrl, pair);
                        break;
                    }
                } catch (Exception e) {
                    Logger.getLogger(this).error("image height/width cannot be parsed from image:" + origUrl + " cause:" + e.getLocalizedMessage(), e);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return pair;
    }

    private int parseSize(String size) {
        return Integer.parseInt(size);
    }

    private void suckSizes(Document doc, Element e) {

        NodeList images = e.getElementsByTagName("fo:external-graphic");
        for (int i = 0, maxi = images.getLength(); i < maxi; i++) {
            Node node = images.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE) {
                Element element = (Element) node;
                Attr contentWidthAttr = element.getAttributeNode("content-width");
                Attr contentHeightAttr = element.getAttributeNode("content-height");

                if ((contentHeightAttr == null) || (contentWidthAttr == null)) {
                    Attr attr = element.getAttributeNode("src");
                    String[] srcParts = attr.getValue().split("[']");
//					System.out.println(attr.getValue());
                    //FIXME this is strange dependecy on magic constant [1] - IMHO JW
                    SizePair pair = getImageSize(srcParts[1]);
                    if (pair == null) {
                        continue;
                    }
                    if (contentHeightAttr != null) {
                        int height = parseSize(contentHeightAttr.getValue());
                        if (height != -1) {
                            int width = (int) ((((float) height) / pair.height) * pair.width);
                            element.setAttribute("content-width", SizePair.getAsStr(width));
                        }
                    } else if (contentWidthAttr != null) {
                        int width = parseSize(contentWidthAttr.getValue());
                        if (width != -1) {
                            int height = (int) ((((float) width) / pair.width) * pair.height);
                            element.setAttribute("content-height", SizePair.getAsStr(height));
                        }
                    } else {
                        element.setAttribute("content-width", pair.getWidthStr());
                        element.setAttribute("content-height", pair.getHeightStr());
                    }

//					System.out.println("\t - width: " + pair.width);
//					System.out.println("\t - height: " + pair.height);
                }
            }
        }
    }

    private void setScale(Document doc, Element e, double scale, int sourceResolution) {

        scale = scale / sourceResolution * 100;

        NodeList images = e.getElementsByTagName("fo:external-graphic");
        for (int i = 0, maxi = images.getLength(); i < maxi; i++) {
            Node node = images.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE) {
                Element element = (Element) node;
                Attr contentWidthAttr = element.getAttributeNode("content-width");
                Attr contentHeightAttr = element.getAttributeNode("content-height");

                if ((contentHeightAttr != null) && (contentWidthAttr != null)) {
                    String width = contentWidthAttr.getValue();
                    String height = contentHeightAttr.getValue();

                    if (!"".equals(width)) {
//						if(!width.matches("[0-9]+([.][0-9]+)?(\\s)px")){
//							width = width.replaceAll("[^0-9.]", "");
                        Double w = (double) Math.round(new Double(width) * scale) / 100;
                        contentWidthAttr.setValue(w.toString() + "in");
//						}
                    }

                    if (!"".equals(height)) {
//						if(!height.matches("[0-9]+([.][0-9]+)?(\\s)px")){
//							height = height.replaceAll("[^0-9.]", "");
                        Double h = (double) Math.round(new Double(height) * scale) / 100;
                        contentHeightAttr.setValue(h.toString() + "in");
//						}
                    }
                }
            }
        }
    }

}
