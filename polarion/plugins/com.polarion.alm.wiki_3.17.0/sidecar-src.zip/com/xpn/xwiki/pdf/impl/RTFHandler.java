/*
 * Copyright (C) 2004-2009 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2009 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES 
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.xpn.xwiki.pdf.impl;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * @author <a href="mailto:dev@polarion.com">Michal Antolik</a>, Polarion Software
 */

public class RTFHandler {
    public static class SizePair {
        public int width = -1;
        public int height = -1;

        public String getWidthStr() {
            return getAsStr(width);
        }

        public String getHeightStr() {
            return getAsStr(height);
        }

        public static String getAsStr(int i) {
            if (i >= 0) {
                return String.valueOf(i);
            }
            return "";
        }
    }

//	final String filename = "result.xml";
//	final String outFilename = "result.out.xml";

//	final private InputStream in;
    final private OutputStream out;

    private static Logger log = Logger.getLogger(Size4image.class);

    private Document doc = null;

    public RTFHandler(InputStream in, OutputStream out) {
//		this.in = in;
        this.out = out;

        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory
                    .newInstance();
            factory.setValidating(false);
            DocumentBuilder builder = factory.newDocumentBuilder();
            doc = builder.parse(in);
        } catch (Exception e) {
            log.error("XSL-FO postprocessing initialization exception", e);
        }

    }

    /**
     * this have to be called when operations with DOM tree will finish, otherwise 
     * result will not be "saved". Any other operations can not be called after it.
     */
    public void endOfOperations() {

        try {
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(out);

            TransformerFactory transFactory = TransformerFactory.newInstance();
            Transformer transformer = transFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.transform(source, result);
        } catch (Exception e) {
            log.error("XSL-FO postprocessing finalizing exception", e);
        }
    }

    /*RTF PREPROCESSING*/
    static private final Set<String> widthElements = new HashSet<String>();

    static {
        widthElements.add("");
        widthElements.add("");
        widthElements.add("margin");

        widthElements.add("");
        widthElements.add("");
        widthElements.add("border");

        widthElements.add("");
        widthElements.add("");
        widthElements.add("padding");
    }

    class WEMap {

        private Map<String, Integer> values = new HashMap<String, Integer>();
        {
            values.put("margin-left", 0);
            values.put("margin-right", 0);
            values.put("border-left", 0);
            values.put("border-right", 0);
            values.put("padding-left", 0);
            values.put("padding-right", 0);
        }

        public void put(String name, String value) {
            if (values.containsKey(name)) {
                Integer i = getInt(value);
                if (i != null) {
                    values.put(name, i);
                }
            } else if (name.equalsIgnoreCase("margin")) {
                put("margin-left", value);
                put("margin-right", value);
            } else if (name.equalsIgnoreCase("border")) {
                put("border-left", value);
                put("border-right", value);
            } else if (name.equalsIgnoreCase("padding")) {
                put("padding-left", value);
                put("padding-right", value);
            }
        }

        public int getTotalWidth() {
            int res = 0;

            for (Integer i : values.values()) {
                res += i;
            }
            return res;
        }

        private Integer getInt(String v) {
            v = v.trim();
            Integer res = null;

            try {
                if (v.matches("[0-9]+(\\s)*px")) {
                    res = new Integer(v.split("px")[0]);
                }
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
            return res;
        }
    }

    public void RTFpreprocessing(int pageWidth, int pageHeight) {
        try {
            Element root = doc.getDocumentElement();

            /*
             * 0. set page width / height
             */
            NodeList list = root.getElementsByTagName("fo:simple-page-master");
            if (list.getLength() > 0) {
                Node n = list.item(0);
                ((Element) n).setAttribute("page-widtht", pageWidth + "px");
                ((Element) n).setAttribute("page-height", pageHeight + "px");
            }

            /*
             * 1. fetch properties of "fo:region-body"
             * e.g. <fo:region-body column-count="1" column-gap="12pt" margin-bottom="48px" margin-left="24px" margin-right="24px" margin-top="48px" /> 
             */
            list = root.getElementsByTagName("fo:region-body");
            if (list.getLength() > 0) {
                //decrease by left and right margins
                Node n = list.item(0);
                pageWidth -= computeAttsWidth(n.getAttributes());
            }

            /*
             * 2. process footer/header
             */
            list = root.getElementsByTagName("fo:static-content");
            processChildsWidth(pageWidth, list);

            /*
             * 3. start fixing widths in blocks  
             */
            list = root.getElementsByTagName("fo:flow");
            processChildsWidth(pageWidth, list);

        } catch (Exception e) {
            log.error("Exception while preprocessing XSL-FO before converting to RTF", e);
        }
    }

    private int computeAttsWidth(NamedNodeMap atts) {
        WEMap wemap = new WEMap();
        for (int i = 0, maxi = atts.getLength(); i < maxi; i++) {
            Node att = atts.item(i);
            wemap.put(att.getNodeName(), att.getNodeValue());
        }
        return wemap.getTotalWidth();
    }

    private void processChildsWidth(int parentWidth, NodeList childsList) {
        for (int i = 0, maxi = childsList.getLength(); i < maxi; i++) {
            Node n = childsList.item(i);
            if (n instanceof Element) {
                String nodeName = n.getNodeName();

                int width = parentWidth;
                if (nodeName.equalsIgnoreCase("fo:block") || nodeName.equalsIgnoreCase("fo:table") || nodeName.equalsIgnoreCase("fo:block-container")) {
                    NamedNodeMap atts = n.getAttributes();
                    width -= computeAttsWidth(atts);
                    Node widthAtt = atts.getNamedItem("width");
                    if (widthAtt == null) {
                        ((Element) n).setAttribute("width", width + "px");
                    } else {
                        setWidthAtt(widthAtt, width);
                    }

                    if (nodeName.equalsIgnoreCase("fo:table")) {
                        //process fo:table-column
                        processTableColumn(n.getChildNodes(), width);
                    }
                } else if (nodeName.equalsIgnoreCase("fo:leader")) {
                    NamedNodeMap atts = n.getAttributes();
                    Node widthAtt = atts.getNamedItem("leader-length");
                    if (widthAtt != null) {
                        String value = widthAtt.getNodeValue();
                        if (value.matches("[0-9]+%")) {
                            value = value.split("%")[0];
                            width = new Integer(value) * parentWidth / 100;
                            ((Element) n).setAttribute("leader-length", width + "px");
                        }
                    }
                }
                processChildsWidth(width, n.getChildNodes());
            }
        }
    }

    private void setWidthAtt(Node widthAtt, int width) {
        if (widthAtt == null) {
            return;
        }

        try {
            String value = widthAtt.getNodeValue();
            if (value.matches("[0-9]+(\\s)*%")) {
                value = value.split("[%]")[0].trim();
                Double d = new Double(value);
                int res = (int) (width * d / 100.0);
                widthAtt.setNodeValue(res + "px");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void processTableColumn(NodeList childList, int parentWidth) {
        for (int i = 0, maxi = childList.getLength(); i < maxi; i++) {
            Node n = childList.item(i);
            if (n instanceof Element) {
                String nodeName = n.getNodeName();
                if (nodeName.equalsIgnoreCase("fo:table-column")) {
                    Node cw = n.getAttributes().getNamedItem("column-width");
                    setWidthAtt(cw, parentWidth);
                }
            }
        }
    }

}
