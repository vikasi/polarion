/*
 * Copyright 2006, XpertNet SARL, and individual contributors as indicated
 * by the contributors.txt.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 * @author ludovic
 * @author wr0ngway
 * @author sdumitriu
 */

package com.xpn.xwiki;

import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.apache.velocity.VelocityContext;
import org.apache.xmlrpc.server.XmlRpcServer;
import org.jetbrains.annotations.Nullable;

import com.polarion.wiki.web.BaselineServlet;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.objects.classes.BaseClass;
import com.xpn.xwiki.user.api.XWikiUser;
import com.xpn.xwiki.util.Util;
import com.xpn.xwiki.validation.XWikiValidationStatus;
import com.xpn.xwiki.web.XWikiEngineContext;
import com.xpn.xwiki.web.XWikiForm;
import com.xpn.xwiki.web.XWikiMessageTool;
import com.xpn.xwiki.web.XWikiRequest;
import com.xpn.xwiki.web.XWikiResponse;
import com.xpn.xwiki.web.XWikiURLFactory;

@SuppressWarnings("nls")
public class XWikiContext<T, V> extends Hashtable<String, java.lang.Object> {

    private static final long serialVersionUID = 1421746759512286392L;
    public static final int MODE_SERVLET = 0;
    public static final int MODE_PORTLET = 1;
    public static final int MODE_XMLRPC = 2;
    public static final int MODE_ATOM = 3;
    public static final int MODE_PDF = 4;
    public static final int MODE_GWT = 5;
    public static final int MODE_GWT_DEBUG = 6;

    private boolean finished = false;
    private XWiki wiki;
    private XWikiEngineContext engine_context;
    private XWikiRequest request;
    private XWikiResponse response;
    private XWikiForm form;
    private String action;
    private String orig_database;
    private String database;
    private boolean virtual;
    private XWikiUser user;
    private String language;
    private String interfaceLanguage;
    private int mode;
    private URL url;
    private XWikiURLFactory URLFactory;
    private XmlRpcServer xmlRpcServer;
    private String wikiOwner;
    private XWikiDocument wikiServer;
    private int cacheDuration = 0;

    // Used to avoid recursive loading of documents if there are recursives usage of classes
    private Map<String, BaseClass> classCache = new HashMap<String, BaseClass>();
    // Used to avoir reloading archives in the same request
    private Map<String, Object> archiveCache = new HashMap<String, Object>();

    private List<String> displayedFields = new ArrayList<String>();
    private static final Object CONTEX_LOCK = new Object();

    public XWikiContext() {
    }

    public XWiki getWiki() {
        return wiki;
    }

    public Util getUtil() {
        Util util = (Util) get("util");
        if (util == null) {
            util = new Util();
            put("util", util);
        }
        return util;
    }

    public void setWiki(XWiki wiki) {
        this.wiki = wiki;
    }

    public XWikiEngineContext getEngineContext() {
        return engine_context;
    }

    public void setEngineContext(XWikiEngineContext engine_context) {
        this.engine_context = engine_context;
    }

    public XWikiRequest getRequest() {
        return request;
    }

    public void setRequest(XWikiRequest request) {
        this.request = request;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public XWikiResponse getResponse() {
        return response;
    }

    public void setResponse(XWikiResponse response) {
        this.response = response;
    }

    public String getDatabase() {
        return database;
    }

    public void setDatabase(String database) {
    }

    public String getOriginalDatabase() {
        return orig_database;
    }

    public void setOriginalDatabase(String database) {
    }

    public boolean isVirtual() {
        return virtual;
    }

    public void setVirtual(boolean virtual) {
        this.virtual = virtual;
    }

    public VelocityContext getVelocityContext() {
        return (VelocityContext) get("vcontext");
    }

    public boolean isInHistoryMode() {
        return isInCompareMode() || getRevision() != null || BaselineServlet.getCurrentBaselineRevision() != null;
    }

    public boolean isInReadOnlyMode() {
        return isInHistoryMode() || isInPdfMode() || isInPrintMode() || isInDocumentEditor();
    }

    public boolean isInDocumentEditor() {
        return "1".equals(get("documentLikeEditor")); //$NON-NLS-1$ //$NON-NLS-2$
    }

    public boolean isInPdfMode() {
        return "1".equals(get("pdf_generate")); //$NON-NLS-1$ //$NON-NLS-2$
    }

    public boolean isInPrintMode() {
        return "print".equals(getAction());
    }

    public boolean isInCompareMode() {
        return "1".equals(get("compareMode")); //$NON-NLS-1$ //$NON-NLS-2$
    }

    @Nullable
    public String getRevision() {
        return (String) get("revision");
    }

    public XWikiDocument getDoc() {
        return (XWikiDocument) get("doc");
    }

    public void setDoc(XWikiDocument doc) {
        put("doc", doc);
    }

    public void setUser(String user, boolean main) {
        synchronized (CONTEX_LOCK) {
            this.user = new XWikiUser(user, main);
        }
    }

    public void setUser(String user) {
        synchronized (CONTEX_LOCK) {
            this.user = new XWikiUser(user);
        }
    }

    public String getUser() {
        synchronized (CONTEX_LOCK) {
            if (user != null && user.getUser() != null) {
                return user.getUser();
            } else
            {
                //return "XWiki.XWikiGuest";
                String name = wiki.getUser();
                setUser(name);
                return name;
            }
        }
    }

    public String getLocalUser() {
        String username = getUser();
        return username.substring(username.indexOf(":") + 1);
    }

    public XWikiUser getXWikiUser() {
        synchronized (CONTEX_LOCK) {
            return user;
        }
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getInterfaceLanguage() {
        return interfaceLanguage;
    }

    public void setInterfaceLanguage(String interfaceLanguage) {
        this.interfaceLanguage = interfaceLanguage;
    }

    public int getMode() {
        return mode;
    }

    public void setMode(int mode) {
        this.mode = mode;
    }

    public URL getURL() {
        return url;
    }

    public void setURL(URL url) {
        this.url = url;
    }

    public XWikiURLFactory getURLFactory() {
        return URLFactory;
    }

    public void setURLFactory(XWikiURLFactory URLFactory) {
        this.URLFactory = URLFactory;
    }

    public XWikiForm getForm() {
        return form;
    }

    public void setForm(XWikiForm form) {
        this.form = form;
    }

    public boolean isFinished() {
        return this.finished;
    }

    public void setFinished(boolean finished) {
        this.finished = finished;
    }

    public XmlRpcServer getXMLRPCServer() {
        return xmlRpcServer;
    }

    public void setXMLRPCServer(XmlRpcServer xmlRpcServer) {
        this.xmlRpcServer = xmlRpcServer;
    }

    public void setWikiOwner(String wikiOwner) {
        this.wikiOwner = wikiOwner;
    }

    public String getWikiOwner() {
        return wikiOwner;
    }

    public void setWikiServer(XWikiDocument doc) {
        wikiServer = doc;
    }

    public XWikiDocument getWikiServer() {
        return wikiServer;
    }

    public int getCacheDuration() {
        return cacheDuration;
    }

    public void setCacheDuration(int cacheDuration) {
        this.cacheDuration = cacheDuration;
    }

    public String getMainXWiki() {
        return (String) get("mainxwiki");
    }

    public void setMainXWiki(String str) {
        put("mainxwiki", str);
    }

    // Used to avoid recursive loading of documents if there are recursives usage of classes
    public void addBaseClass(BaseClass bclass) {
        classCache.put(bclass.getName(), bclass);
    }

    // Used to avoid recursive loading of documents if there are recursives usage of classes
    public BaseClass getBaseClass(String name) {
        return classCache.get(name);
    }

    // Used to avoid recursive loading of documents if there are recursives usage of classes
    public void addDocumentArchive(String key, Object obj) {
        archiveCache.put(key, obj);
    }

    // Used to avoid recursive loading of documents if there are recursives usage of classes
    public Object getDocumentArchive(String key) {
        return archiveCache.get(key);
    }

    public void setLinksAction(String action) {
        put("links_action", action);
    }

    public void unsetLinksAction() {
        remove("links_action");
    }

    public String getLinksAction() {
        return (String) get("links_action");
    }

    public void setLinksQueryString(String value) {
        put("links_qs", value);
    }

    public void unsetLinksQueryString() {
        remove("links_qs");
    }

    public String getLinksQueryString() {
        return (String) get("links_qs");
    }

    public XWikiMessageTool getMessageTool() {
        return ((XWikiMessageTool) get("msg"));
    }

    public XWikiValidationStatus getValidationStatus() {
        return (XWikiValidationStatus) get("validation_status");
    }

    public void setValidationStatus(XWikiValidationStatus status) {
        put("validation_status", status);
    }

    public void addDisplayedField(String fieldname) {
        displayedFields.add(fieldname);
    }

    public List getDisplayedFields() {
        return displayedFields;
    }

    public Object getEditorWysiwyg() {
        return get("editor_wysiwyg");
    }
}
