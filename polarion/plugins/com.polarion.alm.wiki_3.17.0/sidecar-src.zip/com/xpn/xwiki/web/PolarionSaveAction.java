package com.xpn.xwiki.web;

import javax.servlet.ServletOutputStream;

import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.doc.XWikiLock;
import com.xpn.xwiki.objects.BaseObject;
import com.xpn.xwiki.objects.classes.BaseClass;

public class PolarionSaveAction extends XWikiAction
{
    @Override
    public boolean action(XWikiContext context) throws XWikiException
    {
// doc save
/////////////////////////////////////////////////////////////////////////////////////////////////////////		
        XWiki xwiki = context.getWiki();
        XWikiRequest request = context.getRequest();
        XWikiDocument doc = context.getDoc();
        XWikiForm form = context.getForm();

        XWikiDocument docT = (XWikiDocument) doc.clone();
        String contentEdit = "";
        String SaveType = request.getParameter("savetype");

        // Confirm edit to avoid spam robots
        Boolean isResponseCorrect = Boolean.TRUE;
        // If  'save' action after preview
        String isResponsePreviewCorrect = request.getParameter("isResponsePreviewCorrect");
        if ((isResponsePreviewCorrect != null)) {
            isResponseCorrect = Boolean.valueOf(isResponsePreviewCorrect);
        }

        // If captcha is not correct it will be required again
        if (!isResponseCorrect.booleanValue()) {
            return true;
        }

        // This is pretty useless, since contexts aren't shared between threads.
        // It just slows down execution.
        String title = doc.getTitle();
        // Check save session
        int sectionNumber = 0;
        if (request.getParameter("section") != null && xwiki.hasSectionEdit(context)) {
            sectionNumber = Integer.parseInt(request.getParameter("section"));
        }
        synchronized (doc)
        {
            String language = ((EditForm) form).getLanguage();
            // FIXME Which one should be used: doc.getDefaultLanguage or
            // form.getDefaultLanguage()?
            // String defaultLanguage = ((EditForm) form).getDefaultLanguage();
            XWikiDocument tdoc;

            if ((language == null) || (language.equals("")) || (language.equals("default")) || (language.equals(doc.getDefaultLanguage()))) {
                // Need to save parent and defaultLanguage if they have changed
                tdoc = docT;
            } else {
                tdoc = doc.getTranslatedDocument(language, context);
                if ((tdoc == doc) && xwiki.isMultiLingual(context)) {
                    tdoc = new XWikiDocument(doc.getSpace(), doc.getName());
                    tdoc.setLanguage(language);
                    tdoc.setStore(doc.getStore());
                }
                tdoc.setTranslation(1);
            }

            XWikiDocument olddoc = (XWikiDocument) tdoc.clone();
            try {
                tdoc.readFromTemplate(((EditForm) form).getTemplate(), context);
            } catch (XWikiException e) {
                if (e.getCode() == XWikiException.ERROR_XWIKI_APP_DOCUMENT_NOT_EMPTY) {
                    context.put("exception", e);
                    return true;
                }
            }

            if (sectionNumber != 0) {
                XWikiDocument sectionDoc = (XWikiDocument) tdoc.clone();
                sectionDoc.readFromForm((EditForm) form, context);
                String sectionContent = sectionDoc.getContent() + "\n";
                String content = doc.updateDocumentSection(sectionNumber, sectionContent);
                tdoc.setContent(content);
                tdoc.setTitle(title);
            } else {
                tdoc.readFromForm((EditForm) form, context);
            }

            // TODO: handle Author
            String username = context.getUser();
            tdoc.setAuthor(username);
            if (tdoc.isNew()) {
                tdoc.setCreator(username);
            }

            // Make sure we have at least the meta data dirty status
            tdoc.setMetaDataDirty(true);
            // We get the comment to be used from the document
            // It was read using readFromForm

            if (!SaveType.equalsIgnoreCase("savecomments") && !SaveType.equalsIgnoreCase("saveattach"))
            {
                xwiki.saveDocument(tdoc, olddoc, tdoc.getComment(), context);
            }
            contentEdit = tdoc.getContent();

            XWikiLock lock = tdoc.getLock(context);
            if (lock != null) {
                tdoc.removeLock(context);
            }
        }

/////////////////////////////////////////////////////////////////////////////////////////////////////////

// comments save
/////////////////////////////////////////////////////////////////////////////////////////////////////////
        xwiki = context.getWiki();
        request = context.getRequest();
        XWikiResponse response = context.getResponse();
        doc = context.getDoc();
        EditForm oform = (EditForm) context.getForm();
        String comm = request.getParameter("XWiki.XWikiComments_comment");

        if (comm != null && !comm.trim().equalsIgnoreCase("") && SaveType.equalsIgnoreCase("savecomments"))
        {
            // Make sure this class exists
            BaseClass baseclass = xwiki.getCommentsClass(context);
            if (isResponseCorrect.booleanValue())
            {
                XWikiDocument olddoc = (XWikiDocument) doc.clone();
                String className = "XWiki.XWikiComments";
                int nb = doc.createNewObject(className, context);
                BaseObject oldobject = doc.getObject(className, nb);
                BaseObject newobject = (BaseObject) baseclass.fromMap(oform.getObject(className), oldobject);
                newobject.setNumber(oldobject.getNumber());
                newobject.setName(doc.getFullName());
                doc.setObject(className, nb, newobject);
                xwiki.saveDocument(doc, olddoc, context.getMessageTool().get("core.comment.addComment"), context);
            } else
            {
                String url = context.getDoc().getURL("view", "xpage=comments&confirm=false", context);
                try {
                    response.sendRedirect(url);
                } catch (Exception e) {
                    System.err.println(e.getStackTrace().toString());
                }
            }
        }

/////////////////////////////////////////////////////////////////////////////////////////////////////////

        if (SaveType.equalsIgnoreCase("savecomments") || SaveType.equalsIgnoreCase("saveattach"))
        {
            String redirect = Utils.getRedirect("edit", context);
            redirectToEdit(response, redirect, contentEdit);
        }
        else
        {
            String redirect = Utils.getRedirect("view", context);
            sendRedirect(response, redirect);
        }

        return false;
    }

    @Override
    public String render(XWikiContext context) throws XWikiException {
        context.put("message", "nocommentwithnewdoc");
        return "exception";
    }

    public void redirectToEdit(XWikiResponse response, String page, String contentEdit)
    {
        try
        {
            String cont = "<html><body onload='javascript:test.submit();'><form method=\"post\" id=\"test\" name=\"test\" action=\"" + page + "\"><input type=\"hidden\" name=\"content\" value=\"" + contentEdit
                    + "\" /></form></body></html>";

            response.setContentType("text/html");
            response.setContentLength(cont.length());

            byte[] output = cont.getBytes();
            ServletOutputStream ouputStream;
            ouputStream = response.getOutputStream();
            ouputStream.write(output);
            ouputStream.flush();
            ouputStream.close();
        } catch (Exception r)
        {
            try
            {
                response.sendRedirect(page);
            } catch (Exception e) {
            }
        }

    }
}
