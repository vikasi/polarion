package com.xpn.xwiki.web;

import org.apache.velocity.VelocityContext;

import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;

public class RequestToOpenPdfDialogAction extends XWikiAction {
    @Override
    public String render(XWikiContext context) throws XWikiException {

        VelocityContext vcontext = (VelocityContext) context.get("vcontext");

        String url = context.getURL().toString();
        vcontext.put("url", url.replace("requesttoopenpdfdialogaction", "pdfdialogaction"));

        return "requesttopdfdialog";
    }
}
