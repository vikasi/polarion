/*
 * Copyright 2006, XpertNet SARL, and individual contributors as indicated
 * by the contributors.txt.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 * @author ludovic
 * @author namphunghai
 * @author wr0ngway
 * @author sdumitriu
 */
package com.xpn.xwiki.web;

import java.io.IOException;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.velocity.VelocityContext;

import com.sun.jndi.toolkit.url.UrlUtil;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.doc.XWikiAttachment;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.plugin.fileupload.FileUploadPlugin;

public class UploadAction extends XWikiAction
{
    private static final Log log = LogFactory.getLog(UploadAction.class);

    @Override
    public boolean action(XWikiContext context) throws XWikiException
    {
        XWikiResponse response = context.getResponse();
        XWikiDocument doc = context.getDoc();
        String username = context.getUser();
        Object exception = context.get("exception");

        XWikiRequest request = context.getRequest();
        String content = request.getParameter("content");
        boolean saveonly = Boolean.parseBoolean(request.getParameter("saveonly"));
        boolean backtoedit = Boolean.parseBoolean(request.getParameter("backtoedit"));
        if (backtoedit) {
            saveonly = false;
        }
        if (saveonly) {
            ((VelocityContext) context.get("vcontext")).put("from_save_only", Boolean.TRUE);
        }
        try {
            String revision = request.getParameter("revision");
            String currentRevision = doc.getRevision();
            if (revision != null && currentRevision != null) {
                int rev = Integer.valueOf(revision);
                int cur = Integer.valueOf(currentRevision);
                if (cur > rev) {
                    throw new XWikiException(XWikiException.MODULE_XWIKI_APP, XWikiException.ERROR_CONFLICT_ON_SAVE, "The page was modified in the mean time, revision:" + revision + " current:" + currentRevision);
                }
            }
        } catch (RuntimeException e) {
            log.warn("cannot check conflic state cause:" + e.getLocalizedMessage(), e);
        }

        String docType = request.getParameter("page_type");
        // check Exception File upload is large
        if (exception != null) {
            if (exception instanceof XWikiException) {
                XWikiException exp = (XWikiException) exception;
                if (exp.getCode() == XWikiException.ERROR_XWIKI_APP_FILE_EXCEPTION_MAXSIZE) {
                    response.setStatus(HttpServletResponse.SC_REQUEST_ENTITY_TOO_LARGE);
                    throw exp;
                }
            }
        }
        FileUploadPlugin fileupload = (FileUploadPlugin) context.get("fileuploadplugin");

        String filename;
        try {
            filename = fileupload.getFileItemAsString("filename", context);
        } catch (Exception ex) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            context.put("message", "tempdirnotset");
            return true;
        }

        if (filename != null) {
            if (filename.indexOf("/") != -1 || filename.indexOf("\\") != -1)
            {
                response.setStatus(HttpServletResponse.SC_FORBIDDEN);
                context.put("message", "notsupportcharacters");
                return true;
            }
        }

        List<XWikiAttachment> deleteList = new LinkedList<XWikiAttachment>();
        List<XWikiAttachment> saveList = new LinkedList<XWikiAttachment>();

        XWikiDocument olddoc = (XWikiDocument) doc.clone();
        byte[] data = fileupload.getFileItemData("filepath", context);
        String filePathsMult = fileupload.getFileItemAsString("filepathMult", context);

        String forDelete = fileupload.getFileItemAsString("fileNamesDelete", context);
        if (forDelete != null && !forDelete.equalsIgnoreCase(""))
        {
            StringTokenizer strToken = new StringTokenizer(forDelete, ";");
            while (strToken.hasMoreTokens())
            {
                String PathFile = strToken.nextToken();
                if (PathFile != null && !PathFile.equalsIgnoreCase(""))
                {
                    XWikiAttachment attachment = null;
                    attachment = olddoc.getAttachment(PathFile);
                    deleteList.add(attachment);
                }

            }
        }

        olddoc.setAuthor(username);
        if (docType != null) {
            olddoc.setType(docType);
        }

        if (olddoc.isNew()) {
            olddoc.setCreator(username);
        }

        if (filePathsMult != null && !filePathsMult.equalsIgnoreCase(""))
        {
            filePathsMult = filePathsMult.substring(0, filePathsMult.length() - 1);

            StringTokenizer strToken = new StringTokenizer(filePathsMult, ";");
            while (strToken.hasMoreTokens())
            {
                String formPath = strToken.nextToken();
                if (formPath.startsWith("fileTitle")) {
                    continue;
                }
                String titleForToken = "fileTitle" + formPath.substring(formPath.lastIndexOf("t") + 1);
                String attachTitle = request.getParameter(titleForToken);

                byte[] data_mult = fileupload.getFileItemData(formPath, context);

                if (filename == null || filename.equalsIgnoreCase("")) {
                    String fname = fileupload.getFileName(formPath, context);
                    if (fname == null) {
                        continue;
                    }
                    int i = fname.lastIndexOf("\\");
                    if (i == -1) {
                        i = fname.lastIndexOf("/");
                    }
                    filename = fname.substring(i + 1);
                }
                filename = filename.replaceAll("\\+", " ");

                if (!filename.trim().equalsIgnoreCase(""))
                {
                    // Read XWikiAttachment
                    XWikiAttachment attachment = olddoc.getAttachment(filename);

                    if (attachment == null) {
                        attachment = new XWikiAttachment();
                        olddoc.getAttachmentList().add(attachment);
                    }
                    attachment.setContent(data_mult);
                    attachment.setFilename(filename);
                    // TODO: handle Author
                    attachment.setAuthor(username);
                    attachment.setTitle(attachTitle);

                    // Add the attachment to the document
                    attachment.setDoc(olddoc);
                    // Save the content and the archive
                    saveList.add(attachment);
                }
                filename = null;
            }// while

        }
        else
        {

            if (filename == null)
            {
                String fname = fileupload.getFileName("filepath", context);
                if (fname == null)
                {
                    filename = "";
                }
                else
                {
                    int i = fname.lastIndexOf("\\");
                    if (i == -1) {
                        i = fname.lastIndexOf("/");
                    }
                    filename = fname.substring(i + 1);
                }
            }

            filename = filename.replaceAll("\\+", " ");
            if (!filename.trim().equalsIgnoreCase(""))
            {
                XWikiAttachment attachment = olddoc.getAttachment(filename);

                if (attachment == null) {
                    attachment = new XWikiAttachment();
                    olddoc.getAttachmentList().add(attachment);
                }

                if (data.length > 0)
                {
                    attachment.setContent(data);
                    attachment.setFilename(filename);
                    // TODO: handle Author
                    attachment.setAuthor(username);

                    // Add the attachment to the document
                    attachment.setDoc(olddoc);

                    olddoc.setAuthor(username);
                    String attachTitle = request.getParameter("title");
                    attachment.setTitle(attachTitle);
                    if (olddoc.isNew()) {
                        olddoc.setCreator(username);
                    }

                    // Save the content and the archive
                    saveList.add(attachment);
                }
            }
        }
        boolean updateDoc = true;

        if (docType == null) {
            docType = "";
        }

        if (content != null) {
            updateDoc = (!(content.trim().replaceAll("\r\n", "\n")).equals((doc.getContent().trim().replaceAll("\r\n", "\n"))) || !docType.equalsIgnoreCase(doc.getType()));
        }

        if (doc.isTemplate() && doc.isNew()) {
            updateDoc = true;
        }
        if (content != null)
        {
            olddoc.setContent(content);
        }
        context.getWiki().updateXWikiDoc(olddoc, saveList, deleteList, context, updateDoc);

        if (content != null) {
            doc.setContent(content);
        }

        doc.setAttachmentList(olddoc.getAttachmentList());
        doc.setCreator(olddoc.getCreator());
        doc.setCreationDate(olddoc.getCreationDate());
        doc.setDate(olddoc.getDate());
        doc.setAuthor(olddoc.getAuthor());

        if (olddoc.isTemplate())
        {
            doc.setCreator(olddoc.getAuthor());
            doc.setCreationDate(new Date());
            olddoc.setCreationDate(new Date());
            olddoc.setCreator(olddoc.getAuthor());
        }
        doc.setIsTemplate(false);
        olddoc.setIsTemplate(false);

        if (content == null || content.equalsIgnoreCase(""))
        {
            // forward to attach page
            String redirect = fileupload.getFileItemAsString("xredirect", context);
            if ((redirect == null) || (redirect.equals(""))) {
                redirect = context.getDoc().getURL("attach", true, context);
            }
            sendRedirect(response, redirect);
        }
        else
        {
            String redirect;
            if (backtoedit) {
                redirect = Utils.getRedirect("edit", context);
            } else {
                redirect = Utils.getRedirect("view", context);
            }
            if (saveonly) {
                ((VelocityContext) context.get("vcontext")).put("newRevision", olddoc.getRevision());
                ((VelocityContext) context.get("vcontext")).put("redirectUrl", redirect);
                ((VelocityContext) context.get("vcontext")).put("attLimit", System.getProperty("maxAttachmentSize"));
                Utils.parseTemplate("uploaded", context);
                return false;
            }
            try
            {
                sendRedirect(response, UrlUtil.encode(redirect, "UTF-8"));
            } catch (Exception e)
            {

            }

            //String redirect = Utils.getRedirect("edit", context);
            //redirectToEdit(response, redirect,content);
        }
        return false;
    }

    @Override
    public String render(XWikiContext context) throws XWikiException
    {
        boolean ajax = ((Boolean) context.get("ajax")).booleanValue();
        if (ajax) {
            try {
                context.getResponse().getOutputStream().println("error: " + context.getMessageTool().get((String) context.get("message")));
            } catch (IOException ex) {
                log.error("Unhandled exception writing output:", ex);
            }
            return null;
        }
        return "exception";

    }

    public void redirectToEdit(XWikiResponse response, String page, String contentEdit)
    {
        try
        {
            String cont = "<html><body onload='javascript:test.submit();'><form method=\"post\" id=\"test\" name=\"test\" action=\"" + page + "\"><input type=\"hidden\" name=\"content\" value=\"" + contentEdit
                    + "\" /></form></body></html>";

            response.setContentType("text/html");
            response.setContentLength(cont.length());

            byte[] output = cont.getBytes();
            ServletOutputStream ouputStream;
            ouputStream = response.getOutputStream();
            ouputStream.write(output);
            ouputStream.flush();
            ouputStream.close();
        } catch (Exception r)
        {
            try
            {
                response.sendRedirect(page);
            } catch (Exception e) {
            }
        }

    }
}