/*
 * Copyright 2006, XpertNet SARL, and individual contributors as indicated
 * by the contributors.txt.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 * @author wr0ngway
 * @author sdumitriu
 */
package com.xpn.xwiki.web;

import com.polarion.core.util.RunnableWEx;
import com.polarion.portal.server.TransactionalExecuter;
import com.polarion.wiki.util.OverviewPanel;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.pdf.impl.PdfExportImpl;

public class PDFAction extends XWikiAction {
    @Override
    public String render(final XWikiContext context) throws XWikiException {
        XWikiURLFactory urlf = context.getWiki().getURLFactoryService().createURLFactory(XWikiContext.MODE_PDF, context);
        context.setURLFactory(urlf);
        final PdfExportImpl pdfexport = new PdfExportImpl(context);
        handleRevision(context);
        final XWikiDocument doc = context.getDoc();

        if (doc.isNew()) {
            String name = doc.getName();
            String space = doc.getSpaceName();
            String project = doc.getProject();
            String group = doc.getGroup();
            String scope = OverviewPanel.getScope(group, project, space);
            if (OverviewPanel.hasPage(space, name, scope)) {
                //-------- load page content from tempalte ----------------
                doc.setIsTemplate(true);
                XWikiDocument panelDoc = OverviewPanel.getPage(context, space, name, scope);
                if (panelDoc != null)
                {
                    doc.setContent(panelDoc.getContent());
                    doc.setType(panelDoc.getType());
                    doc.setAuthor(panelDoc.getAuthor());
                    doc.setDate(panelDoc.getDate());
                    doc.setCreationDate(panelDoc.getCreationDate());
                    doc.setCreator(panelDoc.getCreator());

                }
            }
        }

        try {
            TransactionalExecuter.executeInTransaction(new RunnableWEx<Void>() {

                @Override
                public Void runWEx() throws Exception {
                    pdfexport.exportToPDF(doc, null, context);
                    return null;
                }

            });
        } catch (Exception e) {
            if (e instanceof XWikiException) {
                throw (XWikiException) e;
            }
            throw new XWikiException(XWikiException.MODULE_XWIKI_CONTENT,
                    XWikiException.ERROR_DOC_XML_PARSING, "Exception validation.", e, null, null); //$NON-NLS-1$
        }
        return null;
    }
}
