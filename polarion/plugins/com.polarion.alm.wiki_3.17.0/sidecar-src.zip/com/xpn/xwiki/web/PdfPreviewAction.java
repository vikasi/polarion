package com.xpn.xwiki.web;

import java.io.File;

import org.apache.velocity.VelocityContext;

import com.polarion.wiki.util.SpaceParser;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.pdf.impl.PdfExportImpl;

public class PdfPreviewAction extends XWikiAction {

    @Override
    public String render(XWikiContext context) throws XWikiException {
        VelocityContext vcontext = (VelocityContext) context.get("vcontext");
        String width = null;
        String height = null;
        String tempdir = null;
        String page = null;
        String error = null;

        String url = context.getURL().toString();
        String[] parts = url.split("[?]");
        url = parts[0];
        if (parts.length == 2) {
            String[] params = parts[1].split("[&]");
            if (params != null) {
                for (String param : params) {
                    String[] parts2 = param.split("[=]");
                    if (parts2.length == 2) {
                        if (parts2[0].trim().equals("width")) {
                            width = parts2[1];
                        } else if (parts2[0].trim().equals("height")) {
                            height = parts2[1];
                        } else if (parts2[0].trim().equals("tempdir")) {
                            tempdir = parts2[1];
                        } else if (parts2[0].trim().equals("page")) {
                            page = parts2[1];
                        }
                    }
                }
            }
        }

        if ((width == null) || (height == null) || (tempdir == null) || (page == null)) {
            error = "Bad arguments";
            vcontext.put("result", error);
            return "showstring";
        }

        XWikiDocument doc = context.getDoc();
        File dir = (File) context.getEngineContext().getAttribute("javax.servlet.context.tempdir");
        String filename = doc.getProject() +
                (SpaceParser.getSpace(doc.getSpace()).startsWith("_") ? "" : "_") +
                SpaceParser.getSpace(doc.getSpace()) +
                "_" + doc.getName() +
                "_" + height +
                "_" + width +
                "_" + page + ".png";

        File previewFile = new File(dir, tempdir + File.separatorChar + filename);
        if (!previewFile.exists()) {
            error = "Page doesn't exist.";
            vcontext.put("result", error);
            return "showstring";
        }

        PdfExportImpl pdfexport = new PdfExportImpl(context);

        try {

            pdfexport.sendPNGResponce(previewFile);
        } catch (XWikiException e) {
            throw e;
        } catch (Exception e) {
            throw new XWikiException(XWikiException.MODULE_XWIKI_CONTENT,
                    XWikiException.ERROR_DOC_XML_PARSING,
                    "Preview file doesn't exist.", e, null, ((XWikiException) e).getSaxLine());
        }

        return null;
    }

}
