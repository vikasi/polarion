/*
 * Copyright 2006-2007, XpertNet SARL, and individual contributors as indicated
 * by the contributors.txt.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */
package com.xpn.xwiki.web;

import java.io.IOException;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.polarion.alm.server.RpcDetailsImpl;
import com.polarion.alm.ui.server.wiki.PageParameters;
import com.polarion.alm.ui.server.wiki.ParameterMacroConfiguration;
import com.polarion.portal.shared.wiki.WikiMacroParametersParser;
import com.polarion.reina.web.shared.JSSharedUtil;
import com.polarion.wiki.web.BaselineServlet;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.doc.XWikiDocument;

/**
 * Action called when the request URL has the "/view/" string in its path (this is configured
 * in <code>struts-config.xml</code>. It means the request is to display a page in view mode.
 *
 * @version $Id: $ 
 */
public class ViewAction extends XWikiAction
{
    /**
     * @todo need an enumerated class for actions.
     */
    private static final String VIEW_ACTION = "view";

    /**
     * {@inheritDoc}
     * @see XWikiAction#action(com.xpn.xwiki.XWikiContext)
     */
    @Override
    @SuppressWarnings("nls")
    public boolean action(XWikiContext context) throws XWikiException
    {
        boolean shouldRender = true;

        XWikiRequest request = context.getRequest();
        context.put("action", VIEW_ACTION);

        // Redirect to the ViewrevAction is the URL has a rev parameter (when the user asks to
        // view a specific revision of a document).
        String rev = request.getParameter("rev");
        XWikiDocument doc = context.getDoc();
        if (rev != null) {
            //context.getRequest().getRequestURL()
            String url = doc.getURL("viewrev", request.getQueryString(), context);
            try {
                context.getResponse().sendRedirect(url);
            } catch (IOException e) {
                e.printStackTrace();
            }
            shouldRender = false;
            return false;
        } else {
            handleSaveParameters(context, request, doc);
        }

        return shouldRender;
    }

    /**
     * @param context
     * @param request
     * @param doc
     * @throws XWikiException
     */
    @SuppressWarnings("nls")
    private void handleSaveParameters(XWikiContext context, XWikiRequest request, XWikiDocument doc) throws XWikiException {
        boolean isSaveParameter = request.getParameterMap().containsKey("saveAsDefault");
        if (isSaveParameter && BaselineServlet.getCurrentBaselineRevision() == null) {
            XWikiDocument cloneDoc = (XWikiDocument) doc.clone();
            String docContent = cloneDoc.getContent();

            Pattern parameterPattern = Pattern.compile("\\{parameter\\}|\\{parameter:[^\\}]*\\}", Pattern.DOTALL);

            Matcher mContent = parameterPattern.matcher(docContent);

            StringBuffer sb2 = new StringBuffer();
            for (int i = 0; mContent.find(); i++) {
                String macroText = mContent.group();

                PageParameters pageParams = new PageParameters();
                pageParams.processParameter(macroText, doc.getProject());
                String paramId = pageParams.keySet().iterator().next();

                if (request.getParameterMap().containsKey(paramId)) {
                    String requestValue = request.get(paramId);
                    WikiMacroParametersParser macroParser = pageParams.getMacroParser(paramId);

                    if (ParameterMacroConfiguration.DATE_TYPE.equals(pageParams.getType(paramId))) {
                        String actualDateString = JSSharedUtil.formatDateOnly(new Date());
                        boolean isCurrent = pageParams.isCurrent(macroParser.getNamedParameter(ParameterMacroConfiguration.VALUE), ParameterMacroConfiguration.DATE_TYPE);
                        if (isCurrent) {
                            if (!actualDateString.equals(requestValue)) {
                                macroParser.setParameter(ParameterMacroConfiguration.VALUE, requestValue);
                            }
                        } else {
                            macroParser.setParameter(ParameterMacroConfiguration.VALUE, requestValue);
                        }

                    } else {
                        macroParser.setParameter(ParameterMacroConfiguration.VALUE, requestValue);
                    }
                    macroText = macroParser.toString();
                }
                mContent.appendReplacement(sb2, Matcher.quoteReplacement(macroText));
            }

            mContent.appendTail(sb2);
            docContent = sb2.toString();
            cloneDoc.setContent(docContent);

            XWikiException exception = null;
            try {
                context.getWiki().saveDocument(cloneDoc, context);
            } catch (XWikiException e) {
                exception = e;
            }

            if (exception == null) {
                doc.setContent(docContent);
            } else {
                throw exception;
            }
        }
    }

    /**
     * {@inheritDoc}
     * @see XWikiAction#render(com.xpn.xwiki.XWikiContext) 
     */
    @Override
    public String render(XWikiContext context) throws XWikiException
    {

        com.xpn.xwiki.api.XWiki xWiki = new com.xpn.xwiki.api.XWiki(context.getWiki(), context);

        if (!xWiki.hasPermission("read")) { //$NON-NLS-1$
            return "accessdenied"; //$NON-NLS-1$
        }

        handleRevision(context);
        XWikiDocument doc = (XWikiDocument) context.get("doc");

        String defaultTemplate = doc.getDefaultTemplate();
        if ((defaultTemplate != null) && (!defaultTemplate.equals(""))) {
            return defaultTemplate;
        } else {
            return VIEW_ACTION;
        }
    }

    @Override
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest req, HttpServletResponse resp) throws Exception, ServletException {
        RpcDetailsImpl.startMeasuring();
        try {
            return super.execute(mapping, form, req, resp);
        } finally {
            RpcDetailsImpl.logElapsedTime();
        }
    }
}
