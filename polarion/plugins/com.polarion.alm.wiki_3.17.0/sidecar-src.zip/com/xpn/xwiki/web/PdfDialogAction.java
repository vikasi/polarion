package com.xpn.xwiki.web;

import java.net.URLDecoder;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.velocity.VelocityContext;

import com.polarion.platform.i18n.Localization;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;

public class PdfDialogAction extends XWikiAction {
    @Override
    public String render(XWikiContext context) throws XWikiException {
        VelocityContext vcontext = (VelocityContext) context.get("vcontext");
        String orientation = null;
        String paper = null;
        String revision = null;
        String headerFooter = null;
        String bookmarks = null;
        String adjustWidth = null;
        String dirName = "tmp_" + RandomStringUtils.randomAlphanumeric(8);

        String url = URLDecoder.decode(context.getURL().toString());
//		if(context.getRequest().getHeader("user-agent").contains("Firefox")){
//			url = url.substring(0,url.indexOf("/polarion/")+10);
//			url = url + "wiki/bin" + context.getRequest().getPathInfo() + "?"+context.getRequest().getQueryString();
//		}
        String[] parts = url.split("[?]");
        url = parts[0];
        if (parts.length == 2) {
            String[] params = parts[1].split("[&]");
            if (params != null) {
                for (String param : params) {
                    String[] parts2 = param.split("[=]");
                    if (parts2.length == 2) {
                        if (parts2[0].trim().equals("orientation")) {
                            orientation = parts2[1];
                        } else if (parts2[0].trim().equals("paper")) {
                            paper = parts2[1];
                        } else if (parts2[0].trim().equals("rev")) {
                            revision = parts2[1];
                        } else if (parts2[0].trim().equals("headerFooter")) {
                            headerFooter = parts2[1];
                        } else if (parts2[0].trim().equals("bookmarks")) {
                            bookmarks = parts2[1];
                        } else if (parts2[0].trim().equals("adjustWidth")) {
                            adjustWidth = parts2[1];
                        }
                    }
                }
            }
        }

        vcontext.put("localization", new Localization());
        vcontext.put("newurl", url.replace("pdfdialogaction", "pdf"));
        vcontext.put("previewurl", url.replace("pdfdialogaction", "pdfpreviewdialogaction"));
        vcontext.put("closeurl", url.replace("pdfdialogaction", "pdfdialogcloseaction"));
        vcontext.put("orientation", orientation);
        vcontext.put("paper", paper);
        vcontext.put("adjustWidth", adjustWidth);
        vcontext.put("paper", paper);
        vcontext.put("bookmarks", bookmarks);
        vcontext.put("headerFooter", headerFooter);
        vcontext.put("tempdir", dirName);
        String rev = context.getRequest().getParameter("rev");
        if (rev == null) {
            rev = "";
        }
        vcontext.put("pdfRev", rev);
        return "openpdfdialog";

    }
}
