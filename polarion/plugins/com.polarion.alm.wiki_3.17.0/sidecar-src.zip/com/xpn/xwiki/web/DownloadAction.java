/*
 * Copyright 2006-2007, XpertNet SARL, and individual contributors as indicated
 * by the contributors.txt.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */
package com.xpn.xwiki.web;

import java.io.IOException;

import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.doc.XWikiAttachment;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.plugin.XWikiPluginManager;

public class DownloadAction extends XWikiAction
{
    public String getFileName(String path, String action)
    {
        path = path.substring(path.indexOf("/" + action));
        //<--IMA 
        //Correct image path with wiki 1.1 it doesn't show
        return path.substring((path.lastIndexOf("/") + 1), path.length());
        //-->
    }

    @Override
    public String render(XWikiContext context) throws XWikiException
    {
        XWikiRequest request = context.getRequest();
        XWikiResponse response = context.getResponse();
        XWikiDocument doc = context.getDoc();
        String path = request.getRequestURI();
        String filename = Utils.decode(getFileName(path, "download"), context);
        XWikiAttachment attachment;

        if (request.getParameter("id") != null) {
            int id = Integer.parseInt(request.getParameter("id"));
            attachment = doc.getAttachmentList().get(id);
        } else {
            attachment = doc.getAttachment(filename);
        }

        if (request.getParameter("attachRev") != null && !request.getParameter("attachRev").equalsIgnoreCase("0") && !request.getParameter("attachRev").equalsIgnoreCase(""))
        {
            XWikiDocument tdoc = doc.getTranslatedDocument(doc.getLanguage(), context);
            XWiki xwiki = context.getWiki();
            XWikiDocument newdoc = xwiki.getDocument(tdoc, request.getParameter("attachRev"), context);
            attachment = newdoc.getAttachment(filename);
            attachment.setDoc(newdoc);
        }

        if (attachment == null) {
            Object[] args = { filename };
            throw new XWikiException(XWikiException.MODULE_XWIKI_APP,
                    XWikiException.ERROR_XWIKI_APP_ATTACHMENT_NOT_FOUND,
                    "Attachment {0} not found", null, args);
        }

        XWikiPluginManager plugins = context.getWiki().getPluginManager();
        attachment = plugins.downloadAttachment(attachment, context);
        // Choose the right content type
        String mimetype = attachment.getMimeType(context);
        response.setContentType(mimetype);

        String ofilename =
                context.getWiki().getURLEncoded(attachment.getFilename()).replaceAll("\\+", " ");

        // The inline attribute of Content-Disposition tells the browser that they should display
        // the downloaded file in the page (see http://www.ietf.org/rfc/rfc1806.txt for more
        // details). We do this so that JPG, GIF, PNG, etc are displayed without prompting a Save
        // dialog box. However, all mime types that cannot be displayed by the browser do prompt a
        // Save dialog box (exe, zip, xar, etc).
        String userAgent = request.getHeader("User-Agent");
        if (userAgent.indexOf("MSIE 7.0") != -1) {
            response.setHeader("Content-disposition", "inline; filename=\"" + ofilename.replaceAll(" ", "%20") + "\"");
        } else {
            response.setHeader("Content-disposition", "inline; filename=\"" + ofilename + "\"");
        }

        // set content type for basic binary documents
        if (ofilename.endsWith(".doc") || ofilename.endsWith(".docx")) {
            response.setContentType("application/ms-word");
        } else if (ofilename.endsWith(".xls") || ofilename.endsWith(".xlsx")) {
            response.setContentType("application/ms-excel");
        } else if (ofilename.endsWith(".pdf")) {
            response.setContentType("application/pdf");
        }

        response.setDateHeader("Last-Modified", attachment.getDate().getTime());
        response.setHeader("Cache-Control", "no-cache, must-revalidate");
        response.setHeader("Expires", "Sat, 26 Jul 1997 05:00:00 GMT");
        response.setHeader("Pragma", "public");

        // Sending the content of the attachment
        byte[] data;
        try {
            data = attachment.getContent(context);
        } catch (XWikiException e) {
            Object[] args = { filename };
            throw new XWikiException(XWikiException.MODULE_XWIKI_APP,
                    XWikiException.ERROR_XWIKI_APP_ATTACHMENT_NOT_FOUND,
                    "Attachment content {0} not found", null, args);
        }

        response.setContentLength(data.length);
        try {
            response.getOutputStream().write(data);
        } catch (IOException e) {
            throw new XWikiException(XWikiException.MODULE_XWIKI_APP,
                    XWikiException.ERROR_XWIKI_APP_SEND_RESPONSE_EXCEPTION,
                    "Exception while sending response", e);
        }
        return null;
    }
}
