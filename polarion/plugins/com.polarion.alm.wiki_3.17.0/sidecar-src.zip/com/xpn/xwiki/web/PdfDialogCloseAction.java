package com.xpn.xwiki.web;

import java.io.File;
import java.util.Calendar;

import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;

public class PdfDialogCloseAction extends XWikiAction {
    @Override
    public String render(XWikiContext context) throws XWikiException {

        File dir = (File) context.getEngineContext().getAttribute("javax.servlet.context.tempdir");
        long deleteOlder = Calendar.getInstance().getTimeInMillis() - 60 * 60 * 1000;

        String url = context.getURL().toString();
        String[] parts = url.split("[?]");
        String[] p2 = parts[1].split("[=]");
        String tmpDirName = p2[1];

        File tmpDir = new File(dir, tmpDirName);
        deleteFile(tmpDir);

        //now delete another temporary directories which are older than 1 hour
        // - we like to have temporary directory to be tidy up
        for (File d : dir.listFiles()) {
            if (d.getName().startsWith("tmp_")) {
                if (d.lastModified() < deleteOlder) {
                    deleteFile(d);
                }
            }
        }

        return null;
    }

    private boolean deleteFile(File file) {
        if (file.isDirectory()) {
            File[] files = file.listFiles();
            for (int i = 0; i < files.length; i++) {
                if (!deleteFile(files[i])) {
                    return false;
                }
            }
        }

        return file.delete();
    }
}
