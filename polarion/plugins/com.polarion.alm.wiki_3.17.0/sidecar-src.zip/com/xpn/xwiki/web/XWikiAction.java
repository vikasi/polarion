/*
 * Copyright 2006, XpertNet SARL, and individual contributors as indicated
 * by the contributors.txt.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 * @author wr0ngway
 * @author sdumitriu
 */

package com.xpn.xwiki.web;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.MDC;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.velocity.VelocityContext;
import org.jetbrains.annotations.NotNull;

import com.polarion.core.util.EscapeChars;
import com.polarion.core.util.ObjectUtils;
import com.polarion.core.util.exceptions.ExceptionUtils;
import com.polarion.core.util.net.Urls;
import com.polarion.core.util.threads.ThreadNDC;
import com.polarion.platform.ITransactionService;
import com.polarion.platform.core.PlatformContext;
import com.polarion.platform.service.repository.driver.DriverException;
import com.polarion.portal.internal.shared.navigation.BaselineHelper;
import com.polarion.wiki.util.Constants;
import com.polarion.wiki.util.OverviewPanel;
import com.polarion.wiki.util.RequestParser;
import com.polarion.wiki.util.SpaceParser;
import com.polarion.wiki.util.XHTMLValidator;
import com.polarion.wiki.web.BaselineServlet;
import com.polarion.wiki.web.XWikiSecureEngineContext;
import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.monitor.api.MonitorPlugin;
import com.xpn.xwiki.plugin.fileupload.FileUploadPlugin;
import com.xpn.xwiki.render.XWikiVelocityRenderer;

/**
 * <p>A simple action that handles the display and editing of an
 * wiki page.. </p>
 * <p/>
 * <p>The action support an <i>action</i> URL. The action in the URL
 * controls what this action class does. The following values are supported:</p>
 * <ul>
 * <li>view - view the Wiki Document
 * <li>edit - edit the Wiki Document
 * <li>preview - preview the Wiki Document
 * <li>save - save the Wiki Document
 * </ul>
 */
public abstract class XWikiAction extends Action {

    // --------------------------------------------------------- Public Methods

    /**
     * Handle server requests.
     *
     * @param mapping The ActionMapping used to select this instance
     * @param form    The optional ActionForm bean for this request (if any)
     * @param req     The HTTP request we are processing
     * @param resp    The HTTP response we are creating
     * @throws IOException      if an input/output error occurs
     * @throws ServletException if a servlet exception occurs
     */
    @Override
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest req, HttpServletResponse resp) throws Exception, ServletException {
        String action = mapping.getName();

        if (action.equalsIgnoreCase("unknown")) {
            return null;
        }

        MonitorPlugin monitor = null;
        FileUploadPlugin fileupload = null;
        XWikiContext<String, java.lang.Object> context = null;

        final ITransactionService txService = PlatformContext.getPlatform().lookupService(ITransactionService.class);
        final boolean txExisted = (txService != null) && txService.txExists();
        ThreadNDC.push("wiki: " + action + " " + req.getRequestURL()); //$NON-NLS-1$ //$NON-NLS-2$
        try {
            XWikiRequest request = new XWikiServletRequest(req);
            XWikiResponse response = new XWikiServletResponse(resp);
            context = Utils.prepareContext(mapping.getName(), request, response,
                    new XWikiSecureEngineContext(new XWikiServletContext(servlet.getServletContext())));

            // Add the form to the context
            context.setForm((XWikiForm) form);
            XWiki xwiki = null;
            try {
                xwiki = XWiki.getXWiki(context);
            } catch (XWikiException e) {
                if (e.getCode() == XWikiException.ERROR_XWIKI_DOES_NOT_EXIST) {
                    // redirect
                    String redirect = context.getWiki().Param("xwiki.virtual.redirect");
                    response.sendRedirect(redirect);
                    return null;
                } else {
                    throw e;
                }
            }
            // Parses multipart so that parms in multipart are available for all actions
            fileupload = Utils.handleMultipart(req, context);

            XWikiURLFactory urlf = xwiki.getURLFactoryService().createURLFactory(context.getMode(), context);
            context.setURLFactory(urlf);
            String sajax = request.get("ajax");
            boolean ajax = false;
            if (sajax != null && !sajax.trim().equals("") && !sajax.equals("0")) {
                ajax = true;
            }
            context.put("ajax", new Boolean(ajax));
            // Any error before this will be treated using a redirection to an error page

            //if user trying to request service page (from XWikiTemplates dir)
            String service = request.get("service");
            if (service != "" && service != null) {
                context.put("service", service);
                context.setURL(RequestParser.getInnerURL(context));
            }

            // Start monitoring timer
            monitor = (MonitorPlugin) xwiki.getPlugin("monitor", context);
            if (monitor != null) {
                monitor.startRequest("", mapping.getName(), context.getURL());
            }
            if (monitor != null) {
                monitor.startTimer("request");
            }

            VelocityContext vcontext = null;
            // Prepare velocity context
            vcontext = XWikiVelocityRenderer.prepareContext(context);
            vcontext.put("spaceParser", new SpaceParser()); //help to format spaces
            try {
                vcontext.put("me", xwiki.getUser());
                if (!ajax) {
                    String fullName = xwiki.getDocumentName(request, context);
                    String docName = SpaceParser.getPage(fullName);

                    if (action.equals("edit") && !xwiki.exists(fullName, context) && (!docName.matches("[0-9,a-z,A-Z,_,\\-,\\s]+")
                            && !fullName.contains(Constants.USERS) && !fullName.contains(Constants.TEST_RUNS)
                            && !fullName.contains(Constants.PLANS))) {
                        context.put("custommessage", EscapeChars.forHTMLTag(docName));
                        vcontext.put("msg1", xwiki.getMessage("wrongpagenametitle", context));
                        vcontext.put("msg2", xwiki.getMessage("wrongpagename", context));
                        throw new XWikiException(0, XWikiException.ERROR_INCORRECT_PAGE_NAME, "");
                    }
                }
                // Prepare documents and put them in the context
                if (xwiki.prepareDocuments(request, context, vcontext) == false) {
                    return null;
                }

                // Let's handle the notification and make sure it never fails
                try {
                    xwiki.getNotificationManager().preverify(context.getDoc(), mapping.getName(), context);
                } catch (Throwable e) {
                    e.printStackTrace();
                }
                if (monitor != null) {
                    monitor.setWikiPage(context.getDoc().getFullName());
                }

                String renderResult = null;
                XWikiDocument doc = context.getDoc();
                //<--
                //IMA
                //if new is canceled show page doesn't exist
                /*
                if (doc.isNew() && ("cancel".equals(action)))
                {
                	String page = Utils.getPage(request, "docdoesnotexist");
                	Utils.parseTemplate(page, context);
                	return null;
                }
                */
                //-->

                if (action(context)) {
                    renderResult = render(context);
                }
                String wantedPage = Utils.getPage(request, "view");
                if (renderResult != null) {
                    if (!doc.isAccess() && "view".equals(action)) {
                        Utils.parseTemplate("NoAccess", context);
                    } else {
                        if (wantedPage.startsWith("xchecksession")) {
                            Utils.parseTemplate(wantedPage, !wantedPage.equals("direct"), context);
                            return null;
                        }
                        boolean isMakroPicker = request.getParameter("makroPicker") != null;
                        if (!isMakroPicker && doc.isNew() &&
                                (action.equals("view") || action.equals("delete") ||
                                        (action.equals("print") && (doc.getName().equalsIgnoreCase(Constants.DASHBOARD_PAGE) || Constants.USERS.equals(doc.getSpaceName())
                                                || Constants.TEST_RUNS.equals(doc.getSpaceName()) || Constants.PLANS.equals(doc.getSpaceName()))))) {
                            String name = doc.getName();
                            String space = doc.getSpaceName();
                            String project = doc.getProject();
                            String group = doc.getGroup();
                            String scope = OverviewPanel.getScope(group, project, space);
                            if (!OverviewPanel.hasPage(space, name, scope)) {
//	                            if ("Dashboard".equals(name)) {
//	                            	Utils.parseTemplate("dashboard", true, context);
//	                            	return null;
//	                            } else {
                                //--------- page doesn't exist - set content and redirect directly to edit -------------
                                if (BaselineServlet.getCurrentBaselineRevision() != null) {
                                    doc.setContent("The page does not exist in selected baseline.");
                                } else {
                                    String pageTitle = request.getParameter("pageTitle");
                                    String pageTitleUrlPart = "";
                                    if (pageTitle != null) {
                                        pageTitleUrlPart = "&pageTitle=" + Utils.encode(pageTitle, context);
                                    }
                                    String redirect = Utils.getRedirect("edit", context) + "?editor=wiki" + pageTitleUrlPart;
                                    doc.setContent("THIS PAGE HAS NO CONTENT YET.\n\nYOU CAN CREATE AND SAVE CONTENT NOW USING THIS EDITOR");
                                    sendRedirect(response, redirect);
                                    return null;
                                    //String page = Utils.getPage(request, "docdoesnotexist");
                                    //Utils.parseTemplate(page, context);
                                    //-->
                                    //	                            }
                                }
                            } else {
                                //-------- load page content from tempalte ----------------
                                doc.setIsTemplate(true);
                                XWikiDocument panelDoc = OverviewPanel.getPage(context, space, name, scope);
                                if (panelDoc != null) {
                                    doc.setContent(panelDoc.getContent());
                                    doc.setType(panelDoc.getType());
                                    doc.setAuthor(panelDoc.getAuthor());
                                    doc.setDate(panelDoc.getDate());
                                    doc.setCreationDate(panelDoc.getCreationDate());
                                    doc.setCreator(panelDoc.getCreator());
                                } else {
                                    doc.setContent("THE TEMPLATE CONTENT DOES NOT VALID.\n\nYOU CAN CREATE AND SAVE CONTENT NOW USING EDITOR");
                                }
                            }
                        } //if
                          //now it's a time to parse document and ouptut
                        wantedPage = Utils.getPage(request, renderResult);
                        Utils.parseTemplate(wantedPage, !wantedPage.equals("direct"), context);
                    }
                }
                return null;
            } catch (Throwable e) {
                if (!(e instanceof XWikiException)) {
                    e = new XWikiException(XWikiException.MODULE_XWIKI_APP, XWikiException.ERROR_XWIKI_UNKNOWN,
                            "Uncaught exception", e);
                }

                try {
                    XWikiException xex = (XWikiException) e;
                    if (xex.getCode() == XWikiException.ERROR_XWIKI_ACCESS_DENIED) {
                        Utils.parseTemplate("accessdenied", context);
                        return null;
                    } else if (xex.getCode() == XWikiException.ERROR_XWIKI_USER_INACTIVE) {
                        Utils.parseTemplate("userinactive", context);
                        return null;
                    } else if (xex.getCode() == XWikiException.ERROR_XWIKI_APP_ATTACHMENT_NOT_FOUND) {
                        context.put("message", "attachmentdoesnotexist");
                        Utils.parseTemplate("exception", context);
                        return null;
                    } else if ((xex.getCode() == XWikiException.ERROR_XWIKI_STORE_RCS_SAVING_FILE ||
                            xex.getCode() == XWikiException.ERROR_XWIKI_STORE_RCS_SAVING_ATTACHMENT ||
                            xex.getCode() == XWikiException.ERROR_XWIKI_STORE_RCS_SAVING_COMMENT) && isAuthException(xex.getException())) {
                        Utils.parseTemplate("NoAccess", context);
                        context.getDoc().setAccess(false);
                        return null;
                    } else if ((xex.getCode() == XWikiException.ERROR_XWIKI_APP_FILE_EXCEPTION_MAXSIZE)) {
                        ((VelocityContext) context.get("vcontext")).put("attLimit", System.getProperty("maxAttachmentSize", "200000000"));
                        Utils.parseTemplate("AttachTooLong", context);
                        return null;
                    } else if ((xex.getCode() == XWikiException.ERROR_XWIKI_APP_JAVA_HEAP_SPACE)) {
                        if (((String) context.get("message")).equalsIgnoreCase("javaheapspace")) {
                            Utils.parseTemplate("AttachTooLongView", context);
                        } else {
                            Utils.parseTemplate("AttachTooLong", context);
                        }
                        return null;

                    } else if (xex.getCode() == XWikiException.ERROR_XWIKI_EXPORT_PDF_FOP_FAILED) {
                        context.put("message", xwiki.parseExceptionMsg(xex.getException().getMessage() != null ? xex.getException().getMessage() : xex.getException().toString()));
                        context.put("custommessage", XHTMLValidator.converMessageText(xex.getSaxLine()));
                        Utils.parseTemplate("pdferror", context);
                        return null;

                    } else if (xex.getCode() == XWikiException.ERROR_XWIKI_APP_PROJECT_DOES_NOT_EXIST) {
                        Utils.parseTemplate("projectdntexist", context);
                        return null;
                    } else if (xex.getCode() == XWikiException.ERROR_DOC_XML_PARSING) {
                        context.put("message", xwiki.parseExceptionMsg(xex.getException().getMessage()));
                        context.put("custommessage", XHTMLValidator.converMessageText(xex.getSaxLine()));
                        Utils.parseTemplate("validationerror", context);
                        return null;
                    } else if (xex.getCode() == XWikiException.ERROR_CONFLICT_ON_SAVE) {
                        context.put("message", xex.getMessage());
                        Utils.parseTemplate("conflictonsave", context);
                        return null;
                    } else if (xex.getCode() == XWikiException.ERROR_INCORRECT_PAGE_NAME) {
                        Utils.parseTemplate("wrongname", context);
                        return null;
                    }
                    vcontext.put("exp", e);
                    Log log = LogFactory.getLog(XWikiAction.class);
                    if (log.isWarnEnabled()) {
                        log.warn("Uncaught exception: " + e.getMessage(), e);
                    }
                    Utils.parseTemplate(Utils.getPage(request, "exception"), context);
                    return null;
                } catch (Exception e2) {
                    // I hope this never happens
                    e.printStackTrace();
                    e2.printStackTrace();
                    return null;
                }
            } finally {

                // Let's make sure we have flushed content and closed
                try {
                    response.getWriter().flush();
                } catch (Throwable e) {
                }

                if (monitor != null) {
                    monitor.endTimer("request");
                }

                if (monitor != null) {
                    monitor.startTimer("notify");
                }

                // Let's handle the notification and make sure it never fails
                try {
                    if (context.getDoc() != null) {
                        xwiki.getNotificationManager().verify(context.getDoc(), mapping.getName(), context);
                    }

                } catch (Throwable e) {
                    e.printStackTrace();
                }

                if (monitor != null) {
                    monitor.endTimer("notify");
                }

                // Make sure we cleanup database connections
                // There could be cases where we have some
                if ((context != null) && (xwiki != null)) {
                    xwiki.getStore().cleanUp(context);
                }
            }
        } finally {
            // End request
            try {
                if (monitor != null) {
                    monitor.endRequest();
                }
                if (fileupload != null) {
                    fileupload.cleanFileList(context);
                }

                if (!txExisted && (txService != null) && txService.txExists()) {
                    Log log = LogFactory.getLog(XWikiAction.class);
                    if (log.isWarnEnabled()) {
                        log.warn("Transaction leaked from Wiki page will be rolled back");
                    }
                    txService.rollbackTx();
                }

                MDC.remove("url");

            } finally {
                ThreadNDC.pop();
            }
        }
    }

    private boolean isAuthException(@NotNull Throwable t) {
        DriverException cause = (DriverException) ExceptionUtils.findException(t, DriverException.class);
        return cause != null && cause.getErrorCode() == DriverException.ErrorCode.AUTHORIZATION_FAILED;
    }

    public String getRealPath(String path) {
        return servlet.getServletContext().getRealPath(path);
    }

    // hook
    public boolean action(XWikiContext context) throws XWikiException {
        return true;
    }

    // hook
    public String render(XWikiContext<String, java.lang.Object> context) throws XWikiException {
        return null;
    }

    protected void handleRevision(XWikiContext<String, java.lang.Object> context) throws XWikiException {
        String rev = context.getRequest().getParameter("rev");

        try {
            String url = context.getURL().toString();
            if (context.getURL().toString().contains("/WebSearch") || context.getURL().toString().contains("/SpaceIndex")) {
                url = context.getURL().toString();
            } else if (context.getAction().equals("print") || context.getAction().equals("pdf") || !context.getRequest().getHeader("user-agent").contains("Firefox")) {
                URL baseUrl = Urls.getBaseUrl(context.getURL());
                url = baseUrl.toString() + "/polarion/wiki/bin" + context.getRequest().getPathInfo() + "?" + context.getRequest().getQueryString(); //$NON-NLS-1$ //$NON-NLS-2$
            } else {
                url = context.getRequest().getRequestURL().toString();
                if (context.getURL().getQuery() != null) {
                    url += "?" + context.getURL().getQuery();
                }
            }
            if (BaselineHelper.getBaselineFromURI(url) == null) {
                url = BaselineHelper.injectBaselineURLPart(BaselineServlet.getCurrentBaselineRevision(), url);
            }
            context.setURL(new URL(url));
        } catch (MalformedURLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        String origName = context.getRequest().getParameter("origDocName");
        String origSpace = context.getRequest().getParameter("origDocSpace");
        if (rev != null) {
            context.put("rev", rev);
            XWikiDocument doc = (XWikiDocument) context.get("doc");
//			if(!context.getAction().equals("pdf") && !context.getAction().equals("print")){
//				doc.setName(URLDecoder.decode(context.getRequest().getRequestURL().substring(context.getRequest().getRequestURL().lastIndexOf("/")+1)));
//			}
//			if(context.getAction().equals("pdf")){
//				doc.setName(URLDecoder.decode(doc.getName()));
//			}
            XWikiDocument tdoc = (XWikiDocument) context.get("tdoc");
            XWikiDocument rdoc = context.getWiki().getDocument(doc, rev, context);
            XWikiDocument rtdoc = context.getWiki().getDocument(tdoc, rev, context);
            context.put("tdoc", rtdoc);

            XWikiDocument origdoc = (XWikiDocument) rdoc.clone();
            if (origName != null && !origName.equalsIgnoreCase("")) {
                origdoc.setName(origName);
            }

            if (origSpace != null && !origSpace.equalsIgnoreCase("")) {
                origdoc.setSpace(origSpace);
            }

            context.put("odoc", origdoc);
            context.put("cdoc", rdoc);
            context.put("doc", rdoc);
            VelocityContext vcontext = (VelocityContext) context.get("vcontext");
            vcontext.put("doc", rdoc.newDocument(context));
            vcontext.put("cdoc", vcontext.get("doc"));
            vcontext.put("tdoc", rtdoc.newDocument(context));
            vcontext.put("odoc", origdoc.newDocument(context));
            appendQueryString(vcontext, context);
        }
    }

    private void appendQueryString(VelocityContext vcontext, XWikiContext<String, Object> context) {
        String query = context.getURL().getQuery();
        if (ObjectUtils.emptyString(query)) {
            return;
        }
        String[] params = query.split("[&]");
        if (params != null) {
            for (String param : params) {
                String[] parts = param.split("[=]");
                if (parts.length == 2) {
                    vcontext.put(parts[0].trim(), parts[1]);
                }
            }
        }
    }

    protected void sendRedirect(XWikiResponse response, String page) throws XWikiException {
        try {
            //response.setCharacterEncoding("UTF-8");
            if (page != null) {
                response.sendRedirect(page);
            }
        } catch (IOException e) {
            Object[] args = { page };
            throw new XWikiException(XWikiException.MODULE_XWIKI_APP,
                    XWikiException.ERROR_XWIKI_APP_REDIRECT_EXCEPTION,
                    "Exception while sending redirect to page {0}", e, args);
        }
    }
}