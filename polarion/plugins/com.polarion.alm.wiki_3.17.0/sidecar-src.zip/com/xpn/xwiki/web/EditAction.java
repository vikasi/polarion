/*
 * Copyright 2006, XpertNet SARL, and individual contributors as indicated
 * by the contributors.txt.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 * @author namphunghai
 * @author torcq
 * @author sdumitriu
 */
package com.xpn.xwiki.web;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.velocity.VelocityContext;

import com.polarion.platform.persistence.internal.PersistencePermission;
import com.polarion.subterra.base.location.ILocation;
import com.polarion.subterra.base.location.Location;
import com.polarion.wiki.svn.ISvnProvider;
import com.polarion.wiki.svn.PolarionSvnProvider;
import com.polarion.wiki.svn.WikiSpacesCache;
import com.polarion.wiki.svn.WikiSvnBaseStore;
import com.polarion.wiki.util.Constants;
import com.polarion.wiki.util.OverviewPanel;
import com.polarion.wiki.util.RequestParser;
import com.polarion.wiki.web.XWikiPolarion;
import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.doc.XWikiLock;
import com.xpn.xwiki.user.api.XWikiRightService;

public class EditAction extends XWikiAction
{

    private static final Log log = LogFactory.getLog(EditAction.class);
    private static PolarionSvnProvider svn = new PolarionSvnProvider();

    @Override
    public String render(XWikiContext<String, java.lang.Object> context) throws XWikiException
    {
        XWikiRequest request = context.getRequest();
        String content = request.getParameter("content");
        String title = request.getParameter("title");
        String template = request.getParameter("tpl");
        //String copySpace = request.getParameter("cpy");
        String create = request.getParameter("create");
        String pageTitle = request.getParameter("pageTitle");
        XWikiDocument doc = context.getDoc();

        String type = request.getParameter("doctype");

        if (doc.isNew()) {

            boolean hasCreatePermission;
            XWikiRightService rightService = context.getWiki().getRightService();
            if (Constants.USERS.equals(doc.getSpaceName())) {
                hasCreatePermission = rightService.hasUserDashboardPermission(doc.getName(), PersistencePermission.ACTION_CREATE, doc.getProject());
            } else if (Constants.TEST_RUNS.equals(doc.getSpaceName())) {
                hasCreatePermission = rightService.hasTestRunPermission(doc.getName(), PersistencePermission.ACTION_CREATE, doc.getProject());
            } else if (Constants.PLANS.equals(doc.getSpaceName())) {
                hasCreatePermission = rightService.hasPlanPermission(doc.getName(), PersistencePermission.ACTION_CREATE, doc.getProject());
            } else {
                hasCreatePermission = rightService.hasPermission(doc.getSpaceName(), doc.getName(), PersistencePermission.ACTION_CREATE, doc.getProject());
            }
            if (!hasCreatePermission) {
                return "accessdenied"; //$NON-NLS-1$
            }

            if (type != null && !type.equalsIgnoreCase("")) {
                doc.setType(type);
            }
            if (pageTitle != null && !pageTitle.equalsIgnoreCase("")) {
                doc.setPageTitle(pageTitle);
            }
            Pattern correctName = Pattern.compile("[0-9,a-z,A-Z,_,\\-,\\s]+");
            String project = doc.getProject();
            String space = doc.getSpaceName();
            String name = doc.getName();
            String group = doc.getGroup();
            String scope = OverviewPanel.getScope(group, project, space);
            if (OverviewPanel.hasPage(space, name, scope))
            {
                //doc.setIsTemplate(true);
                XWikiDocument panelDoc = OverviewPanel.getPage(context, space, name, scope);
                if (panelDoc != null)
                {
                    doc.setContent(panelDoc.getContent());
                    doc.setType(panelDoc.getType());
                    doc.setAuthor(panelDoc.getAuthor());
                    doc.setDate(panelDoc.getDate());
                    doc.setCreationDate(panelDoc.getCreationDate());
                    doc.setCreator(panelDoc.getCreator());
                    doc.setIsTemplate(true);
                } else {
                    doc.setContent("");
                }
            }

            Matcher spaceMatcher = correctName.matcher(space);
            Matcher pageMatcer = correctName.matcher(name);
            if (!pageMatcer.matches() && !Constants.USERS.equals(space))
            {
                context.put("custommessage", name);
                return "wrongname";
            }

            if (!spaceMatcher.matches() && !Constants.USERS.equals(space))
            {
                context.put("custommessage", space);
                return "wrongname";
            }

            if (create == null) {
                WikiSpacesCache spacesCache = WikiSpacesCache.getInstance();
                String sLoc = svn.getProjectPath(project) + "/" + XWikiPolarion._WIKI + "/" + space;
                ILocation loc = Location.getLocation(sLoc);
                if (spacesCache.getSpace(loc) == null) {
                    return "spacenotexists";
                }
            }
        }

        XWiki xwiki = context.getWiki();
        //XWikiDocument tmpDoc = null;
        //List attachmentList = Collections.EMPTY_LIST;
        log.debug("EditAction for: " + doc.getFullName() + " - " + template);
        String comment_edit = request.getParameter("XWiki.XWikiComments_comment");
        String isEdit = request.getParameter("isEdit");

        doc.setIsEdit(isEdit);
        doc.setComment(comment_edit);

        /* not for Release 3.0
        if (template != null)
        {
        	tmpDoc = xwiki.getDocument(template, context);
        	attachmentList = tmpDoc.getAttachmentList();

        	for (int i=0; i<attachmentList.size(); i++)
        	{	
        		String filename = ((XWikiAttachment)attachmentList.get(i)).getFilename(); 
        		XWikiAttachment attachment = tmpDoc.getAttachment(filename);
        		
        		attachment.setContent(attachment.getContent(context));

        		if (attachment != null)
        			attachment.setDoc(doc);
        		doc.getAttachmentList().add(attachment);
        	}
        	
        	XWikiAttachment attachment = new XWikiAttachment();
        	attachment.setDoc(doc);
        	
            doc.clonexWikiObjects(tmpDoc);
            doc.setContent(tmpDoc.getContent());
        	
        	log.error("Using as template: " + tmpDoc.getFullName());
        }
        else if (copySpace != null)
        {
        	log.error("Copy space form: " + copySpace);
        	((WikiSvnStore)xwiki.getNotCacheStore()).copySpace(copySpace,doc.getSpace(), context);
        	
        	XWikiDocument doc1 = ((WikiSvnStore)xwiki.getNotCacheStore()).loadXWikiDoc(doc, context);
        	attachmentList = doc1.getAttachmentList();

        	for (int i=0; i<attachmentList.size(); i++)
        	{	
        		String filename = ((XWikiAttachment)attachmentList.get(i)).getFilename(); 
        		XWikiAttachment attachment = doc1.getAttachment(filename);
        		
        		attachment.setContent(attachment.getContent(context));

        		if (attachment != null)
        			attachment.setDoc(doc);
        		doc.getAttachmentList().add(attachment);
        	}
        	
        	XWikiAttachment attachment = new XWikiAttachment();
        	attachment.setDoc(doc);
        	
            doc.clonexWikiObjects(doc1);
            doc.setContent(doc1.getContent());
        	
        }
        */

        XWikiForm form = context.getForm();
        VelocityContext vcontext = (VelocityContext) context.get("vcontext");

        // Check for edit section
        String sectionContent = "";
        int sectionNumber = 0;
        if (request.getParameter("section") != null && xwiki.hasSectionEdit(context)) {
            sectionNumber = Integer.parseInt(request.getParameter("section"));
            sectionContent = doc.getContentOfSection(sectionNumber);
        }
        vcontext.put("sectionNumber", new Integer(sectionNumber));

        synchronized (doc) {
            XWikiDocument tdoc = (XWikiDocument) context.get("tdoc");
            EditForm peform = (EditForm) form;
            String parent = peform.getParent();
            if (parent != null) {
                doc.setParent(parent);
            }
            String creator = peform.getCreator();
            if (creator != null) {
                doc.setCreator(creator);
            }
            String defaultTemplate = peform.getDefaultTemplate();
            if (defaultTemplate != null) {
                doc.setDefaultTemplate(defaultTemplate);
            }
            String defaultLanguage = peform.getDefaultLanguage();
            if ((defaultLanguage != null) && !defaultLanguage.equals("")) {
                doc.setDefaultLanguage(defaultLanguage);
            }
            if (doc.getDefaultLanguage().equals("")) {
                doc.setDefaultLanguage(context.getWiki().getLanguagePreference(context));
            }

            String language = context.getWiki().getLanguagePreference(context);
            String languagefromrequest = context.getRequest().getParameter("language");
            String languagetoedit = ((languagefromrequest == null) || (languagefromrequest.equals(""))) ?
                    language : languagefromrequest;

            if ((languagetoedit == null) || (languagetoedit.equals("default"))) {
                languagetoedit = "";
            }
            if (doc.isNew() || (doc.getDefaultLanguage().equals(languagetoedit))) {
                languagetoedit = "";
            }

//            if (languagetoedit.equals("")) {

            // In this case the created document is going to be the default document
            tdoc = doc;
            context.put("tdoc", doc);
            vcontext.put("tdoc", vcontext.get("doc"));
            if (doc.isNew()) {
                doc.setDefaultLanguage(language);
                doc.setLanguage("");
            }
//            } else {
//				// If the translated doc object is the same as the doc object
//                // this means the translated doc did not exists so we need to create it
//                if ((tdoc==doc)&&context.getWiki().isMultiLingual(context)) {
//					tdoc = new XWikiDocument(doc.getSpace(), doc.getName());
//					tdoc.setLanguage(languagetoedit);
//					tdoc.setContent(doc.getContent());
//					tdoc.setAuthor(context.getUser());
//					tdoc.setStore(doc.getStore());
//					context.put("tdoc", tdoc);
//					vcontext.put("tdoc", tdoc.newDocument(context));
//				}
//			}

            XWikiDocument tdoc2 = (XWikiDocument) tdoc.clone();
            if (content != null) {
                tdoc2.setContent(content);
                tdoc2.setTitle(title);
            }

            if (sectionContent != null && !sectionContent.equals("")) {
                if (content != null) {
                    tdoc2.setContent(content);
                } else {
                    tdoc2.setContent(sectionContent);
                }
                if (title != null) {
                    tdoc2.setTitle(doc.getDocumentSection(sectionNumber).getSectionTitle());
                } else {
                    tdoc2.setTitle(title);
                }
            }

            context.put("tdoc", tdoc2);
            vcontext.put("tdoc", tdoc2.newDocument(context));

            try {
                tdoc2.readFromTemplate(peform, context);
            } catch (XWikiException e) {
                if (e.getCode() == XWikiException.ERROR_XWIKI_APP_DOCUMENT_NOT_EMPTY) {
                    context.put("exception", e);
                    return "docalreadyexists";
                }
            }

            /* Setup a lock */
            try {
                XWikiLock lock = tdoc.getLock(context);
                if ((lock == null) || (lock.getUserName().equals(context.getUser())) || (peform.isLockForce())) {
                    tdoc.setLock(context.getUser(), context);
                }
            } catch (Exception e) {
                e.printStackTrace();
                // Lock should never make XWiki fail
                // But we should log any related information
                log.error("Exception while setting up lock", e);
            }
        }

        if (!RequestParser.isDocumentPage(doc.getSpace()))
        {
            context.put("custommessage", doc.getSpace());
            return "wrongspace";
        }

        if (create == null) {
            create = "0";
        }
        if ((doc.isNew() && doc.getName().equalsIgnoreCase("Home")) || create.equalsIgnoreCase("1"))
        {

            ISvnProvider svnProvider = ((WikiSvnBaseStore) context.getDoc().getStore()).getSvnProvider();
            try
            {
                svnProvider.createSpace(doc);
            } catch (Exception e)
            {
                // if can't create cpace you'll see error page after save doc
            }

        }
        return "edit";
    }
}
