/*
 * Copyright 2006, XpertNet SARL, and individual contributors as indicated
 * by the contributors.txt.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 * @author sdumitriu
 */
package com.xpn.xwiki.web;

import java.util.Vector;

import javax.servlet.ServletOutputStream;

import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.objects.BaseObject;

public class ObjectRemoveAction extends XWikiAction {
    private static final String STR_DEL_OBJ = "core.comment.deleteObject";

    @Override
    public boolean action(XWikiContext context) throws XWikiException {
        XWiki xwiki = context.getWiki();
        XWikiRequest request = context.getRequest();
        XWikiResponse response = context.getResponse();
        XWikiDocument doc = context.getDoc();
        XWikiForm form = context.getForm();

        String content = request.getParameter("content");

        XWikiDocument olddoc = (XWikiDocument) doc.clone();
        String className = ((ObjectRemoveForm) form).getClassName();
        int classId = ((ObjectRemoveForm) form).getClassId();
        Vector objects = doc.getObjects(className);
        BaseObject object = (BaseObject) objects.get(classId);
        // Remove it from the object list
        objects.set(classId, null);
        doc.addObjectsToRemove(object);
        doc.setAuthor(context.getUser());
        String sCom = context.getMessageTool().get(STR_DEL_OBJ);
        if (STR_DEL_OBJ.equals(sCom)) {
            sCom = "";
        }
        xwiki.saveDocument(doc, olddoc, sCom, context);

        if (content == null || content.equalsIgnoreCase(""))
        {
            // forward to edit
            String redirect = Utils.getRedirect("edit", context);
            sendRedirect(response, redirect);
        }
        else
        {
            String redirect = Utils.getRedirect("edit", context);
            redirectToEdit(response, redirect, content);
        }
        return false;

    }

    public void redirectToEdit(XWikiResponse response, String page, String contentEdit)
    {
        try
        {
            String cont = "<html><body onload='javascript:test.submit();'><form method=\"post\" id=\"test\" name=\"test\" action=\"" + page + "\"><input type=\"hidden\" name=\"content\" value=\"" + contentEdit
                    + "\" /></form></body></html>";

            response.setContentType("text/html");
            response.setContentLength(cont.length());

            byte[] output = cont.getBytes();
            ServletOutputStream ouputStream;
            ouputStream = response.getOutputStream();
            ouputStream.write(output);
            ouputStream.flush();
            ouputStream.close();
        } catch (Exception r)
        {
            try
            {
                response.sendRedirect(page);
            } catch (Exception e) {
            }
        }

    }
}
