package com.xpn.xwiki.web;

import java.io.File;

import org.apache.velocity.VelocityContext;

import com.polarion.wiki.util.SpaceParser;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.pdf.impl.PdfExportImpl;

public class PdfPreviewDialogAction extends XWikiAction {
    @Override
    public String render(XWikiContext context) throws XWikiException {
        VelocityContext vcontext = (VelocityContext) context.get("vcontext");
        Integer pages = null;

        XWikiURLFactory urlf = context.getWiki().getURLFactoryService().createURLFactory(XWikiContext.MODE_PDF, context);
        File dir = (File) context.getEngineContext().getAttribute("javax.servlet.context.tempdir");
        context.setURLFactory(urlf);
        PdfExportImpl pdfexport = new PdfExportImpl(context);
        XWikiDocument doc = context.getDoc();
        handleRevision(context);

//        Double w = new Double(pdfexport.width) / 0.03;
//        Double h = new Double(pdfexport.height) / 0.03;
//        Double width = (double)Math.round(w) / 100;
//        Double height = (double)Math.round(h) / 100;
//        pdfexport.width = width.toString();
//        pdfexport.height = height.toString();

        try {
            String filename = doc.getProject() +
                    (SpaceParser.getSpace(doc.getSpace()).startsWith("_") ? "" : "_") +
                    SpaceParser.getSpace(doc.getSpace()) +
                    "_" + doc.getName() +
                    //        		"_" + pdfexport.height +
//        		"_" + pdfexport.width +
                    "_1.png";
            File tmpDir = new File(dir, pdfexport.tempDirName);
            if (!(new File(tmpDir, filename).exists())) {
                pages = null;
            } else {
                //TODO not very nice, make it better
                String fileNameBase = filename.substring(0, filename.length() - 5);
                pages = 1;
                while (true) {
                    int i = pages + 1;
                    File f = new File(tmpDir, fileNameBase + i + ".png");
                    if (f.exists()) {
                        pages++;
                    } else {
                        break;
                    }
                }
            }

//        	pdfexport.exportToPDF(doc, null, context);
        } catch (Exception e) {
            throw new XWikiException(XWikiException.MODULE_XWIKI_CONTENT,
                    XWikiException.ERROR_DOC_XML_PARSING,
                    "Exception validation.", e, null, ((XWikiException) e).getSaxLine());
        }

        vcontext.put("pages", (pages == null) ? 0 : pages);
//		vcontext.put("width", pdfexport.width);
//		vcontext.put("height", pdfexport.height);
//		vcontext.put("frameWidth", new Double(pdfexport.width) * 96 + 50);
//		vcontext.put("frameHeight", new Double(pdfexport.height) * 96 + 50);
        vcontext.put("tempDirName", pdfexport.tempDirName);
        vcontext.put("previewLink", pdfexport.link.replace("pdfpreviewdialogaction", "pdfpreviewaction"));
        return "openpdfpreviewdialog";
    }

}
