/*
 * Copyright 2006, XpertNet SARL, and individual contributors as indicated
 * by the contributors.txt.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 * @author sdumitriu
 */
package com.xpn.xwiki.web;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.sun.jndi.toolkit.url.UrlUtil;
import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.doc.XWikiAttachment;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.notify.XWikiDocChangeNotificationInterface;

public class RollbackAction extends XWikiAction {
    @Override
    public boolean action(XWikiContext context) throws XWikiException {
        XWiki xwiki = context.getWiki();
        XWikiResponse response = context.getResponse();
        XWikiDocument doc = context.getDoc();
        RollbackForm form = (RollbackForm) context.getForm();

        String confirm = form.getConfirm();
        String rev = form.getRev();
        String language = form.getLanguage();
        XWikiDocument tdoc;

        if ((confirm == null) || (!confirm.equals("1"))) {
            return true;
        }

        if ((language == null) || (language.equals("")) || (language.equals("default")) || (language.equals(doc.getDefaultLanguage()))) {
            // Need to save parent and defaultLanguage if they have changed
            tdoc = doc;
        } else {
            tdoc = doc.getTranslatedDocument(language, context);
            if (tdoc == doc) {
                tdoc = new XWikiDocument(doc.getSpace(), doc.getName());
                tdoc.setLanguage(language);
            }
            tdoc.setTranslation(1);
        }

        XWikiDocument olddoc = (XWikiDocument) tdoc.clone();
        XWikiDocument newdoc = xwiki.getDocument(tdoc, rev, context);

        String username = context.getUser();
        newdoc.setAuthor(username);
        newdoc.setRCSVersion(tdoc.getRCSVersion());
        newdoc.setVersion(tdoc.getVersion());
        newdoc.setContentDirty(true);
        //<<--PBO
        newdoc.setDate(newdoc.getDate());
        newdoc.setCreationDate(newdoc.getCreationDate());
        //-->>
        List<String> params = new ArrayList<String>();
        params.add(rev);

        List list = newdoc.getAttachmentList();
        Iterator itr = list.iterator();
        while (itr.hasNext())
        {
            XWikiAttachment att = (XWikiAttachment) itr.next();
            att.setDoc(newdoc);
        }

        xwiki.rollbackXWikiDoc(newdoc, context);
        context.getWiki().getNotificationManager().verify(doc, olddoc,
                XWikiDocChangeNotificationInterface.EVENT_CHANGE, context);

        doc.setAttachmentList(newdoc.getAttachmentList());
        doc.setCreator(newdoc.getCreator());
        doc.setCreationDate(newdoc.getCreationDate());
        doc.setDate(newdoc.getDate());
        doc.setAuthor(newdoc.getAuthor());

        // forward to view
        String redirect = Utils.getRedirect("view", context);
        try
        {
            sendRedirect(response, UrlUtil.encode(redirect, "UTF-8"));
        } catch (Exception e)
        {

        }

        return false;
    }

    @Override
    public String render(XWikiContext<String, java.lang.Object> context) throws XWikiException {
        handleRevision(context);
        return "rollback";
    }
}
