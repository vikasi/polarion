package com.xpn.xwiki.store;

/**
 * 
 * @author VKO
 * Class to store cache for ReIndexPluginApi:
 * get cache here when context is unavailable during indexing
 */

public class XWikiCacheStoreProvider
{
    private static XWikiCacheStore cacheStore;

    public XWikiCacheStoreProvider(XWikiCacheStore cacheStore) {
        XWikiCacheStoreProvider.cacheStore = cacheStore;
    }

    public static XWikiCacheStore getCacheStore() {
        return XWikiCacheStoreProvider.cacheStore;
    }
}
