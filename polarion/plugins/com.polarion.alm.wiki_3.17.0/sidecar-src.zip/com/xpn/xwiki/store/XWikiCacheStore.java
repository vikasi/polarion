/*
 * Copyright 2006, XpertNet SARL, and individual contributors as indicated
 * by the contributors.txt.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 * @author ludovic
 * @author sdumitriu
 * @author thomas
 */

package com.xpn.xwiki.store;

import java.io.InputStream;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.polarion.portal.internal.shared.navigation.BaselineHelper;
import com.polarion.wiki.svn.bo.DocumentSvnInfo;
import com.polarion.wiki.svn.bo.SpaceSvnInfo;
import com.polarion.wiki.util.Constants;
import com.polarion.wiki.util.OverviewPanel;
import com.polarion.wiki.util.RequestParser;
import com.polarion.wiki.web.BaselineServlet;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.cache.api.XWikiCache;
import com.xpn.xwiki.cache.api.XWikiCacheNeedsRefreshException;
import com.xpn.xwiki.cache.api.XWikiCacheService;
import com.xpn.xwiki.doc.XWikiAttachment;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.doc.XWikiLock;
import com.xpn.xwiki.objects.classes.BaseClass;

/**
 * A proxy store implementation that caches Documents when they are first fetched and subsequently return them from
 * a cache. It delegates all write and search operations to an underlying store without doing any caching on them.
 * 
 * @version $Id: $
 */
public class XWikiCacheStore implements XWikiCacheStoreInterface {

    private static final Log log = LogFactory.getLog(XWikiCacheStore.class);

    private XWikiStoreInterface store;
    private XWikiCache cache;
    private XWikiCache pageExistCache;
    private XWikiContext context;
    private int cacheCapacity = 100;
    private int pageExistCacheCapacity = 10000;

    public XWikiCacheStore(XWikiStoreInterface store, XWikiContext context) throws XWikiException {
        setStore(store);
        initCache(context);
        this.context = context;
        new XWikiCacheStoreProvider(this);
    }

    public synchronized void initCache(XWikiContext context) throws XWikiException {
        if (cache == null || pageExistCache == null) {
            try {
                String capacity = context.getWiki().Param("xwiki.store.cache.capacity");
                if (capacity != null) {
                    cacheCapacity = Integer.parseInt(capacity);
                }
            } catch (Exception e) {
            }
            try {
                String capacity = context.getWiki().Param("xwiki.store.cache.pageexistcapacity");
                if (capacity != null) {
                    pageExistCacheCapacity = Integer.parseInt(capacity);
                }
            } catch (Exception e) {
            }
            initCache(cacheCapacity, pageExistCacheCapacity, context);
        }
    }

    @Override
    public void initCache(int capacity, int pageExistCacheCapacity, XWikiContext context) throws XWikiException {
        XWikiCacheService cacheService = context.getWiki().getCacheService();
        setCache(cacheService.newCache("xwiki.store.pagecache", capacity));
        setPageExistCache(cacheService.newCache("xwiki.store.pageexistcache", pageExistCacheCapacity));
    }

    @Override
    public XWikiStoreInterface getStore() {
        return store;
    }

    @Override
    public void setStore(XWikiStoreInterface store) {
        this.store = store;
    }

    @Override
    public void saveXWikiDoc(XWikiDocument doc, XWikiContext context) throws XWikiException {
        saveXWikiDoc(doc, context, true);
    }

    @Override
    public void saveXWikiDoc(XWikiDocument doc, XWikiContext context, boolean bTransaction) throws XWikiException {

        // <-- DMA
        try
        {

            if (doc.isNewTitle())
            {
                /*
                deleteXWikiDoc(doc, context);
                doc.setName(doc.getTitle());

                doc.setNewTitle(false);
                 */
                doc.rename(doc.getSpace() + "." + doc.getTitle(), context);

                doc.setNewTitle(false);
            }

        } catch (Exception e)
        {
            log.error("Exception while rename document: " + e.getMessage());
        }
        // -->

        String key = getKey(doc, context);
        synchronized (key) {
            store.saveXWikiDoc(doc, context, bTransaction);
            doc.setStore(store);
            // Make sure cache is initialized
            initCache(context);

            // We need to flush so that caches
            // on the cluster are informed about the change
            getCache().flushEntry(key);
            getCache().putInCache(key, doc);
            getPageExistCache().flushEntry(key);
            getPageExistCache().putInCache(key, new Boolean(true));
        }
    }

    @Override
    public void saveXWikiDocPart(XWikiDocument doc, XWikiContext context, boolean contOrComm) throws XWikiException {
        String key = getKey(doc, context);
        synchronized (key) {

            try
            {
                log.debug("Before saving doc");
                RequestParser.decodeName(doc);
                store.saveXWikiDocPart(doc, context, contOrComm);
            } catch (XWikiException e)
            {
                doc.setCachedContentValid(false);
                throw e;
            } finally
            {
                log.debug("Before writing doc in cache");
                doc.setStore(store);
                // Make sure cache is initialized
                initCache(context);

                // We need to flush so that caches
                // on the cluster are informed about the change
                getCache().flushEntry(key);
                getCache().putInCache(key, doc);
                getPageExistCache().flushEntry(key);
                getPageExistCache().putInCache(key, new Boolean(true));
                log.debug("After cache write");

            }
        }
    }

    @Override
    public void flushCache() {
        if (cache != null) {
            cache.flushAll();
            cache = null;
        }
        if (pageExistCache != null) {
            pageExistCache.flushAll();
            pageExistCache = null;
        }
    }

    public String getKey(XWikiDocument doc, XWikiContext context) {
        return getKey(doc.getFullName(), doc.getLanguage(), context);
    }

    public String getKey(String fullName, String language, XWikiContext context) {
        String db = context.getDatabase();
        if (db == null) {
            db = "";
        }
        String key = fullName;

//        TODO language localization (because in cache is stroed in diferend key the same document)
//        TODO how remove from cache all trasnlated documents...
//        if ("".equals(language))
//			return key;
//		else
//			return key + ":" + language;
        return key;
    }

    @Override
    @SuppressWarnings({ "unchecked", "nls" })
    public XWikiDocument loadXWikiDoc(XWikiDocument doc, XWikiContext context) throws XWikiException {
        String baselinePrefix = BaselineHelper.getBaselineURLPart(BaselineServlet.getCurrentBaselineRevision(), false, true);
        String revision = (String) context.get("revision");
        if (revision != null) {
            baselinePrefix = "baseline/" + revision + "/";
        }
        String key = getKey(doc, context);
        String validKey = baselinePrefix + getValidKey(key, doc.getSpaceName());
        if (log.isDebugEnabled()) {
            log.debug("Cache: begin for doc " + validKey + " in cache");
        }

        initCache(context);
        XWikiDocument loadedDoc;
        synchronized (this) {
            try {
                RequestParser.decodeName(doc);

                if (log.isDebugEnabled()) {
                    log.debug("Cache: Trying to get doc " + validKey + " from cache");
                }

                loadedDoc = (XWikiDocument) getCache().getFromCache(validKey);
                if (loadedDoc == null) {
                    throw new XWikiCacheNeedsRefreshException();
                }
                // to ensure that user without write rights will not see cached content after save
                if (!loadedDoc.isCachedContentValid() && context.getAction().equals("view")) {
                    loadedDoc.setCachedContentValid(true);
                    throw new XWikiCacheNeedsRefreshException();
                }

                //this information should not be cached!
                // (in case user dont have right - set to false - cached and then it is loaded by user which have rights but from cache --bad)
                //so set it to true always (security layer will handle it)
                loadedDoc.setAccess(true);
                loadedDoc.setFromCache(true);
                if (log.isDebugEnabled()) {
                    log.debug("Cache: got doc " + validKey + " from cache");
                }
            } catch (XWikiCacheNeedsRefreshException e)
            {
                //getCache().cancelUpdate(key);
                boolean cacheResultLoad = false;
                try {
                    if (log.isDebugEnabled()) {
                        log.debug("Cache: Trying to get doc " + validKey + " for real");
                    }
                    if (revision != null && !"".equals(revision)) {
                        loadedDoc = store.loadXWikiDocByRevision(doc, revision, context);
                    } else {
                        loadedDoc = store.loadXWikiDoc(doc, context);
                    }
                    loadedDoc.setStore(store);
                    doc.setNew(loadedDoc.isNew());
                    cacheResultLoad = true;
                    if (log.isDebugEnabled()) {
                        log.debug("Cache: Got doc " + validKey + " for real");
                    }
                } catch (XWikiException xwikiexception) {
                    if (log.isDebugEnabled()) {
                        log.debug("Cache: exception while getting doc " + validKey + " for real");
                    }
                    getCache().cancelUpdate(validKey);
                    throw xwikiexception;
                } finally {
                    if (!cacheResultLoad) {
                        getCache().cancelUpdate(validKey);
                    }
                }

                if (log.isDebugEnabled()) {
                    log.debug("Cache: put doc " + validKey + " in cache");
                }

                boolean cacheResult = false;
                boolean isOverviewPanelPage = OverviewPanel.hasPage(doc.getSpace(), doc.getName(), OverviewPanel.getScope(doc.getGroup(), doc.getProject(), doc.getSpace()));

                if (!doc.isNew() || isOverviewPanelPage) {
                    getCache().putInCache(validKey, loadedDoc);
                    getPageExistCache().putInCache(baselinePrefix + key, new Boolean(!loadedDoc.isNew()));
                    cacheResult = true;
                }
                // after XWikiCacheNeedsRefreshException have to call: put or cancel !!!
                if (!cacheResult) {
                    getCache().cancelUpdate(validKey);
                }

            }
            loadedDoc.setFullName(key);
            return loadedDoc;

        }
    }

    public String getValidKey(String key, String space) {
        if (Constants.USERS.equals(space) || key.contains("group/")) {
            return key.substring(key.indexOf("page/"));
        }
        return key;
    }

    @Override
    public void deleteXWikiDoc(XWikiDocument doc, XWikiContext context) throws XWikiException
    {
        String key = getValidKey(getKey(doc, context), doc.getSpaceName());
        synchronized (key)
        {
            store.deleteXWikiDoc(doc, context);

            // Make sure cache is initialized
            initCache(context);
            getCache().flushEntry(key);
            getPageExistCache().flushEntry(key);
            getPageExistCache().putInCache(key, new Boolean(false));
        }
    }

    public void deleteXWikiProjectDocs(XWikiDocument doc, XWikiContext context) throws XWikiException
    {
        String key = getKey(doc, context);
        synchronized (key)
        {
            // Make sure cache is initialized
            initCache(context);
            getCache().flushEntry(key);
            getPageExistCache().flushEntry(key);
            getPageExistCache().putInCache(key, new Boolean(false));
        }
    }

    @Override
    public List getClassList(XWikiContext context) throws XWikiException {
        return store.getClassList(context);
    }

    @Override
    public List searchDocumentsNames(String wheresql, XWikiContext context) throws XWikiException {
        return store.searchDocumentsNames(wheresql, context);
    }

    @Override
    public List searchDocumentsNames(String wheresql, int nb, int start, XWikiContext context) throws XWikiException {
        return store.searchDocumentsNames(wheresql, nb, start, context);
    }

    @Override
    public List searchDocumentsNames(String wheresql, int nb, int start, String selectColumns, XWikiContext context) throws XWikiException {
        return store.searchDocumentsNames(wheresql, nb, start, selectColumns, context);
    }

    @Override
    public List searchDocumentsNames(String wheresql, String projectweb, int nb, int start, XWikiContext context) throws XWikiException
    {
        return store.searchDocumentsNames(wheresql, projectweb, nb, start, context);
    }

    @Override
    public List searchAttachmentsNames(String wheresql, String projectweb, int nb, int start, XWikiContext context) throws XWikiException
    {
        return store.searchAttachmentsNames(wheresql, projectweb, nb, start, context);
    }

    @Override
    public List searchCommentsNames(String wheresql, String projectweb, int nb, int start, XWikiContext context) throws XWikiException
    {
        return store.searchCommentsNames(wheresql, projectweb, nb, start, context);
    }

    @Override
    public boolean isCustomMappingValid(BaseClass bclass, String custommapping1, XWikiContext context) throws XWikiException
    {
        return store.isCustomMappingValid(bclass, custommapping1, context);
    }

    @Override
    public boolean injectCustomMapping(BaseClass doc1class, XWikiContext context) throws XWikiException {
        return store.injectCustomMapping(doc1class, context);
    }

    @Override
    public boolean injectCustomMappings(XWikiDocument doc, XWikiContext context) throws XWikiException {
        return store.injectCustomMappings(doc, context);
    }

    @Override
    public List searchDocuments(String wheresql, boolean distinctbyname, XWikiContext context) throws XWikiException {
        return store.searchDocuments(wheresql, distinctbyname, context);
    }

    @Override
    public List searchDocuments(String wheresql, boolean distinctbyname, boolean customMapping, XWikiContext context) throws XWikiException {
        return store.searchDocuments(wheresql, distinctbyname, customMapping, context);
    }

    @Override
    public List searchDocuments(String wheresql, boolean distinctbyname, int nb, int start, XWikiContext context) throws XWikiException {
        return store.searchDocuments(wheresql, distinctbyname, nb, start, context);
    }

    @Override
    public List searchDocuments(String wheresql, boolean distinctbyname, boolean customMapping, int nb, int start, XWikiContext context) throws XWikiException {
        return store.searchDocuments(wheresql, distinctbyname, customMapping, nb, start, context);
    }

    @Override
    public List searchDocuments(String wheresql, XWikiContext context) throws XWikiException {
        return store.searchDocuments(wheresql, context);
    }

    @Override
    public List searchDocuments(String wheresql, int nb, int start, XWikiContext context) throws XWikiException {
        return store.searchDocuments(wheresql, nb, start, context);
    }

    @Override
    public List searchDocuments(String wheresql, boolean distinctbyname, boolean customMapping, boolean checkRight, int nb, int start, XWikiContext context) throws XWikiException {
        return store.searchDocuments(wheresql, distinctbyname, customMapping, checkRight, nb, start, context);
    }

    @Override
    public XWikiLock loadLock(long docId, XWikiContext context, boolean bTransaction) throws XWikiException {
        return store.loadLock(docId, context, bTransaction);
    }

    @Override
    public void saveLock(XWikiLock lock, XWikiContext context, boolean bTransaction) throws XWikiException {
        store.saveLock(lock, context, bTransaction);
    }

    @Override
    public void deleteLock(XWikiLock lock, XWikiContext context, boolean bTransaction) throws XWikiException {
        store.deleteLock(lock, context, bTransaction);
    }

    @Override
    public List loadLinks(long docId, XWikiContext context, boolean bTransaction) throws XWikiException {
        return store.loadLinks(docId, context, bTransaction);
    }

    @Override
    public List loadBacklinks(String fullName, XWikiContext context, boolean bTransaction) throws XWikiException {
        return store.loadBacklinks(fullName, context, bTransaction);
    }

    @Override
    public void saveLinks(XWikiDocument doc, XWikiContext context, boolean bTransaction) throws XWikiException {
        store.saveLinks(doc, context, bTransaction);
    }

    @Override
    public void deleteLinks(long docId, XWikiContext context, boolean bTransaction) throws XWikiException {
        store.deleteLinks(docId, context, bTransaction);
    }

    @Override
    public List search(String sql, int nb, int start, XWikiContext context) throws XWikiException {
        return store.search(sql, nb, start, context);
    }

    @Override
    public List search(String sql, int nb, int start, Object[][] whereParams, XWikiContext context) throws XWikiException {
        return store.search(sql, nb, start, whereParams, context);
    }

    @Override
    public synchronized void cleanUp(XWikiContext context) {
        store.cleanUp(context);
    }

    @Override
    public void createWiki(String wikiName, XWikiContext context) throws XWikiException {
        synchronized (wikiName) {
            store.createWiki(wikiName, context);
        }
    }

    @Override
    public boolean exists(XWikiDocument doc, XWikiContext context) throws XWikiException {
        String key = getKey(doc, context);
        initCache(context);
        synchronized (key) {
            try {
                try {
                    RequestParser.decodeName(doc);
                    Boolean result = (Boolean) getPageExistCache().getFromCache(key);
                    return result.booleanValue();
                } catch (XWikiCacheNeedsRefreshException e) {
                    getPageExistCache().cancelUpdate(key);
                }
            } catch (Exception e) {
            }
            boolean result = store.exists(doc, context);
            getPageExistCache().putInCache(key, new Boolean(result));
            return result;
        }
    }

    public XWikiCache getCache() {
        return cache;
    }

    public void setCache(XWikiCache cache) {
        this.cache = cache;
    }

    public XWikiCache getPageExistCache() {
        return pageExistCache;
    }

    public void setPageExistCache(XWikiCache pageExistCache) {
        this.pageExistCache = pageExistCache;
    }

    @Override
    public List getCustomMappingPropertyList(BaseClass bclass) {
        return store.getCustomMappingPropertyList(bclass);
    }

    @Override
    public synchronized void injectCustomMappings(XWikiContext context) throws XWikiException {
        store.injectCustomMappings(context);
    }

    @Override
    public void injectUpdatedCustomMappings(XWikiContext context) throws XWikiException {
        store.injectUpdatedCustomMappings(context);
    }

    @Override
    public List getTranslationList(XWikiDocument doc, XWikiContext context) throws XWikiException {
        return store.getTranslationList(doc, context);
    }

    @Override
    public void deleteAllAtatachments(XWikiDocument doc, XWikiContext context)
    {
        store.deleteAllAtatachments(doc, context);
    }

    @Override
    public List getDocumentHistoryList(String mixedSpac, String pageName) {
        return store.getDocumentHistoryList(mixedSpac, pageName);
    }

    @Override
    public DocumentSvnInfo getDocumentSvnInfo(String project, String space, String page, String rev)
    {
        return store.getDocumentSvnInfo(project, space, page, rev);
    }

    @Override
    public boolean canRead(XWikiDocument doc) throws XWikiException {
        return store.canRead(doc);
    }

    @Override
    public void deleteXWikiSpace(String space, String page, XWikiContext context) throws XWikiException
    {
        store.deleteXWikiSpace(space, page, context);
    }

    @Override
    public SpaceSvnInfo getSpaceInfo(String mixedSpace)
    {
        return store.getSpaceInfo(mixedSpace);
    }

    @Override
    public InputStream getFileContent(String mixedSpace, String filename) throws XWikiException
    {
        return store.getFileContent(mixedSpace, filename);
    }

    @Override
    public String convertDocImgUrls(String url) throws Exception
    {
        return store.convertDocImgUrls(url);
    }

    @Override
    public List searchDocumentsModified(String days, int count, String wheresql, boolean isInSpace, XWikiContext context) throws XWikiException
    {
        return store.searchDocumentsModified(days, count, wheresql, isInSpace, context);
    }

    public XWikiContext getContext() {
        return context;
    }

    @Override
    public void updateXWikiDoc(XWikiDocument doc, List saveList, List deleteList, XWikiContext context, boolean updateDoc) throws XWikiException
    {
        // <-- DMA
        try
        {

            if (doc.isNewTitle())
            {
                doc.rename(doc.getSpace() + "." + doc.getTitle(), context);
                doc.setNewTitle(false);
            }

        } catch (Exception e)
        {
            log.error("Exception while rename document: " + e.getMessage());
        }
        // -->

        String key = getKey(doc, context);
        synchronized (key) {
            store.updateXWikiDoc(doc, saveList, deleteList, context, updateDoc);
            doc.setStore(store);

            // Make sure cache is initialized
            initCache(context);

            // We need to flush so that caches
            // on the cluster are informed about the change
            getCache().flushEntry(key);
            getCache().putInCache(key, doc);
            getPageExistCache().flushEntry(key);
            getPageExistCache().putInCache(key, new Boolean(true));

        }

    }

    @Override
    public void deleteAttachmentNew(XWikiDocument doc, XWikiAttachment att, XWikiContext context) throws XWikiException
    {
        // <-- DMA
        try
        {

            if (doc.isNewTitle())
            {
                doc.rename(doc.getSpace() + "." + doc.getTitle(), context);
                doc.setNewTitle(false);
            }

        } catch (Exception e)
        {
            log.error("Exception while rename document: " + e.getMessage());
        }
        // -->

        String key = getKey(doc, context);
        synchronized (key) {
            store.deleteAttachmentNew(doc, att, context);
            doc.setStore(store);
            // Make sure cache is initialized
            initCache(context);

            // We need to flush so that caches
            // on the cluster are informed about the change
            getCache().flushEntry(key);
            getCache().putInCache(key, doc);
            getPageExistCache().flushEntry(key);
            getPageExistCache().putInCache(key, new Boolean(true));
        }

    }

    @Override
    public void rollbackXWikiDoc(XWikiDocument doc, XWikiContext context) throws XWikiException
    {
        // <-- DMA
        try
        {

            if (doc.isNewTitle())
            {
                doc.rename(doc.getSpace() + "." + doc.getTitle(), context);
                doc.setNewTitle(false);
            }

        } catch (Exception e)
        {
            log.error("Exception while rename document: " + e.getMessage());
        }
        // -->

        String key = getKey(doc, context);
        synchronized (key) {
            store.rollbackXWikiDoc(doc, context);
            doc.setStore(store);
            // Make sure cache is initialized
            initCache(context);

            // We need to flush so that caches
            // on the cluster are informed about the change
            getCache().flushEntry(key);
            getCache().putInCache(key, doc);
            getPageExistCache().flushEntry(key);
            getPageExistCache().putInCache(key, new Boolean(true));
        }

    }

    @Override
    public XWikiDocument loadXWikiDocByRevision(XWikiDocument doc, String revision, XWikiContext<String, Object> context) throws XWikiException {
        return loadXWikiDoc(doc, context);
    }
}
