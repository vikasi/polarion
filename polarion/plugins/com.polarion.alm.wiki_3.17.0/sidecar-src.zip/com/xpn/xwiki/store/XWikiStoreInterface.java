/*
 * Copyright 2006, XpertNet SARL, and individual contributors as indicated
 * by the contributors.txt.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 * @author ludovic
 * @author sdumitriu
 * @author thomas
 */

package com.xpn.xwiki.store;

import java.io.InputStream;
import java.util.List;

import com.polarion.wiki.svn.bo.DocumentSvnInfo;
import com.polarion.wiki.svn.bo.SpaceSvnInfo;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.doc.XWikiAttachment;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.doc.XWikiLock;
import com.xpn.xwiki.objects.classes.BaseClass;

public interface XWikiStoreInterface {
    public void updateXWikiDoc(XWikiDocument doc, List saveList, List deleteList, XWikiContext context, boolean updateDoc) throws XWikiException;

    public void rollbackXWikiDoc(XWikiDocument doc, XWikiContext context) throws XWikiException;

    public void deleteAttachmentNew(XWikiDocument doc, XWikiAttachment attachment, XWikiContext context) throws XWikiException;

    public void saveXWikiDoc(XWikiDocument doc, XWikiContext context) throws XWikiException;

    public void saveXWikiDocPart(XWikiDocument doc, XWikiContext context, boolean writeContOrComm) throws XWikiException;

    public void saveXWikiDoc(XWikiDocument doc, XWikiContext context, boolean bTransaction) throws XWikiException;

    public XWikiDocument loadXWikiDoc(XWikiDocument doc, XWikiContext<String, java.lang.Object> context) throws XWikiException;

    public void deleteXWikiDoc(XWikiDocument doc, XWikiContext context) throws XWikiException;

    public void deleteXWikiSpace(String space, String page, XWikiContext context) throws XWikiException;

    public List getClassList(XWikiContext context) throws XWikiException;

    public List searchDocumentsModified(String days, int count, String wheresql, boolean isInSpace, XWikiContext context) throws XWikiException;

    public List searchDocumentsNames(String wheresql, XWikiContext context) throws XWikiException;

    public List searchDocumentsNames(String wheresql, int nb, int start, XWikiContext context) throws XWikiException;

    public List searchDocuments(String wheresql, boolean distinctbyname, XWikiContext context) throws XWikiException;

    public List searchDocuments(String wheresql, boolean distinctbyname, boolean customMapping, XWikiContext context) throws XWikiException;

    public List searchDocuments(String wheresql, boolean distinctbyname, int nb, int start, XWikiContext context) throws XWikiException;

    public List searchDocuments(String wheresql, boolean distinctbyname, boolean customMapping, int nb, int start, XWikiContext context) throws XWikiException;

    public List searchDocuments(String wheresql, XWikiContext context) throws XWikiException;

    public List searchDocuments(String wheresql, int nb, int start, XWikiContext context) throws XWikiException;

    public XWikiLock loadLock(long docId, XWikiContext context, boolean bTransaction) throws XWikiException;

    public void saveLock(XWikiLock lock, XWikiContext context, boolean bTransaction) throws XWikiException;

    public void deleteLock(XWikiLock lock, XWikiContext context, boolean bTransaction) throws XWikiException;

    public List loadLinks(long docId, XWikiContext context, boolean bTransaction) throws XWikiException;

    public List loadBacklinks(String fullName, XWikiContext context, boolean bTransaction) throws XWikiException;

    public void saveLinks(XWikiDocument doc, XWikiContext context, boolean bTransaction) throws XWikiException;

    public void deleteLinks(long docId, XWikiContext context, boolean bTransaction) throws XWikiException;

    public List search(String sql, int nb, int start, XWikiContext context) throws XWikiException;

    public List search(String sql, int nb, int start, Object[][] whereParams, XWikiContext context) throws XWikiException;

    public void cleanUp(XWikiContext context);

    public void createWiki(String wikiName, XWikiContext context) throws XWikiException;

    public boolean exists(XWikiDocument doc, XWikiContext context) throws XWikiException;

    public List searchDocumentsNames(String wheresql, int nb, int start, String selectColumns, XWikiContext context) throws XWikiException;

    public boolean isCustomMappingValid(BaseClass bclass, String custommapping1, XWikiContext context) throws XWikiException;

    public boolean injectCustomMapping(BaseClass doc1class, XWikiContext xWikiContext) throws XWikiException;

    public boolean injectCustomMappings(XWikiDocument doc, XWikiContext context) throws XWikiException;

    public List getCustomMappingPropertyList(BaseClass bclass);

    public void injectCustomMappings(XWikiContext context) throws XWikiException;

    public List searchDocuments(String wheresql, boolean distinctbyname, boolean customMapping, boolean checkRight, int nb, int start, XWikiContext context) throws XWikiException;

    public void injectUpdatedCustomMappings(XWikiContext context) throws XWikiException;

    public List getTranslationList(XWikiDocument doc, XWikiContext context) throws XWikiException;

    public void deleteAllAtatachments(XWikiDocument doc, XWikiContext context);

    //<--IMA
    public List searchDocumentsNames(String wheresql, String projectweb, int nb, int start, XWikiContext context) throws XWikiException;

    public List searchAttachmentsNames(String wheresql, String projectweb, int nb, int start, XWikiContext context) throws XWikiException;

    public List searchCommentsNames(String wheresql, String projectweb, int nb, int start, XWikiContext context) throws XWikiException;

    //-->

    public List getDocumentHistoryList(String mixedSpac, String pageName);

    public DocumentSvnInfo getDocumentSvnInfo(String project, String space, String page, String rev);

    public SpaceSvnInfo getSpaceInfo(String mixedSpace);

    public boolean canRead(XWikiDocument doc) throws XWikiException;

    public InputStream getFileContent(String mixedspace, String filename) throws XWikiException;

    public String convertDocImgUrls(String url) throws Exception;

    public XWikiDocument loadXWikiDocByRevision(XWikiDocument doc, String revision, XWikiContext<String, java.lang.Object> context) throws XWikiException;
}
