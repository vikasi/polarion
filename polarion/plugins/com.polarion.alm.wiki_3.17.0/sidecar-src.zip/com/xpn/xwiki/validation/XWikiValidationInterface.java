package com.xpn.xwiki.validation;

import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.objects.BaseObject;

public interface XWikiValidationInterface {
    public boolean validateDocument(XWikiDocument doc, XWikiContext context);

    public boolean validateObject(BaseObject object, XWikiContext context);
}
