/*
 * Copyright 2006-2007, XpertNet SARL, and individual contributors as indicated
 * by the contributors.txt.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 */
package com.xpn.xwiki.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.htmlparser.jericho.Element;
import net.htmlparser.jericho.Source;

import org.apache.commons.collections.OrderedMap;
import org.apache.commons.collections.map.ListOrderedMap;

import com.xpn.xwiki.XWikiContext;

public class TOCGenerator {
    public static final String TOC_DATA_NUMBERING = "numbering";
    public static final String TOC_DATA_LEVEL = "level";
    public static final String TOC_DATA_TEXT = "text";

    public static Map<String, Map<String, Object>> generateTOC(String content, int init, int max, boolean numbered, XWikiContext context, boolean processByVelocity) {
        OrderedMap tocData = ListOrderedMap.decorate(new HashMap());
        List<String> processedHeadings = new ArrayList<String>();
        int previousNumbers[] = { 0, 0, 0, 0, 0, 0, 0 };

        Source source = new Source(content);

        source.fullSequentialParse();

        List<Element> allElements = source.getAllElements();
        for (Element element : allElements) {
            if (element.getName().startsWith("h")) { //$NON-NLS-1$

                String className = element.getAttributeValue("class"); //$NON-NLS-1$

                if (className == null) {
                    continue;
                }

                List<Element> childElements = element.getChildElements();

                if (childElements == null || childElements.isEmpty()) {
                    continue;
                }

                Element span = childElements.get(childElements.size() - 1);

                String id = span.getAttributeValue("id"); //$NON-NLS-1$

                int level = className.length() - className.replace("1", "").length(); //$NON-NLS-1$ //$NON-NLS-2$

                String text = element.getTextExtractor().toString();

                if (processByVelocity) {
                    text = context.getWiki().parseContent(text, context);
                }

                Map<String, Object> tocEntry = new HashMap<String, Object>();
                tocEntry.put(TOC_DATA_LEVEL, new Integer(level));
                tocEntry.put(TOC_DATA_TEXT, text);

                if (level >= init && level <= max) {
                    if (numbered) {
                        String number = "";
                        int currentNumber = 0;
                        for (int i = previousNumbers.length - 1; i >= init; i--) {
                            int num = 0;
                            int previousNumber = previousNumbers[i];
                            // if there is already a number previously assigned to a level
                            if (previousNumber > 0) {
                                // copy parent level from previous number
                                num = previousNumber;
                                if (i == level) {
                                    // increment the number if there was already previous number on the same leaf level
                                    num = previousNumber + 1;
                                } else if (i > level) {
                                    //reset numbers of all deeper levels
                                    previousNumbers[i] = 0;
                                }
                            } else {
                                num = 1;
                                // incremet the previous number if there was already a number assigned
                                // to any of the depper levels
                                if (i < level) {
                                    previousNumbers[i] = previousNumbers[i] + 1;
                                }
                            }

                            // construct the string representation of the number
                            if (i <= level) {
                                if ((number.length()) == 0) {
                                    // start new number
                                    number = num + number;
                                    currentNumber = num;
                                } else {
                                    // append to the existing number
                                    number = num + "." + number;
                                }
                            }
                        }
                        // remeber the number for this leaf level
                        previousNumbers[level] = currentNumber;

                        tocEntry.put(TOC_DATA_NUMBERING, number);
                    }

                    tocData.put(id, tocEntry);
                }
            }
        }
        return tocData;
    }

    public static String makeHeadingID(String text, int occurence, XWikiContext context) {
        text = proccessWI(text);
        text = text.replaceAll("[\r\n]", "");
        text = "H" + context.getWiki().getURLEncoded(text);
        text = text.replaceAll("[^a-zA-Z0-9]", "");

        if (occurence > 0) {
            return text + "-" + occurence;
        } else {
            return text;
        }
    }

    private static String proccessWI(String text)
    {
        int a = 0;
        int b = 0;

        while (a != -1 && b != -1)
        {
            a = text.indexOf("{workitem:", a);
            if (a != -1) {
                b = text.indexOf("}", a + 1);
            }
            if (a != -1 && b != -1) {
                text = text.substring(0, a) + text.substring(b + 1, text.length());
            }
        }

        a = 0;
        b = 0;

        while (a != -1 && b != -1)
        {
            a = text.indexOf("<span onmouseover", a);
            if (a != -1) {
                b = text.indexOf("</span></span></a></span>", a + 1);
            }
            if (a != -1 && b != -1) {
                text = text.substring(0, a) + text.substring(b + 25, text.length());
            }

        }

        return text;
    }

}