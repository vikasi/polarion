package com.xpn.xwiki;

/**
 * Created by IntelliJ IDEA.
 * User: jerem
 * Date: Nov 22, 2006
 * Time: 10:56:01 AM
 * To change this template use File | Settings | File Templates.
 */
public class XWikiConstant {
    public static final String TAG_CLASS = "XWiki.TagClass";
    public static final String TAG_CLASS_PROP_TAGS = "tags";
    public static final String URL_WIKI_FULL_VIEW = "wiki/bin/view";
    public static final String URL_WIKI_PREVIEW = "wiki/bin/preview";
    public static final String URL_WIKI_PORTLETVIEW = "wiki/bin/portletview";
    public static final String URL_POLARION_VIEW_SEPARATOR = "#";
    public static final String URL_WIKI_PAGE_VIEW_NAME = "page";
    public static final String URL_POLARION_VIEW_DOC = "wiki";
    public static final String DEFAULT_WI_IMAGE = "type_generic.gif";
    public static final String DEFAULT_WI_IMAGE_FOLDER = "/skins/sidecar/images/workitem/";
    public static final String DEFAULT_DOCUMENT_PAGENAME = "page.xml";
    public static final String PANELS_FILE_NAME = "wikipanels.xml";
    public static final String REPORTS_FILE_NAME = "wikireports.xml";

}
