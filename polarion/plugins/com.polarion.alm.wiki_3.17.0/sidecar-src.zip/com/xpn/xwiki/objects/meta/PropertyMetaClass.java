/*
 * Copyright 2006, XpertNet SARL, and individual contributors as indicated
 * by the contributors.txt.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 */

package com.xpn.xwiki.objects.meta;

import com.xpn.xwiki.objects.BaseCollection;
import com.xpn.xwiki.objects.PropertyInterface;
import com.xpn.xwiki.objects.classes.BaseClass;
import com.xpn.xwiki.objects.classes.BooleanClass;
import com.xpn.xwiki.objects.classes.NumberClass;
import com.xpn.xwiki.objects.classes.StringClass;
import com.xpn.xwiki.objects.classes.TextAreaClass;

public class PropertyMetaClass extends BaseClass implements PropertyInterface {

    public PropertyMetaClass() {
        super();
        StringClass type_class = new StringClass(this);
        type_class.setName("classType"); //$NON-NLS-1$
        type_class.setPrettyName("Class Type");
        type_class.setSize(40);
        type_class.setUnmodifiable(true);
        // This should not be touched
        // safeput("classType", type_class);
        StringClass name_class = new StringClass(this);
        name_class.setName("name"); //$NON-NLS-1$
        name_class.setPrettyName("Name");
        name_class.setUnmodifiable(true);
        name_class.setSize(40);
        safeput("name", name_class); //$NON-NLS-1$

        StringClass prettyname_class = new StringClass(this);
        prettyname_class.setName("prettyName"); //$NON-NLS-1$
        prettyname_class.setPrettyName("Pretty Name");
        prettyname_class.setSize(40);
        safeput("prettyName", prettyname_class); //$NON-NLS-1$

        TextAreaClass tooltip_class = new TextAreaClass(this);
        tooltip_class.setName("tooltip"); //$NON-NLS-1$
        tooltip_class.setPrettyName("Tooltip");
        tooltip_class.setSize(60);
        tooltip_class.setRows(5);
        safeput("tooltip", tooltip_class); //$NON-NLS-1$

        TextAreaClass customdisplay_class = new TextAreaClass(this);
        customdisplay_class.setName("customDisplay"); //$NON-NLS-1$
        customdisplay_class.setPrettyName("Custom Display");
        customdisplay_class.setRows(5);
        customdisplay_class.setSize(80);
        safeput("customDisplay", customdisplay_class); //$NON-NLS-1$

        BooleanClass unmodif_class = new BooleanClass(this);
        unmodif_class.setName("unmodifiable"); //$NON-NLS-1$
        unmodif_class.setPrettyName("Unmodifiable");
        unmodif_class.setDisplayType("yesno"); //$NON-NLS-1$
        safeput("unmodifiable", unmodif_class); //$NON-NLS-1$

        NumberClass number_class = new NumberClass(this);
        number_class.setName("number"); //$NON-NLS-1$
        number_class.setPrettyName("Number");
        number_class.setNumberType("integer"); //$NON-NLS-1$
        safeput("number", number_class); //$NON-NLS-1$

        StringClass validationRegExp_class = new StringClass(this);
        validationRegExp_class.setName("validationRegExp"); //$NON-NLS-1$
        validationRegExp_class.setPrettyName("Validation Regular Expression");
        validationRegExp_class.setSize(40);
        safeput("validationRegExp", validationRegExp_class); //$NON-NLS-1$

        StringClass validationMessage_class = new StringClass(this);
        validationMessage_class.setName("validationMessage"); //$NON-NLS-1$
        validationMessage_class.setPrettyName("Validation Message");
        validationMessage_class.setSize(80);
        safeput("validationMessage", validationMessage_class); //$NON-NLS-1$
    }

    @Override
    public BaseCollection getObject() {
        return null;
    }

    @Override
    public void setObject(BaseCollection object) {
    }

    @Override
    public String toFormString() {
        return null;
    }
}
