/*
 * Copyright 2006, XpertNet SARL, and individual contributors as indicated
 * by the contributors.txt.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 * @author sdumitriu
 */

package com.xpn.xwiki.objects;

import java.io.IOException;
import java.io.Serializable;
import java.io.StringWriter;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.dom.DOMDocument;
import org.dom4j.dom.DOMElement;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;

import com.xpn.xwiki.web.Utils;

// TODO: shouldn't this be abstract? toFormString and toText
// will never work unless getValue is overriden
public class BaseProperty extends BaseElement implements PropertyInterface, Serializable {
    private BaseCollection object;
    private int id;

    @Override
    public BaseCollection getObject() {
        return object;
    }

    @Override
    public void setObject(BaseCollection object) {
        this.object = object;
    }

    @Override
    public boolean equals(Object el) {
        // I hate this.. needed for hibernate to find the object
        // when loading the collections..
        if ((object == null) || ((BaseProperty) el).getObject() == null) {
            return (hashCode() == el.hashCode());
        }

        if (!super.equals(el)) {
            return false;
        }

        return (getId() == ((BaseProperty) el).getId());
    }

    @Override
    public int getId() {
        // I hate this.. needed for hibernate to find the object
        // when loading the collections..
        if (object == null) {
            return id;
        } else {
            return getObject().getId();
        }
    }

    @Override
    public void setId(int id) {
        // I hate this.. needed for hibernate to find the object
        // when loading the collections..
        this.id = id;
    }

    @Override
    public int hashCode() {
        // I hate this.. needed for hibernate to find the object
        // when loading the collections..
        return ("" + getId() + getName()).hashCode();
    }

    public String getClassType() {
        return getClass().getName();
    }

    public void setClassType(String type) {
    }

    @Override
    public Object clone() {
        BaseProperty property = (BaseProperty) super.clone();
        property.setObject(getObject());
        return property;
    }

    public Object getValue() {
        return null;
    }

    public void setValue(Object value) {
    }

    @Override
    public Element toXML() {
        Element el = new DOMElement(getName());
        Object value = getValue();
        el.setText((value == null) ? "" : value.toString());
        return el;
    }

    @Override
    public String toFormString() {
        return Utils.formEncode(toText());
    }

    public String toText() {
        return getValue().toString();
    }

    public String toXMLString() {
        Document doc = new DOMDocument();
        doc.setRootElement(toXML());
        OutputFormat outputFormat = new OutputFormat("", true);
        StringWriter out = new StringWriter();
        XMLWriter writer = new XMLWriter(out, outputFormat);
        try {
            writer.write(doc);
            return out.toString();
        } catch (IOException e) {
            e.printStackTrace();
            return "";
        }
    }

    @Override
    public String toString() {
        return toXMLString();
    }

    public Object getCustomMappingValue() {
        return getValue();
    }
}