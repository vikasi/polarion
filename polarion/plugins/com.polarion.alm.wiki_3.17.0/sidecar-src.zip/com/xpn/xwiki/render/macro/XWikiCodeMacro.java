/*
 * Copyright 2006, XpertNet SARL, and individual contributors as indicated
 * by the contributors.txt.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 * @author sdumitriu
 */
/*
 * This file is part of "SnipSnap Radeox Rendering Engine".
 *
 * Copyright (c) 2002 Stephan J. Schmidt, Matthias L. Jugel
 * All Rights Reserved.
 *
 * Please visit http://radeox.org/ for updates and contact.
 *
 * --LICENSE NOTICE--
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * --LICENSE NOTICE--
 */

package com.xpn.xwiki.render.macro;

import java.io.IOException;
import java.io.Writer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.radeox.macro.CodeMacro;
import org.radeox.macro.parameter.MacroParameter;

public class XWikiCodeMacro extends CodeMacro {

    public XWikiCodeMacro() {
        super();
    }

    @Override
    public String getLocaleKey() {
        return "macro.code";
    }

    @Override
    public void execute(Writer writer, MacroParameter params)
            throws IllegalArgumentException, IOException {
        String content = params.getContent().trim();
        content = StringUtils.replace(content, "<", "&#60;");
        content = StringUtils.replace(content, ">", "&#62;");
        content = StringUtils.replace(content, ":", "&#58;"); //due to making links by wiki

        Pattern classPattern = Pattern.compile("[\r\n]{2,}");
        Pattern classPattern_view = Pattern.compile("[\n]{2,}");
        Matcher classMatcher = classPattern.matcher(content);
        Matcher classMatcher_view = classPattern_view.matcher(content);

        while (classMatcher.find() || classMatcher_view.find())
        {
            if (classMatcher.find()) {
                content = content.replaceAll("\r\n\r\n", "\r\n&nbsp;\r\n");
            }
            if (classMatcher_view.find()) {
                content = content.replaceAll("\n\n", "\n&nbsp;\n");
            }
        }
        content = content.replaceAll("[\r\n]\\s{2,}[\r\n]", "\r\n&nbsp;\r\n");
        content = content.replaceAll("[\n]\\s{2,}[\n]", "\n&nbsp;\n");

        params.setContent(content.trim());

        super.execute(writer, params);

        return;

    }
}
