package com.xpn.xwiki.render.macro;

import java.io.IOException;
import java.io.Writer;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

public class AttachmentMacro extends BaseLocaleMacro {
    @Override
    public String getLocaleKey() {
        return "macro.attachment";
    }

    @Override
    public void execute(Writer writer, MacroParameter params) throws IllegalArgumentException, IOException
    {
        new AttachMacro().execute(writer, params);
    }
}
