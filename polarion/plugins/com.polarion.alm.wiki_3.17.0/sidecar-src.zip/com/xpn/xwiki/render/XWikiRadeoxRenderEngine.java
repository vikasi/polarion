/*
 * Copyright 2006, XpertNet SARL, and individual contributors as indicated
 * by the contributors.txt.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 * @author ludovic
 * @author sdumitriu
 * @author thomas
 * @author tepich
 */

package com.xpn.xwiki.render;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.radeox.api.engine.ImageRenderEngine;
import org.radeox.api.engine.context.InitialRenderContext;
import org.radeox.engine.BaseRenderEngine;
import org.radeox.filter.Filter;
import org.radeox.filter.FilterPipe;
import org.radeox.util.Service;

import com.polarion.core.util.logging.Logger;
import com.polarion.portal.internal.shared.navigation.BaselineHelper;
import com.polarion.subterra.base.location.ILocation;
import com.polarion.wiki.svn.ISvnProvider;
import com.polarion.wiki.svn.WikiSvnBaseStore;
import com.polarion.wiki.svn.WikiSvnStore;
import com.polarion.wiki.util.Constants;
import com.polarion.wiki.util.LocationMapping;
import com.polarion.wiki.util.OverviewPanel;
import com.polarion.wiki.util.RequestParser;
import com.polarion.wiki.util.SpaceParser;
import com.xpn.xwiki.XWikiConstant;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.render.filter.LinkInfo;
import com.xpn.xwiki.render.filter.XWikiFilter;
import com.xpn.xwiki.store.XWikiCacheStore;
import com.xpn.xwiki.web.Utils;

public class XWikiRadeoxRenderEngine extends BaseRenderEngine implements IWikiRenderEngine, ImageRenderEngine {
    private static Logger log = Logger.getLogger(XWikiRadeoxRenderEngine.class);
    private XWikiContext<String, java.lang.Object> context;
    private SimpleEscapingTool escapingTool = new SimpleEscapingTool();

    public XWikiRadeoxRenderEngine(XWikiContext<String, java.lang.Object> context) {
        // super();
        setContext(context);
    }

    public XWikiRadeoxRenderEngine(InitialRenderContext ircontext, XWikiContext<String, java.lang.Object> context) {
        super(ircontext);
        setContext(context);
    }

    public XWikiContext<String, java.lang.Object> getContext() {
        return context;
    }

    public void setContext(XWikiContext<String, java.lang.Object> context) {
        this.context = context;
    }

    // Overidding to load our own Filter list.
    @Override
    protected void init() {
        if (null == fp) {
            fp = new FilterPipe(initialContext);

            Iterator iterator = Service.providers(XWikiFilter.class);
            while (iterator.hasNext()) {
                try {
                    Filter filter = (Filter) iterator.next();
                    fp.addFilter(filter);
                    log.debug("Loaded filter: " + filter.getClass().getName());
                } catch (Exception e) {
                    log.warn("BaseRenderEngine: unable to load filter", e);
                }
            }

            fp.init();
            //Logger.debug("FilterPipe = "+fp.toString());
        }
    }

    public String noaccents(String name) {
        return name;
        //IMA Seems this function is useless in our case but takes perfomace time 2-4%
        //return StringUtils.replace( Util.noaccents(name), " ", "");
    }

    /**
     * @param name the name of a wiki page
     * @return true if the page exists or false otherwise
     * @see org.radeox.api.engine.WikiRenderEngine#exists(String)
     */
    @Override
    public boolean exists(String name) {
        boolean exists = false;

        // first check project
        if (!existProject(name)) {
            return false;
        }

        String database = context.getDatabase();
        try {
            XWikiDocument currentdoc = context.getDoc();

            int qsIndex = name.indexOf("?");
            if (qsIndex != -1) {
                name = name.substring(0, qsIndex);
            }

            // + is use for spaces
            name = name.replaceAll("\\+", " ");
            String newname = noaccents(name);
            XWikiDocument doc = new XWikiDocument(
                    (currentdoc != null) ? currentdoc.getSpace() : "Main",
                    newname);

            String space = SpaceParser.removeGroup(doc.getSpace());
            String mappedSpace = SpaceParser.getSpace(LocationMapping.getMappedSpace(space));

            try {
                exists = context.getWiki().exists(SpaceParser.getFullName(doc.getProject(), mappedSpace, doc.getName()), context);
            } catch (IllegalArgumentException iae) {
                log.error("Error while check location exists" + iae.getMessage());
                return false;
            }
            // If the document exists with the spaces and accents converted then we use this one
            if (exists) {
                return true;
            }

            // if the document does not exists then we check the one not converted
            doc = new XWikiDocument((currentdoc != null) ? currentdoc.getSpace() : "Main", name);
            exists = context.getWiki().exists(doc.getFullName(), context);
            if (exists) {
                return true;
            } else {
                return OverviewPanel.isPageExists(context, space, doc.getName(), OverviewPanel.getScope(null, doc.getProject(), mappedSpace));
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            context.setDatabase(database);
        }

    }

    @Override
    public boolean showCreate() {
        return true;
    }

    /**
     * Appends for example the &lt;a href&gt; HTML code for linking to a wiki
     * page with the given name to the passed buffer.
     *
     * @param buffer the string to append to
     * @param name the name of the wiki page pointed to by the link
     * @param view the text that will be shown to the user for the link
     * @param anchor the anchor specified in the link if any (can be null)
     * @see org.radeox.api.engine.WikiRenderEngine#appendLink(StringBuffer, String, String, String) 
     */
    @Override
    public void appendLink(StringBuffer buffer, String name, String view, String anchor) {
        // allow using spaces in links to anchors
        if (anchor != null) {
            anchor = anchor.replaceAll(" ", "+");
        }

        if (name.length() == 0 && anchor != null) {
            appendInternalLink(buffer, view, anchor);
        } else {
            String database = context.getDatabase();
            XWikiContext<String, java.lang.Object> context = getContext();

            try {
                String db = null;
                String querystring = null;
                int qsIndex = name.indexOf("?");
                if (qsIndex != -1) {
                    querystring = name.substring(qsIndex + 1);
                    name = name.substring(0, qsIndex);
                }

                // + is use for spaces
                // TODO: This causes problems with [C++ Examples]
                name = name.replaceAll("\\+", " ");

                // If the document exists with the conversion of spaces and accents
                // then we use this one
                XWikiDocument newdoc = new XWikiDocument();
                String newname = noaccents(name);
                if (name.indexOf(".") != -1) {
                    newdoc.setFullName(name, context);
                } else {
                    newdoc.setSpace(LocationMapping.getMappedSpace(context.getDoc().getSpace()));
                    newdoc.setName(name);
                }

                // If the document does not exist, then we use the normal name as is
                if (!context.getWiki().exists(newdoc.getFullName(), context)) {
                    if (newname.indexOf(".") != -1) {
                        newdoc.setFullName(newname, context);
                    } else {
                        newdoc.setSpace(context.getDoc().getSpace());
                        newdoc.setName(newname);
                    }
                }

                if ((db == null) || (database.equals(db))) {
                    addLinkToContext(newdoc.getFullName(), context);
                }

                String pdf = (String) context.get("pdf_generate");
                URL url = context.getURLFactory().createURL(SpaceParser.removeGroup(newdoc.getSpace()), newdoc.getName(),
                        "view", querystring, anchor, context);

                String title = SpaceParser.getFullName(newdoc.getProject(), newdoc.getDocSpace(), newdoc.getName());

                buffer.append("<span class=\"wikilink\"><a onclick=\"return checkDiscardChanges();\" title=\"" + escapeTitle(title) + "\" href=\"");
                String res_url = context.getURLFactory().getURL(url, context);

                if (pdf != null && pdf.equalsIgnoreCase("1"))
                {
                    res_url = res_url.replaceAll(XWikiConstant.URL_WIKI_FULL_VIEW, XWikiConstant.URL_POLARION_VIEW_SEPARATOR);
                    res_url = res_url.replaceAll("/" + XWikiConstant.URL_WIKI_PAGE_VIEW_NAME + "/", "/" + XWikiConstant.URL_POLARION_VIEW_DOC + "/");
                    if (res_url.endsWith("/")) {
                        res_url += WikiSvnBaseStore.WIKI_DEFAULT_PAGE;
                    }
                }
                buffer.append(escapeUrl(res_url));

                XWikiDocument currentdoc = context.getDoc();
                if (currentdoc != null) {
                    //         buffer.append("?parent=" + currentdoc.getFullName());
                }

                buffer.append("\">");
                buffer.append(view);
                buffer.append("</a></span>");
            } finally {
                context.setDatabase(database);
            }
        }
    }

    private void addLinkToContext(String docname, XWikiContext<String, java.lang.Object> context) {
        // Add to backlinks in context object
        try {
            List<String> links = (List<String>) context.get("links");
            if (links == null) {
                links = new ArrayList<String>();
                context.put("links", links);
            }
            if (!links.contains(docname)) {
                links.add(docname);
            }
        } catch (Exception e) {
            if (log.isErrorEnabled()) {
                log.error("Error adding link to context", e);
            }
        }
    }

    @Override
    public void appendLink(StringBuffer buffer, String name, String view) {
        appendLink(buffer, name, view, null);
    }

    public void appendInternalLink(StringBuffer buffer, String view, String anchor) {
        buffer.append("<span class=\"wikilink\"><a href=\"#");
        buffer.append(anchor);
        buffer.append("\">");
        if (view.length() == 0) {
            view = Utils.decode(anchor, context);
        }
        buffer.append(view);
        buffer.append("</a></span>");
    }

    @Override
    public void appendCreateLink(StringBuffer buffer, String name, String view) {
        String database = context.getDatabase();
        XWikiContext<String, java.lang.Object> context = getContext();

        try {
            String db = null;
            int qsIndex = name.indexOf("?");
            if (qsIndex != -1) {
                name = name.substring(0, qsIndex);
            }

            // + is used for spaces
            name = name.replaceAll("\\+", " ");

            String newname = name;
            XWikiDocument newdoc = new XWikiDocument();
            if (newname.indexOf(".") != -1) {
                newdoc.setFullName(newname, context);
            } else {
                newdoc.setSpace(LocationMapping.getMappedSpace(context.getDoc().getSpace()));
                newdoc.setName(newname);
            }

            String querystring = null;
            XWikiDocument currentdoc = context.getDoc();
            if (currentdoc != null) {
                querystring = "parent=" + currentdoc.getFullName();
            }

            if ((db == null) || (database.equals(db))) {
                addLinkToContext(newdoc.getFullName(), context);
            }

            String editor = context.getWiki().getEditorPreference(context);
            if ((!editor.equals("") && (!editor.equals("text"))) && (!editor.equals("---"))) {
                querystring += "&editor=" + editor;
            }

            URL url = context.getURLFactory().createURL(SpaceParser.removeGroup(newdoc.getSpace()), newdoc.getName(),
                    "edit", querystring, null, context);
            String title = SpaceParser.getFullName(newdoc.getProject(), newdoc.getDocSpace(), newdoc.getName());
            buffer.append("<a onclick=\"return checkDiscardChanges();\" class=\"wikicreatelink\" title=\"" + escapeTitle(title) + "\" href=\"");
            buffer.append(escapeUrl(context.getURLFactory().getURL(url, context)));
            buffer.append("\">");
            buffer.append("<span class=\"wikicreatelinktext\">");
            buffer.append(view);
            buffer.append("</span>");
            //buffer.append("<span class=\"wikicreatelinkqm\">?</span>");
            buffer.append("</a>");
        } finally {
            context.setDatabase(database);
        }
    }

    /**
     * Get a link to an image. This can be used by filters or
     * macros to get images for e.g. external links or icons
     * Should be refactored to get other images as well
     *
     * @return result String with an HTML link to an image
     */
    @Override
    public String getExternalImageLink() {
        return ""; //$NON-NLS-1$
    }

    @SuppressWarnings("nls")
    private String escapeTitle(String text) {
        return escapingTool.escapeForHtmlTag(text).replaceAll("~", "&#126;").replaceAll("-", "&#45;").replaceAll("\\*", "&#42;").replaceAll("_", "&#95;");
    }

    @SuppressWarnings("nls")
    private String escapeUrl(String text) {
        return escapingTool.escapeForHtmlTag(text).replaceAll("~", "&#126;").replaceAll("-", "&#45;").replaceAll("\\*", "&#42;").replaceAll("_", "&#95;").replaceAll("\\+", "%20");
    }

    @Override
    public void appendLinkProject(StringBuffer buffer, String name, String view, String anchor)
    {
        // allow using spaces in links to anchors
        if (anchor != null) {
            anchor = anchor.replaceAll(" ", "+");
        }

        if (name.length() == 0 && anchor != null) {
            appendInternalLink(buffer, view, anchor);
        } else {
            String database = context.getDatabase();
            XWikiContext<String, java.lang.Object> context = getContext();

            try {
                String db = null;
                String querystring = null;
                int qsIndex = name.indexOf("?");
                if (qsIndex != -1) {
                    querystring = name.substring(qsIndex + 1);
                    name = name.substring(0, qsIndex);
                }
                name = name.replaceAll("\\+", " ");
                if ((db == null) || (database.equals(db))) {
                    addLinkToContext(name, context);
                }

                int n = name.indexOf("/");
                String leftPart = "";
                String rightPart = "";
                if (n > 0)
                {
                    leftPart = name.substring(0, n);
                    rightPart = name.substring(n + 1, name.length());
                }
                String fullName = Constants.PROJECT_IN_URL + "/" + leftPart + "/" + Constants.PAGE_IN_URL + "/" + rightPart;

                String pdf = (String) context.get("pdf_generate");
                URL url = context.getURLFactory().createURL(fullName, Constants.DEFAULT_PAGE,
                        "view", querystring, anchor, context);

                String title = fullName;
                buffer.append("<span class=\"wikilink\"><a onclick=\"return checkDiscardChanges();\" title=\"" + escapeTitle(title) + "\" href=\"");
                String res_url = context.getURLFactory().getURL(url, context);

                if (pdf != null && pdf.equalsIgnoreCase("1"))
                {
                    res_url = res_url.replaceAll(XWikiConstant.URL_WIKI_FULL_VIEW, XWikiConstant.URL_POLARION_VIEW_SEPARATOR);
                    res_url = res_url.replaceAll("/" + XWikiConstant.URL_WIKI_PAGE_VIEW_NAME + "/", "/" + XWikiConstant.URL_POLARION_VIEW_DOC + "/");
                    if (res_url.endsWith("/")) {
                        res_url += WikiSvnBaseStore.WIKI_DEFAULT_PAGE;
                    }
                }
                buffer.append(escapeUrl(res_url));

                XWikiDocument currentdoc = context.getDoc();
                if (currentdoc != null) {
                    //   buffer.append("?parent=" + currentdoc.getFullName());
                }

                buffer.append("\">");
                buffer.append(view);
                buffer.append("</a></span>");
            } finally {
                context.setDatabase(database);
            }
        }

    }

    @Override
    public void appendCreateLinkProject(StringBuffer buffer, String name, String view)
    {
        String database = context.getDatabase();
        XWikiContext<String, java.lang.Object> context = getContext();

        try {
            String db = null;
            int qsIndex = name.indexOf("?");
            if (qsIndex != -1) {
                name = name.substring(0, qsIndex);
            }

            name = name.replaceAll("\\+", " ");
            String querystring = null;
            XWikiDocument currentdoc = context.getDoc();
            if (currentdoc != null) {
                querystring = "parent=" + currentdoc.getFullName();
            }

            if ((db == null) || (database.equals(db))) {
                addLinkToContext(name, context);
            }

            String editor = context.getWiki().getEditorPreference(context);
            if ((!editor.equals("") && (!editor.equals("text"))) && (!editor.equals("---"))) {
                querystring += "&editor=" + editor;
            }

            int n = name.indexOf("/");
            String leftPart = "";
            String rightPart = "";
            if (n > 0)
            {
                leftPart = name.substring(0, n);
                rightPart = name.substring(n + 1, name.length());
            }
            String fullName = Constants.PROJECT_IN_URL + "/" + leftPart + "/" + Constants.PAGE_IN_URL + "/" + rightPart;

            URL url = context.getURLFactory().createURL(fullName, Constants.DEFAULT_PAGE,
                    "edit", querystring, null, context);
            String title = fullName;
            buffer.append("<a onclick=\"return checkDiscardChanges();\" class=\"wikicreatelink\" title=\"" + escapeTitle(title) + "\" href=\"");
            buffer.append(escapeUrl(context.getURLFactory().getURL(url, context)));
            buffer.append("\">");
            buffer.append("<span class=\"wikicreatelinktext\">");
            buffer.append(view);
            buffer.append("</span>");
            //buffer.append("<span class=\"wikicreatelinkqm\">?</span>");
            buffer.append("</a>");
        } finally {
            context.setDatabase(database);
        }

    }

    @Override
    public boolean existsProject(String name)
    {
        boolean exists = false;

        if (!existProject(name)) {
            return false;
        }

        try {
            exists = context.getWiki().exists(name + "." + Constants.DEFAULT_PAGE, context);
        } catch (IllegalArgumentException iae) {
            return false;
        }
        if (exists) {
            return true;
        } else {
            return OverviewPanel.isPageExists(context, Constants.DEFAULT_SPACE, Constants.DEFAULT_PAGE, OverviewPanel.getScope(null, name, Constants.DEFAULT_SPACE));
        }
    }

    private boolean existProject(String name)
    {
        try
        {
            int n = name.indexOf("/");
            String leftPart = "";
            if (n > 0) {
                leftPart = name.substring(0, n);
            }

            ILocation projectLocation = null;
            WikiSvnStore wss = (WikiSvnStore) ((XWikiCacheStore) context.getWiki().getStore()).getStore();
            ISvnProvider svn = wss.getSvnProvider();
            projectLocation = svn.getProjectWikiLocation(leftPart);
            if (projectLocation != null) {
                return true;
            }
        } catch (Exception e)
        {
            return false;
        }

        return false;
    }

    @Override
    public boolean exists(LinkInfo info, boolean type)
    {
        boolean result = false;
        boolean resultSpace = false;

        try {

            String rev = info.getRevision();
            WikiSvnStore wss = (WikiSvnStore) ((XWikiCacheStore) context.getWiki().getStore()).getStore();
            ISvnProvider svn = wss.getSvnProvider();
            if (rev != null) {
                result = svn.exist(svn.getPageWikiLocation(info.getProject(), info.getSpace(), info.getPage()).setRevision(rev));
            } else {
                result = svn.exist(svn.getPageWikiLocation(info.getProject(), info.getSpace(), info.getPage()));
            }
            if (!info.getSpace().equalsIgnoreCase(".")) {
                resultSpace = svn.exist(svn.getSpaceWikiLocation(info.getProject(), info.getSpace()));
            }

            if (type)
            {
                if (result) {
                    return true;
                } else if (Constants.defineNames.contains(info.getSpace())) {
                    if (!RequestParser.isDocumentPage(info.getSpace()))
                    {
                        info.setProject(ISvnProvider.REPO_ROOT_AS_PROJECT_NAME);
                        String path = context.getEngineContext().getRealPath(WikiSvnBaseStore.WIKI_TEMPLITES_ROOT_XML_S + "/" + info.getSpace() + "/" + info.getPage() + ".xml");
                        File fl = new File(path);
                        boolean res = fl.exists();
                        if (res) {
                            return true;
                        } else
                        {
                            info.setCorrectLink(false);
                            return false;
                        }
                    }
                    else
                    {
                        info.setCorrectLink(false);
                        return false;
                    }
                }
                else if (resultSpace) {
                    return OverviewPanel.isPageExists(context, info.getSpace(), info.getPage(), OverviewPanel.getScope(null, info.getProject(), info.getSpace()));
                } else {
                    return result;
                }
            }
            else
            {
                return result || resultSpace;
            }

        } catch (IllegalArgumentException iae) {
            return false;
        } catch (Throwable e)
        {
            return false;
        }

    }

    @Override
    public void appendViewLink(LinkInfo info, StringBuffer buffer)
    {
        String querystring = null;
        int qsIndex = info.getHref().indexOf("?");
        if (qsIndex != -1) {
            querystring = info.getHref().substring(qsIndex + 1);
        }

        String anchor = "";
//        if ((db==null)||(database.equals(db)))
//            addLinkToContext(newdoc.getFullName(), context);

        String pdf = (String) context.get("pdf_generate");
        URL url = context.getURLFactory().createURL(info.getProject(), info.getSpace(), info.getPage(),
                "view", info.getText(), querystring, anchor, context);

        String title = info.getTitle();

        buffer.append("<span class=\"wikilink\"><a class=\"wikilink\" title=\"" + escapeTitle(title) + "\" href=\"");
        String res_url = context.getURLFactory().getURL(url, context);

        boolean topLink = querystring == null && info.getParams() == null; // this controls the hack that normal links to wiki pages should be top links
        if (pdf != null && pdf.equalsIgnoreCase("1") || topLink)
        {
            String baseline = BaselineHelper.getBaselineFromURI(res_url);
            if (baseline != null) {
                res_url = BaselineHelper.removeBaselineFromURI(res_url);
            }
            res_url = res_url.replaceAll(XWikiConstant.URL_WIKI_FULL_VIEW, XWikiConstant.URL_POLARION_VIEW_SEPARATOR);
            res_url = res_url.replaceAll("/" + XWikiConstant.URL_WIKI_PAGE_VIEW_NAME + "/", "/" + XWikiConstant.URL_POLARION_VIEW_DOC + "/");
            res_url = res_url.replaceAll("/wiki/_default/", "/wiki/");
            if (res_url.endsWith("/")) {
                res_url += WikiSvnBaseStore.WIKI_DEFAULT_PAGE;
            }
            if (baseline != null) {
                res_url = res_url.replaceFirst(XWikiConstant.URL_POLARION_VIEW_SEPARATOR, XWikiConstant.URL_POLARION_VIEW_SEPARATOR + BaselineHelper.getBaselineURLPart(baseline, true, false));
            }
        }
        buffer.append(escapeUrl(res_url));

        XWikiDocument currentdoc = context.getDoc();
        if (currentdoc != null) {
            if (info.getParams() == null) {
                //   buffer.append("?parent=" + encodeLink(currentdoc.getFullName()));
            } else
            {
                if (info.getParams().indexOf("tab=history") != -1) {
                    buffer.append("?" + info.getParams());
                } else {
                    buffer.append("?" + info.getParams() + "&tab=history");
                }
            }
        }

        buffer.append("\"");
        if (topLink) {
            buffer.append(" target=\"_top\"");
            if (res_url != null && res_url.startsWith("/polarion/#")) {
                res_url = res_url.substring("/polarion/#".length());
            }
            buffer.append(" onclick=\"if(checkDiscardChanges() && top.navigateFromFrame && !(event.shiftKey || event.ctrlKey || event.altKey)){top.navigateFromFrame('"
                    + escapeUrl(res_url == null ? "" : res_url) + "'); return false;} else {return checkDiscardChanges();}\"");
            // the javascript is a hack for IE which will otherwise reload the whole portal page
        } else {
            buffer.append(" onclick=\"return checkDiscardChanges();\"");
        }
        buffer.append(">");
        buffer.append(info.getText());
        buffer.append("</a></span>");

    }

    @Override
    public void appendCreateLink(LinkInfo info, StringBuffer buffer)
    {
        XWikiContext context = getContext();

        String anchor = "";
        String querystring = null;
        XWikiDocument currentdoc = context.getDoc();
        if (currentdoc != null) {
            querystring = "parent=" + currentdoc.getFullName();
        }

        String editor = context.getWiki().getEditorPreference(context);
        if ((!editor.equals("") && (!editor.equals("text"))) && (!editor.equals("---"))) {
            querystring += "&editor=" + editor;
        }

        URL url = context.getURLFactory().createURL(info.getProject(), info.getSpace(), info.getPage(),
                "edit", info.getText(), querystring, anchor, context);

        String title = info.getTitle();
        buffer.append("<a onclick=\"return checkDiscardChanges();\" class=\"wikicreatelink\" title=\"" + escapeTitle(title) + "\" href=\"");
        buffer.append(escapeUrl(context.getURLFactory().getURL(url, context)));
        buffer.append("\">");
        buffer.append("<span class=\"wikicreatelinktext\">");
        buffer.append(info.getText());
        buffer.append("</span>");
        //buffer.append("<span class=\"wikicreatelinkqm\">?</span>");
        buffer.append("</a>");

    }

}
