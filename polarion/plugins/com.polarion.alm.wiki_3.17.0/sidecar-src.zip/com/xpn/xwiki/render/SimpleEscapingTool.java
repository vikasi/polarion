package com.xpn.xwiki.render;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import com.polarion.core.util.EscapeChars;

public class SimpleEscapingTool {

    public String hash = "#"; //$NON-NLS-1$
    public String bsl = "\\"; //$NON-NLS-1$
    public String quot = "\""; //$NON-NLS-1$
    public String slash = "/"; //$NON-NLS-1$

    public SimpleEscapingTool() {
        super();
    }

    public String getHash() {
        return hash;
    }

    public String getBsl() {
        return bsl;
    }

    public String getQuot() {
        return quot;
    }

    public String getSlash() {
        return slash;
    }

    public String escape(String input) {
        input = input.replace("#", "${esc.hash}"); //$NON-NLS-1$//$NON-NLS-2$
        input = input.replace("\\", "${esc.bsl}"); //$NON-NLS-1$//$NON-NLS-2$
        input = input.replace("\"", "${esc.quot}"); //$NON-NLS-1$//$NON-NLS-2$
        input = input.replace("/", "${esc.slash}"); //$NON-NLS-1$//$NON-NLS-2$
        return input;
    }

    @NotNull
    public String escapeForHtmlTag(@Nullable String input) {
        return EscapeChars.forHTMLTag(input);
    }

    @NotNull
    public String escapeForJavascriptString(@NotNull String input) {
        return EscapeChars.forJavascriptString(input);
    }

}
