/*
 * Copyright (C) 2004-2016 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2016 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.xpn.xwiki.render;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.jetbrains.annotations.NotNull;

public class IncludedPagesReader {

    /**
     * Macros "#includeMacros" and "#includeForm" are synonyms and deprecated (see DPP-92438).
     * Both are pre-processed (to define macros in the velocity context), i.e. rendered by Velocity
     * one additional time before the containing page is rendered.
     */
    @NotNull
    public static final String DIRECTIVE_INCLUDE_MACROS_OLD = "#includeMacros"; //$NON-NLS-1$
    @NotNull
    public static final String DIRECTIVE_INCLUDE_FORM = "#includeForm"; //$NON-NLS-1$

    /**
     * This macro is used to import macros from another page (which is done when pre-processing the container page),
     * this macro does not add anything to the content of the page.
     */
    @NotNull
    public static final String DIRECTIVE_INCLUDE_MACROS = "#include_macros"; //$NON-NLS-1$

    @NotNull
    private String wikiContent;
    @NotNull
    private String containingSpace;

    public IncludedPagesReader(@NotNull String wikiContent, @NotNull String containingSpace) {
        this.wikiContent = wikiContent;
        this.containingSpace = containingSpace;
    }

    /**
     * Returns pages 'included' by the given directives. The directives (in the format e.g. '#include') must accept
     * single argument which is the page name, optionally including the space (separated with '.').
     * Page names in the returned list always contain the space - default space is added when needed.
     */
    @NotNull
    public List<String> getIncludedPages(@NotNull String... includeDirectives) {
        Set<String> result = new LinkedHashSet<String>();
        for (String includeDirective : includeDirectives) {
            collectIncludedPages(includeDirective, result);
        }
        return new ArrayList<String>(result);
    }

    private void collectIncludedPages(@NotNull String directive, @NotNull Set<String> result) {
        for (int i = wikiContent.indexOf(directive); i >= 0; i = wikiContent.indexOf(directive, i + directive.length())) {
            if ((i == 0) || (wikiContent.charAt(i - 1) != '\\')) {
                String name = unquote(getInBrackets(wikiContent.substring(i), '(', ')').trim());
                if (!name.trim().isEmpty()) {
                    if (!name.contains(".")) { //$NON-NLS-1$
                        name = containingSpace + "." + name; //$NON-NLS-1$
                    }
                    result.add(name);
                }
            }
        }
    }

    @NotNull
    private String unquote(@NotNull String s) {
        return s.substring(s.startsWith("\"") ? 1 : 0, s.endsWith("\"") ? s.length() - 1 : s.length()); //$NON-NLS-1$ //$NON-NLS-2$
    }

    @NotNull
    private String getInBrackets(@NotNull String s, char opening, char closing) {
        int start = -1;
        int nesting = 0;
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch == opening) {
                if (start < 0) {
                    start = i;
                }
                nesting++;
            } else if (ch == closing) {
                if (--nesting == 0) {
                    return s.substring(start + 1, i);
                }
            }
        }
        return ""; //$NON-NLS-1$
    }

}
