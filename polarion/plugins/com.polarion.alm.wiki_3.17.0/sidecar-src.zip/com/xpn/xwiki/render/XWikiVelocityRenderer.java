/*
 * Copyright 2006-2007, XpertNet SARL, and individual contributors as indicated
 * by the contributors.txt.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */
package com.xpn.xwiki.render;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.tools.VelocityFormatter;
import org.apache.velocity.context.InternalContextAdapterImpl;
import org.apache.velocity.exception.ParseErrorException;
import org.apache.velocity.runtime.RuntimeConstants;
import org.apache.velocity.runtime.RuntimeInstance;
import org.apache.velocity.runtime.parser.ParseException;
import org.apache.velocity.runtime.parser.node.SimpleNode;
import org.jetbrains.annotations.Nullable;

import com.polarion.alm.server.ServerUiContext;
import com.polarion.alm.server.api.transaction.WriteTransactionImpl;
import com.polarion.alm.server.util.VelocityInstanceFilter;
import com.polarion.alm.shared.api.model.internal.RendererBase;
import com.polarion.alm.shared.api.utils.RunnableWithResult;
import com.polarion.alm.ui.server.wiki.PageParameters;
import com.polarion.alm.wiki.IWikiService;
import com.polarion.platform.core.PlatformContext;
import com.polarion.platform.i18n.Localization;
import com.polarion.platform.internal.TxLogger;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.api.Context;
import com.xpn.xwiki.api.Document;
import com.xpn.xwiki.api.XWiki;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.util.Util;

public class XWikiVelocityRenderer implements XWikiRenderer, XWikiInterpreter {

    private static final Log LOG = LogFactory.getLog(XWikiVelocityRenderer.class);

    private final ThreadLocal<Set<String>> includedPagesTL = new ThreadLocal<Set<String>>();

    /**
     * {@inheritDoc}
     * @see XWikiInterpreter#interpret(String, XWikiDocument, XWikiContext)
     */
    @Override
    public String interpret(String content, XWikiDocument contextdoc, XWikiContext context) {
        return render(content, contextdoc, contextdoc, context);
    }

    /**
     * {@inheritDoc}
     * @see XWikiRenderer#render(String, XWikiDocument, XWikiDocument, XWikiContext)
     */
    @Override
    public String render(String content, XWikiDocument contentdoc, XWikiDocument contextdoc, XWikiContext context) {
        VelocityContext vcontext = prepareContext(context);
        Document previousdoc = (Document) vcontext.get("doc"); //$NON-NLS-1$

        Pattern parameterPattern = Pattern.compile("\\{parameter\\}|\\{parameter:[^\\}]*\\}", Pattern.DOTALL); //$NON-NLS-1$

        Matcher mContent = parameterPattern.matcher(content);

        StringBuffer sb2 = new StringBuffer();
        while (mContent.find()) {
            String macroText = mContent.group();
            mContent.appendReplacement(sb2, Matcher.quoteReplacement("$pageParameters.processParameter(\"" + new SimpleEscapingTool().escape(macroText) + "\", \"" + contextdoc.getProject() + "\")")); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$
        }

        mContent.appendTail(sb2);
        content = sb2.toString();

        content = context.getUtil().substitute("s/#include\\(/\\\\#include\\(/go", content); //$NON-NLS-1$
        try {
            IWikiService wikiService = PlatformContext.getPlatform().lookupService(IWikiService.class);
            vcontext.put("page", wikiService.getPage(contextdoc.getName(), contextdoc.getSpace(), contextdoc.getProject(), contextdoc.getRevision())); //$NON-NLS-1$
            vcontext.put("doc", contextdoc.newDocument(context)); //$NON-NLS-1$
            try {
                for (Map.Entry<String, Object> entry : wikiService.getWikiRenderingContextMap().entrySet()) {
                    vcontext.put(entry.getKey(), entry.getValue());
                }
                vcontext.put("transaction", new WriteTransactionImpl());// new instance needs to be created for every rendering //$NON-NLS-1$

            } catch (Exception e1) {
                LOG.error("Unable to fill wiki rendering context: " + e1.getLocalizedMessage(), e1); //$NON-NLS-1$
            }

            // We need to do this in case there are any macros in the content
            String name = contentdoc.getSpaceName() + '.' + contentdoc.getName();
            boolean first = false;
            Set<String> includedPages = includedPagesTL.get();
            if (includedPages == null) {
                includedPagesTL.set(includedPages = new LinkedHashSet<String>());
                first = true;
            }
            if (includedPages.add(name)) {
                try {
                    com.xpn.xwiki.XWiki xwiki = context.getWiki();
                    IncludedPagesReader reader = new IncludedPagesReader(content, contentdoc.getSpaceName());
                    List<String> pages = reader.getIncludedPages(
                            IncludedPagesReader.DIRECTIVE_INCLUDE_MACROS_OLD,
                            IncludedPagesReader.DIRECTIVE_INCLUDE_FORM,
                            IncludedPagesReader.DIRECTIVE_INCLUDE_MACROS);
                    pages.removeAll(includedPages);
                    for (String docname : pages) {
                        LOG.debug("Pre-including macro topic " + docname); //$NON-NLS-1$
                        try {
                            xwiki.include(docname, true, context);
                        } catch (Exception e) {
                            // Make sure we never fail
                            LOG.warn("Exception while pre-including macro topic: " + docname + ", context url: " + context.getURL(), e); //$NON-NLS-1$ //$NON-NLS-2$
                        }
                    }
                } finally {
                    includedPages.remove(name);
                    if (first) {
                        includedPagesTL.remove();
                    }
                }
            }
            Util util = context.getUtil();
            CodeSubstitution codeSubst = new CodeSubstitution(util, false, true);
            content = codeSubst.substitute(content);

            String res = evaluateImpl(content, contextdoc, vcontext, context);
            res = codeSubst.insertNonWikiText(res);

            return res;

        } finally {
            if (previousdoc != null) {
                vcontext.put("doc", previousdoc); //$NON-NLS-1$
            }
        }
    }

    private String evaluateImpl(final String content, final XWikiDocument contextdoc, final VelocityContext vcontext, final XWikiContext context) {
        return RendererBase.executeWithImplicitBuilderTarget(ServerUiContext.getInstance().createHtmlFragmentBuilderFor().oldWiki().target(), new RunnableWithResult<String>() {

            @Override
            @Nullable
            public String run() {
                return evaluate(content, contextdoc.getFullName(), vcontext, context);
            }
        });
    }

    @Override
    public void flushCache() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    /**
     * @todo this method is used in several places which is why it had to be made static. Instead
     *       we need to move it in a VelocityServices class or something similar as it's not
     *       related to rendering.
     */
    public static VelocityContext prepareContext(XWikiContext context) {
        VelocityContext vcontext = (VelocityContext) context.get("vcontext"); //$NON-NLS-1$
        if (vcontext == null) {
            vcontext = new VelocityContext();
        }

        vcontext.put("localization", new Localization()); //$NON-NLS-1$

        vcontext.put("formatter", new VelocityFormatter(vcontext)); //$NON-NLS-1$
        vcontext.put("msg", context.get("msg")); //$NON-NLS-1$ //$NON-NLS-2$

        if (vcontext.get("pageParameters") == null) { //$NON-NLS-1$
            PageParameters pageParameters = new PageParameters();
            pageParameters.setRequest(context.getRequest());
            vcontext.put("pageParameters", pageParameters); //$NON-NLS-1$
        }

        vcontext.put("esc", new SimpleEscapingTool()); //$NON-NLS-1$

        // We put the com.xpn.xwiki.api.XWiki object into the context and not the
        // com.xpn.xwiki.XWiki one which is for internal use only. In this manner we control what
        // the user can access.
        vcontext.put("xwiki", new XWiki(context.getWiki(), context)); //$NON-NLS-1$

        vcontext.put("request", context.getRequest()); //$NON-NLS-1$
        vcontext.put("response", context.getResponse()); //$NON-NLS-1$

        // We put the com.xpn.xwiki.api.Context object into the context and not the
        // com.xpn.xwiki.XWikiContext one which is for internal use only. In this manner we control
        // what the user can access.
        vcontext.put("context", new Context(context)); //$NON-NLS-1$

        // Save the Velocity Context in the XWiki context so that users can access the objects
        // we've put in it (xwiki, request, response, etc).
        context.put("vcontext", vcontext); //$NON-NLS-1$

        return vcontext;
    }

    public static String evaluate(String content, String name, VelocityContext vcontext) {
        return evaluate(content, name, vcontext, null);
    }

    public static String evaluate(String content, String name, VelocityContext vcontext, XWikiContext context) {
        StringWriter writer = new StringWriter();
        try {
            XWikiVelocityRenderer.evaluate(vcontext, writer, name, new StringReader(content + (!content.endsWith("\r\n") ? "\r\n" : ""))); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
            return writer.toString();
        } catch (Exception e) {
            Object[] args = { name };
            XWikiException xe = new XWikiException(XWikiException.MODULE_XWIKI_RENDERING, XWikiException.ERROR_XWIKI_RENDERING_VELOCITY_EXCEPTION,
                    "Error while parsing velocity page {0}", e, args); //$NON-NLS-1$
            return Util.getHTMLExceptionMessage(xe, context);
        }
    }

    public static boolean evaluate(org.apache.velocity.context.Context context, Writer writer, String logTag, InputStream instream) throws Exception {
        /*
         *  first, parse - convert ParseException if thrown
         */

        BufferedReader br = null;
        String encoding = null;

        try {
            encoding = VelocityInstanceFilter.getVelocityInstance().getString(RuntimeConstants.INPUT_ENCODING, RuntimeConstants.ENCODING_DEFAULT);
            br = new BufferedReader(new InputStreamReader(instream, encoding));
        } catch (UnsupportedEncodingException uce) {
            String msg = "Unsupported input encoding : " + encoding //$NON-NLS-1$
                    + " for template " + logTag; //$NON-NLS-1$
            throw new ParseErrorException(msg);
        }

        return XWikiVelocityRenderer.evaluate(context, writer, logTag, br);
    }

    /**
     *  Renders the input reader using the context into the output writer.
     *  To be used when a template is dynamically constructed, or want to
     *  use Velocity as a token replacer.
     *
     *  @param context context to use in rendering input string
     *  @param writer  Writer in which to render the output
     *  @param logTag  string to be used as the template name for log messages
     *                 in case of error
     *  @param reader Reader containing the VTL to be rendered
     *
     *  @return true if successful, false otherwise.  If false, see
     *               Velocity runtime log
     *
     *  @since Velocity v1.1
     */
    private static boolean evaluate(org.apache.velocity.context.Context context, Writer writer, String logTag, Reader reader) throws Exception {
        try {
            TxLogger.began("Velocity", "evaluate in Wiki"); //$NON-NLS-1$ //$NON-NLS-2$
            return evaluateImpl(context, writer, logTag, reader);
        } finally {
            TxLogger.ended("Velocity", "evaluate in Wiki"); //$NON-NLS-1$ //$NON-NLS-2$
        }
    }

    private static boolean evaluateImpl(org.apache.velocity.context.Context context, Writer writer, String logTag, Reader reader) throws Exception {
        SimpleNode nodeTree = null;

        RuntimeInstance runtimeInstance = VelocityInstanceFilter.getVelocityInstance();
        try {
            nodeTree = runtimeInstance.parse(reader, logTag, false);
        } catch (ParseException pex) {
            throw new ParseErrorException(pex.getMessage());
        }

        /*
         * now we want to init and render
         */

        if (nodeTree != null) {
            InternalContextAdapterImpl ica = new InternalContextAdapterImpl(context);

            ica.pushCurrentTemplateName(logTag);

            try {
                try {
                    nodeTree.init(ica, runtimeInstance);
                } catch (Exception e) {
                    runtimeInstance.error("Velocity.evaluate() : init exception for tag = " //$NON-NLS-1$
                            + logTag + " : " + e); //$NON-NLS-1$
                }

                /*
                 *  now render, and let any exceptions fly
                 */

                nodeTree.render(ica, writer);
            } finally {
                ica.popCurrentTemplateName();
            }

            return true;
        }

        return false;
    }

    private void generateFunction(StringBuffer result, String param, String data, XWikiVirtualMacro macro) {
        Map<String, String> namedparams = new HashMap<String, String>();
        List<String> unnamedparams = new ArrayList<String>();
        if ((param != null) && (!param.trim().equals(""))) { //$NON-NLS-1$
            String[] params = StringUtils.split(param, "|"); //$NON-NLS-1$
            for (String param2 : params) {
                String[] rparam = StringUtils.split(param2, "="); //$NON-NLS-1$
                if (rparam.length == 1) {
                    unnamedparams.add(param2);
                } else {
                    namedparams.put(rparam[0].trim(), rparam[1].trim());
                }
            }
        }

        result.append("#"); //$NON-NLS-1$
        result.append(macro.getFunctionName());
        result.append("("); //$NON-NLS-1$

        List macroparam = macro.getParams();
        int j = 0;
        for (int i = 0; i < macroparam.size(); i++) {
            String name = (String) macroparam.get(i);
            String value = namedparams.get(name);
            if (value == null) {
                try {
                    value = unnamedparams.get(j);
                    j++;
                } catch (Exception e) {
                    value = ""; //$NON-NLS-1$
                }
            }
            if (i > 0) {
                result.append(" "); //$NON-NLS-1$
            }
            result.append("\""); //$NON-NLS-1$
            result.append(value.replaceAll("\"", "\\\\\"")); //$NON-NLS-1$ //$NON-NLS-2$
            result.append("\""); //$NON-NLS-1$
        }

        if (data != null) {
            result.append(" "); //$NON-NLS-1$
            result.append("\""); //$NON-NLS-1$
            result.append(data.replaceAll("\"", "\\\\\"")); //$NON-NLS-1$ //$NON-NLS-2$
            result.append("\""); //$NON-NLS-1$
        }
        result.append(")"); //$NON-NLS-1$
    }

    private void addVelocityMacros(StringBuffer result, XWikiContext context) {
        Object macroAdded = context.get("velocityMacrosAdded"); //$NON-NLS-1$
        if (macroAdded == null) {
            context.put("velocityMacrosAdded", "1"); //$NON-NLS-1$ //$NON-NLS-2$
            String velocityMacrosDocumentName = context.getWiki().getXWikiPreference("macros_velocity", context); //$NON-NLS-1$
            if (velocityMacrosDocumentName.trim().length() > 0) {
                try {
                    XWikiDocument doc = context.getWiki().getDocument(velocityMacrosDocumentName, context);
                    result.append(doc.getContent());
                } catch (XWikiException e) {
                    if (LOG.isErrorEnabled()) {
                        LOG.error("Impossible to load velocity macros doc " //$NON-NLS-1$
                                + velocityMacrosDocumentName);
                    }
                }
            }
        }
    }

    @Override
    public String convertSingleLine(String macroname, String param, String allcontent, XWikiVirtualMacro macro, XWikiContext context) {
        StringBuffer result = new StringBuffer();
        addVelocityMacros(result, context);
        generateFunction(result, param, null, macro);
        return result.toString();
    }

    @Override
    public String convertMultiLine(String macroname, String param, String data, String allcontent, XWikiVirtualMacro macro, XWikiContext context) {
        StringBuffer result = new StringBuffer();
        addVelocityMacros(result, context);
        generateFunction(result, param, data, macro);
        return result.toString();
    }

}
