/*
 * Copyright 2006, XpertNet SARL, and individual contributors as indicated
 * by the contributors.txt.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 * @author sdumitriu
 */

package com.xpn.xwiki.render.macro;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.radeox.api.engine.context.InitialRenderContext;
import org.radeox.macro.Macro;

public class MacroRepository extends org.radeox.macro.PluginRepository {
    protected static Log log = LogFactory.getLog(MacroRepository.class);
    protected InitialRenderContext context;

    protected static MacroRepository instance;
    protected List loaders;

    public synchronized static com.xpn.xwiki.render.macro.MacroRepository getInstance() {
        if (null == instance) {
            instance = new com.xpn.xwiki.render.macro.MacroRepository();
        }
        return instance;
    }

    protected void initialize(InitialRenderContext context) {
        Iterator iterator = list.iterator();
        while (iterator.hasNext()) {
            Macro macro = (Macro) iterator.next();
            macro.setInitialContext(context);
        }
        init();
    }

    public void setInitialContext(InitialRenderContext context) {
        this.context = context;
        initialize(context);
    }

    protected void init() {
        Map newPlugins = new HashMap();

        Iterator iterator = list.iterator();
        while (iterator.hasNext()) {
            Macro macro = (Macro) iterator.next();
            newPlugins.put(macro.getName(), macro);
        }
        plugins = newPlugins;
    }

    /**
       * Loads macros from all loaders into plugins.
    */
    protected void load() {
        Iterator iterator = loaders.iterator();
        while (iterator.hasNext()) {
            MacroLoader loader = (MacroLoader) iterator.next();
            loader.setRepository(this);
            log.debug("Loading from: " + loader.getClass());
            loader.loadPlugins(this);
        }
    }

    protected MacroRepository() {
        loaders = new ArrayList();
        loaders.add(new MacroLoader());
        load();
    }
}
