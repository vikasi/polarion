/*
 * Copyright 2006, XpertNet SARL, and individual contributors as indicated
 * by the contributors.txt.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 * @author Phung Nam (phunghainam@xwiki.com)
 */

package com.xpn.xwiki.render.macro;

import java.io.IOException;
import java.io.Writer;

import org.radeox.api.engine.RenderEngine;
import org.radeox.api.engine.context.RenderContext;
import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.doc.XWikiAttachment;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.render.XWikiRadeoxRenderEngine;

public class StyleMacro extends BaseLocaleMacro {
    @Override
    public String getLocaleKey() {
        return "macro.style";
    }

    @Override
    public void execute(Writer writer, MacroParameter params)
            throws IllegalArgumentException, IOException {
        RenderContext context = params.getContext();
        RenderEngine engine = context.getRenderEngine();
        XWikiContext xcontext = ((XWikiRadeoxRenderEngine) engine).getContext();

        String text = params.getContent();
        String type = params.get("type"); //$NON-NLS-1$
        String id = params.get("id"); //$NON-NLS-1$
        String classes = params.get("class"); //$NON-NLS-1$
        String name = params.get("name"); //$NON-NLS-1$
        String size = params.get("font-size"); //$NON-NLS-1$
        String font = params.get("font-family"); //$NON-NLS-1$
        String color = params.get("color"); //$NON-NLS-1$
        String bgcolor = params.get("background-color"); //$NON-NLS-1$
        String fl = params.get("float"); //$NON-NLS-1$
        String width = params.get("width"); //$NON-NLS-1$
        String height = params.get("height"); //$NON-NLS-1$
        String border = params.get("border"); //$NON-NLS-1$
        String document = params.get("document"); //$NON-NLS-1$
        String icon = params.get("icon"); //$NON-NLS-1$
        String text_align = params.get("text-align"); //$NON-NLS-1$
        boolean hasIcon = false;

        if (null == document || document.indexOf("=") != -1) { //$NON-NLS-1$
            document = null;
        }

        if ((!"none".equals(icon)) && (icon != null) && (!"".equals(icon.trim()))) { //$NON-NLS-1$ //$NON-NLS-2$
            hasIcon = true;
        }
        // Get the target document
        XWikiDocument doc = null;

        if (document != null && !("".equals(document))) { //$NON-NLS-1$
            String space = ""; //$NON-NLS-1$
            if (document.indexOf(".") >= 0) { //$NON-NLS-1$
                space = document.substring(0, document.indexOf(".")).trim(); //$NON-NLS-1$
                document = document.substring(document.indexOf(".") + 1, document.length()).trim(); //$NON-NLS-1$
            }
            try {
                if (space.equals("")) { //$NON-NLS-1$
                    space = xcontext.getDoc().getSpace();
                }
                doc = xcontext.getWiki().getDocument(space, document, xcontext);
            } catch (XWikiException e) {
                // NullPointer or ClassCast
            }
        } else {
            doc = xcontext.getDoc();
        }

        XWikiAttachment image = doc.getAttachment(icon);
        String path = ""; //$NON-NLS-1$
        if (image != null) {
            path = doc.getAttachmentURL(icon, "download", xcontext); //$NON-NLS-1$
        } else {
            icon = "icons/" + icon; // icons default directory that contain icon image.  //$NON-NLS-1$
            path = xcontext.getWiki().getSkinFile(icon, xcontext);
        }

        if (("none".equals(type)) || (type == null) || ("".equals(type.trim()))) { //$NON-NLS-1$ //$NON-NLS-2$
            type = "span"; //$NON-NLS-1$
        }
        StringBuffer str = new StringBuffer();
        str.append("<" + type + " "); //$NON-NLS-1$ //$NON-NLS-2$

        if ((!"none".equals(id)) && (id != null) && (!"".equals(id.trim()))) { //$NON-NLS-1$ //$NON-NLS-2$
            str.append("id=\"" + id.trim() + "\" "); //$NON-NLS-1$ //$NON-NLS-2$
        }
        if ((!"none".equals(classes)) && (classes != null) && (!"".equals(classes.trim()))) { //$NON-NLS-1$ //$NON-NLS-2$
            str.append("class=\"" + classes.trim() + "\" "); //$NON-NLS-1$ //$NON-NLS-2$
        } else if (hasIcon) {
            str.append("class=\"stylemacro\" "); //$NON-NLS-1$
        }
        if ((!"none".equals(name)) && (name != null) && (!"".equals(name.trim()))) { //$NON-NLS-1$ //$NON-NLS-2$
            str.append("name=\"" + name.trim() + "\" "); //$NON-NLS-1$//$NON-NLS-2$
        }

        str.append("style=\""); //$NON-NLS-1$

        if (hasIcon) {
            str.append("background-image: url(" + path + "); "); //$NON-NLS-1$//$NON-NLS-2$
        }
        if ((!"none".equals(size)) && (size != null) && (!"".equals(size.trim()))) { //$NON-NLS-1$ //$NON-NLS-2$
            str.append("font-size:" + size.trim() + "; "); //$NON-NLS-1$ //$NON-NLS-2$
        }
        if ((!"none".equals(font)) && (font != null) && (!"".equals(font.trim()))) { //$NON-NLS-1$ //$NON-NLS-2$
            str.append("font-family:" + font.trim() + "; "); //$NON-NLS-1$ //$NON-NLS-2$
        }
        if ((!"none".equals(color)) && (color != null) && (!"".equals(color.trim()))) { //$NON-NLS-1$//$NON-NLS-2$
            str.append("color:" + color.trim() + "; "); //$NON-NLS-1$//$NON-NLS-2$
        }
        if ((!"none".equals(bgcolor)) && (bgcolor != null) && (!"".equals(bgcolor.trim()))) {
            str.append("background-color:" + bgcolor.trim() + "; ");
        }
        if ((!"none".equals(width)) && (width != null) && (!"".equals(width.trim()))) {
            str.append("width:" + width.trim() + "; ");
        }
        if ((!"none".equals(fl)) && (fl != null) && (!"".equals(fl.trim()))) {
            str.append("float:" + fl.trim() + "; ");
        }
        if ((!"none".equals(height)) && (height != null) && (!"".equals(height.trim()))) {
            str.append("height:" + height.trim() + "; ");
        }
        if ((!"none".equals(border)) && (border != null) && (!"".equals(border.trim()))) {
            str.append("border:" + border.trim() + "; ");
        }
        if ((!"none".equals(text_align)) && (text_align != null) && (!"".equals(text_align.trim()))) {
            str.append("text-align:" + text_align.trim() + "; ");
        }
        str.append("\" >");
        if ((!"none".equals(text)) && (text != null) && (!"".equals(text.trim()))) {
            str.append(text);
        }
        str.append("</" + type + ">");

        writer.write(str.toString());
    }
}
