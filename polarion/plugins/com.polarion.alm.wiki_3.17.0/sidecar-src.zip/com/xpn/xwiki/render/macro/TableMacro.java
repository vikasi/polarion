/*
 *      Copyright 2001-2004 Fraunhofer Gesellschaft, Munich, Germany, for its 
 *      Fraunhofer Institute Computer Architecture and Software Technology
 *      (FIRST), Berlin, Germany
 *      
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package com.xpn.xwiki.render.macro;

import java.io.IOException;
import java.io.Writer;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

import com.polarion.wiki.integration.utils.MP;
import com.polarion.wiki.integration.utils.MacroRenderer;
import com.polarion.wiki.integration.utils.MacroUtils;
import com.xpn.xwiki.XWikiContext;

/**
 * Macro for defining and displaying tables. The rows of the table are
 * devided by newlins and the columns are divided by pipe symbols "|".
 * The first line of the table can be optionally rendered as column headers.
 * {table}
 *  A|B|C
 *  1|2|3
 * {table}
 * 
 * ADDED: styles
 * {table:header=no} -> first line in table will not be header
 * {table:border=no} -> no border lines
 * {table:bold=1,2,3} -> text in all cells of columns 1,2,3 will be bold
 * {table:valign=middle} -> vertival align in cells (values from css vertical-align tag)
 * {table:padding=3px} -> padding of cells (values from css padding tag)
 *
 * @author stephan
 * @team sonicteam
 * @version $Id: TableMacro.java,v 1.9 2004/04/27 19:30:38 leo Exp $
 */

public class TableMacro extends BaseLocaleMacro {

    private final MacroUtils utils = MacroUtils.getInstance();

    private static final String PARAM_HEADER = "header";
    private static final String PARAM_BORDER = "border";
    private static final String PARAM_BOLD = "bold";
    private static final String PARAM_VALIGN = "valign";
    private static final String PARAM_TEXT_ALIGN = "align";
    private static final String PARAM_TABLE_ALIGN = "table-align";
    private static final String PARAM_WIDTH = "width";
    private static final String PARAM_PADDING = "padding";
    private static final String PARAM_ID = "id";

    protected final MacroRenderer renderer = MacroRenderer.getInstance();

    @Override
    public String getLocaleKey() {
        return "macro.table";
    }

    @Override
    public void execute(Writer writer, MacroParameter params) throws IllegalArgumentException, IOException {
        XWikiContext context = utils.getXWikiContext(params);
        Map<String, String> errors = new HashMap<String, String>();

        HashMap<String, String> newMap = new HashMap<String, String>();
        Map mp = params.getParams();
        Set st = mp.entrySet();
        Iterator itr = st.iterator();
        while (itr.hasNext())
        {
            Map.Entry me = (Map.Entry) itr.next();
            if (me != null)
            {
                String fld = (String) me.getKey();
                String val = (String) me.getValue();
                if (fld != null && val != null) {
                    newMap.put(fld.trim(), val.trim());
                }
            }
        }

        String pdf = (String) context.get("pdf_generate");
        String compare = (String) context.get("compareMode");
        boolean forPdf = false;
        boolean forcompare = false;
        if (pdf != null && pdf.equalsIgnoreCase("1")) {
            forPdf = true;
        }
        if (compare != null && compare.equalsIgnoreCase("1")) {
            forcompare = true;
        }

        String content = params.getContent();

        String header = newMap.get(PARAM_HEADER);
        String border = newMap.get(PARAM_BORDER);
        String boldColumns = newMap.get(PARAM_BOLD);
        String valign = newMap.get(PARAM_VALIGN);
        String textAlign = newMap.get(PARAM_TEXT_ALIGN);
        String tableAlign = newMap.get(PARAM_TABLE_ALIGN);
        String width = newMap.get(PARAM_WIDTH);
        String padding = newMap.get(PARAM_PADDING);
        String id = newMap.get(PARAM_ID);

        if (null == content || content.trim().equals("")) {
            throw new IllegalArgumentException("TableMacro: missing table content");
        }

        content = content.trim() + "\n";

        Table table = TableBuilder.build(content);
        table.calc(); // calculate macros like =SUM(A1:A3)

        if (!isEmpty(header) && "no".equals(header.trim())) {
            table.setHeadStyle(false);
        }

        if (!isEmpty(border) && "no".equals(border.trim())) {
            table.setBorderStyle(false);
        }

        if (!isEmpty(boldColumns)) {
            boldColumns = boldColumns.trim();
            if (boldColumns.matches("[0-9]+(\\s)*(,(\\s)*[0-9]+)*")) {
                table.setBoldColumns(boldColumns.trim());
            } else {
                errors.put(boldColumns, MP.Const.ERR_MSG_BOLD_COLUMNS.replaceFirst("%value%", boldColumns));
            }
        }

        if (!isEmpty(valign)) {
            valign = valign.trim();
            if (valign.matches("(top|middle|bottom)")) {
                table.setValignStyle(valign.trim());
            } else {
                errors.put(valign, MP.Const.ERR_MSG_VALIGN.replaceFirst("%value%", valign));
            }
        }

        if (!isEmpty(textAlign)) {
            textAlign = textAlign.trim();
            if (textAlign.matches("(left|right|center)")) {
                table.setTextAlignStyle(textAlign.trim());
            } else {
                errors.put(textAlign, MP.Const.ERR_MSG_ALIGN.replaceFirst("%value%", textAlign));
            }
        }
        if (!isEmpty(tableAlign)) {
            tableAlign = tableAlign.trim();
            if (tableAlign.matches("(left|right|center)")) {
                table.setTableAlignStyle(tableAlign.trim());
            } else {
                errors.put(tableAlign, MP.Const.ERR_MSG_ALIGN.replaceFirst("%value%", tableAlign));
            }
        }

        if (!isEmpty(width)) {
            width = width.trim().replaceAll("&#037;", "%");
            if (width.matches(MP.Const.VV_HTML_SIZE)) {
                table.setWidth(width);
            } else {
                errors.put(width, MP.Const.ERR_MSG_HTML_SIZE);
            }
        }

        if (!isEmpty(padding)) {
            padding = padding.trim().replaceAll("&#037;", "%");
            if (padding.matches(MP.Const.VV_HTML_PADDING)) {
                table.setPadding(padding);
            } else {
                errors.put(padding, MP.Const.ERR_MSG_HTML_SIZE);
            }
        }

        if (!isEmpty(id)) {
            table.setId(id);
        }

        if (errors.isEmpty()) {
            table.appendTo(writer, forPdf, forcompare);
        } else {
            writer.write(renderer.renderErrors(errors, utils.buildMacroTextFromParameters("table", utils.getParameters(params)), forPdf));
        }

        return;
    }

//    private boolean validateDimension(String value){
//    	return value == null || value.matches("[0-9]+|[0-9]+px|[0-9]+\\%");
//    }

    protected boolean isEmpty(String s) {
        return (s == null) || ("".equals(s.trim()));
    }

}
