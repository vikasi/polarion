/*
 * Copyright (C) 2004-2015 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2004-2015 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * POLARION SOFTWARE MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. POLARION SOFTWARE
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.xpn.xwiki.render;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import net.htmlparser.jericho.Element;
import net.htmlparser.jericho.OutputDocument;
import net.htmlparser.jericho.Source;

import org.radeox.api.engine.context.InitialRenderContext;
import org.radeox.api.engine.context.RenderContext;
import org.radeox.engine.context.BaseInitialRenderContext;
import org.radeox.engine.context.BaseRenderContext;
import org.radeox.filter.context.BaseFilterContext;

import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.render.filter.XWikiHeadingFilter;
import com.xpn.xwiki.render.filter.XWikiTOCFilter;
import com.xpn.xwiki.util.TOCGenerator;

public class XWikiTOCRenderer implements XWikiRenderer {

    @Override
    public String render(String content, XWikiDocument contentdoc, XWikiDocument contextdoc, XWikiContext context) {
        StringBuffer output = new StringBuffer();
        if (context != null) {
            Integer includeCounter = (Integer) context.get("include_counter");//$NON-NLS-1$
            if ((includeCounter == null || includeCounter == 0) && content.contains("<toc")) { //$NON-NLS-1$
                RenderContext renderContext = getRenderContext(context);

                XWikiTOCFilter filter = new XWikiTOCFilter();
                BaseFilterContext filterContext = new BaseFilterContext();
                filterContext.setRenderContext(renderContext);

                output.append(filter.filter(content, filterContext));

                Map<String, Map<String, Object>> tocData = (Map<String, Map<String, Object>>) context.get(XWikiHeadingFilter.TOC_DATA);

                Source source = new Source(output);

                source.fullSequentialParse();

                OutputDocument outputDocument = new OutputDocument(source);

                List<Element> allElements = source.getAllElements();
                for (Element element : allElements) {
                    if (element.getName().startsWith("h")) { //$NON-NLS-1$

                        List<Element> childElements = element.getChildElements();

                        if (childElements == null || childElements.isEmpty()) {
                            continue;
                        }

                        Element span = childElements.get(childElements.size() - 1);

                        String headingId = span.getAttributeValue("id"); //$NON-NLS-1$

                        Map<String, Object> tocEntry = tocData.get(headingId);

                        if (tocEntry != null) {

                            String numbering = (String) tocEntry.get(TOCGenerator.TOC_DATA_NUMBERING);

                            StringBuilder newContent = new StringBuilder();
                            newContent.append(span.getStartTag());
                            if (numbering != null && !numbering.isEmpty()) {
                                newContent.append(numbering + " "); //$NON-NLS-1$
                            }
                            newContent.append(span.getContent());
                            newContent.append(span.getEndTag());

                            outputDocument.replace(span, newContent);
                        }

                    }
                }
                return outputDocument.toString();
            }

        }

        output.append(content);
        return output.toString();
    }

    private RenderContext getRenderContext(XWikiContext context) {
        RenderContext renderContext = (RenderContext) context.get("rcontext"); //$NON-NLS-1$
        if (renderContext == null) {
            renderContext = new BaseRenderContext();
            renderContext.setParameters(new HashMap());
            renderContext.set("xcontext", context); //$NON-NLS-1$
        }
        if (renderContext.getRenderEngine() == null) {
            // This is needed so that our local config is used
            InitialRenderContext ircontext = new BaseInitialRenderContext();
            Locale locale = new Locale("xwiki", "xwiki"); //$NON-NLS-1$//$NON-NLS-2$
            ircontext.set(RenderContext.INPUT_LOCALE, locale);
            ircontext.set(RenderContext.OUTPUT_LOCALE, locale);
            ircontext.setParameters(new HashMap());

            XWikiRadeoxRenderEngine radeoxengine = new XWikiRadeoxRenderEngine(ircontext, context);
            renderContext.setRenderEngine(radeoxengine);
        }
        return renderContext;
    }

    @Override
    public void flushCache() {
        //
    }

    @Override
    public String convertMultiLine(String macroname, String params, String data, String allcontent, XWikiVirtualMacro macro, XWikiContext context) {
        return allcontent;
    }

    @Override
    public String convertSingleLine(String macroname, String params, String allcontent, XWikiVirtualMacro macro, XWikiContext context) {
        return allcontent;
    }

}
