package com.xpn.xwiki.render;

import org.radeox.api.engine.WikiRenderEngine;

import com.xpn.xwiki.render.filter.LinkInfo;

public interface IWikiRenderEngine extends WikiRenderEngine
{
    boolean existsProject(String name);

    void appendLinkProject(StringBuffer buffer, String href, String text, String hash);

    void appendCreateLinkProject(StringBuffer buffer, String href, String text);

    boolean exists(LinkInfo info, boolean type);

    void appendViewLink(LinkInfo info, StringBuffer buffer);

    void appendCreateLink(LinkInfo info, StringBuffer buffer);
}
