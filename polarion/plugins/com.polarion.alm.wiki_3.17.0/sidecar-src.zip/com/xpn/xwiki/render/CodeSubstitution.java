package com.xpn.xwiki.render;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.oro.text.regex.MatchResult;
import org.apache.oro.text.regex.Pattern;
import org.apache.oro.text.regex.PatternMatcher;
import org.apache.oro.text.regex.PatternMatcherInput;
import org.apache.oro.text.regex.Perl5Compiler;

public class CodeSubstitution extends WikiSubstitution {
    private int counter = 0;
    private List<String> list = new ArrayList<String>();
    private boolean removePre = false;
    private boolean escape = false;

    public CodeSubstitution(com.xpn.xwiki.util.Util util, boolean removepre, boolean escape) {
        super(util);
        setPattern("({code}|{code:xml}|{code:java}|{code:sql}|{code:none}).*?{code}", Perl5Compiler.CASE_INSENSITIVE_MASK | Perl5Compiler.SINGLELINE_MASK);
        setRemovePre(removepre);
        this.escape = escape;
    }

    @Override
    public void appendSubstitution(StringBuffer stringBuffer, MatchResult matchResult, int i, PatternMatcherInput minput, PatternMatcher patternMatcher, Pattern pattern) {
        String content = matchResult.group(0);
        if (isRemovePre()) {
            content = getUtil().substitute("s/{code}//ig", content);
            //content = getUtil().substitute("s/{code}//ig", content);
        }
        getList().add(content);
        stringBuffer.append("%_%" + counter + "%_%");
        counter++;
    }

    public List<String> getList() {
        return list;
    }

    public void setList(List<String> list) {
        this.list = list;
    }

    public String insertNonWikiText(String content) {
        for (int i = 0; i < list.size(); i++)
        {
            String resMain = list.get(i);
            String innerRes = "";
            innerRes = resMain.substring(resMain.indexOf("}") + 1, resMain.lastIndexOf("{"));
            String content1 = escapeValue(innerRes);
            content1 = resMain.substring(0, resMain.indexOf("}") + 1) + content1 + resMain.substring(resMain.lastIndexOf("{"), resMain.length());
            content = StringUtils.replace(content, "%_%" + i + "%_%", content1);
        }
        return content;
    }

    public boolean isRemovePre() {
        return removePre;
    }

    public void setRemovePre(boolean remove) {
        removePre = remove;
    }

    public String escapeValue(String content) {

        if (!escape)
        {
            content = StringUtils.replace(content, "\\#", "&#35;");

            content = StringUtils.replace(content, "\\{", "&#123;");
            content = StringUtils.replace(content, "\\}", "&#125;");
            content = StringUtils.replace(content, "{", "\\{");
            content = StringUtils.replace(content, "}", "\\}");
            content = StringUtils.replace(content, "\\$", "&#36;");
        }
        else
        {
            content = StringUtils.replace(content, "\\#", "&#35;");
            content = StringUtils.replace(content, "\\$", "&#36;");
        }
        return content;

    }

}
