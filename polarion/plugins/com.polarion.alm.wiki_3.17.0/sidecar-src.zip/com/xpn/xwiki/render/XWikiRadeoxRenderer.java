/*
 * Copyright 2006, XpertNet SARL, and individual contributors as indicated
 * by the contributors.txt.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 * @author ludovic
 * @author sdumitriu
 */

package com.xpn.xwiki.render;

import java.util.HashMap;
import java.util.Locale;

import org.radeox.api.engine.context.InitialRenderContext;
import org.radeox.api.engine.context.RenderContext;
import org.radeox.engine.context.BaseInitialRenderContext;
import org.radeox.engine.context.BaseRenderContext;

import com.polarion.platform.ITransactionService;
import com.polarion.platform.core.PlatformContext;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.util.Util;

public class XWikiRadeoxRenderer implements XWikiRenderer {

    private boolean removePre = true;
    private final ITransactionService txService = PlatformContext.getPlatform().lookupService(ITransactionService.class);

    public XWikiRadeoxRenderer() {
    }

    public XWikiRadeoxRenderer(boolean removePre) {
        setRemovePre(removePre);
    }

    @Override
    public String render(String content, XWikiDocument contentdoc, XWikiDocument contextdoc, XWikiContext context) {
        Util util = context.getUtil();
        // Remove the content that is inside "{pre}"
        PreTagSubstitution preTagSubst = new PreTagSubstitution(util, isRemovePre());
        CodeSubstitution codeSubst = new CodeSubstitution(util, isRemovePre(), false);

//        Integer includeCounter = (Integer) context.get("include_counter"); //$NON-NLS-1$
//        if (includeCounter == null || includeCounter.intValue() == 0) {
//            context.put(XWikiTOCFilter.TOC_PRE_TAG_SUBST, preTagSubst);
//        }

        content = preTagSubst.substitute(content);

        content = codeSubst.substitute(content);
        content = codeSubst.insertNonWikiText(content);

        //{pre2} can be used inside of macro's output
        PreTagSubstitution pre2TagSubst = new PreTagSubstitution(util, true, PreTagSubstitution.PRE2_TAG);
        context.put(PreTagSubstitution.PRE2_CONTEXT_VARIABLE_KEY, pre2TagSubst);

        RenderContext rcontext = (RenderContext) context.get("rcontext"); //$NON-NLS-1$
        if (rcontext == null) {
            rcontext = new BaseRenderContext();
            rcontext.setParameters(new HashMap());
            rcontext.set("xcontext", context); //$NON-NLS-1$
        }
        if (rcontext.getRenderEngine() == null) {
            // This is needed so that our local config is used
            InitialRenderContext ircontext = new BaseInitialRenderContext();
            Locale locale = new Locale("xwiki", "xwiki"); //$NON-NLS-1$//$NON-NLS-2$
            ircontext.set(RenderContext.INPUT_LOCALE, locale);
            ircontext.set(RenderContext.OUTPUT_LOCALE, locale);
            ircontext.setParameters(new HashMap());

            XWikiRadeoxRenderEngine radeoxengine = new XWikiRadeoxRenderEngine(ircontext, context);
            rcontext.setRenderEngine(radeoxengine);

        }
        String result;
        boolean tx = txService.canBeginTx();
        boolean failed = true;
        if (tx) {
            txService.beginTx();
        }
        try {
            result = rcontext.getRenderEngine().render(content, rcontext);
            failed = false;
        } finally {
            if (tx) {
                try {
                    txService.endTx(failed);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        }
        result = renderExternalLink(result);

        result = pre2TagSubst.insertNonWikiText(result);
        return preTagSubst.insertNonWikiText(result);
    }

    /**
     * DMA
     * @param result
     * @return rendered content - external links target now is not Polarion workarea
     */
    public String renderExternalLink(String result)
    {
        String renderedResult = result;
        try
        {
            int spanInd = renderedResult.indexOf("<span"); //$NON-NLS-1$

            while (spanInd != -1)
            {
                int spanEndInd = renderedResult.indexOf("/span>", spanInd); //$NON-NLS-1$

                if (spanEndInd == -1) {
                    break;
                }

                String spanElem = renderedResult.substring(spanInd, spanEndInd);
                if (spanElem.indexOf("class=\"nobr\"") != -1 && spanElem.indexOf("<a") != -1) //$NON-NLS-1$//$NON-NLS-2$
                {
                    int linkInd = renderedResult.indexOf("<a", spanInd); //$NON-NLS-1$
                    renderedResult = renderedResult.substring(0, linkInd + 2) + " target=\"_blank\"" + renderedResult.substring(linkInd + 2); //$NON-NLS-1$
                }

                spanInd = renderedResult.indexOf("<span", spanInd + 6); //$NON-NLS-1$
            }
        } catch (RuntimeException e)
        {
            return result;
        }

        return renderedResult;
    }

    @Override
    public void flushCache() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public boolean isRemovePre() {
        return removePre;
    }

    public void setRemovePre(boolean removePre) {
        this.removePre = removePre;
    }

    @Override
    public String convertMultiLine(String macroname, String params, String data, String allcontent, XWikiVirtualMacro macro, XWikiContext context) {
        return allcontent;
    }

    @Override
    public String convertSingleLine(String macroname, String params, String allcontent, XWikiVirtualMacro macro, XWikiContext context) {
        return allcontent;
    }
}
