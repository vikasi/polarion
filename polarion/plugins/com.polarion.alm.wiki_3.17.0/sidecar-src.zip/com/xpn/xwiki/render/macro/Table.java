package com.xpn.xwiki.render.macro;

import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import com.polarion.alm.shared.util.StringUtils;
import com.polarion.portal.server.HTMLBuilder;
import com.polarion.reina.web.shared.html.HTMLConst;
import com.polarion.reina.web.shared.html.IHTMLBuilder;

@SuppressWarnings("nls")
public class Table extends org.radeox.macro.table.Table {

    protected boolean head;
    protected boolean border;
    protected String boldColumns;
    protected String valign;
    protected String textAlign;
    private String tableAlign;
    protected String width;
    private String padding;
    private String id;

    protected List<Integer> list;

    public Table(boolean drawHeader, boolean drawBorder) {
        super();

        head = drawHeader;
        border = drawBorder;
    }

    public Table() {
        super();

        head = true;
        border = true;
        boldColumns = "";
    }

    public void setHeadStyle(boolean head) {
        this.head = head;
    }

    public void setBorderStyle(boolean border) {
        this.border = border;
    }

    public void setStructure(List<Integer> list) {
        this.list = list;
    }

    public void setValignStyle(String valign) {
        this.valign = valign;
    }

    public void setTextAlignStyle(String textAlign) {
        this.textAlign = textAlign;
    }

    public void setTableAlignStyle(String align) {
        tableAlign = align;
    }

    public void setWidth(String width) {
        this.width = width;
    }

    public void setBoldColumns(String boldColumns) {
        this.boldColumns = boldColumns;
    }

    public void setPadding(String padding) {
        this.padding = padding;
    }

    public void setId(String id) {
        this.id = id;
    }

    private String[] fetchRow(int rowNumber) {
        int columns = list.get(rowNumber);
        String[] res = new String[columns];
        for (int i = 0; i < columns; i++) {
            res[i] = (String) getXY(i, rowNumber);
        }

        return res;
    }

    private int getBiggestRow() {
        int maxi = 0;
        for (Integer i : list) {
            if (i > maxi) {
                maxi = i;
            }
        }

        return maxi;
    }

    private boolean[] getBoldColumns() {
        int columns = getBiggestRow();

        boolean[] cols = new boolean[columns];
        StringTokenizer st = new StringTokenizer(boldColumns, ",");
        while (st.hasMoreTokens()) {
            int t = Integer.parseInt(st.nextToken()) - 1;
            if ((t < 0) || (t > columns)) {
                continue;
            }

            cols[t] = true;
        }

        return cols;
    }

    private List getRows() {
        int rowSize = list.size();
        List<String[]> rows = new ArrayList<String[]>(rowSize);
        for (int i = 0; i < rowSize; i++) {
            rows.add(fetchRow(i));
        }
        return rows;
    }

    /**
     * Serialize table by appending it to a writer. The output
     * format is HTML.
     *
     * @param writer Writer to append the table object to
     *
     * @return writer Writer the table object appended itself to
     */
    public Writer appendTo(Writer writer, boolean forPdf, boolean forcompare) throws IOException {
        if (forcompare) {
            return renderTableForCompare(writer);
        } else if (!forPdf) {
            return renderTable(writer);
        } else {
            return renderTableForPdf(writer);
        }
    }

    private Writer renderTableForPdf(Writer writer) throws IOException {
        IHTMLBuilder builder = new HTMLBuilder();
        StringBuilder tableStyle = new StringBuilder();
        String tableClass = border ? "polarion-wiki-table" : "polarion-wiki-table-noborder";
        if (width != null) {
            tableStyle.append("width:").append(width).append(";");
        } else {
            tableStyle.append("width:").append("100%").append(";");
        }
        if (border) {
            tableStyle.append("border:1px solid #CCCCCC;");
        } else {
            tableStyle.append("border:0px;");
        }
        builder.appendElementStart(HTMLConst.TABLE, tableClass, tableStyle.toString(), getTableAlignForPdf());

        List outputRows = getRows();
        int rowSize = outputRows.size();
        boolean[] boldCols = getBoldColumns();
        boolean odd = true;
        for (int i = 0; i < rowSize; i++) {
            if (isHeaderRow(i)) {
                builder.appendHTML("<thead>");
            } else if (i == 0 && !head) {
                builder.appendHTML("<tbody>");
            }
            builder.appendHTML("<tr");
            if (i == 0) {
                builder.appendHTML(">");
            } else if (odd) {
                builder.appendHTML(" class=\"table-odd\">");
                odd = false;
            } else {
                builder.appendHTML(" class=\"table-even\">");
                odd = true;
            }
            String[] outputCols = (String[]) outputRows.get(i);
            int colSize = outputCols.length;
            for (int j = 0; j < colSize; j++) {
                StringBuilder cellStyle = new StringBuilder();
                StringBuilder columnStyle = new StringBuilder();
                if (valign != null) {
                    columnStyle.append("vertical-align:").append(valign).append(";");
                }
                if (textAlign != null) {
                    columnStyle.append("text-align:").append(textAlign).append(";");
                }
                if (padding != null) {
                    columnStyle.append("padding:").append(padding).append(";");
                }
                boolean isTH = i == 0 && head;
                if (isTH) {
                    columnStyle.append("background-color: #F0F0F0;");
                }

                cellStyle = cellStyle.append(border ? "border:1px solid #CCCCCC;" : "border:0px;").append(columnStyle);
                cellStyle.append("font-size:11px;font-family:verdana;");
                builder.appendHTML(isTH ? "<th class=\"polarion-wiki-table-th\" style=\"" + cellStyle.toString() + "\">" : "<td class=\"polarion-wiki-table-td\"  style=\"" + cellStyle.toString() + "\">");
                if (outputCols[j] == null || outputCols[j].trim().length() == 0) {
                    builder.appendHTML("");
                } else {
                    if (boldCols[j]) {
                        builder.appendHTML("<b>");
                    }
                    builder.appendHTML(outputCols[j]);
                    if (boldCols[j]) {
                        builder.appendHTML("</b>");
                    }
                }
                builder.appendHTML(isTH ? "</th>" : "</td>");
            }
            builder.appendElementEnd(HTMLConst.TR);
            if (isHeaderRow(i)) {
                builder.appendHTML("</thead>");
                builder.appendHTML("<tbody>");
            }
        }
        builder.appendElementEnd(HTMLConst.TBODY);
        builder.appendElementEnd(HTMLConst.TABLE);
        builder.appendElementStart(HTMLConst.DIV, null, "clear:both;", null);
        builder.appendHTML("&nbsp;");
        builder.appendElementEnd(HTMLConst.DIV);

        writer.write(builder.toString());
        return writer;
    }

    private Writer renderTable(Writer writer) throws IOException {
        String tableClass = border ? "polarion-wiki-table" : "polarion-wiki-table-noborder";
        String tableStyle = " style=\"";
        if (width != null) {
            tableStyle += "width: " + width + ";";
        }

        tableStyle += getTableAlign();

        tableStyle += "\"";
        writer.write("<table" + (id != null ? " id=\"" + id + "\"" : "") + " class=\"" + tableClass + "\" cellpadding=\"0\" cellspacing=\"0\"" + tableStyle + ">");
        List outputRows = getRows();
        int rowSize = outputRows.size();
        boolean[] boldCols = getBoldColumns();
        boolean odd = true;
        for (int i = 0; i < rowSize; i++) {
            if (isHeaderRow(i)) {
                writer.write("<thead>");
            } else if (i == 0 && !head) {
                writer.write("<tbody>");
            }
            writer.write("<tr");
            if (i == 0) {
                writer.write(">");
            } else if (odd) {
                writer.write(" class=\"table-odd\">");
                odd = false;
            } else {
                writer.write(" class=\"table-even\">");
                odd = true;
            }
            String[] outputCols = (String[]) outputRows.get(i);
            int colSize = outputCols.length;
            for (int j = 0; j < colSize; j++) {
                String cellAttrs = "";
                StringBuffer style = new StringBuffer();
                if (valign != null) {
                    style.append("vertical-align: ").append(valign).append(";");
                }
                if (textAlign != null) {
                    style.append("text-align: ").append(textAlign).append(";");
                }
                if (padding != null) {
                    style.append("padding: ").append(padding).append(";");
                }
                if (!border) {
                    style.append("border: ").append("0px").append(";");
                }
                if (style.length() > 0) {
                    cellAttrs = " style=\"" + style.toString() + "\"";
                }
                writer.write((i == 0 && head) ? "<th class=\"polarion-wiki-table-th\" " + cellAttrs + ">" : "<td class=\"polarion-wiki-table-td\" " + cellAttrs + ">");
                if (outputCols[j] == null || outputCols[j].trim().length() == 0) {
                    writer.write("");
                } else {
                    if (boldCols[j]) {
                        writer.write("<b>");
                    }
                    writer.write(outputCols[j]);
                    if (boldCols[j]) {
                        writer.write("</b>");
                    }
                }
                writer.write((i == 0 && head) ? "</th>" : "</td>");
            }
            writer.write("</tr>");
            if (isHeaderRow(i)) {
                writer.write("</thead>");
                writer.write("<tbody>");
            }
        }
        writer.write("</tbody>");
        writer.write("</table>");

        return writer;
    }

    private boolean isHeaderRow(int rowIndex) {
        return rowIndex == 0 && head;
    }

    private Writer renderTableForCompare(Writer writer) throws IOException {
        String tableClass = border ? "polarion-wiki-table" : "polarion-wiki-table-noborder";

        String tableStyle = " style=\"";
        if (width != null) {
            tableStyle += "width: " + width + ";";
        }

        tableStyle += getTableAlign();
        tableStyle += "\"";

        List outputRows = getRows();
        int rowSize = outputRows.size();
        boolean[] boldCols = getBoldColumns();
        boolean odd = true;
        for (int i = 0; i < rowSize; i++) {
            writer.write("<table class=\"" + tableClass + "\" cellpadding=\"0\" cellspacing=\"0\"" + tableStyle + ">");
            if (isHeaderRow(i)) {
                writer.write("<thead>");
            } else {
                writer.write("<tbody>");
            }
            writer.write("<tr");
            if (i == 0) {
                writer.write(">");
            } else if (odd) {
                writer.write(" class=\"table-odd\">");
                odd = false;
            } else {
                writer.write(" class=\"table-even\">");
                odd = true;
            }
            String[] outputCols = (String[]) outputRows.get(i);
            int colSize = outputCols.length;
            for (int j = 0; j < colSize; j++) {
                String cellAttrs = "";
                StringBuffer style = new StringBuffer();
                if (valign != null) {
                    style.append("vertical-align: ").append(valign).append(";");
                    cellAttrs = " style=\"vertical-align: " + valign + "\"";
                }
                if (textAlign != null) {
                    style.append("text-align: ").append(textAlign).append(";");
                }
                if (padding != null) {
                    style.append("padding: ").append(padding).append(";");
                }
                if (!border) {
                    style.append("border: ").append("0px").append(";");
                }

                style.append("width: ").append((100 / colSize) + "%").append(";");

                if (style.length() > 0) {
                    cellAttrs = " style=\"" + style.toString() + "\"";
                }
                writer.write((i == 0 && head) ? "<th class=\"polarion-wiki-table-th\" " + cellAttrs + ">" : "<td class=\"polarion-wiki-table-td\" " + cellAttrs + ">");
                if (outputCols[j] == null || outputCols[j].trim().length() == 0) {
                    writer.write("");
                } else {
                    if (boldCols[j]) {
                        writer.write("<b>");
                    }
                    writer.write(outputCols[j]);
                    if (boldCols[j]) {
                        writer.write("</b>");
                    }
                }
                writer.write((i == 0 && head) ? "</th>" : "</td>");
            }
            writer.write("</tr>");
            if (isHeaderRow(i)) {
                writer.write("</thead>");
                writer.write("<tbody> </tbody>");
            } else {
                writer.write("</tbody>");
            }
            writer.write("</table>");
            writer.write("\n");
        }
        //writer.write("</table>");
        return writer;
    }

    private String getTableAlignForPdf() {
        return tableAlign == null ? " align=\"center\" " : " align=\"" + tableAlign + "\" ";
    }

    private String getTableAlign() {

        String align = ""; //$NON-NLS-1$
        if (StringUtils.areEqualTrimmed("left", tableAlign)) { //$NON-NLS-1$
            align += "margin-left: 0px;"; //$NON-NLS-1$
        } else if (StringUtils.areEqualTrimmed("right", tableAlign)) { //$NON-NLS-1$
            align += "margin-right: 0px;"; //$NON-NLS-1$
        }
        return align;
    }

}
