package com.xpn.xwiki.render.macro;

import java.io.IOException;
import java.io.Writer;

import org.radeox.macro.BaseLocaleMacro;
import org.radeox.macro.parameter.MacroParameter;

public class XWikiCodeVelocityMacro extends BaseLocaleMacro {

    public XWikiCodeVelocityMacro() {
        //super();
    }

    @Override
    public String getLocaleKey() {
        return "macro.velocitycode";
    }

    @Override
    public void execute(Writer writer, MacroParameter params)
            throws IllegalArgumentException, IOException {

        String content = params.getContent().trim();
        writer.write("<div style=\"border: 1px dashed #3c78b5;margin: 5px 10px 5px 10px;padding-left: 5px;\">");
        writer.write(content);
        writer.write("</div>");

        return;

    }
}
