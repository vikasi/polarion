/*
 * Copyright 2006, XpertNet SARL, and individual contributors as indicated
 * by the contributors.txt.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 * @author ludovic
 * @author sdumitriu
 */

package com.xpn.xwiki.render.filter;

import java.io.IOException;
import java.io.Writer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.radeox.api.engine.RenderEngine;
import org.radeox.api.engine.WikiRenderEngine;
import org.radeox.filter.context.FilterContext;
import org.radeox.filter.interwiki.InterWiki;
import org.radeox.filter.regex.LocaleRegexTokenFilter;
import org.radeox.util.Encoder;
import org.radeox.util.StringBufferWriter;

import com.polarion.alm.shared.util.StringUtils;
import com.polarion.alm.wiki.IWikiService;
import com.polarion.alm.wiki.model.IWikiPage;
import com.polarion.alm.wiki.model.IWikiSpace;
import com.polarion.platform.core.PlatformContext;
import com.polarion.wiki.integration.link.PageLink;
import com.polarion.wiki.integration.link.PageLinkParser;
import com.polarion.wiki.svn.ISvnProvider;
import com.polarion.wiki.util.Constants;
import com.polarion.wiki.util.SpaceParser;
import com.polarion.wiki.web.BaselineServlet;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.render.IWikiRenderEngine;
import com.xpn.xwiki.render.XWikiRadeoxRenderEngine;

/*
* LinkTestFilter finds [text] in its input and transforms this
* to <a href="text">...</a> if the wiki page exists. If not
* it adds a [create text] to the output.
*
* @author stephan
* @team sonicteam
* @version $Id: XWikiLinkFilter.java 448 2005-01-26 08:37:17Z ldubost $
*/

public class XWikiLinkFilter extends LocaleRegexTokenFilter {
    public static String DEFAULT_SPACE_NAME = Constants.DEFAULT_SPACE;
    public static String DEFAULT_PAGE_NAME = Constants.DEFAULT_PAGE;
    private static IWikiService wikiService = PlatformContext
            .getPlatform().lookupService(IWikiService.class);
    private static Log log = LogFactory.getLog(XWikiLinkFilter.class);

    /**
     * The regular expression for detecting WikiLinks.
     * Overwrite in subclass to support other link styles like
     * OldAndUglyWikiLinking :-)
     *
     * /[A-Z][a-z]+([A-Z][a-z]+)+/
     * wikiPattern = "\\[(.*?)\\]";
     */

    @Override
    protected String getLocaleKey() {
        return "filter.link";
    }

    @Override
    protected void setUp(FilterContext context) {
        context.getRenderContext().setCacheable(true);
    }

    @Override
    public void handleMatch(StringBuffer buffer, org.radeox.regex.MatchResult result, FilterContext context) {
        RenderEngine engine = context.getRenderContext().getRenderEngine();
        XWikiContext<String, java.lang.Object> wikiContext = ((XWikiRadeoxRenderEngine) context.getRenderContext().getRenderEngine()).getContext();

        if (engine instanceof WikiRenderEngine) {
            IWikiRenderEngine wikiEngine = (IWikiRenderEngine) engine;
            Writer writer = new StringBufferWriter(buffer);

            String str = result.group(1);
            if (str != null) {

                // TODO: This line creates bug XWIKI-188. The encoder seems to be broken. Fix this!
                // The only unescaping done should be %xx => char,
                // since &#nnn; must be preserved (the active encoding cannot handle the character)
                // and + should be preserved (for "Doc.C++ examples").
                // Anyway, this unescaper only treats &#nnn;
                // trim the name and unescape it
                // str = Encoder.unescape(str.trim());
                str = str.trim();
                str = str.replaceAll("&#037;", "%");
                //str = Utils.decode(str, wikiContext);

                String text = null, href = null, target = null;
                boolean specificText = false;

                // Is there an alias like [alias|link] ?
                int pipeIndex = str.indexOf('|');
                int pipeLength = 1;
                if (pipeIndex == -1) {
                    pipeIndex = str.indexOf('>');
                }
                if (pipeIndex == -1) {
                    pipeIndex = str.indexOf("&gt;");
                    pipeLength = 4;
                }
                if (-1 != pipeIndex) {
                    text = str.substring(0, pipeIndex).trim();
                    str = str.substring(pipeIndex + pipeLength);
                    specificText = true;
                }

                // Is there a target like [alias|link|target] ?
                pipeIndex = str.indexOf('|');
                pipeLength = 1;
                if (pipeIndex == -1) {
                    pipeIndex = str.indexOf('>');
                }
                if (pipeIndex == -1) {
                    pipeIndex = str.indexOf("&gt;");
                    pipeLength = 4;
                }
                if (-1 != pipeIndex) {
                    target = str.substring(pipeIndex + pipeLength).trim();
                    str = str.substring(0, pipeIndex);
                }
                // Done splitting

                // Fill in missing components
                href = str.trim();

                if (text == null) {
                    text = "";
                }

                //Find out is link restricted in Community Edition
                //href = SpaceParser.expandLink(href);
                PageLink pl = null;
                try {
                    pl = (new PageLinkParser()).parse(SpaceParser.expandLink(href));
                } catch (Exception e) {
                    log.error(e);
                }

                // Done, now print the link

                // to make sure that % is parsed like u25
                // Determine target type: external, interwiki, internal
                //int protocolIndex = href.indexOf("://");
                int protocolIndex = href.indexOf(":");
                if (((protocolIndex >= 0)/*&&(protocolIndex<10)*/)
                        || (href.indexOf("mailto:") == 0)
                        || (href.indexOf("callto:") == 0))
                {
                    if (text.equalsIgnoreCase("")) {
                        text = href;
                    }

                    // External link
                    buffer.append("<span class=\"wikiexternallink\"><a class=\"wikilink\" onclick=\"return checkDiscardChanges();\" href=\"");
                    buffer.append(href);
                    buffer.append("\"");
                    if (target != null) {
                        buffer.append(" target=\"" + target + "\"");
                    } else {
                        buffer.append(" target=\"_blank\"");
                    }
                    buffer.append(">");
                    buffer.append(text.replaceAll("http://", "").replaceAll("ftp://", ""));
                    buffer.append("</a></span>");
                    return;
                }

                int hashIndex = href.lastIndexOf('#');
                String hash = "";

                if (-1 != hashIndex && hashIndex != href.length() - 1) {
                    hash = href.substring(hashIndex + 1);
                    href = href.substring(0, hashIndex);
                }
                if (href.trim().equals("")) {
                    // Internal (anchor) link
                    if (text.equalsIgnoreCase("")) {
                        text = href;
                    }

                    buffer.append("<span class=\"wikilink\"><a class=\"wikilink\" onclick=\"return checkDiscardChanges();\" href=\"#");
                    buffer.append(hash);
                    buffer.append("\">");
                    if (!specificText || text.length() == 0) {
                        text = Encoder.unescape(hash);
                    }
                    buffer.append(text.replaceAll("http://", "").replaceAll("ftp://", ""));
                    buffer.append("</a></span>");
                    return;
                }

                /*
                // We need to keep this in XWiki
                int colonIndex = name.indexOf(':');
                // typed link ?
                if (-1 != colonIndex) {
                    // for now throw away the type information
                    name = name.substring(colonIndex + 1);
                }
                */

                int atIndex = href.lastIndexOf('@');
                // InterWiki link
                if (-1 != atIndex) {
                    String extSpace = href.substring(atIndex + 1);
                    // Kown extarnal space?
                    InterWiki interWiki = InterWiki.getInstance();
                    if (interWiki.contains(extSpace)) {
                        href = href.substring(0, atIndex);
                        try {
                            if (-1 != hashIndex) {
                                interWiki.expand(writer, extSpace, href, text, hash);
                            } else {
                                interWiki.expand(writer, extSpace, href, text);
                            }
                        } catch (IOException e) {
                            log.debug("InterWiki " + extSpace + " not found.");
                        }
                    } else {
                        buffer.append("&#91;<span class=\"error\">");
                        buffer.append(result.group(1));
                        buffer.append("?</span>&#93;");
                    }
                } else {
                    LinkInfo info = linkURL(href, wikiContext, wikiEngine);
                    info.setText(text);
                    if (info.getCorrectLink())
                    {
                        if (wikiEngine.exists(info, true))
                        {
                            wikiEngine.appendViewLink(info, buffer);
                        }
                        else if ((info.getRevision() != null) || (BaselineServlet.getCurrentBaselineRevision() != null))
                        {
                            buffer.append(info.getHref());
                        }
                        else
                        {
                            if (info.getCorrectLink())
                            {
                                if (info.getPage().equalsIgnoreCase(Constants.DEFAULT_PAGE) && !info.getSpace().equalsIgnoreCase(Constants.DEFAULT_SPACE) && !info.getIsPageInLink())
                                {
                                    info.setPage(info.getSpace());
                                    info.setSpace(Constants.DEFAULT_SPACE);
                                }
                                wikiEngine.appendCreateLink(info, buffer);
                                context.getRenderContext().setCacheable(false);
                            } else {
                                buffer.append(info.getHref());
                            }
                        }
                    }
                    else {
                        buffer.append(info.getHref());
//////////////////////////////////////////////////////////////////////////////////////////////////
                    }

                    if (target != null) {
                        int where = buffer.lastIndexOf(" href=\"");
                        if (where >= 0) {
                            buffer.insert(where, " target=\"" + target + "\"");
                        }
                    }

                }
            } else {
                buffer.append(Encoder.escape(result.group(0)));
            }
        }
    }

    /**
     * Returns the view of the wiki name that is shown to the
     * user. Overwrite to support other views for example
     * transform "WikiLinking" to "Wiki Linking".
     * Does nothing by default.
     *
     * @return view The view of the wiki name
     */
    protected String getWikiView(String name) {
        return convertWikiWords(name);
    }

    public static String convertWikiWords(String name) {
        try {
            if (name.indexOf("u25") != -1) {
                name = name.replaceAll("u25", "%");
            }
            name = name.substring(name.lastIndexOf(".") + 1);
            return name.replaceAll("([a-z])([A-Z])", "$1 $2");
        } catch (Exception e) {
            return name;
        }
    }

    private LinkInfo linkURL(String href, XWikiContext context, IWikiRenderEngine wikiEngine)
    {
        LinkInfo info = new LinkInfo();

        if (href.indexOf("?") != -1)
        {
            info.setParams(href.substring(href.indexOf("?") + 1, href.length()));
            href = href.substring(0, href.indexOf("?"));
        }

        // 0 - project, 1 - space, 2 - page, 3 - type(root, current, project)

        Pattern urlTemplate1 = Pattern.compile("[^$]+/[^.]+(\\.)[^.]+");
        Pattern urlTemplate2 = Pattern.compile("[^$]+/[^.]+");
        Pattern urlTemplate3 = Pattern.compile("[^$]+/$");
        Pattern urlTemplate4 = Pattern.compile("^/[^.]+(\\.)[^.]+");
        Pattern urlTemplate41 = Pattern.compile("^/[^.]+");
        Pattern urlTemplate5 = Pattern.compile("^[^.]+(\\.)[^.]+$");
        Pattern urlTemplate6 = Pattern.compile("^[^.]+$");

        Matcher urlMatcher1 = urlTemplate1.matcher(href);
        Matcher urlMatcher2 = urlTemplate2.matcher(href);
        Matcher urlMatcher3 = urlTemplate3.matcher(href);
        Matcher urlMatcher4 = urlTemplate4.matcher(href);
        Matcher urlMatcher41 = urlTemplate41.matcher(href);
        Matcher urlMatcher5 = urlTemplate5.matcher(href);
        Matcher urlMatcher6 = urlTemplate6.matcher(href);

        // multi dot in wiki space and page
        Pattern urlTemplate1_mdt = Pattern.compile("[^$]+/[^$]+");
        Pattern urlTemplate2_mdt = Pattern.compile("^/[^$]+");
        Pattern urlTemplate3_mdt = Pattern.compile("^[^$]+$");

        Matcher urlMatcher1_mdt = urlTemplate1_mdt.matcher(href);
        Matcher urlMatcher2_mdt = urlTemplate2_mdt.matcher(href);
        Matcher urlMatcher3_mdt = urlTemplate3_mdt.matcher(href);

        XWikiDocument currentdoc = context.getDoc();
        String project = "";
        String space = "";
        String spaceTitle = null;
        String page = "";
        String pageTitle = null;
        int level = LinkInfo.CURRENT_LEVEL;

        if (urlMatcher1.matches())
        {
            project = href.substring(0, href.indexOf("/"));
            space = href.substring(href.lastIndexOf("/") + 1, href.lastIndexOf("."));
            page = href.substring(href.lastIndexOf(".") + 1, href.length());
            IWikiPage wikiPage = getWikiPage(currentdoc, project, space, page);
            pageTitle = wikiPage.getTitle();
            spaceTitle = getSpaceTitleOrName(wikiPage);
            level = LinkInfo.PROJECT_LEVEL;
        }
        else if (urlMatcher2.matches())
        {
            LinkInfo infoLocal = new LinkInfo();

            infoLocal.setProject(href.substring(0, href.indexOf("/")));
            infoLocal.setSpace(Constants.DEFAULT_SPACE);
            infoLocal.setPage(href.substring(href.lastIndexOf("/") + 1, href.length()));
            infoLocal.setLevel(LinkInfo.PROJECT_LEVEL);

            if (wikiEngine.exists(infoLocal, true))
            {
                project = href.substring(0, href.indexOf("/"));
                space = Constants.DEFAULT_SPACE;
                page = href.substring(href.lastIndexOf("/") + 1, href.length());
                IWikiPage wikiPage = getWikiPage(currentdoc, project, space, page);
                pageTitle = wikiPage.getTitle();
                spaceTitle = getSpaceTitleOrName(wikiPage);
                level = LinkInfo.PROJECT_LEVEL;

            }
            else
            {
                project = href.substring(0, href.indexOf("/"));
                space = href.substring(href.lastIndexOf("/") + 1, href.length());
                page = Constants.DEFAULT_PAGE;
                info.setIsPageInLink(false);
                level = LinkInfo.PROJECT_LEVEL;
            }
        }
        else if (urlMatcher3.matches())
        {
            project = href.substring(0, href.indexOf("/"));
            space = Constants.DEFAULT_SPACE;
            page = Constants.DEFAULT_PAGE;
            info.setIsPageInLink(false);
            level = LinkInfo.PROJECT_LEVEL;

        }
        else if (urlMatcher4.matches())
        {

            project = ISvnProvider.REPO_ROOT_AS_PROJECT_NAME;
            space = href.substring(1, href.lastIndexOf("."));
            page = href.substring(href.lastIndexOf(".") + 1, href.length());
            IWikiPage wikiPage = getWikiPage(currentdoc, project, space, page);
            pageTitle = wikiPage.getTitle();
            spaceTitle = getSpaceTitleOrName(wikiPage);
            level = LinkInfo.ROOT_LEVEL;

        }
        else if (urlMatcher41.matches())
        {

            LinkInfo infoLocal = new LinkInfo();

            infoLocal.setProject(ISvnProvider.REPO_ROOT_AS_PROJECT_NAME);
            infoLocal.setSpace(Constants.DEFAULT_SPACE);
            infoLocal.setPage(href.substring(1, href.length()));
            infoLocal.setLevel(LinkInfo.ROOT_LEVEL);

            if (wikiEngine.exists(infoLocal, true))
            {
                project = ISvnProvider.REPO_ROOT_AS_PROJECT_NAME;
                space = Constants.DEFAULT_SPACE;
                page = href.substring(1, href.length());
                IWikiPage wikiPage = getWikiPage(currentdoc, project, space, page);
                pageTitle = wikiPage.getTitle();
                spaceTitle = getSpaceTitleOrName(wikiPage);
                level = LinkInfo.ROOT_LEVEL;

            }
            else
            {
                project = ISvnProvider.REPO_ROOT_AS_PROJECT_NAME;
                space = href.substring(1, href.length());
                page = Constants.DEFAULT_PAGE;
                info.setIsPageInLink(false);
                level = LinkInfo.ROOT_LEVEL;
            }
        }
        else if (urlMatcher5.matches())
        {

            project = currentdoc.getProject();
            space = href.substring(0, href.lastIndexOf("."));
            page = href.substring(href.lastIndexOf(".") + 1, href.length());
            IWikiPage wikiPage = getWikiPage(currentdoc, project, space, page);
            pageTitle = wikiPage.getTitle();
            spaceTitle = getSpaceTitleOrName(wikiPage);
            level = LinkInfo.CURRENT_LEVEL;
        }
        else if (urlMatcher6.matches())
        {
            project = currentdoc.getProject();
            space = SpaceParser.getSpace(currentdoc.getSpace());
            page = href;
            IWikiPage wikiPage = getWikiPage(currentdoc, project, space, page);
            pageTitle = wikiPage.getTitle();
            spaceTitle = getSpaceTitleOrName(wikiPage);
            level = LinkInfo.CURRENT_LEVEL;

        }
        else if (urlMatcher1_mdt.matches() || urlMatcher2_mdt.matches() || urlMatcher3_mdt.matches())
        {
            info.setCorrectLink(false);
        }
        else
        {
            project = currentdoc.getProject();
            space = Constants.DEFAULT_SPACE;
            page = Constants.DEFAULT_PAGE;
            info.setIsPageInLink(false);
            level = LinkInfo.PROJECT_LEVEL;

        }

        info.setProject(project);
        info.setSpace(space);
        info.setPage(page);
        info.setLevel(level);
        info.setHref(href);
        info.setPageTitle(pageTitle);
        info.setSpaceTitle(spaceTitle);
        return info;
    }

    @Nullable
    private String getSpaceTitleOrName(@NotNull IWikiPage wikiPage) {
        IWikiSpace space = wikiPage.getSpace();
        return space != null ? space.getTitle() : null;
    }

    @NotNull
    private IWikiPage getWikiPage(XWikiDocument currentdoc, String project, String space, String page) {
        String targetProject = project;
        if (StringUtils.areEqual(project, ISvnProvider.REPO_ROOT_AS_PROJECT_NAME)) {
            targetProject = null;
        }
        IWikiPage wikiPage = wikiService.getPage(page, space, targetProject, currentdoc.getRevision());
        return wikiPage;
    }

}
