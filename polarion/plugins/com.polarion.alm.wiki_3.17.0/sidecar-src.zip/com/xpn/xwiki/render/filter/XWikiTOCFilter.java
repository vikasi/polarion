/*
 * Copyright 2006, XpertNet SARL, and individual contributors as indicated
 * by the contributors.txt.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */
package com.xpn.xwiki.render.filter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.radeox.api.engine.context.RenderContext;
import org.radeox.filter.FilterSupport;
import org.radeox.filter.context.FilterContext;

import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.render.PreTagSubstitution;
import com.xpn.xwiki.render.XWikiRadeoxRenderEngine;
import com.xpn.xwiki.util.TOCGenerator;

public class XWikiTOCFilter extends FilterSupport {
    @NotNull
    public static final String TOC_PRE_TAG_SUBST = "__TOC_preTagSubst"; //$NON-NLS-1$
    @NotNull
    private static final String TOC_REGEX = "<toc init=\"([0-9]+)\" max=\"([0-9]+)\" numbered=\"(true|false)\" pdf=\"(true|false)\">"; //$NON-NLS-1$
    @NotNull
    private static final Pattern tocPattern = Pattern.compile(TOC_REGEX);

    private void handleMatchImpl(@NotNull Matcher matcher, @NotNull FilterContext context, @NotNull StringBuffer sb, @NotNull String content) {

        String generatedToc = generateTocImpl(matcher, context, content);

        matcher.appendReplacement(sb, Matcher.quoteReplacement(generatedToc));
    }

    @NotNull
    private String generateTocImpl(@NotNull Matcher matcher, @NotNull FilterContext context, @NotNull String content) {
        int init = Integer.parseInt(matcher.group(1));
        int max = Integer.parseInt(matcher.group(2));
        boolean numbered = Boolean.parseBoolean(matcher.group(3));
        boolean isForPdf = Boolean.parseBoolean(matcher.group(4));
        String generatedToc = generateTOC(context, content, init, max, numbered, isForPdf);
        return generatedToc;
    }

    @NotNull
    private String generateTOC(@NotNull FilterContext context, @NotNull String content, int init, int max, boolean numbered, boolean isForPdf) {
        RenderContext rcontext = context.getRenderContext();
        XWikiContext xcontext = ((XWikiRadeoxRenderEngine) rcontext.getRenderEngine()).getContext();

        StringBuffer generatedToc = new StringBuffer();
        Map<String, Map<String, Object>> tocData = TOCGenerator.generateTOC(content, init, max, numbered, xcontext, false);

        //data for com.xpn.xwiki.render.filter.XWikiHeadingFilter
        xcontext.put(XWikiHeadingFilter.TOC_NUMBERED, new Boolean(numbered));
        xcontext.put(XWikiHeadingFilter.TOC_DATA, tocData);
        if (isForPdf) {
//          <pd4ml:toc tocInit="$init" tocMax="$max">
            generatedToc.append("<pd4ml:toc tocInit=\""); //$NON-NLS-1$
            generatedToc.append(init);
            generatedToc.append("\" tocMax=\""); //$NON-NLS-1$
            generatedToc.append(max);
            generatedToc.append("\">"); //$NON-NLS-1$
        } else {
            generateTocForWiki(init, generatedToc, tocData);
        }
        return generatedToc.toString();
    }

    private void generateTocForWiki(int init, @NotNull StringBuffer generatedToc, @NotNull Map<String, Map<String, Object>> tocData) {
        generatedToc.append("<div class=\"tocDivision\">"); //$NON-NLS-1$

        int lastLevel = init - 1;
        int depth = 0;
        boolean openedItem = true;
        for (Entry<String, Map<String, Object>> entry : tocData.entrySet()) {
            int level = (Integer) entry.getValue().get(TOCGenerator.TOC_DATA_LEVEL);
            if (level > lastLevel) {
                int to = lastLevel + 1;
                for (int i = level; i >= to; i--) {
                    if (openedItem) {
                        openedItem = false;
                    } else {
                        generatedToc.append("<li>"); //$NON-NLS-1$
                    }
                    generatedToc.append("<ul>"); //$NON-NLS-1$
                    depth++;
                }
            } else if (level < lastLevel) {
                int to = level + 1;
                generatedToc.append("</li>"); //$NON-NLS-1$
                for (int i = lastLevel; i >= to; i--) {
                    generatedToc.append("</ul>"); //$NON-NLS-1$
                    generatedToc.append("</li>"); //$NON-NLS-1$
                    depth--;

                }
            } else {
                generatedToc.append("</li>"); //$NON-NLS-1$
            }

            generatedToc.append("<li class=\"tocEntry\"><a href=\"#"); //$NON-NLS-1$
            generatedToc.append(entry.getKey());
            generatedToc.append("\">"); //$NON-NLS-1$
            String numberingValue = getNumberingValue(entry);
            if (numberingValue != null) {
                generatedToc.append(numberingValue);
                generatedToc.append(" "); //$NON-NLS-1$
            }
            generatedToc.append(entry.getValue().get(TOCGenerator.TOC_DATA_TEXT));
            generatedToc.append("</a>"); //$NON-NLS-1$

            lastLevel = level;
            openedItem = true;
        }
        if (depth > 0) {
            for (int i = 1; i <= depth; i++) {
                generatedToc.append("</li>"); //$NON-NLS-1$
                generatedToc.append("</ul>"); //$NON-NLS-1$
            }

        }
        generatedToc.append("</div>"); //$NON-NLS-1$
    }

    @Nullable
    private String getNumberingValue(@NotNull Entry<String, Map<String, Object>> entry) {
        Map<String, Object> map = entry.getValue();
        if (map != null) {
            String value = (String) map.get(TOCGenerator.TOC_DATA_NUMBERING);
            if (value != null) {
                return value;
            }
        }
        return null;
    }

    @Override
    public String filter(String input, FilterContext context) {

        RenderContext rcontext = context.getRenderContext();
        XWikiContext xcontext = ((XWikiRadeoxRenderEngine) rcontext.getRenderEngine()).getContext();
        Integer counter = (Integer) xcontext.get("include_counter"); //$NON-NLS-1$
        PreTagSubstitution preTagSubst = (PreTagSubstitution) xcontext.get(TOC_PRE_TAG_SUBST);
        if (counter == null || counter.intValue() == 0) {
            if (preTagSubst != null) {
                String contentWithSubstitutions = preTagSubst.insertNonWikiText(input);
                Matcher matcher = tocPattern.matcher(contentWithSubstitutions);
                String generatedToc = null;
                while (matcher.find()) {
                    generatedToc = generateTocImpl(matcher, context, contentWithSubstitutions);
                }
                if (generatedToc != null) {
                    String quotedGeneratedToc = Matcher.quoteReplacement(generatedToc);
                    replaceTocInSubstitutedContent(preTagSubst, quotedGeneratedToc);
                    return input.replaceAll(TOC_REGEX, quotedGeneratedToc);
                }

                return input; //if no toc is generated, then there are no TOC macro's in whole wiki content (with included content), so return input
            }
            return filterImpl(input, context); // do it standard way

        }
        // Do nothing if in include page
        return input;

    }

    private void replaceTocInSubstitutedContent(@NotNull PreTagSubstitution preTagSubst, @NotNull String quotedGeneratedToc) {
        List<String> list = preTagSubst.getList();
        if (list != null) {
            List<String> resultList = new ArrayList<>();
            for (String str : list) {
                String out = str.replaceAll(TOC_REGEX, quotedGeneratedToc);
                resultList.add(out);
            }
            preTagSubst.setList(resultList);
        }
    }

    private String filterImpl(String input, FilterContext context) {
        StringBuffer sb = new StringBuffer();
        Matcher matcher = tocPattern.matcher(input);
        while (matcher.find()) {
            handleMatchImpl(matcher, context, sb, input);
        }

        matcher.appendTail(sb);
        return sb.toString();
    }
}
