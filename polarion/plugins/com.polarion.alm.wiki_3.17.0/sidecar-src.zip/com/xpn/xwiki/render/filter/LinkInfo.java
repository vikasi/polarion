package com.xpn.xwiki.render.filter;

import java.util.Scanner;
import java.util.regex.Pattern;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import com.polarion.wiki.integration.utils.MacroUtils;
import com.polarion.wiki.svn.ISvnProvider;
import com.polarion.wiki.util.Constants;

public class LinkInfo
{
    public static final int ROOT_LEVEL = 0;
    public static final int CURRENT_LEVEL = 1;
    public static final int PROJECT_LEVEL = 2;

    private String project = "";
    private String space = "";
    private String page = "";
    private int level;
    private String viewText = "";
    private String title = "";
    private String href = "";
    private boolean rightLink = true;
    private boolean isPageInLink = true;
    private String params;
    @Nullable
    private String pageTitle;
    @Nullable
    private String spaceTitle;

    @Override
    public LinkInfo clone()
    {
        LinkInfo inf = new LinkInfo();
        inf.setHref(href);
        inf.setLevel(level);
        inf.setPage(page);
        inf.setProject(project);
        inf.setSpace(space);
        inf.setText(viewText);
        inf.setTitle(title);
        inf.setCorrectLink(rightLink);
        inf.setIsPageInLink(isPageInLink);
        inf.setPageTitle(pageTitle);
        return inf;
    }

    public void setProject(String project)
    {
        this.project = project;
    }

    public String getProject()
    {
        if ((project).equalsIgnoreCase(ISvnProvider.REPO_ROOT_AS_PROJECT_NAME))
        {
            return "";
        } else {
            return project;
        }
    }

    public void setSpace(String space)
    {
        this.space = space;
    }

    public String getSpace()
    {
        return space;
    }

    public void setPage(String page)
    {
        this.page = page;
    }

    public String getPage()
    {
        return page;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }

    public String getTitle()
    {
        return (!(project).equalsIgnoreCase(ISvnProvider.REPO_ROOT_AS_PROJECT_NAME) ? project : "") + "/" + getSpaceTitleOrSpace() + "." + getPageTitleOrPage();
    }

    public void setText(String text)
    {
        viewText = text;
    }

    @NotNull
    private String escape(@NotNull String escape) {
        return MacroUtils.getInstance().escapeValue(escape);
    }

    public String getText()
    {

        if (!viewText.equalsIgnoreCase("")) {
            return viewText;
        } else
        {

            String text = "";
            if (level == ROOT_LEVEL) {
                text += "/";
            } else if (level != CURRENT_LEVEL) {
                text += project + "/";
            }

            if (!(space).equalsIgnoreCase(Constants.DEFAULT_SPACE)/* && ( this.level != CURRENT_LEVEL  )*/)
            {
                text += escape(getSpaceTitleOrSpace());
            }

            if (!(page).equalsIgnoreCase(Constants.DEFAULT_PAGE) && !(space).equalsIgnoreCase(Constants.DEFAULT_SPACE))
            {
                text += "." + escape(getPageTitleOrPage());
            }
            else if (!(page).equalsIgnoreCase(Constants.DEFAULT_PAGE) && (space).equalsIgnoreCase(Constants.DEFAULT_SPACE))
            {
                text += escape(getPageTitleOrPage());
            }
            else if ((page).equalsIgnoreCase(Constants.DEFAULT_PAGE) && (space).equalsIgnoreCase(Constants.DEFAULT_SPACE))
            {
                text += Constants.DEFAULT_PAGE;
            }

            return text;
        }
    }

    public void setLevel(int level)
    {
        this.level = level;
    }

    public int getLevel()
    {
        return level;
    }

    public void setHref(String href)
    {
        this.href = href;
    }

    public String getHref()
    {
        return href;
    }

    public void setCorrectLink(boolean val)
    {
        rightLink = val;
    }

    public boolean getCorrectLink()
    {
        return rightLink;
    }

    public void setIsPageInLink(boolean val)
    {
        isPageInLink = val;
    }

    public boolean getIsPageInLink()
    {
        return isPageInLink;
    }

    public void setParams(String val)
    {
        params = val;
    }

    public String getParams()
    {
        return params;
    }

    public String getRevision()
    {
        if (params != null && !params.equalsIgnoreCase(""))
        {
            Scanner sc = new Scanner(params);
            String line1 = sc.findInLine(Pattern.compile("rev=[0-9]+"));
            String line2 = null;
            if (line1 != null)
            {
                sc = new Scanner(line1);
                line2 = sc.findInLine(Pattern.compile("[0-9]+"));
                return line2;
            } else {
                return null;
            }
        } else {
            return null;
        }
    }

    public void setPageTitle(@Nullable String pageTitle) {
        this.pageTitle = pageTitle;
    }

    @Nullable
    public String getPageTitle() {
        return pageTitle;
    }

    @NotNull
    private String getPageTitleOrPage() {
        String pageTitleToReturn = com.polarion.core.util.StringUtils.getNullIfEmpty(getPageTitle());
        if (pageTitleToReturn != null) {
            return pageTitleToReturn;
        }
        return getPage();
    }

    public void setSpaceTitle(@Nullable String spaceTitle) {
        this.spaceTitle = spaceTitle;
    }

    @Nullable
    public String getSpaceTitle() {
        return spaceTitle;
    }

    @NotNull
    private String getSpaceTitleOrSpace() {
        String spaceTitleToReturn = com.polarion.core.util.StringUtils.getNullIfEmpty(getSpaceTitle());
        if (spaceTitleToReturn != null) {
            return spaceTitleToReturn;
        }
        String spaceToReturn = getSpace();
        return spaceToReturn != null ? spaceToReturn : "";
    }

}
