/*
 * $Id$
 *
 * Copyright (C) 2000-2005 Polarion Software
 * All rights reserved.
 * Email: dev@polarion.com
 *
 *
 * Copyright (C) 2000-2005 Polarion Software
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Polarion Software  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * Polarion Software MAKES NO REPRESENTATIONS OR WARRANTIES 
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESSED OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. Polarion Software
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT
 * OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES. *
 */
package com.polarion.webdav.servlet;

import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLDecoder;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.eclipse.webdav.http.client.HttpConnection;

import com.polarion.core.util.Base64;
import com.polarion.core.util.FileHelper;
import com.polarion.core.util.MIMEContentType;
import com.polarion.core.util.MIMEUtils;
import com.polarion.core.util.StreamUtils;
import com.polarion.platform.core.PlatformContext;
import com.polarion.platform.service.repository.IRepositoryService;
import com.polarion.subterra.base.location.Location;

/** 
 *
 * @author  <A HREF="mailto:dev@polarion.com">Jiri Wale</A>,Polarion Software
 */
public class DelegatingWebDavServlet extends HttpServlet {
    
    private static final long serialVersionUID = -680131731018790499L;

    private static final Logger log = Logger.getLogger(DelegatingWebDavServlet.class);
    
    private static final String SERVLET_PATH = "/polarion/webdav";

    private static final String HTTP_HEADER_ACCEPT_ENCODING = "Accept-Encoding";
    private static final String HTTP_HEADER_CONTENT_LENGTH = "Content-Length";
    private static final String HTTP_HEADER_CONTENT_TYPE = "Content-Type";
    private static final String HTTP_HEADER_HOST = "Host";
    
    private static final String MIME_TYPE_XML = "text/xml";
    private static final String DEFAULT_XML_CHARSET = "utf-8";

    public void init(ServletConfig config) throws ServletException {
        super.init(config);  
    }

    public void destroy() {
        // empty
    }

    private static final String BASIC_CREDENTIALS_ENCODING = "US-ASCII";
    
    private static final Set INTACT_METHODS = new HashSet();
    static {
        INTACT_METHODS.add("GET");
        INTACT_METHODS.add("HEAD");
        INTACT_METHODS.add("TRACE");
        // looks like POST has no meaning in WebDAV anyway
        INTACT_METHODS.add("POST");
    }

    protected void service(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {                
        
        IRepositoryService repositoryService = (IRepositoryService) PlatformContext.getPlatform().lookupService(IRepositoryService.class);
        URL documentURL = repositoryService.getAccessibleURLForLocation(Location.getLocation(IRepositoryService.DEFAULT, URLDecoder.decode(request.getPathInfo(),"UTF-8"), null)).toURL();
        
        if(log.isDebugEnabled()){
            log.debug("========= Request =================" );
            log.debug(documentURL);
            log.debug("original = " + request.getRequestURL());
            log.debug("method = " + request.getMethod());
            log.debug("query = " + request.getQueryString());
            log.debug("path info = " + request.getPathInfo());
        }
        
        String httpAuth = request.getHeader(HTTP_HEADER_AUTHORIZATION);
        if (httpAuth == null) {
            response.setStatus(401);
            String realm = "Repository " + repositoryService.getRepository(IRepositoryService.DEFAULT).getRepositoryUri().toString();
            response.setHeader("WWW-Authenticate", "Basic realm=\"" + realm + "\"");
            if (log.isDebugEnabled()) {
                log.debug("No authorization, failing with code 401 (realm set to " + realm + ")");
            }
            return;
        }
        // auth schemes other than Basic are simply forwarded to Subversion
        if (httpAuth.startsWith("Basic")) {
            int i = httpAuth.indexOf(' ');
            if (i > -1) {
                String credentials = httpAuth.substring(i).trim();
                byte[] data = Base64.decode(credentials);
                if (data != null) {
                    credentials = new String(data, BASIC_CREDENTIALS_ENCODING);
                    int j = credentials.indexOf(':');
                    if (j > -1) {
                        String user = credentials.substring(0, j);
                        String pass = credentials.substring(j + 1);
                        if (log.isDebugEnabled()) {
                            log.debug("Decoded Basic credentials: user=" + user + ", pass=" + pass);
                        }
                        int k;
                        if ((k = user.indexOf('@')) > -1) {
                            // username@domain
                            user = user.substring(0, k);
                        } else if ((k = user.indexOf('/')) > -1) {
                            // domain/username
                            user = user.substring(k + 1);
                        } else if ((k = user.indexOf('\\')) > -1) {
                            // domain\\username (there is only one slash, but Eclipse refused such comment)
                            user = user.substring(k + 1);
                        }
                        if (log.isDebugEnabled()) {
                            log.debug("Used username: " + user);
                        }
                        httpAuth = userNamePasswordBase64(user, pass);
                    }
                }
            }
        }
        
        HttpConnection httpConnection = new HttpConnection(documentURL); 
        httpConnection.setRequestMethod(request.getMethod());
        Enumeration headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String name = (String) headerNames.nextElement();
            // we are not able to filter encoded SVN responses
            // we leave the Host header setting on HttpConnection
            if (name.equalsIgnoreCase(HTTP_HEADER_ACCEPT_ENCODING)
                    || name.equalsIgnoreCase(HTTP_HEADER_HOST)) {
                if(log.isDebugEnabled()){
                    log.debug("Skiped parameter: "+name  + " = " + request.getHeader(name));
                }
                continue;
            }
            if (name.equalsIgnoreCase(HTTP_HEADER_AUTHORIZATION)) {
                // HttpConnection has case-sensitive headers so we must prevent multiple headers of same semantics
                // actual value will be set later
                continue;
            }
            httpConnection.setRequestHeaderField(name,request.getHeader(name));
            if(log.isDebugEnabled()){
                log.debug(name  + " = " + request.getHeader(name));
            }
        }    
    
        httpConnection.setRequestHeaderField(HTTP_HEADER_AUTHORIZATION, httpAuth);
        if(log.isDebugEnabled()){
            log.debug(HTTP_HEADER_AUTHORIZATION  + " = " + httpConnection.getRequestHeaderFieldValue(HTTP_HEADER_AUTHORIZATION));
        }        
        if(request.getContentLength()>0){
            OutputStream delegatedRequestStream = httpConnection.getOutputStream();
            FileHelper.copyStreams(request.getInputStream(), delegatedRequestStream);
            delegatedRequestStream.close();
        }        
        
        String delegatedContentTypeStr = httpConnection.getResponseHeaderFieldValue(HTTP_HEADER_CONTENT_TYPE);
        MIMEContentType delegatedContentType = null;
        boolean isXML = false;
        if (delegatedContentTypeStr != null) {
            delegatedContentType = MIMEUtils.getMIMEContentType(delegatedContentTypeStr);
            isXML = delegatedContentType.getFullMediaType().equals(MIME_TYPE_XML);
        }
        if (log.isDebugEnabled()) {
            log.debug("Delegated content type: " + delegatedContentType + " (is XML: " + isXML + ")");
        }
        if (!isXML || INTACT_METHODS.contains(request.getMethod())) {
            // for GET, HEAD, TRACE and POST always, for others if it is not text/xml
            // send response unchanged back to the caller
            if (log.isDebugEnabled()) {
                log.debug("----------- Unchanged response ----------------------------" );
            }
            // status
            int status = httpConnection.getStatusCode();
            response.setStatus(status);
            if (log.isDebugEnabled()) {
                log.debug("Status:" + status);
            }
            // headers
            int i = 0;
            while (true){
                String name = httpConnection.getResponseHeaderFieldName(i);            
                if (name == null){
                    break;
                }
                String value = httpConnection.getResponseHeaderFieldValue(i);
                // XXX proper Content-Type should be set by the one who put the file in SVN
                if (name.equals(HTTP_HEADER_CONTENT_TYPE)) {
                    if (documentURL.toString().endsWith(".xls")) {
                        value = "application/vnd.ms-excel";
                    } else if(documentURL.toString().endsWith(".doc")) {
                        value = "application/msword";
                    }                            
                }
                response.setHeader(name,value);
                if (log.isDebugEnabled()) {
                    log.debug(name + " = " + value);
                }
                i++;
            }
            // data
            try {
                OutputStream os = response.getOutputStream();
                FileHelper.copyStreams(httpConnection.getInputStream(), os);
                os.close();
            } finally {
                httpConnection.close();
            }
            return;
        }
        
        // from this point on we know it is XML
        String charset = delegatedContentType.getParameter(MIMEUtils.TYPE_PARAM_CHARSET);
        if (charset == null) {
            charset = DEFAULT_XML_CHARSET;
        }
        if (log.isDebugEnabled()) {
            log.debug("Delegated charset: " + charset);
        }
        
        if (log.isDebugEnabled()) {
            log.debug("----------- Response ----------------------------" );
        }
        
        int status = httpConnection.getStatusCode();
        response.setStatus(status);
        if (log.isDebugEnabled()) {
            log.debug("Status:" + status);
        }
        
        byte[] output = StreamUtils.suckStreamThenClose(httpConnection.getInputStream());        
        String outputStr = new String(output, charset);        
       
        outputStr = outputStr.replaceAll("<D:href>/[a-z]*/", "<D:href>" + SERVLET_PATH + "/");
        byte[] newOutput = outputStr.getBytes(charset);

        int i = 0;
        while(true){
            String name = httpConnection.getResponseHeaderFieldName(i);            
            if(name==null){
                break;
            }
            String value = httpConnection.getResponseHeaderFieldValue(i);
            if(name.equals(HTTP_HEADER_CONTENT_LENGTH) && output!=null){
                value = String.valueOf(newOutput.length);                
            }
            response.setHeader(name,value);
            if(log.isDebugEnabled()){
                log.debug(name  + " = " + value);
            }
            i++;
        }        
        if(log.isDebugEnabled()){
            log.debug(outputStr);
        }
        
        httpConnection.close();
        
        OutputStream outputStream = response.getOutputStream();
        outputStream.write(newOutput);
        outputStream.close();        
       
        
    }

    public String getServletInfo() {
        return "Polarion Delegating SVN WebDav servlet.";
    }
    
    public static final String HTTP_HEADER_AUTHORIZATION = "Authorization";
    
    private String userNamePasswordBase64(String username, String password) {
        try {
            return "Basic " + Base64.encodeBytes((username + ":" + password).getBytes(BASIC_CREDENTIALS_ENCODING));
        } catch (UnsupportedEncodingException e) {
            // should not happen
            throw new RuntimeException("INTERNAL ERROR", e);
        }
    }
    

}

/*
 * $Log$
 */