/**
 * BuilderWebServiceServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.polarion.alm.ws.client.builder;

public class BuilderWebServiceServiceLocator extends org.apache.axis.client.Service implements com.polarion.alm.ws.client.builder.BuilderWebServiceService {

/**
 * This service provides build related functionality.
 */

    public BuilderWebServiceServiceLocator() {
    }


    public BuilderWebServiceServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public BuilderWebServiceServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for BuilderWebService
    private java.lang.String BuilderWebService_address = "http://localhost:8888/polarion/ws/services/BuilderWebService";

    public java.lang.String getBuilderWebServiceAddress() {
        return BuilderWebService_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String BuilderWebServiceWSDDServiceName = "BuilderWebService";

    public java.lang.String getBuilderWebServiceWSDDServiceName() {
        return BuilderWebServiceWSDDServiceName;
    }

    public void setBuilderWebServiceWSDDServiceName(java.lang.String name) {
        BuilderWebServiceWSDDServiceName = name;
    }

    public com.polarion.alm.ws.client.builder.BuilderWebService getBuilderWebService() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(BuilderWebService_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getBuilderWebService(endpoint);
    }

    public com.polarion.alm.ws.client.builder.BuilderWebService getBuilderWebService(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.polarion.alm.ws.client.builder.BuilderWebServiceSoapBindingStub _stub = new com.polarion.alm.ws.client.builder.BuilderWebServiceSoapBindingStub(portAddress, this);
            _stub.setPortName(getBuilderWebServiceWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setBuilderWebServiceEndpointAddress(java.lang.String address) {
        BuilderWebService_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.polarion.alm.ws.client.builder.BuilderWebService.class.isAssignableFrom(serviceEndpointInterface)) {
                com.polarion.alm.ws.client.builder.BuilderWebServiceSoapBindingStub _stub = new com.polarion.alm.ws.client.builder.BuilderWebServiceSoapBindingStub(new java.net.URL(BuilderWebService_address), this);
                _stub.setPortName(getBuilderWebServiceWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("BuilderWebService".equals(inputPortName)) {
            return getBuilderWebService();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://ws.polarion.com/BuilderWebService", "BuilderWebServiceService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://ws.polarion.com/BuilderWebService", "BuilderWebService"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("BuilderWebService".equals(portName)) {
            setBuilderWebServiceEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
